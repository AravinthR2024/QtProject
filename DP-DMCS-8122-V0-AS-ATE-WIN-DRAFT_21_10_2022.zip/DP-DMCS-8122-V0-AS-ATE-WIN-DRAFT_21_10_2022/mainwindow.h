#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFile>
#include <QMessageBox>
#include <QDebug>
#include <QPixmap>
#include <QDateTime>
#include <QFile>
#include <QFileDialog>
#include <QStringListModel>

#include "macros.h"
#include "about.h"
#include "qcustomplot.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    CAbout *m_pAbout;

    void loadStyle();
    void initModStatusTable();

    char m_cSystemSelection;

    /* Graph functions */
    QString m_strLogFileName;
    int m_iSelectedTestCase;

    QCPItemLine *m_pTracerLine;
    QCPItemTracer *m_pTracer;
    QCPItemText *m_pTracerLabel;

    QCPItemTracer *m_pTracer2;
    QCPItemText *m_pTracerLabel2;

    QCPItemTracer *m_pTracer3;
    QCPItemText *m_pTracerLabel3;
    bool m_bPlot3Tracers;

    QVector<double> m_dvectCol1;
    QVector<double> m_dvectCol2;
    QVector<double> m_dvectCol3;
    QVector<double> m_dvectCol4;

    void initGraph();
    void loadTestcases();
    void configureGraph();
    void initTracer();
    void setGraphAppearance();
    bool readLogFileLines(QStringList *out_strLines);
    bool parseLogData (QStringList in_strLog, QVector<double> *out_dvectCol1, QVector<double> *out_dvectCol2, QVector<double> *out_dvectCol3, QVector<double> *out_dvectCol4);
    void getRange(QVector<double> in_dVector, double *out_pdLower, double *out_pdUpper);
    bool plotGraph(QVector<double> in_dvectCol1, QVector<double> in_dvectCol2, QVector<double> in_dvectCol3, QVector<double> in_dvectCol4);
    void saveGraph(QString in_qstrFilename);

private slots:
    void on_pbModDetProceed_clicked();

    void on_stackedWidget_currentChanged(int in_iPageIndex);

    void on_pbConfRS232Proceed_clicked();

    void on_action_Self_Test_triggered();

    void on_pbSelfTest_clicked();

    void on_actionConfigure_RS232_triggered();

    void on_pbFlash_Program_clicked();

    void on_pbFlash_Browse_clicked();

    void on_action_Flash_Program_triggered();

    void on_pbFlash_Verify_clicked();

    void on_actionConfigure_Control_Loop_Constant_triggered();

    void on_pbCLCConfig_ReadEEPROM_clicked();

    void on_pbCLCConfig_WriteEEPROM_clicked();

    void on_action_Encoder_Calibration_triggered();

    void on_cbEncoderAcutator_Azimuth_clicked();

    void on_cbEncoderAcutator_Elevation_clicked();

    void on_actionMotor_Control_triggered();

    void on_actionAbout_ATE_triggered();

    void on_action_System_Details_triggered();

    void on_action_PBIT_Status_triggered();

    void on_pbPBITProceed_clicked();

    void on_action_CBIT_Status_triggered();

    void on_action_Report_Monitoring_triggered();

    void on_pbEncoder_Read_clicked();

    void on_pbEncoder_StartCalibration_clicked();

    void on_pbSCM_Configure_clicked();

    void slot_graphSavepoint(QMouseEvent *in_pMevent);

    void slot_graphTracePoint(QMouseEvent *in_pMevent);

    bool initiateGraphPlot();

    void on_label_13_linkActivated(const QString &link);

    void on_label_16_linkActivated(const QString &link);

    void on_label_19_linkActivated(const QString &link);

    void on_label_18_linkActivated(const QString &link);

    void on_label_40_linkActivated(const QString &link);

    void on_pbApp_Home_clicked();

    void on_pbConfRS232_Verify_clicked();

    void on_actionInitialization_Module_triggered();

    void on_pbSelftest_FileBrowse_clicked();

    void on_rbInit_Sys_RGA_RTGA_toggled(bool checked);

    void on_rbInit_Sys_Seaspray_toggled(bool checked);

    void on_action_Communication_Status_triggered();

    void on_pbSerial_Configure_clicked();

    void on_lstviewDiag_TestCasesList_clicked(const QModelIndex &in_iTestCase);

    void on_pbDiag_Start_clicked();

    void on_pbDiag_TCCollapse_toggled(bool checked);

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
