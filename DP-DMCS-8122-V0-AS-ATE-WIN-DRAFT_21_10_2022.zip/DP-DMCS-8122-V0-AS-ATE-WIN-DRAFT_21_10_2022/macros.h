#ifndef MACROS
#define MACROS

#define WINDOW_TITLE        "DP-DMCS-8122 SCM ATE Application"
#define CHANGE_PAGE ui->stackedWidget->setCurrentIndex

#define QSS_FILE    ":/styles/styles/BlueTheme.txt"
#define MSG_STYLE   "QMainWindow, QDialog, QMenu {\
font :  bold 10pt \"MS Shell Dlg 2\";\
background-color: rgb(4, 67, 85);\
background-color: rgb(4, 95, 120);\
}\
QPushButton{\
background-color: qradialgradient(spread:pad, cx:0.499807, cy:0.489, radius:0.8, fx:0.499, fy:0.488909, stop:0.0795455 rgba(0, 147, 185, 255), stop:1 rgba(50, 50, 50, 255));\
border: 1px solid black;\
/*width : 80px;\
height : 30px;*/\
font :  bold 10pt \"MS Shell Dlg 2\";\
padding: 3px 7px;\
border-radius: 5px;\
color:white;\
}\
QPushButton:pressed{\
background-color: qradialgradient(spread:pad, cx:0.5, cy:0.5, radius:0.749, fx:0.5, fy:0.5, stop:0 rgba(18, 37, 41, 255), stop:0.511364 rgba(39, 80, 90, 255), stop:1 rgba(9, 140, 174, 255));\
border: 2px solid black;\
border-color : rgb(9, 158, 195);\
/*width : 80px;\
height : 30px;*/\
font :  bold 10pt \"MS Shell Dlg 2\";\
padding: 3px 7px;\
border-radius: 5px;\
color:white;\
}\
QPushButton:hover:!pressed {\
background-color: qradialgradient(spread:pad, cx:0.499807, cy:0.489, radius:0.8, fx:0.499, fy:0.488909, stop:0.0795455 rgba(0, 150, 190, 255), stop:1 rgba(50, 50, 100, 255));\
border: 1px solid black;\
/*width : 80px;\
height : 30px;*/\
font :  bold 10pt \"MS Shell Dlg 2\";\
padding: 3px 7px;\
border-radius: 5px;\
color:white;\
}"
#define DISPLAY_MESSAGE_BOX(obj, title, msg)    {\
    QMessageBox msgbox(obj);\
    msgbox.setWindowTitle(title);\
    msgbox.setText(msg);\
    msgbox.layout()->setSizeConstraint(QLayout::SetFixedSize);\
    msgbox.setStyleSheet(MSG_STYLE);\
    msgbox.exec();\
}

#define APPEND_ACTION_LOG(message, color) {\
    QString qstrTime = QDateTime::currentDateTime().toString("dd/MM/yyyy HH:mm:ss");\
    ui->teActionLog->append(QString("%1   - <span style=\"color: %3; font-weight: bold;\">%2</span>").arg(qstrTime).arg(message).arg(color));\
}
#define LOG_INFO        "black"
#define LOG_ERROR       "red"
#define LOG_SUCCESS     "green"
#define LOG_WARNING     "yellow"

enum SYSTEM_SELECTION
{
    SYS_RGA_RTGA = 0,
    SYS_SEASPRAY
};

enum PAGE_INDEX
{
    PAGE_INVALID = -1,
    PAGE_INIT,
    PAGE_CONFIG_RS232,
    PAGE_PBIT,
    PAGE_SELF_TEST,
    PAGE_FLASH_PROGRAMMING,
    PAGE_CONFIG_CTRL_LOOP_CONST,
    PAGE_ENCODER_CALIBRATION,
    PAGE_SCM_OPERATION,
    PAGE_CBIT,
    PAGE_RESPONSE_MONITORING,
    PAGE_SYSTEM_DETAILS,
    PAGE_SERIAL_COMM_CONFIGURATION
};

/************************** TEST CASES **************************/
enum TEST_CASES
{
    TC_GIMBAL_ZERO_POS_CALIB = 0,
    TC_ENCODER_CALIB,
    TC_POS_MODE_PERFORMANCE,
    TC_POS_MODE_BIDIR_SCAN,
    TC_RATE_MODE_PERFORMANCE,
    TC_RATE_MODE_ALT_SCAN,
    TC_OPEN_LOOP_BW_TEST,
    TC_CLOSED_LOOP_BW_TEST
};

/*************** GRAPH *********************/
#define _QSS_        /** define _QSS_ for Dark Mode, undef for Light Mode */

enum GRAPH_SELECTION
{
    GRAPH_FREQ_GAIN_PHASE,
    GRAPH_POS_MODE_BIDIR_SCAN_DEM,
    GRAPH_RATE_MODE_ALT_SCAN_RES
};

#ifdef _QSS_    /* APPEARANCE FOR DARK MODE */

#define GRAPH_BACKGROUND_COLOR          QColor(0x00, 0x00, 0x00)        /* BLACK */
#define LEGEND_TEXT_COLOR               QColor(0xFF, 0xFF, 0xFF)        /* WHITE */
#define GRID_COLOR                      QColor(0xA0, 0xA0, 0xA4)        /* GRAY */
#define XAXIS_BASE_TICK_COLOR           QColor(0xFF, 0xFF, 0xFF)        /* WHITE */
#define YAXIS2_BASE_TICK_COLOR          QColor(0x00, 0xFF, 0xFF)        /* CYAN */
#define TRACER2_COLOR                   QColor(0x00, 0x80, 0x80)        /* DARK CYAN */

#else           /* APPEARANCE FOR LIGHT MODE */

#define GRAPH_BACKGROUND_COLOR          QColor(0xFF, 0xFF, 0xFF)        /* WHITE */
#define LEGEND_TEXT_COLOR               QColor(0x00, 0x00, 0x00)        /* BLACK */
#define GRID_COLOR                      QColor(0x00, 0x00, 0x00)        /* BLACK */
#define XAXIS_BASE_TICK_COLOR           QColor(0x00, 0x00, 0x00)        /* BLACK */
#define YAXIS2_BASE_TICK_COLOR          QColor(0x00, 0x00, 0xFF)        /* BLUE */
#define TRACER2_COLOR                   QColor(0x00, 0x00, 0x80)        /* DARK BLUE */

#endif

/* APPEARANCE WITH NO CHANGE FOR DARK OR LIGHT MODE */
#define SUBGRID_COLOR                   QColor(0x80, 0x80, 0x80)        /* DARK GRAY */

#define YAXIS_BASE_TICK_COLOR           QColor(0xFF, 0x00, 0x00)        /* RED */

#define LEGEND_COLOR                    GRAPH_BACKGROUND_COLOR
#define LEGEND_BORDER_COLOR             QColor(0xC0, 0xC0, 0xC0)        /* LIGHT GRAY */

#define LABEL_FONT                      QFont("Arial", 13)

#define TRACER_STYLE                    QCPItemTracer::tsCircle
#define TRACER_SIZE                     10.0
#define TRACER_LINE_COLOR               QColor(0x80, 0x80, 0x00)        /* DARK YELLOW */

#define TRACER1_COLOR                   QColor(0x80, 0x00, 0x00)        /* DARK RED */
#define TRACER1_LABEL_POSITION          Qt::AlignLeft | Qt::AlignRight

#define TRACER2_LABEL_POSITION          Qt::AlignRight | Qt::AlignBottom

#define TRACER3_COLOR                   QColor(0x02, 0xFF, 0x02)        /* GREEN */
#define TRACER3_LABEL_POSITION          Qt::AlignRight | Qt::AlignTop

#define MOUSE_TRACER_LABEL_COLOR        LEGEND_TEXT_COLOR
#define MOUSE_TRACER_COLOR              QColor(0x00, 0x80, 0x80)        /* DARK CYAN */
#define MOUSE_TRACER2_COLOR             QColor(0x80, 0x00, 0x80)        /* DARK MAGENTA */
#define MOUSE_TRACER3_COLOR             QColor(0x00, 0x80, 0x00)        /* DARK GREEN */

#define ENABLE_BODE_GRAPH(graph) {\
    QSharedPointer<QCPAxisTickerLog> ticker(new QCPAxisTickerLog);\
    graph->xAxis->setTicker(ticker);\
    qDebug() << "THIS IS PRINTING";\
    graph->xAxis->setScaleType(QCPAxis::stLogarithmic);\
    graph->yAxis->ticker().data()->setTickCount(10);\
    graph->yAxis2->ticker().data()->setTickCount(10);\
}

#define SET_TRACING_STATE(state) {\
    m_pTracer->setVisible(state);\
    m_pTracer2->setVisible(state);\
    m_pTracer3->setVisible(state);\
    m_pTracerLine->setVisible(state);\
    m_pTracerLabel->setVisible(state);\
    m_pTracerLabel2->setVisible(state);\
    m_pTracerLabel3->setVisible(state);\
    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);\
}


#endif // MACROS
