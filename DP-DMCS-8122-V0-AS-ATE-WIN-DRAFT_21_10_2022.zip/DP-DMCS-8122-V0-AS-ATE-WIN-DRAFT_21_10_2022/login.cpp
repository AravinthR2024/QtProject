#include "login.h"
#include "ui_login.h"

CLogin::CLogin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CLogin)
{
    ui->setupUi(this);

    loadStyle();

    m_bIsAuthorized = false;

    setWindowTitle("Login");
    setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);

    ui->leUsername->setReadOnly(true);
    ui->leUsername->setText(USERNAME);
    ui->lePassword->setFocus();

    ui->pbLogin->setEnabled(false);
}

CLogin::~CLogin()
{
    delete ui;
}

void CLogin::loadStyle()
{
    QFile qFile(QSS_FILE);

    if (!qFile.open(QIODevice::ReadOnly))
    {
        qDebug() << "Styles not applied : " << qFile.errorString();
        return;
    }

    this->setStyleSheet(qFile.readAll().data());
    qFile.close();
}

void CLogin::closeEvent(QEvent *in_pEvt)
{
    if (!m_bIsAuthorized)
    {
        DISPLAY_MESSAGE_BOX(this, "Login", "Closing the application...");
    }
    in_pEvt->accept();
}

void CLogin::on_pbLogin_clicked()
{
    QString qstrUsername = ui->leUsername->text();
    QString qstrPassword = ui->lePassword->text();

#if 0
    if (qstrUsername.isEmpty())
    {
        DISPLAY_MESSAGE_BOX(this, "Login", "Enter Username!");
        return;
    }
#endif

    if (qstrPassword.isEmpty())
    {
        DISPLAY_MESSAGE_BOX(this, "Login", "Enter Password!");
        return;
    }

    if (QString::compare(qstrPassword, PASSWORD) != 0)
    {
        DISPLAY_MESSAGE_BOX(this, "Login", "Wrong Password!");
        ui->lePassword->setFocus();
        ui->lePassword->selectAll();
        return;
    }

    m_bIsAuthorized = true;
    this->close();
}

void CLogin::on_pbCancel_clicked()
{
    this->close();
}

#if 0
void CLogin::on_leUsername_textEdited(const QString &in_qstrUsername)
{
    if (in_qstrUsername.isEmpty())
    {
        ui->pbLogin->setEnabled(false);
    }
    else
    {
        ui->pbLogin->setEnabled(true);
    }
}
#endif

void CLogin::on_lePassword_textEdited(const QString &in_qstrUsername)
{
    if (in_qstrUsername.isEmpty())
    {
        ui->pbLogin->setEnabled(false);
    }
    else
    {
        ui->pbLogin->setEnabled(true);
    }
}

#if 0
void CLogin::on_leUsername_returnPressed()
{
    on_pbLogin_clicked();
}

void CLogin::on_lePassword_returnPressed()
{
    on_pbLogin_clicked();
}
#endif
