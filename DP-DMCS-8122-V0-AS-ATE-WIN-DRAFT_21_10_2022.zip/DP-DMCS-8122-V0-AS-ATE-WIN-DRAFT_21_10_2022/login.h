#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include <QFile>
#include <QDebug>
#include <QMessageBox>

#include "macros.h"

#define USERNAME    "administrator"
#define PASSWORD    "admin"

namespace Ui {
class CLogin;
}

class CLogin : public QDialog
{
    Q_OBJECT

public:
    explicit CLogin(QWidget *parent = 0);
    ~CLogin();

    bool m_bIsAuthorized;

    void loadStyle();

    void closeEvent(QEvent *in_pEvt);

private slots:
    void on_pbLogin_clicked();

    void on_pbCancel_clicked();

#if 0
    void on_leUsername_textEdited(const QString &in_qstrUsername);

    void on_leUsername_returnPressed();

    void on_lePassword_returnPressed();
#endif

    void on_lePassword_textEdited(const QString &in_qstrUsername);


private:
    Ui::CLogin *ui;
};

#endif // LOGIN_H
