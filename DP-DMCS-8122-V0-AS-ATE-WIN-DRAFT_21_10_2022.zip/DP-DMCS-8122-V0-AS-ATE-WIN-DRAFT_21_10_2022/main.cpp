#include "mainwindow.h"
#include "login.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    CLogin *pLogin = new CLogin;

    pLogin->exec();

    if (!pLogin->m_bIsAuthorized)
    {
        qDebug("Application opening cancelled");
        return 0;
    }

    w.showMaximized();

    return a.exec();
}
