#include "mainwindow.h"
#include "ui_mainwindow.h"

PAGE_INDEX g_previousPage = PAGE_INVALID;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    loadStyle();
    loadTestcases();
    initModStatusTable();

    m_bPlot3Tracers = false;

    ui->pbDiag_TCCollapse->setCursor(Qt::PointingHandCursor);

    // To be modified later to Gimbal zero position test
    m_iSelectedTestCase = TC_OPEN_LOOP_BW_TEST;

    initGraph();

    setWindowTitle(WINDOW_TITLE);

    m_cSystemSelection = -1;

    m_pAbout = new CAbout(this);

    connect(ui->widgetGraph, SIGNAL(mouseDoubleClick(QMouseEvent*)), this, SLOT(slot_graphSavepoint(QMouseEvent*)));
    connect(ui->widgetGraph, SIGNAL(mouseMove(QMouseEvent*)), this, SLOT(slot_graphTracePoint(QMouseEvent*)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::loadStyle()
{
    QFile qFile(QSS_FILE);

    if (!qFile.open(QIODevice::ReadOnly))
    {
        qDebug() << "Styles not applied : " << qFile.errorString();
        return;
    }

    this->setStyleSheet(qFile.readAll().data());
    qFile.close();
}

void MainWindow::initGraph()
{
    bool bIsBodeGraph  = (m_iSelectedTestCase == TC_OPEN_LOOP_BW_TEST);
    bool bIs3AxisGraph = (m_iSelectedTestCase != TC_RATE_MODE_ALT_SCAN);

    /* Clear all graphs, tracers, tracer lines and tracer labels, if any */
    if (ui->widgetGraph->graphCount() > 0)
    {
        ui->widgetGraph->clearItems();
        ui->widgetGraph->clearGraphs();
    }

#if 0
    QCPItemText *tempItemTemp = NULL;
    while(vectItemText.size())
    {
        tempItemTemp = vectItemText.at(0);
        if(ui->widgetGraph->hasItem(tempItemTemp))
        {
            ui->widgetGraph->removeItem(tempItemTemp);
        }
        vectItemText.pop_front();
    }
#endif

    /* Set user-interactions allowed in the graph plot -> Drag Range, Zoom Range */
    ui->widgetGraph->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);

    /* Show Legend, X-Axis, Y-Axis, Y2-Axis and Hide X2-Axis */
    ui->widgetGraph->legend->setVisible(true);
    ui->widgetGraph->xAxis->setVisible(true);
    ui->widgetGraph->yAxis->setVisible(true);
    ui->widgetGraph->xAxis2->setVisible(false);
    /* Don't show Y2-Axis for Rate Mode Alternating Scan Response Graph */
    ui->widgetGraph->yAxis2->setVisible(bIs3AxisGraph);

    /* Only show subgrids for X-Axis */
    ui->widgetGraph->xAxis->grid()->setSubGridVisible(bIsBodeGraph);

    /* Initializing tracers */
    qDebug() << "3 axis : " << !bIs3AxisGraph;
    initTracer();

    /* Change graph styling */
    setGraphAppearance();

#if 0
    /** Enabling Bode Graph */
    if (bIsBodeGraph)
    {
        ENABLE_BODE_GRAPH(ui->widgetGraph);
    }
#endif

    /* Setting Graph Type - Bode or Normal Graph */
    configureGraph();

#if 0
    ui->widgetGraph->xAxis->setLabel("Time (s)");
    ui->widgetGraph->yAxis->setLabel("Demand Angle (deg)");
    ui->widgetGraph->yAxis2->setLabel("Rate (deg/s)");
    ui->widgetGraph->yAxis2->setVisible(true);
    ui->widgetGraph->yAxis->setRange(-100, 100);
    ui->widgetGraph->yAxis2->setRange(-59, 61);
    ui->widgetGraph->xAxis->setRange(0, 15);

    ui->widgetGraph->xAxis->ticker().data()->setTickStepStrategy(QCPAxisTicker::tssMeetTickCount);
    ui->widgetGraph->xAxis->ticker().data()->setTickCount(4);
    ui->widgetGraph->yAxis->ticker().data()->setTickCount(4);
    ui->widgetGraph->yAxis2->ticker().data()->setTickCount(4);
#endif

    /* Make sure to replot to reflect the changes */
    ui->widgetGraph->replot();
}

void MainWindow::loadTestcases()
{
    QStringListModel *pModel = new QStringListModel(this);
    QStringList qstrlstTestCases;
    qstrlstTestCases << "Gimbal Zero Position Calibration" << "Encoder Calibration" \
                     << "Position Mode Performance" << "Position Mode Bidirectional Test"\
                     << "Continuous Rate Mode Performance" << "Rate Mode Alternating Scan Test"\
                     << "Open Loop Bandwidth Test" << "Closed Loop Bandwidth Test";
    pModel->setStringList(qstrlstTestCases);
    ui->lstviewDiag_TestCasesList->setModel(pModel);

    ui->lstviewDiag_TestCasesList->setDragDropMode(QAbstractItemView::NoDragDrop);
    ui->lstviewDiag_TestCasesList->viewport()->setAcceptDrops(false);
}

void MainWindow::configureGraph()
{
    QString qstrGraphXName = QString();
    QString qstrGraphYName = QString();
    QString qstrGraphY2Name = QString();

    switch (m_iSelectedTestCase)
    {
    case TC_GIMBAL_ZERO_POS_CALIB:
    {
        QSharedPointer<QCPAxisTickerFixed> ticker(new QCPAxisTickerFixed);
        ui->widgetGraph->xAxis->setTicker(ticker);
        ui->widgetGraph->xAxis->ticker().data()->setTickStepStrategy(QCPAxisTicker::tssMeetTickCount);
        ui->widgetGraph->xAxis->setScaleType(QCPAxis::stLinear);
        ui->widgetGraph->xAxis->ticker().data()->setTickCount(4);
        ui->widgetGraph->yAxis->ticker().data()->setTickCount(4);
        ui->widgetGraph->yAxis2->ticker().data()->setTickCount(4);

        m_bPlot3Tracers = false;

        qstrGraphXName = "TBD";
        qstrGraphYName = "TBD";
        qstrGraphY2Name = "TBD";

        break;
    }
    case TC_ENCODER_CALIB:
    {
        QSharedPointer<QCPAxisTickerFixed> ticker(new QCPAxisTickerFixed);
        ui->widgetGraph->xAxis->setTicker(ticker);
        ui->widgetGraph->xAxis->ticker().data()->setTickStepStrategy(QCPAxisTicker::tssMeetTickCount);
        ui->widgetGraph->xAxis->setScaleType(QCPAxis::stLinear);
        ui->widgetGraph->xAxis->ticker().data()->setTickCount(4);
        ui->widgetGraph->yAxis->ticker().data()->setTickCount(4);
        ui->widgetGraph->yAxis2->ticker().data()->setTickCount(4);

        m_bPlot3Tracers = false;

        qstrGraphXName = "TBD";
        qstrGraphYName = "TBD";
        qstrGraphY2Name = "TBD";

        break;
    }
    case TC_POS_MODE_PERFORMANCE:
    {
        QSharedPointer<QCPAxisTickerFixed> ticker(new QCPAxisTickerFixed);
        ui->widgetGraph->xAxis->setTicker(ticker);
        ui->widgetGraph->xAxis->ticker().data()->setTickStepStrategy(QCPAxisTicker::tssMeetTickCount);
        ui->widgetGraph->xAxis->setScaleType(QCPAxis::stLinear);
        ui->widgetGraph->xAxis->ticker().data()->setTickCount(4);
        ui->widgetGraph->yAxis->ticker().data()->setTickCount(4);
        ui->widgetGraph->yAxis2->ticker().data()->setTickCount(4);

        m_bPlot3Tracers = false;

        qstrGraphXName = "TBD";
        qstrGraphYName = "TBD";
        qstrGraphY2Name = "TBD";

        break;
    }
    case TC_POS_MODE_BIDIR_SCAN:
    {
        ui->widgetGraph->xAxis->ticker().data()->setTickStepStrategy(QCPAxisTicker::tssMeetTickCount);
        ui->widgetGraph->xAxis->setScaleType(QCPAxis::stLinear);
        ui->widgetGraph->xAxis->ticker().data()->setTickCount(4);
        ui->widgetGraph->yAxis->ticker().data()->setTickCount(4);
        ui->widgetGraph->yAxis2->ticker().data()->setTickCount(4);

        m_bPlot3Tracers = false;

        qstrGraphXName = "Time (s)";
        qstrGraphYName = "Demanded Angle (deg)";
        qstrGraphY2Name = "Rate (deg)";

        break;
    }
    case TC_RATE_MODE_PERFORMANCE:
    {
        QSharedPointer<QCPAxisTickerFixed> ticker(new QCPAxisTickerFixed);
        ui->widgetGraph->xAxis->setTicker(ticker);
        ui->widgetGraph->xAxis->ticker().data()->setTickStepStrategy(QCPAxisTicker::tssMeetTickCount);
        ui->widgetGraph->xAxis->setScaleType(QCPAxis::stLinear);
        ui->widgetGraph->xAxis->ticker().data()->setTickCount(4);
        ui->widgetGraph->yAxis->ticker().data()->setTickCount(4);
        ui->widgetGraph->yAxis2->ticker().data()->setTickCount(4);

        m_bPlot3Tracers = false;

        qstrGraphXName = "TBD";
        qstrGraphYName = "TBD";
        qstrGraphY2Name = "TBD";

        break;
    }
    case TC_RATE_MODE_ALT_SCAN:
    {
        ui->widgetGraph->xAxis->ticker().data()->setTickStepStrategy(QCPAxisTicker::tssMeetTickCount);
        ui->widgetGraph->xAxis->setScaleType(QCPAxis::stLinear);
        ui->widgetGraph->xAxis->ticker().data()->setTickCount(10);
        ui->widgetGraph->yAxis->ticker().data()->setTickCount(6);

        m_bPlot3Tracers = true;

        qstrGraphXName = "Time (s)";
        qstrGraphYName = "Angle (deg)";

        break;
    }
    case TC_OPEN_LOOP_BW_TEST:
    {
        QSharedPointer<QCPAxisTickerLog> ticker(new QCPAxisTickerLog);
        ui->widgetGraph->xAxis->setTicker(ticker);
        ui->widgetGraph->xAxis->setScaleType(QCPAxis::stLogarithmic);
        ui->widgetGraph->yAxis->ticker().data()->setTickCount(10);
        ui->widgetGraph->yAxis2->ticker().data()->setTickCount(10);

        m_bPlot3Tracers = false;

        qstrGraphXName = "Frequency (Hz)";
        qstrGraphYName = "Gain (dB)";
        qstrGraphY2Name = "Phase (deg)";

        break;
    }
    case TC_CLOSED_LOOP_BW_TEST:
    {
        QSharedPointer<QCPAxisTickerFixed> ticker(new QCPAxisTickerFixed);
        ui->widgetGraph->xAxis->setTicker(ticker);
        ui->widgetGraph->xAxis->ticker().data()->setTickStepStrategy(QCPAxisTicker::tssMeetTickCount);
        ui->widgetGraph->xAxis->setScaleType(QCPAxis::stLinear);
        ui->widgetGraph->xAxis->ticker().data()->setTickCount(4);
        ui->widgetGraph->yAxis->ticker().data()->setTickCount(4);
        ui->widgetGraph->yAxis2->ticker().data()->setTickCount(4);

        m_bPlot3Tracers = false;

        qstrGraphXName = "TBD";
        qstrGraphYName = "TBD";
        qstrGraphY2Name = "TBD";

        break;
    }
    default: break;
    }

    /* Setting label for X, Y and Y2 Axes */
    ui->widgetGraph->xAxis->setLabel(qstrGraphXName);
    ui->widgetGraph->yAxis->setLabel(qstrGraphYName);
    if ((m_iSelectedTestCase != GRAPH_RATE_MODE_ALT_SCAN_RES))
    {
        ui->widgetGraph->yAxis2->setLabel(qstrGraphY2Name);
    }
}

void MainWindow::initTracer()
{
    /* Create a tracer(cursor) for 1st graph */
    m_pTracer = new QCPItemTracer(ui->widgetGraph);

#if 0
    m_pTracer->position->setType(QCPItemPosition::ptViewportRatio);
#endif

    /* Create tracer label (text on tracer) */
    m_pTracerLabel = new QCPItemText(ui->widgetGraph);
    m_pTracerLabel->setLayer("overlay");

    /* Make the tracer label change position with respect to the tracer */
    m_pTracerLabel->position->setParentAnchor(m_pTracer->position);
    m_pTracerLabel->position->setCoords(0,0);

    /* Create tracer line */
    m_pTracerLine = new QCPItemLine(ui->widgetGraph);
    m_pTracerLine->start->setCoords(0, 0);
    m_pTracerLine->end->setCoords(0, 0);

    /* Creating tracer, tracer label for 2nd graph */
    m_pTracer2 = new QCPItemTracer(ui->widgetGraph);
    m_pTracer2->position->setType(QCPItemPosition::ptViewportRatio);
    m_pTracerLabel2 = new QCPItemText(ui->widgetGraph);
    m_pTracerLabel2->setLayer("overlay");
    m_pTracerLabel2->position->setParentAnchor(m_pTracer2->position);
    m_pTracerLabel2->position->setCoords(0, 0);

    /* Change 1st tracer style */
    m_pTracer->setPen(QPen(TRACER1_COLOR));
    m_pTracer->setBrush(QBrush(TRACER1_COLOR));
    m_pTracer->setStyle(TRACER_STYLE);
    m_pTracer->setSize(TRACER_SIZE);

    /* Change 1st tracer label style */
    m_pTracerLabel->setPen(QPen(TRACER1_COLOR));
    m_pTracerLabel->setPositionAlignment(TRACER1_LABEL_POSITION);

    /* Change 2nd tracer style */
    m_pTracer2->setPen(QPen(TRACER2_COLOR));
    m_pTracer2->setBrush(QBrush(TRACER2_COLOR));
    m_pTracer2->setStyle(TRACER_STYLE);
    m_pTracer2->setSize(TRACER_SIZE);

    /* Change 2nd tracer label style */
    m_pTracerLabel2->setPen(QPen(TRACER2_COLOR));
    m_pTracerLabel2->setPositionAlignment(TRACER2_LABEL_POSITION);

    if (m_bPlot3Tracers)
    {
        /* Creating tracer, tracer label for 3rd graph */
        m_pTracer3 = new QCPItemTracer(ui->widgetGraph);
        m_pTracer3->position->setType(QCPItemPosition::ptViewportRatio);
        m_pTracerLabel3 = new QCPItemText(ui->widgetGraph);
        m_pTracerLabel3->setLayer("overlay");
        m_pTracerLabel3->position->setParentAnchor(m_pTracer2->position);
        m_pTracerLabel3->position->setCoords(0, 0);

        /* Change 3rd tracer style */
        m_pTracer3->setPen(QPen(TRACER3_COLOR));
        m_pTracer3->setBrush(QBrush(TRACER3_COLOR));
        m_pTracer3->setStyle(TRACER_STYLE);
        m_pTracer3->setSize(TRACER_SIZE);

        /* Change 3rd tracer label style */
        m_pTracerLabel3->setPen(QPen(TRACER3_COLOR));
        m_pTracerLabel3->setPositionAlignment(TRACER3_LABEL_POSITION);
    }

    /* Change tracer line style */
    m_pTracerLine->setPen(QPen(TRACER_LINE_COLOR));

    /* Hide tracer, tracer label, tracer line initially */
    m_pTracerLine->setVisible(false);
    m_pTracerLabel->setVisible(false);
    m_pTracer->setVisible(false);
    m_pTracer2->setVisible(false);
    m_pTracerLabel2->setVisible(false);
    if (m_bPlot3Tracers)
    {
        m_pTracer3->setVisible(false);
        m_pTracerLabel3->setVisible(false);
    }
}

void MainWindow::setGraphAppearance()
{
    /* Create a Dash lined pen */
    QPen pen(Qt::DashLine);
    pen.setColor(GRID_COLOR);

    /* Set pen style for all axes */
    ui->widgetGraph->xAxis->grid()->setPen(pen);
    ui->widgetGraph->yAxis->grid()->setPen(pen);
    ui->widgetGraph->yAxis2->grid()->setPen(pen);

    /* Change X-axis subgrid style */
    pen.setColor(SUBGRID_COLOR);
    ui->widgetGraph->xAxis->grid()->setSubGridPen(pen);

    /* Set Graph Background */
    ui->widgetGraph->setBackground(QBrush(GRAPH_BACKGROUND_COLOR));

    /* Change legend style */
    ui->widgetGraph->legend->setBrush(QBrush(LEGEND_COLOR));
    ui->widgetGraph->legend->setTextColor(LEGEND_TEXT_COLOR);
    ui->widgetGraph->legend->setBorderPen(QPen(LEGEND_BORDER_COLOR));

    /* Change Base color for all axes */
    ui->widgetGraph->xAxis->setBasePen(QPen(XAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis->setBasePen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis2->setBasePen(QPen(YAXIS2_BASE_TICK_COLOR));

    /* Change tick style for all axes */
    ui->widgetGraph->xAxis->setTickPen(QPen(XAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis->setTickPen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis2->setTickPen(QPen(YAXIS2_BASE_TICK_COLOR));

    /* Change subtick style for all axes */
    ui->widgetGraph->xAxis->setSubTickPen(QPen(XAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis->setSubTickPen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis2->setSubTickPen(QPen(YAXIS2_BASE_TICK_COLOR));

    /* Change label color, font for all axes */
    ui->widgetGraph->xAxis->setLabelColor(XAXIS_BASE_TICK_COLOR);
    ui->widgetGraph->yAxis->setLabelColor(YAXIS_BASE_TICK_COLOR);
    ui->widgetGraph->yAxis2->setLabelColor(YAXIS2_BASE_TICK_COLOR);
    ui->widgetGraph->xAxis->setLabelFont(LABEL_FONT);
    ui->widgetGraph->yAxis->setLabelFont(LABEL_FONT);
    ui->widgetGraph->yAxis2->setLabelFont(LABEL_FONT);

    /* Change tick label color for all axes */
    ui->widgetGraph->xAxis->setTickLabelColor(LEGEND_TEXT_COLOR);
    ui->widgetGraph->yAxis->setTickLabelColor(LEGEND_TEXT_COLOR);
    ui->widgetGraph->yAxis2->setTickLabelColor(LEGEND_TEXT_COLOR);
}

/* Generic for all test cases */
bool MainWindow::readLogFileLines(QStringList *out_strLines)
{
    QFile fpLogfile;
    QTextStream stream;

    /* Return false if no file name is set */
    if (m_strLogFileName.isEmpty())
    {
        qDebug("No log file selected");
        return false;
    }

    fpLogfile.setFileName(m_strLogFileName);
    /* Return false if file not opened */
    if (!fpLogfile.open(QIODevice::ReadOnly))
    {
        qDebug() << "File open error : " << fpLogfile.errorString();
        return false;
    }

    /* Set stream device as QFile pointer */
    stream.setDevice(&fpLogfile);

    /* Iterate through all the lines in the file */
    while (!stream.atEnd())
    {
        /* Append every line as a QString into out_strLines QStringList */
        out_strLines->append(stream.readLine());
    }

    /* Make sure to close the log file */
    fpLogfile.close();

    return true;
}

/* Generic for all test cases */
bool MainWindow::parseLogData(QStringList in_strLog, QVector<double> *out_dvectCol1, \
                                QVector<double> *out_dvectCol2, QVector<double> *out_dvectCol3, \
                              QVector<double> *out_dvectCol4)
{
    bool bOk        = false;
    double dTemp    = 0.0;
    int iCount      = 0;
    QStringList strTempList = QStringList();

    /* Clear the output vectors, incase if any */
    out_dvectCol1->clear();
    out_dvectCol2->clear();
    out_dvectCol3->clear();
    out_dvectCol4->clear();

    /* Return false if list of lines is empty */
    if (in_strLog.isEmpty())
    {
        qDebug() << "Log data lines are empty";
        return false;
    }

    /* Iterate through all lines in the list */
    foreach (QString strLine, in_strLog)
    {
        iCount = 0;
        /* Trim (to clear trailing spaces) and split with ',' */
        strTempList = strLine.trimmed().split(",");

        /* Iterate the splitted list */
        foreach (QString strTemp, strTempList)
        {
            /* Typecast first data to double, if cannot typecast, then return false */
            dTemp = strTemp.toDouble(&bOk);
            if (!bOk)
            {
                qDebug() << "Cannot parse data to double : " << strTemp;
                return false;
            }

            switch (iCount)
            {
            case 0: /* If 1st cycle, then append data to 1st vector */
            {
                out_dvectCol1->append(dTemp);
                break;
            }
            case 1: /* If 2nd cycle, then append data to 2nd vector */
            {
                out_dvectCol2->append(dTemp);
                break;
            }
            case 2: /* If 3rd cycle, then append data to 3rd vector */
            {
                out_dvectCol3->append(dTemp);
                break;
            }
            case 3: /* If 4th cycle, then append data to 4th Vector (only for 3 Graph plots) */
            {
                out_dvectCol4->append(dTemp);
                break;
            }
            default: break;
            }
            iCount++;   /* Increment iCount to go to next cycle */
        }
    }

    return true;
}

void MainWindow::getRange(QVector<double> in_dVector, double *out_pdLower, double *out_pdUpper)
{
    double dTemp = 0.0;

    *out_pdUpper = INT_MIN; /* Set upper limit to be minimum value initially */
    *out_pdLower = INT_MAX; /* Set lower limit to be maximum value initially */

    /* Create a QVectorIterator to iterate input vector */
    QVectorIterator<double> iter(in_dVector);

    /* Iterate all the elements of vector */
    while (iter.hasNext())
    {
        dTemp = iter.next();

        /* If element is greater than upper limit, then the element is new upper limit */
        if (dTemp > *out_pdUpper)
        {
            *out_pdUpper = dTemp;
        }

        /* If element is lesser than lower limit, then the element is new lower limit */
        if (dTemp < *out_pdLower)
        {
            *out_pdLower = dTemp;
        }
    }
}

bool MainWindow::plotGraph(QVector<double> in_dvectCol1, QVector<double> in_dvectCol2, \
                           QVector<double> in_dvectCol3, QVector<double> in_dvectCol4)
{
    double dLowerLimit = 0.0;
    double dUpperLimit = 0.0;

    /* If any of the input is empty, return false */
    if (in_dvectCol1.isEmpty() || in_dvectCol2.isEmpty() || in_dvectCol3.isEmpty())
    {
        qDebug() << "Input vector is empty";
        return false;
    }

    if (m_bPlot3Tracers)
    {
        if (in_dvectCol4.isEmpty())
        {
            qDebug() << "Input vector 4 is empty";
            return false;
        }
    }

    /* If all inputs does not have same number of data, return false */
    if ((in_dvectCol1.length() != in_dvectCol2.length()) \
            || (in_dvectCol2.length() != in_dvectCol3.length()) \
            || (in_dvectCol3.length() != in_dvectCol1.length()))
    {
        qDebug() << "Vector length doesnot matched";
        return false;
    }

    if (m_bPlot3Tracers)
    {
        if (in_dvectCol1.length() != in_dvectCol4.length())
        {
            qDebug() << "Vector 4 length doesnot matched";
            return false;
        }
    }

    /* Initialize graph to remove previous plots (if any) */
    initGraph();

    /* Add 2 new graphs */
    ui->widgetGraph->addGraph(ui->widgetGraph->xAxis, ui->widgetGraph->yAxis);
    ui->widgetGraph->addGraph(ui->widgetGraph->xAxis, ui->widgetGraph->yAxis2);
    if (m_bPlot3Tracers)
    {
        ui->widgetGraph->addGraph(ui->widgetGraph->xAxis, ui->widgetGraph->yAxis2);
    }

    /* Set pen style for both graphs */
    ui->widgetGraph->graph(0)->setPen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->graph(1)->setPen(QPen(YAXIS2_BASE_TICK_COLOR));
    if (m_bPlot3Tracers)
    {
        ui->widgetGraph->graph(2)->setPen(QPen(TRACER3_COLOR));
    }

#if 0
    ui->widgetGraph->graph(0)->setSelectable(QCP::stMultipleDataRanges);
    ui->widgetGraph->graph(1)->setSelectable(QCP::stMultipleDataRanges);
#endif

    /* Set names for both graph (Displayed in legend) */
    ui->widgetGraph->graph(0)->setName("Gain");
    ui->widgetGraph->graph(1)->setName("Phase");
    if (m_bPlot3Tracers)
    {
        ui->widgetGraph->graph(2)->setName("Scan Rate Demand");
    }

    /* Set range for Frequency (X-Axis) */
    getRange(in_dvectCol1, &dLowerLimit, &dUpperLimit);
    ui->widgetGraph->xAxis->setRange(dLowerLimit, dUpperLimit);

    /* Set range for Gain (Y-Axis) */
    getRange(in_dvectCol2, &dLowerLimit, &dUpperLimit);
    ui->widgetGraph->yAxis->setRange(dLowerLimit, dUpperLimit);

    /* Set range for Phase (Y2-Axis) */
    getRange(in_dvectCol3, &dLowerLimit, &dUpperLimit);
    ui->widgetGraph->yAxis2->setRange(dLowerLimit, dUpperLimit);

    /* Set the data and line style for both graphs */
    ui->widgetGraph->graph(0)->setData(in_dvectCol1, in_dvectCol2);
    ui->widgetGraph->graph(0)->setLineStyle(QCPGraph::lsLine);
    ui->widgetGraph->graph(1)->setData(in_dvectCol1, in_dvectCol3);
    ui->widgetGraph->graph(1)->setLineStyle(QCPGraph::lsLine);
    if (m_bPlot3Tracers)
    {
        ui->widgetGraph->graph(2)->setData(in_dvectCol1, in_dvectCol4);
        ui->widgetGraph->graph(2)->setLineStyle(QCPGraph::lsStepLeft);
    }

    /* Make sure to replot to reflect the changes */
    ui->widgetGraph->replot();

    return true;
}

void MainWindow::saveGraph(QString in_qstrFilename)
{
    bool bIsSuccess     = false;
    QString qstrTitle   = QString("");
    QString qstrMessage = QString("");

    /* Hide tracer, tracer label, tracer line */
    SET_TRACING_STATE(false);

    /* Save the graph with given filename */
    bIsSuccess = ui->widgetGraph->savePdf(in_qstrFilename);
    if (bIsSuccess)
    {
        qstrTitle.sprintf("Graph");
        qstrMessage = QString("Graph saved <a style=\"color: white;\" href=\"file:///%1\">here!</a>")\
                .arg(in_qstrFilename);  /* Display saved message with link to the file */
    }
    else
    {
        qstrTitle.sprintf("Graph Unsaved :(");
        qstrMessage.sprintf("Error saving Graph as PDF");
    }

    /* Display success or error message */
    DISPLAY_MESSAGE_BOX(this, qstrTitle, qstrMessage);

    /* Re-show the tracer, tracer label, tracer line */
    SET_TRACING_STATE(true);
}

void MainWindow::initModStatusTable()
{
    CHANGE_PAGE(PAGE_INIT);
    g_previousPage = PAGE_INVALID;
    ui->pbModDetProceed->setEnabled(false);
    ui->frameCBITStatus->setVisible(false);
    ui->tblwidModuleStatus->setFocusPolicy(Qt::NoFocus);
    ui->tblwidModuleStatus->horizontalHeader()->setVisible(true);
    ui->tblwidModuleStatus->verticalHeader()->setVisible(false);
    ui->tblwidModuleStatus->horizontalHeader()->setSectionsClickable(false);
    ui->tblwidModuleStatus->setSelectionMode(QAbstractItemView::NoSelection);
    ui->tblwidModuleStatus->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tblwidModuleStatus->setColumnWidth(0,240);
    ui->tblwidModuleStatus->setColumnWidth(1,100);
    ui->tblwidModuleStatus->setColumnWidth(2,100);
    ui->tblwidModuleStatus->setColumnWidth(3,120);
    ui->tblwidModuleStatus->setColumnWidth(4,60);
    ui->pbApp_Home->setVisible(false);

    APPEND_ACTION_LOG("DP-cPCI-7554 module initialization success", LOG_SUCCESS);
}

void MainWindow::on_pbModDetProceed_clicked()
{
    if (ui->rbInit_Sys_RGA_RTGA->isChecked())
    {
        m_cSystemSelection = SYS_RGA_RTGA;
    }
    else
    {
        m_cSystemSelection = SYS_SEASPRAY;
    }

    CHANGE_PAGE(PAGE_CONFIG_RS232);
}

void MainWindow::on_stackedWidget_currentChanged(int in_iPageIndex)
{
    switch(in_iPageIndex)
    {
    case PAGE_INIT:
    {
        ui->pbApp_Home->setVisible(true);
        ui->pbApp_Home->setText("Home");
        ui->lbPageTitle->setText("Servo Control Module ATE Application");
        ui->pbModDetProceed->setEnabled(ui->rbInit_Sys_RGA_RTGA->isChecked() || ui->rbInit_Sys_Seaspray->isChecked());
        ui->frameCBITStatus->setVisible(false);
    } break;
    case PAGE_CONFIG_RS232:
    {
        ui->pbApp_Home->setVisible(true);
        ui->pbApp_Home->setText("Home");
        ui->lbPageTitle->setText("Communication Status");
        ui->frameCBITStatus->setVisible(false);
    } break;
    case PAGE_PBIT:
    {
        ui->pbApp_Home->setVisible(true);
        ui->pbApp_Home->setText("Home");
        ui->lbPageTitle->setText("PBIT Status");
        ui->frameCBITStatus->setVisible(false);
        APPEND_ACTION_LOG("SCM PBIT Status Success", LOG_SUCCESS);
    } break;
    case PAGE_SELF_TEST:
    {
        ui->pbApp_Home->setVisible(true);
        ui->pbApp_Home->setText("Home");
        ui->lbPageTitle->setText("ATE Selftest");
        ui->frameCBITStatus->setVisible(true);
        ui->rbSelfTest_CmdPort->setChecked(true);
    } break;
    case PAGE_FLASH_PROGRAMMING:
    {
        ui->pbApp_Home->setVisible(true);
        ui->pbApp_Home->setText("Home");
        ui->lbPageTitle->setText("Flash Programming");
        ui->frameCBITStatus->setVisible(true);
        ui->leFlash_FilePath->clear();
        ui->progressFlashProgram->setVisible(false);
    } break;
    case PAGE_CONFIG_CTRL_LOOP_CONST:
    {
        ui->pbApp_Home->setVisible(true);
        ui->pbApp_Home->setText("Home");
        ui->lbPageTitle->setText("Control Loop Constant Configuration");
        ui->frameCBITStatus->setVisible(true);
    } break;
    case PAGE_ENCODER_CALIBRATION:
    {
        ui->pbApp_Home->setVisible(true);
        ui->pbApp_Home->setText("Home");
        ui->lbPageTitle->setText("Encoder Calibration");
        ui->frameCBITStatus->setVisible(true);
        ui->cbEncoderAcutator_Azimuth->setChecked(true);
        ui->cbEncoderAcutator_Elevation->setChecked(true);
    } break;
    case PAGE_SCM_OPERATION:
    {
        ui->pbApp_Home->setVisible(true);
        ui->pbApp_Home->setText("Home");
        ui->lbPageTitle->setText("Servo Control Operation");
        ui->frameCBITStatus->setVisible(true);
        ui->rbSCM_CmdMode_Digital->setChecked(true);
        ui->rbSCM_PositionCommand->setChecked(true);
    } break;
    case PAGE_CBIT:
    {
        ui->pbApp_Home->setVisible(true);
        ui->pbApp_Home->setText("Home");
        ui->lbPageTitle->setText("CBIT Status");
        ui->frameCBITStatus->setVisible(true);
    } break;
    case PAGE_RESPONSE_MONITORING:
    {
        ui->pbApp_Home->setVisible(true);
        ui->pbApp_Home->setText("Home");
        ui->lbPageTitle->setText("Servo Response Monitoring");
        ui->frameCBITStatus->setVisible(true);
    } break;
    case PAGE_SYSTEM_DETAILS:
    {
        ui->pbApp_Home->setVisible(true);
        ui->pbApp_Home->setText("Home");
        ui->lbPageTitle->setText("SCM System Version Details");
        ui->frameCBITStatus->setVisible(true);
    } break;
    case PAGE_SERIAL_COMM_CONFIGURATION:
    {
        ui->pbApp_Home->setVisible(true);
        ui->pbApp_Home->setText("Home");
        ui->lbPageTitle->setText("Serial Communication Configuration");
        ui->frameCBITStatus->setVisible(true);
    } break;

    default: break;
    }
}

void MainWindow::on_pbConfRS232Proceed_clicked()
{
    CHANGE_PAGE(PAGE_PBIT);
}

void MainWindow::on_action_Self_Test_triggered()
{
    CHANGE_PAGE(PAGE_SELF_TEST);
}

void MainWindow::on_pbSelfTest_clicked()
{
    QString qstrTestSel = (ui->rbSelfTest_CmdPort->isChecked()) ? "Command Port" : "Debug Port";
    QString qstrFilepath = ui->leSelftest_FilePath->text();

    if (qstrFilepath.isEmpty())
    {
        DISPLAY_MESSAGE_BOX(this, "Self Test", "Please select a file");
        return;
    }

    APPEND_ACTION_LOG(QString("RS232 %1 Self test passed").arg(qstrTestSel), LOG_SUCCESS);
}

void MainWindow::on_actionConfigure_RS232_triggered()
{
    CHANGE_PAGE(PAGE_SERIAL_COMM_CONFIGURATION);
}

void MainWindow::on_pbFlash_Program_clicked()
{
    if (ui->leFlash_FilePath->text().isEmpty())
    {
        DISPLAY_MESSAGE_BOX(this, "Flash", "Please select Program file");
        return;
    }

    ui->progressFlashProgram->setVisible(true);
    ui->progressFlashProgram->setValue(100);

    APPEND_ACTION_LOG("Flash programmed successfully", LOG_SUCCESS);
}

void MainWindow::on_pbFlash_Browse_clicked()
{
    QString qstrFilePath = QFileDialog::getOpenFileName(this, "Flash", "./config/", "LDR File (*.ldr)");

    if (qstrFilePath.isEmpty())
    {
        DISPLAY_MESSAGE_BOX(this, "Flash", "No file selected");
        return;
    }

    ui->leFlash_FilePath->setText(qstrFilePath);
}

void MainWindow::on_action_Flash_Program_triggered()
{
    CHANGE_PAGE(PAGE_FLASH_PROGRAMMING);
}

void MainWindow::on_pbFlash_Verify_clicked()
{
    ui->leFlash_Checksum->setText("0x4AE9634C");
    APPEND_ACTION_LOG("Checksum calculated : " + ui->leFlash_Checksum->text(), LOG_INFO);
}

void MainWindow::on_actionConfigure_Control_Loop_Constant_triggered()
{
    CHANGE_PAGE(PAGE_CONFIG_CTRL_LOOP_CONST);
}

void MainWindow::on_pbCLCConfig_ReadEEPROM_clicked()
{
    APPEND_ACTION_LOG("Control Loop Constant values read from EEPROM", LOG_INFO);
}

void MainWindow::on_pbCLCConfig_WriteEEPROM_clicked()
{

    APPEND_ACTION_LOG("Control Loop Constant written to EEPROM successfully", LOG_SUCCESS);
}

void MainWindow::on_action_Encoder_Calibration_triggered()
{
    CHANGE_PAGE(PAGE_ENCODER_CALIBRATION);
}

void MainWindow::on_cbEncoderAcutator_Azimuth_clicked()
{

}

void MainWindow::on_cbEncoderAcutator_Elevation_clicked()
{

}

void MainWindow::on_actionMotor_Control_triggered()
{
    CHANGE_PAGE(PAGE_SCM_OPERATION);
}

void MainWindow::on_actionAbout_ATE_triggered()
{
    m_pAbout->show();
}

void MainWindow::on_action_System_Details_triggered()
{
    CHANGE_PAGE(PAGE_SYSTEM_DETAILS);
}

void MainWindow::on_action_PBIT_Status_triggered()
{
    CHANGE_PAGE(PAGE_PBIT);
}

void MainWindow::on_pbPBITProceed_clicked()
{
    CHANGE_PAGE(PAGE_SCM_OPERATION);
}

void MainWindow::on_action_CBIT_Status_triggered()
{
    CHANGE_PAGE(PAGE_CBIT);
}

void MainWindow::on_action_Report_Monitoring_triggered()
{
    CHANGE_PAGE(PAGE_RESPONSE_MONITORING);
}

void MainWindow::on_pbEncoder_Read_clicked()
{
    APPEND_ACTION_LOG("Data read from Encoder", LOG_INFO);
}

void MainWindow::on_pbEncoder_StartCalibration_clicked()
{
    APPEND_ACTION_LOG("Performing Encoder Calibration", LOG_INFO);

    APPEND_ACTION_LOG("Encoder calibration successful", LOG_SUCCESS);
}

void MainWindow::on_pbSCM_Configure_clicked()
{
    APPEND_ACTION_LOG("Servo Motor Control Simulation Started", LOG_INFO);

    CHANGE_PAGE(PAGE_RESPONSE_MONITORING);
}

void MainWindow::slot_graphSavepoint(QMouseEvent *in_pMevent)
{
    /* Ignore if other than left mouse button is clicked */
    if (in_pMevent->button() != Qt::LeftButton)
    {
        return;
    }

    /* Ignore if number of graphs is not equal to 2 */
    if (ui->widgetGraph->graphCount() <= 0)
    {
        return;
    }

    double xValue       = 0.0;
    double yValue       = 0.0;
    QString qstrData    = QString("");
    QPointF qPos        = QPointF();
    QPointF qPos2       = QPointF();
    QPointF qPos3       = QPointF();
    QCPItemText *pTracerLabel = NULL;

    /* Set tracer for Gain Graph (Y-Axis) and tracer2 for Phase Graph (Y2-Axis) */
    m_pTracer->setGraph(ui->widgetGraph->graph(0));
    m_pTracer2->setGraph(ui->widgetGraph->graph(1));

    /* Get the position in pixels of both tracers */
    qPos = m_pTracer->position->pixelPosition();
    qPos2 = m_pTracer2->position->pixelPosition();
    qPos3 = m_pTracer3->position->pixelPosition();

    /* Create a tracer label for 1st graph */
    pTracerLabel = new QCPItemText(ui->widgetGraph);
    pTracerLabel->setLayer("overlay");
#if 0
//    vectItemText.push_back(pTracerLabel);
#endif

    /* Set style for tracer label */
    pTracerLabel->setPen(QPen(YAXIS_BASE_TICK_COLOR));
    pTracerLabel->setColor(MOUSE_TRACER_LABEL_COLOR);
    pTracerLabel->setPositionAlignment(TRACER1_LABEL_POSITION);

    /* Get X and Y values from the tracer */
    xValue = m_pTracer->position->key();
    yValue = m_pTracer->position->value();
    qstrData.sprintf("(%0.5f, %0.5f)", xValue, yValue);

    /* Set label at the tracer position (fixed) */
    pTracerLabel->position->setPixelPosition(qPos);
    pTracerLabel->setText(qstrData);

    /* Create a tracer label for 2nd graph */
    pTracerLabel = new QCPItemText(ui->widgetGraph);
    pTracerLabel->setLayer("overlay");
#if 0
//    vectItemText.push_back(pTracerLabel);
#endif

    /* Set style for tracer label */
    pTracerLabel->setPen(QPen(YAXIS2_BASE_TICK_COLOR));
    pTracerLabel->setColor(LEGEND_TEXT_COLOR);
    pTracerLabel->setPositionAlignment(TRACER2_LABEL_POSITION);

    /* Get X and Y values from the tracer2 */
    xValue = m_pTracer2->position->key();
    yValue = m_pTracer2->position->value();
    qstrData.sprintf("(%0.5f, %0.5f)", xValue, yValue);

    /* Set label at the tracer2 position (fixed) */
    pTracerLabel->position->setPixelPosition(qPos2);
    pTracerLabel->setText(qstrData);

    if (m_bPlot3Tracers)
    {
        /* Create a tracer label for 3rd graph */
        pTracerLabel = new QCPItemText(ui->widgetGraph);
        pTracerLabel->setLayer("overlay");
#if 0
        //    vectItemText.push_back(pTracerLabel);
#endif

        /* Set style for tracer label */
        pTracerLabel->setPen(QPen(MOUSE_TRACER3_COLOR));
        pTracerLabel->setColor(LEGEND_TEXT_COLOR);
        pTracerLabel->setPositionAlignment(TRACER3_LABEL_POSITION);

        /* Get X and Y values from the tracer2 */
        xValue = m_pTracer3->position->key();
        yValue = m_pTracer3->position->value();
        qstrData.sprintf("(%0.5f, %0.5f)", xValue, yValue);

        /* Set label at the tracer2 position (fixed) */
        pTracerLabel->position->setPixelPosition(qPos3);
        pTracerLabel->setText(qstrData);
    }

    /* Replot to reflect the changes */
    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}

void MainWindow::slot_graphTracePoint(QMouseEvent *in_pMevent)
{
    /* Ignore if number of graph is not 2 */
    if (ui->widgetGraph->graphCount() < 2)
    {
        return;
    }

    QString qstrData    = QString("");
    double dMouseX      = 0.0;
    double dStart       = 0.0;
    double dEnd         = 0.0;
    double dValueX      = 0.0;
    double dValueY      = 0.0;

    /* Get X value of mouse position */
    dMouseX = ui->widgetGraph->xAxis->pixelToCoord(in_pMevent->pos().x());

    /* Get start and end (0 and height of graph) */
    dStart = ui->widgetGraph->yAxis->pixelToCoord(0);
    dEnd = ui->widgetGraph->yAxis->pixelToCoord(ui->widgetGraph->size().height());

    /* Set tracer line start at (mouseX, start) and ends at (mouseX, end) */
    m_pTracerLine->start->setCoords(dMouseX, dStart);
    m_pTracerLine->end->setCoords(dMouseX, dEnd);

    /* Set tracer for Gain graph */
    m_pTracer->setGraph(ui->widgetGraph->graph(0));

    /* Set tracer position key to mouseX */
    m_pTracer->setGraphKey(dMouseX);

    /* Set interpolation for the graph
     * Enable to trace along the plot
     * Else only plotted data points is positioned */
    m_pTracer->setInterpolating(true);

    /* Update position everytime to move tracer to new position */
    m_pTracer->updatePosition();

    /* Get X(Frequency) and Y(Gain) values from tracer position */
    dValueX = m_pTracer->position->key();
    dValueY = m_pTracer->position->value();
    qstrData.sprintf("(%0.5f, %0.5f)", dValueX, dValueY);

    /* Set label position */
    m_pTracerLabel->position->setType(QCPItemPosition::ptAbsolute);
    m_pTracerLabel->setPositionAlignment(TRACER1_LABEL_POSITION);
    m_pTracerLabel->position->setCoords(1.0, 1);

    /* Set tracer style */
    m_pTracer->setPen(QPen(MOUSE_TRACER_COLOR));
    m_pTracer->setBrush(QBrush(MOUSE_TRACER_COLOR));

    /* Set label style */
    m_pTracerLabel->setTextAlignment(Qt::AlignRight);
    m_pTracerLabel->setFont(QFont(font().family(), 12));
    m_pTracerLabel->setPadding(QMargins(9, 3, 3, 9));
    m_pTracerLabel->setColor(LEGEND_TEXT_COLOR);
    m_pTracerLabel->setText(qstrData);   /* Display label */

    /* Set tracer2 for Gain graph */
    m_pTracer2->setGraph(ui->widgetGraph->graph(1));

    /* Set tracer position key to mouseX */
    m_pTracer2->setGraphKey(dMouseX);

    /* Set interpolation for the graph
     * Enable to trace along the plot
     * Else only plotted data points is positioned */
    m_pTracer2->setInterpolating(true);

    /* Update position everytime to move tracer2 to new position */
    m_pTracer2->updatePosition();

    /* Get X(Frequency) and Y(Gain) values from tracer2 position */
    dValueX = m_pTracer2->position->key();
    dValueY = m_pTracer2->position->value();
    qstrData.sprintf("(%0.5f, %0.5f)", dValueX, dValueY);

    /* Set label2 position */
    m_pTracerLabel2->position->setType(QCPItemPosition::ptAbsolute);
    m_pTracerLabel2->setPositionAlignment(TRACER2_LABEL_POSITION);
    m_pTracerLabel2->position->setCoords(0, 0);

    /* Set tracer2 style */
    m_pTracer2->setPen(QPen(MOUSE_TRACER2_COLOR));
    m_pTracer2->setBrush(QBrush(MOUSE_TRACER2_COLOR));

    /* Set label2 style */
    m_pTracerLabel2->setTextAlignment(Qt::AlignRight);
    m_pTracerLabel2->setFont(QFont(font().family(), 12));
    m_pTracerLabel2->setPadding(QMargins(9, 3, 3, 9));
    m_pTracerLabel2->setColor(LEGEND_TEXT_COLOR);
    m_pTracerLabel2->setText(qstrData);  /* Display label2 */

    if (m_bPlot3Tracers)
    {
        m_pTracer3->setGraph(ui->widgetGraph->graph(2));

        /* Set tracer position key to mouseX */
        m_pTracer3->setGraphKey(dMouseX);

        /* Set interpolation for the graph
         * Enable to trace along the plot
         * Else only plotted data points is positioned */
        m_pTracer3->setInterpolating(true);

        /* Update position everytime to move tracer3 to new position */
        m_pTracer3->updatePosition();

        /* Get X and Y values from tracer3 position */
        dValueX = m_pTracer3->position->key();
        dValueY = m_pTracer3->position->value();
        qstrData.sprintf("(%0.5f, %0.5f)", dValueX, dValueY);

        /* Set label3 position */
        m_pTracerLabel3->position->setType(QCPItemPosition::ptAbsolute);
        m_pTracerLabel3->setPositionAlignment(TRACER3_LABEL_POSITION);
        m_pTracerLabel3->position->setCoords(0, 0);

        /* Set tracer3 style */
        m_pTracer3->setPen(QPen(MOUSE_TRACER3_COLOR));
        m_pTracer3->setBrush(QBrush(MOUSE_TRACER3_COLOR));

        /* Set labe3 style */
        m_pTracerLabel3->setTextAlignment(Qt::AlignRight);
        m_pTracerLabel3->setFont(QFont(font().family(), 12));
        m_pTracerLabel3->setPadding(QMargins(9, 3, 3, 9));
        m_pTracerLabel3->setColor(LEGEND_TEXT_COLOR);
        m_pTracerLabel3->setText(qstrData);  /* Display label3 */
    }

    /* Show tracer, tracer label for both graph */
    m_pTracer->setVisible(true);
    m_pTracerLabel->setVisible(true);
    m_pTracer2->setVisible(true);
    m_pTracerLabel2->setVisible(true);
    m_pTracerLine->setVisible(true);
    if (m_bPlot3Tracers)
    {
        m_pTracerLabel3->setVisible(true);
        m_pTracer3->setVisible(false);
    }

    /* Replot graph to reflect the changes */
    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}

bool MainWindow::initiateGraphPlot()
{
    bool bIsSuccess             = false;
    QStringList strLogfileLines = QStringList();

    /* Read all lines from log file */
    bIsSuccess = readLogFileLines(&strLogfileLines);
    if (!bIsSuccess)    /* If read lines failed, then terminate */
    {
        DISPLAY_MESSAGE_BOX(this, "File Error", "Cannot read log file data");
        return false;
    }

    bIsSuccess = false;

    /* Parse data from log file lines */
    bIsSuccess = parseLogData(strLogfileLines, &m_dvectCol1, &m_dvectCol2, &m_dvectCol3, &m_dvectCol4);
    if (!bIsSuccess)    /* If parsing failed, then termiante */
    {
        DISPLAY_MESSAGE_BOX(this, "File Error", "Cannot read log file data");
        return false;
    }

#if 1
    qDebug() << "COL 1 : " << m_dvectCol1;
    qDebug() << "COL 2 : " << m_dvectCol2;
    qDebug() << "COL 3 : " << m_dvectCol3;
    qDebug() << "COL 4 : " << m_dvectCol4;
#endif

    bIsSuccess = false;

    /* Plot graph with parsed Frequency, Gain and Phase values */
    bIsSuccess = plotGraph(m_dvectCol1, m_dvectCol2, m_dvectCol3, m_dvectCol4);
    if (!bIsSuccess)    /* If plotting failed, then terminate */
    {
        initGraph();    /* Clear wrong graph (if any) */
        DISPLAY_MESSAGE_BOX(this, "Graph Error", "Cannot Plot Graph");
        return false;
    }

    return true;
}

void MainWindow::on_label_13_linkActivated(const QString &link)
{
    Q_UNUSED(link);

    CHANGE_PAGE(PAGE_CBIT);
}

void MainWindow::on_label_16_linkActivated(const QString &link)
{
    on_label_13_linkActivated(link);
}

void MainWindow::on_label_19_linkActivated(const QString &link)
{
    on_label_13_linkActivated(link);
}

void MainWindow::on_label_18_linkActivated(const QString &link)
{
    on_label_13_linkActivated(link);
}

void MainWindow::on_label_40_linkActivated(const QString &link)
{
    on_label_13_linkActivated(link);
}

void MainWindow::on_pbApp_Home_clicked()
{
    CHANGE_PAGE(PAGE_SCM_OPERATION);
}

void MainWindow::on_pbConfRS232_Verify_clicked()
{
    APPEND_ACTION_LOG("Communication Status Success", LOG_SUCCESS);
}

void MainWindow::on_actionInitialization_Module_triggered()
{
    CHANGE_PAGE(PAGE_INIT);
}

void MainWindow::on_pbSelftest_FileBrowse_clicked()
{
    QString qstrFilePath = QFileDialog::getOpenFileName(this, "Self Test", "./config/", "File (*.bin *.csv *.txt)");

    if (qstrFilePath.isEmpty())
    {
        DISPLAY_MESSAGE_BOX(this, "Self Test", "No file selected");
        return;
    }

    ui->leSelftest_FilePath->setText(qstrFilePath);
}

void MainWindow::on_rbInit_Sys_RGA_RTGA_toggled(bool checked)
{
    Q_UNUSED(checked);

    if (ui->rbInit_Sys_RGA_RTGA->isChecked() || ui->rbInit_Sys_Seaspray->isChecked())
    {
        ui->pbModDetProceed->setEnabled(true);
    }
}

void MainWindow::on_rbInit_Sys_Seaspray_toggled(bool checked)
{
    Q_UNUSED(checked);

    if (ui->rbInit_Sys_RGA_RTGA->isChecked() || ui->rbInit_Sys_Seaspray->isChecked())
    {
        ui->pbModDetProceed->setEnabled(true);
    }
}

void MainWindow::on_action_Communication_Status_triggered()
{
    CHANGE_PAGE(PAGE_CONFIG_RS232);
}

void MainWindow::on_pbSerial_Configure_clicked()
{
    APPEND_ACTION_LOG("RS232 Configuration Successful", LOG_SUCCESS);
}

void MainWindow::on_lstviewDiag_TestCasesList_clicked(const QModelIndex &in_iTestCase)
{
    m_iSelectedTestCase = in_iTestCase.row();
    m_strLogFileName = "./log_files/";
    switch (m_iSelectedTestCase)
    {
    case TC_GIMBAL_ZERO_POS_CALIB:
    {
        break;
    }
    case TC_ENCODER_CALIB: {
        break;
    }
    case TC_POS_MODE_PERFORMANCE:
    {
        break;
    }
    case TC_POS_MODE_BIDIR_SCAN:
    {
        m_strLogFileName.append("Pos_Mode_Dem.csv");
        break;
    }
    case TC_RATE_MODE_PERFORMANCE:
    {
        break;
    }
    case TC_RATE_MODE_ALT_SCAN:
    {
        m_strLogFileName.append("Rate_Mode_Response.csv");
        break;
    }
    case TC_OPEN_LOOP_BW_TEST:
    {
        m_strLogFileName.append("Freq_Gain_Phase.csv");
        break;
    }
    case TC_CLOSED_LOOP_BW_TEST:
    {
        break;
    }
    default:
    {
        qDebug() << "Invalid test case";
        break;
    }
    }
    initGraph();
}

void MainWindow::on_pbDiag_Start_clicked()
{
    if (QString::compare(ui->pbDiag_Start->text(), "S&tart") == 0)
    {
        if (initiateGraphPlot())
        {
            ui->pbDiag_Start->setText("S&top");
        }
    }
    else
    {
        initGraph();
        ui->pbDiag_Start->setText("S&tart");
    }
}

void MainWindow::on_pbDiag_TCCollapse_toggled(bool checked)
{
    ui->lstviewDiag_TestCasesList->setVisible(checked);
    ui->gbDiag_DACSelection->setVisible(checked);
}
