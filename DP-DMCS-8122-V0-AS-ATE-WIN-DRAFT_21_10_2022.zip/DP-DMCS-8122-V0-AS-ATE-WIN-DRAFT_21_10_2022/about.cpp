#include "about.h"
#include "ui_about.h"

CAbout::CAbout(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CAbout)
{
    ui->setupUi(this);

    loadStyle();
    setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);

    ui->lbChecksum->setText("0x" + QString::number(10002024, 16).toUpper());
}

CAbout::~CAbout()
{
    delete ui;
}

void CAbout::loadStyle()
{
    QFile qFile(QSS_FILE);

    if (!qFile.open(QIODevice::ReadOnly))
    {
        return;
    }

    this->setStyleSheet(qFile.readAll().data());
    qFile.close();
}

void CAbout::on_pbOk_clicked()
{
    this->close();
}
