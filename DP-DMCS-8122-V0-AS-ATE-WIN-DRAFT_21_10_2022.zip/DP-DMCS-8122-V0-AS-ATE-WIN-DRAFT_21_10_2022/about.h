#ifndef ABOUT_H
#define ABOUT_H

#include <QDialog>
#include <QFile>

#include "macros.h"

namespace Ui {
class CAbout;
}

class CAbout : public QDialog
{
    Q_OBJECT

public:
    explicit CAbout(QWidget *parent = 0);
    ~CAbout();

    void loadStyle();

private slots:
    void on_pbOk_clicked();

private:
    Ui::CAbout *ui;
};

#endif // ABOUT_H
