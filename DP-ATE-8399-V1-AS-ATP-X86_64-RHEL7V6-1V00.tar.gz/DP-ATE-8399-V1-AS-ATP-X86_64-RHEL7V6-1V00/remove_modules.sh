rmmod dp1553bxt

rmmod dpmm1123

rmmod dpmm1105

rmmod dpmmcrdrv

rmmod dpcpci3096
