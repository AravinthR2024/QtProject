insmod ./lib/dp1553bxt.ko

insmod ./lib/dpmmcrdrv.ko

insmod ./lib/dpmm1105.ko

insmod ./lib/dpmm1123.ko

insmod ./lib/dpcpci3096.ko

