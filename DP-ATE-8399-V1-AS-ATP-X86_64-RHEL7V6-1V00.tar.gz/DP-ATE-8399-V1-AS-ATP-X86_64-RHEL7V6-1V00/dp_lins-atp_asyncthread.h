#ifndef DP_LINSATP_ASYNCTHREAD
#define DP_LINSATP_ASYNCTHREAD

#include <QThread>
#include <QDir>

#include "includes/dp-lins_1553b_wrapper.h"

class C_BC_READ_THREAD  : public QThread
{
    Q_OBJECT

public:
    C_BC_READ_THREAD(unsigned short usChannelNo, QString in_1553BLogDir);
    cDP1553BWrapper           *m_pobj1553WrBC;
    SDP1553BXT_BC_MSG *m_1553B_BC_Strct;
    bool m_bFlagStartStop;
    int m_iBCmsgCnt;
    int m_iAsyncMsgID;
    int iResult;
    QString m_strTimeTag;
    QString m_strCmd;
    QString m_qs1553BLogDir;
    void Start();
    void Stop();

private:
    unsigned short m_usChannelNo;

 protected:
     void run();
};

class C_RT_READ_THREAD  : public QThread
{
    Q_OBJECT

public:
    C_RT_READ_THREAD(unsigned short usChannelNo, QString in_1553BLogDir);
    cDP1553BWrapper           *m_pobj1553WrRT;
    SDP1553BXT_RT_MSG *m_1553B_RT_Strct;
    bool m_bFlagStartStop;
    int m_iRTmsgCnt;
    SDP1553B_MRT_CONFIG m_S_pMRT_Config;
    QString m_qs1553BLogDir;
    void Start();
    void Stop();

private:
    unsigned short m_usChannelNo;

 protected:
     void run();
};

class C_MT_READ_THREAD  : public QThread
{
    Q_OBJECT

public:
    C_MT_READ_THREAD(unsigned short usChannelNo, unsigned short usMTNo, QString in_1553BLogDir);
    cDP1553BWrapper           *m_pobj1553WrMT;
    SDP1553BXT_MT_MSG *m_1553B_MT_Strct;
    QString m_qs1553BLogDir;
    bool m_bFlagStartStop;
    void Start();
    void Stop();

private:
    unsigned short m_usChannelNo;
    unsigned short m_usMTNo;

 protected:
     void run();
};

int GetTimeFromTimetag(U64BIT in_u64Timetag, U16BIT in_u16TTRes, S_APP_TIMETAG_TIME *out_pTime, char *out_pszTime);

#endif // DP_LINSATP_ASYNCTHREAD

