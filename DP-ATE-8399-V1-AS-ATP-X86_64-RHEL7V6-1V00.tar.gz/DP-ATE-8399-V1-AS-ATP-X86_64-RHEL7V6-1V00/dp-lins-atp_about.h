#ifndef ABOUT_H
#define ABOUT_H

#include <QDialog>
#include "dp-lins-atp_includes.h"

namespace Ui {
class CAbout;
}

class CAbout : public QDialog
{
    Q_OBJECT

public:
    explicit CAbout(QWidget *parent = 0);
    ~CAbout();
    QString m_strAppVer;

private slots:
    void on_pb_Ok_clicked();

private:
    Ui::CAbout *ui;
};

#endif // ABOUT_H
