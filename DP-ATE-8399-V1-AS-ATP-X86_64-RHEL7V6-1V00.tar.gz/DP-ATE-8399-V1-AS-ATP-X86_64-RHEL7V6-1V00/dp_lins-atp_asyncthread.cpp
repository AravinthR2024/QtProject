#include "dp_lins-atp_asyncthread.h"
#include "dp-lins-atp_testthread.h"
#include  <QDebug>

C_BC_READ_THREAD::C_BC_READ_THREAD(unsigned short usChannelNo, QString in_1553BLogDir)
{
    m_usChannelNo = usChannelNo;
    iResult = 0;
    m_qs1553BLogDir = in_1553BLogDir;
}

void C_BC_READ_THREAD::Start()
{
    if(!isRunning())
    {
        m_bFlagStartStop = true;

        start(QThread::HighestPriority);
    }
}

void C_BC_READ_THREAD::Stop()
{
    m_bFlagStartStop = false;
}

void C_BC_READ_THREAD::run()
{
    char szTimetag[256] = "";
    char szErrStr[256] = "";
    char szFileName[256] = "";
    unsigned short usNoofmsgsread=0, usMsgToRead = 11;
    U16BIT u16RTAddr = 0, u16SubAddr1 = 0, u16SubAddr2 = 0, u16WC_MC = 0, u16WC_MC2 = 0,  u16TxRx = 0;
    unsigned int uiMsgCount = 0;
    m_iBCmsgCnt = 0;
    int iloop = 0;
    int iBCMsgIndex = 0;
    int iRetVal = 0;
    SDP1553BXT_BC_MSG sbcResult[256] ;
    FILE *fpBCMesg = NULL;
    memset(sbcResult, 0, sizeof(SDP1553BXT_BC_MSG) * 256);

    QString qsFileName;
    QString qsLogDirPath;
    qsLogDirPath = m_qs1553BLogDir+DP_LINS_REPORT_1553B_ASYNC_DIR+"/CH"+ QString::number(m_usChannelNo + 1)+"_Async";
    QDir dir(qsLogDirPath);
    if(!dir.exists())
    {
        dir.mkpath(qsLogDirPath);
    }

    qsFileName = qsLogDirPath + "/CH"+ QString::number(m_usChannelNo + 1)+"_BCLogFile.txt";
    strncpy(szFileName, qsFileName.toStdString().c_str(), qsFileName.count());

    fpBCMesg = fopen(szFileName, "w");
    if(!fpBCMesg)
    {
        qDebug("\n\t\t Error in opening BC Log Messages file\n");
        return;
    }

    //	printf("\n");
    while(m_bFlagStartStop)
    {
        unsigned int uiWaitTime = 0;
        unsigned int uiEventStatus = 0;
        iRetVal = m_pobj1553WrBC->DP1553B_BC_WaitForEvents(m_usChannelNo, 1, DP1553BXT_EVT_OPT_WAIT_ANY, &uiWaitTime, &uiEventStatus);
        if(iRetVal == 0)
        {
//qDebug() << "BC Running" << uiEventStatus;
        }
//        qDebug() << "running";
        iRetVal = m_pobj1553WrBC->DP1553B_BC_ReadMessage(m_usChannelNo,sbcResult,usMsgToRead,&usNoofmsgsread, NULL);
        if(iRetVal)
        {
//            m_pobj1553Wr->DP1553BXT_GetErrorMessage(iRetVal, szErrStr, sizeof(szErrStr));
//            printf("\n\t\tDriver Error: %s \n", szErrStr);
        }
        //printf("usNoofmsgsread :%d\n", usNoofmsgsread);
        if(usNoofmsgsread)
        {
//            qDebug("\n\n\tTotal BC Message Exchanges (INTR) = %6d ( Last read: %4d ) ChannelNo :%d \n ",uiMsgCount+1, usNoofmsgsread, m_usChannelNo+1);

            for(iBCMsgIndex = 0; iBCMsgIndex < usNoofmsgsread; iBCMsgIndex++)
            {
                GetTimeFromTimetag(sbcResult[iBCMsgIndex].u64TimeTagVal, sbcResult[iBCMsgIndex].u16TimetagRes, NULL, szTimetag);
                DP1553BXT_GET_CMD_WORD(sbcResult[iBCMsgIndex].u16CmdWord1, u16RTAddr, u16SubAddr1, u16WC_MC,  u16TxRx );

                if(sbcResult[iBCMsgIndex].u16MsgID == m_iAsyncMsgID)
                {
                    iResult = 1;
                    m_strTimeTag.sprintf("%s", szTimetag);
                    m_strCmd.sprintf("Cmd Word: 0x%04X (RT - %2d, SA - %2d, WC - %2d, TR - %d), BSW = 0x%X, RT Status Word 1 = 0x%X", sbcResult[iBCMsgIndex].u16CmdWord1, u16RTAddr, u16SubAddr1, u16WC_MC,  u16TxRx, sbcResult[iBCMsgIndex].u16BlockStsWord, sbcResult[iBCMsgIndex].u16RTStsWord1);
                    fprintf(fpBCMesg,"\n\n---------- Message No.: %d (Async Message: %d)----------", uiMsgCount+1, sbcResult[iBCMsgIndex].u16MsgID);
                }
                else
                    fprintf(fpBCMesg,"\n\n---------- Message No.: %d (Msg ID: %d)----------", uiMsgCount+1, sbcResult[iBCMsgIndex].u16MsgID);

                fprintf(fpBCMesg,"\n\tCmd Word 1 = 0x%04X (RT: %2d, SA:%2d, WC/MC: %2d & T/R: %d),", sbcResult[iBCMsgIndex].u16CmdWord1, u16RTAddr, u16SubAddr1, u16WC_MC,  u16TxRx);

                fprintf(fpBCMesg,"\n\tBSW = 0x%X, RT Status Word 1 = 0x%X, RT Status Word 2 = 0x%X", sbcResult[iBCMsgIndex].u16BlockStsWord, sbcResult[iBCMsgIndex].u16RTStsWord1, sbcResult[iBCMsgIndex].u16RTStsWord2);
                fprintf(fpBCMesg,"\n\tTimetag = 0x%llX ",sbcResult[iBCMsgIndex].u64TimeTagVal);
                fprintf(fpBCMesg,"(Hrs:MM:SS.ms.us.ns = %s)",szTimetag);
                fprintf(fpBCMesg,"\n\tTime to Next Msg(us) = %d, Control Word = 0x%X, Loopback Word = 0x%X",sbcResult[iBCMsgIndex].u16TimeToNextMsg, sbcResult[iBCMsgIndex].u16CtrlWord, sbcResult[iBCMsgIndex].u16LoopbackWord);
                fprintf(fpBCMesg,"\n\tData Word(s) : ");

                if(u16SubAddr1 != 0 && u16SubAddr1 != 31) // Non-mode code data
                {
                    for(iloop=0; iloop < sbcResult[iBCMsgIndex].u16WordCount; iloop++)
                    {
                        if(((iloop)%8) == 0)
                        {
                            fprintf(fpBCMesg,"\n\t  ");
                        }
                        fprintf(fpBCMesg,"0x%04X ",sbcResult[iBCMsgIndex].u16Data[iloop]);
                    }
                }
                else
                {
                    if(u16WC_MC >= 16 && u16WC_MC <= 21) // MC with data
                    {
                        fprintf(fpBCMesg,"0x%04X ",sbcResult[iBCMsgIndex].u16Data[0]);
                    }
                    else
                    {
                        fprintf(fpBCMesg, "NA");
                    }
                }
                uiMsgCount++;
                fflush(fpBCMesg);
            }
        }
        m_iBCmsgCnt = uiMsgCount;
    }

//    qDebug("\n\n\t<< %d Messages Extracted to %s >>\n", uiMsgCount, szFileName);

    if(fpBCMesg)
    {
        fclose(fpBCMesg);
        fpBCMesg = NULL;
    }

    return ;
}

int GetTimeFromTimetag(U64BIT in_u64Timetag, U16BIT in_u16TTRes, S_APP_TIMETAG_TIME *out_pTime, char *out_pszTime)
{
    double fResUs[] ={64.0, 32.0, 16.0, 8.0, 4.0, 2.0, 1.0, 0.5, 0.1, 0.0, 0.0};
    long double dTotalTime_us = 0.0;
    double fTimetag_ns;
    double fTimetag_us;
    unsigned long ulTimetag_ms = 0, ulTimetag_s = 0, ulTimetag_min = 0, ulTimetag_hr = 0;

    if(out_pTime)
    {
        memset(out_pTime, 0, sizeof(S_APP_TIMETAG_TIME));
    }
    if(in_u16TTRes > 10)
    {
        printf("\n\t Invalid Timetag Resolution.");
        return -1;
    }

    dTotalTime_us = in_u64Timetag * fResUs[in_u16TTRes];
    fTimetag_ns = (double)(dTotalTime_us - ((U64BIT)dTotalTime_us));
    fTimetag_us =  (double)((U64BIT)dTotalTime_us % 1000);
    fTimetag_us = fTimetag_us + fTimetag_ns;
    ulTimetag_ms = (double)((U64BIT)dTotalTime_us / 1000);
    ulTimetag_s = ulTimetag_ms / 1000;
    ulTimetag_ms = ulTimetag_ms % 1000;
    ulTimetag_min = ulTimetag_s / 60;
    ulTimetag_s = ulTimetag_s % 60;
    ulTimetag_hr = ulTimetag_min / 60;
    ulTimetag_min = ulTimetag_min % 60;
#ifdef Debug
    //printf("dTotalTime_us : %Lf fTimetag_ns: %Lf ulTimetag_ms: %Lf", dTotalTime_us,fTimetag_ns,ulTimetag_ms);
#endif

    if(out_pTime)
    {
        out_pTime->fMicroSec = fTimetag_us;
        out_pTime->u16MilliSec = (U16BIT)ulTimetag_ms;
        out_pTime->u8Sec = (U8BIT)ulTimetag_s;
        out_pTime->u8Min = (U8BIT)ulTimetag_min;
        out_pTime->u32Hour = (U32BIT)ulTimetag_hr;
    }
    if(out_pszTime)
    {
        sprintf(out_pszTime, "%u:%02d:%02d.%03d.%07.03f", (U32BIT)ulTimetag_hr,
                (U8BIT)ulTimetag_min, (U8BIT)ulTimetag_s, (U16BIT)ulTimetag_ms, fTimetag_us);

//        out_qsTime->sprintf("%u:%02d:%02d.%03d.%07.03f", (U32BIT)ulTimetag_hr,
//                (U8BIT)ulTimetag_min, (U8BIT)ulTimetag_s, (U16BIT)ulTimetag_ms, fTimetag_us);
#ifdef Debug
        //printf("out_pszTime : %s\n", out_pszTime);
#endif
    }
    return 0;
}

C_RT_READ_THREAD::C_RT_READ_THREAD(unsigned short usChannelNo, QString in_1553BLogDir)
{
    m_usChannelNo = usChannelNo;
    m_S_pMRT_Config.u8RTNumber = 0;
    m_S_pMRT_Config.u8RTType = 0;
    m_qs1553BLogDir = in_1553BLogDir;
}

void C_RT_READ_THREAD::Start()
{
    if(!isRunning())
    {
        m_bFlagStartStop = true;

        start(QThread::HighestPriority);
    }
}

void C_RT_READ_THREAD::Stop()
{
    m_bFlagStartStop = false;
}

void C_RT_READ_THREAD::run()
{
    char szTimetag[256] = "";
    char szErrStr[256] = "";
    char szFileName[256] = "";
    unsigned short usNoofmsgsread=0, usMsgToRead = 256, usAvailMsgs = 0;
    U16BIT u16RTAddr = 0, u16SubAddr1 = 0, u16SubAddr2 = 0, u16WC_MC = 0, u16WC_MC2 = 0,  u16TxRx = 0;
    unsigned int uiMsgCount = 0;
    m_iRTmsgCnt = 0;
    int iloop = 0;
    int iBCMsgIndex = 0;
    int iRetVal = 0;
    SDP1553BXT_RT_MSG sRTResult[256] ;
    FILE *fpBCMesg = NULL;
    memset(sRTResult, 0, sizeof(SDP1553BXT_RT_MSG) * 256);

    QString qsFileName;
    QString qsLogDirPath;
    qsLogDirPath = m_qs1553BLogDir+DP_LINS_REPORT_1553B_ASYNC_DIR+"/CH"+ QString::number(m_usChannelNo + 1)+"_Async";
    QDir dir(qsLogDirPath);
    if(!dir.exists())
    {
        dir.mkpath(qsLogDirPath);
    }

    qsFileName = qsLogDirPath + "/CH"+ QString::number(m_usChannelNo + 1)+"_RTLogFile.txt";
    strncpy(szFileName, qsFileName.toStdString().c_str(), qsFileName.count());

    fpBCMesg = fopen(szFileName, "w");
    if(!fpBCMesg)
    {
        qDebug("\n\t\t Error in opening RT Log Messages file\n");
        return;
    }

    //	printf("\n");
    while(m_bFlagStartStop)
    {
        unsigned int uiWaitTime = 0;
        unsigned int uiEventStatus = 0;
        iRetVal = m_pobj1553WrRT->DP1553B_RT_WaitForEvents(m_usChannelNo, 1, DP1553BXT_EVT_OPT_WAIT_ANY, &uiWaitTime, &uiEventStatus);
        if(iRetVal == 0)
        {
//qDebug() << "BC Running" << uiEventStatus;
        }
//        qDebug() << "running";
        iRetVal = m_pobj1553WrRT->DP1553B_RT_ReadMessage(m_usChannelNo,sRTResult,usMsgToRead,&usAvailMsgs, NULL, &m_S_pMRT_Config);
        if(iRetVal)
        {
//            m_pobj1553Wr->DP1553BXT_GetErrorMessage(iRetVal, szErrStr, sizeof(szErrStr));
//            printf("\n\t\tDriver Error: %s \n", szErrStr);
        }
        //printf("usNoofmsgsread :%d\n", usNoofmsgsread);
        if(usAvailMsgs)
        {
//            qDebug("\n\n\tTotal BC Message Exchanges (INTR) = %6d ( Last read: %4d ) ChannelNo :%d \n ",uiMsgCount+1, usNoofmsgsread, m_usChannelNo+1);

            for(iBCMsgIndex = 0; iBCMsgIndex < usAvailMsgs; iBCMsgIndex++)
            {
                GetTimeFromTimetag(sRTResult[iBCMsgIndex].u64TimeTag, sRTResult[iBCMsgIndex].u16TimetagRes, NULL, szTimetag);
                fprintf(fpBCMesg,"\n\n---------- Message No.: %d ----------", uiMsgCount+1);
                DP1553BXT_GET_CMD_WORD(sRTResult[iBCMsgIndex].u16CmdWord, u16RTAddr, u16SubAddr1, u16WC_MC,  u16TxRx );
                fprintf(fpBCMesg,"\n\tCmd Word 1 = 0x%04X (RT: %2d, SA:%2d, WC/MC: %2d & T/R: %d),", sRTResult[iBCMsgIndex].u16CmdWord, u16RTAddr, u16SubAddr1, u16WC_MC,  u16TxRx);

                fprintf(fpBCMesg,"\n\tBSW = 0x%X, RT Status Word = 0x%X", sRTResult[iBCMsgIndex].u16BlockStsWord, sRTResult[iBCMsgIndex].u16CmdWord);
                fprintf(fpBCMesg,"\n\tTimetag = 0x%llX ",sRTResult[iBCMsgIndex].u64TimeTag);
                fprintf(fpBCMesg,"(Hrs:MM:SS.ms.us.ns = %s)",szTimetag);
                fprintf(fpBCMesg,"\n\tData Word(s) : ");

                if(u16SubAddr1 != 0 && u16SubAddr1 != 31) // Non-mode code data
                {
                    for(iloop=0; iloop < sRTResult[iBCMsgIndex].u16WordCount; iloop++)
                    {
                        if(((iloop)%8) == 0)
                        {
                            fprintf(fpBCMesg,"\n\t  ");
                        }
                        fprintf(fpBCMesg,"0x%04X ",sRTResult[iBCMsgIndex].u16Data[iloop]);
                    }
                }
                else
                {
                    if(u16WC_MC >= 16 && u16WC_MC <= 21) // MC with data
                    {
                        fprintf(fpBCMesg,"0x%04X ",sRTResult[iBCMsgIndex].u16Data[0]);
                    }
                    else
                    {
                        fprintf(fpBCMesg, "NA");
                    }
                }
                uiMsgCount++;
                fflush(fpBCMesg);
            }
        }
        m_iRTmsgCnt = uiMsgCount;
    }

//    qDebug("\n\n\t<< %d Messages Extracted to %s >>\n", uiMsgCount, szFileName);

    if(fpBCMesg)
    {
        fclose(fpBCMesg);
        fpBCMesg = NULL;
    }

    return ;
}

C_MT_READ_THREAD::C_MT_READ_THREAD(unsigned short usChannelNo, unsigned short usMTNo, QString in_1553BLogDir)
{
    m_usChannelNo = usChannelNo;
    m_usMTNo = usMTNo;
    m_qs1553BLogDir = in_1553BLogDir;
}

void C_MT_READ_THREAD::Start()
{
    if(!isRunning())
    {
        m_bFlagStartStop = true;

        start(QThread::HighestPriority);
    }
}

void C_MT_READ_THREAD::Stop()
{
    m_bFlagStartStop = false;
}

void C_MT_READ_THREAD::run()
{
    char szTimetag[256] = "";
    char szErrStr[256] = "";
    char szFileName[256] = "";
    unsigned short usNoofmsgsread=0, usMsgToRead = 256, usAvailMsgs = 0;
    U16BIT u16RTAddr = 0, u16SubAddr1 = 0, u16SubAddr2 = 0, u16WC_MC = 0, u16WC_MC2 = 0,  u16TxRx = 0;
    unsigned int uiMsgCount = 0;
    int iloop = 0;
    int iBCMsgIndex = 0;
    int iRetVal = 0;
    SDP1553BXT_MT_MSG sMTResult[256] ;
    FILE *fpBCMesg = NULL;
    memset(sMTResult, 0, sizeof(SDP1553BXT_MT_MSG) * 256);

    QString qsFileName;
    QString qsLogDirPath;
    qsLogDirPath = m_qs1553BLogDir+DP_LINS_REPORT_1553B_ASYNC_DIR+"/CH"+ QString::number(m_usChannelNo + 1)+"_Async";
    QDir dir(qsLogDirPath);
    if(!dir.exists())
    {
        dir.mkpath(qsLogDirPath);
    }

    qsFileName = qsLogDirPath + "/CH"+ QString::number(m_usChannelNo + 1)+"_MTLogFile.txt";
    strncpy(szFileName, qsFileName.toStdString().c_str(), qsFileName.count());

    fpBCMesg = fopen(szFileName, "w");
    if(!fpBCMesg)
    {
        qDebug("\n\t\t Error in opening MT Log Messages file\n");
        return;
    }

    //	printf("\n");
    while(m_bFlagStartStop)
    {
        unsigned int uiWaitTime = 0;
        unsigned int uiEventStatus = 0;
        iRetVal = m_pobj1553WrMT->DP1553B_MT_WaitForEvents(m_usChannelNo, 1, DP1553BXT_EVT_OPT_WAIT_ANY, &uiWaitTime, &uiEventStatus);
        if(iRetVal == 0)
        {
//qDebug() << "BC Running" << uiEventStatus;
        }
//        qDebug() << "running";
        iRetVal = m_pobj1553WrMT->DP1553B_MT_ReadMessage(m_usChannelNo,1,NULL,sMTResult, &usAvailMsgs);
        if(iRetVal)
        {
//            m_pobj1553Wr->DP1553BXT_GetErrorMessage(iRetVal, szErrStr, sizeof(szErrStr));
//            printf("\n\t\tDriver Error: %s \n", szErrStr);
        }
        //printf("usNoofmsgsread :%d\n", usNoofmsgsread);
        if(usAvailMsgs)
        {
//            qDebug("\n\n\tTotal BC Message Exchanges (INTR) = %6d ( Last read: %4d ) ChannelNo :%d \n ",uiMsgCount+1, usNoofmsgsread, m_usChannelNo+1);

            for(iBCMsgIndex = 0; iBCMsgIndex < usAvailMsgs; iBCMsgIndex++)
            {
                GetTimeFromTimetag(sMTResult[iBCMsgIndex].u64TimeTag, sMTResult[iBCMsgIndex].u16TimetagRes, NULL, szTimetag);
                fprintf(fpBCMesg,"\n\n---------- Message No.: %d ----------", uiMsgCount+1);
                DP1553BXT_GET_CMD_WORD(sMTResult[iBCMsgIndex].u16CmdWord1, u16RTAddr, u16SubAddr1, u16WC_MC,  u16TxRx );
                fprintf(fpBCMesg,"\n\tCmd Word 1 = 0x%04X (RT: %2d, SA:%2d, WC/MC: %2d & T/R: %d),", sMTResult[iBCMsgIndex].u16CmdWord1, u16RTAddr, u16SubAddr1, u16WC_MC,  u16TxRx);

                fprintf(fpBCMesg,"\n\tBSW = 0x%X, RT Status Word 1 = 0x%X, RT Status Word 2 = 0x%X", sMTResult[iBCMsgIndex].u16BlockStatusWord, sMTResult[iBCMsgIndex].u16RTStsWrd1, sMTResult[iBCMsgIndex].u16RTStsWrd2);
                fprintf(fpBCMesg,"\n\tTimetag = 0x%llX ",sMTResult[iBCMsgIndex].u64TimeTag);
                fprintf(fpBCMesg,"(Hrs:MM:SS.ms.us.ns = %s)",szTimetag);
                fprintf(fpBCMesg,"\n\tData Word(s) : ");

                if(u16SubAddr1 != 0 && u16SubAddr1 != 31) // Non-mode code data
                {
                    for(iloop=0; iloop < 30; iloop++)
                    {
                        if(((iloop)%8) == 0)
                        {
                            fprintf(fpBCMesg,"\n\t  ");
                        }
                        fprintf(fpBCMesg,"0x%04X ",sMTResult[iBCMsgIndex].u16Data[iloop]);
                    }
                }
                else
                {
                    if(u16WC_MC >= 16 && u16WC_MC <= 21) // MC with data
                    {
                        fprintf(fpBCMesg,"0x%04X ",sMTResult[iBCMsgIndex].u16Data[0]);
                    }
                    else
                    {
                        fprintf(fpBCMesg, "NA");
                    }
                }
                uiMsgCount++;
                fflush(fpBCMesg);
            }
        }
    }


//    qDebug("\n\n\t<< %d Messages Extracted to %s >>\n", uiMsgCount, szFileName);

    if(fpBCMesg)
    {
        fclose(fpBCMesg);
        fpBCMesg = NULL;
    }

    return ;
}
