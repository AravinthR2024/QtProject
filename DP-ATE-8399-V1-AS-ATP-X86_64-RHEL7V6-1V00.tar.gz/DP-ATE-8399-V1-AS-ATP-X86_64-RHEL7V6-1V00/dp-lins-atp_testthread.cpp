/*******************************************************************************
 File Name    : dp-lins-atp_Testthread.cpp
 Author       : Manikandan K
 Created Date : Mar 11,2019
 Description  : Test Thread function definitions.
*******************************************************************************/

/*******************************************************************************
 Company Name : DATA PATTERNS INDIA PRIVATE LIMITED
 Address      : No. H9,4th MainRoad,SIPCOT IT Park,Siruseri,Chennai-603103
 Email        : support@datapatterns.co.in
 Phone        : +91 44 47414000
 Fax          : +91 44 47414444
*******************************************************************************/

/******************************************************************************
 Copyright (c) 2019 DATA PATTERNS

 All rights reserved. These materials are confidential and proprietary to
 DATA PATTERNS and no part of these materials should be reproduced or published
 in any form by any means, electronic or mechanical, including photocopy, on any
 information storage or retrieval system, nor should the materials be disclosed
 to third parties without the explicit written authorization of DATA PATTERNS.

*******************************************************************************/

#include "dp-lins-atp_testthread.h"
#include "dp-lins-atp_mainwindow.h"

extern int g_iCnt;

CTestThread::CTestThread()
{
    m_iCountIndex = 0;
    m_iCombinedModeSNO = 0;
    m_iTermiChnCombination = 0;

    m_iRS485TestPassCnt = 0;
    m_iAsyncChnTestPassCnt = 0;
    m_iTerminalChnTestPassCnt = 0;
    m_iCombinedChnTestPassCnt = 0;

    m_bSyncTestSts = false;
    m_bPwrRatingNotSet = true;
}

void CTestThread :: Start(bool in_bTestType)
{
    m_bTestTypeAuto = in_bTestType;
    m_bTestStop = false;
    start(QThread::HighPriority);
}

void CTestThread :: Stop()
{
    m_bTestStop = true;

    msleep(100);

    if(isRunning())
    {
        closeReport();

        terminate();
    }
}

void CTestThread::readPowerRating(int in_iPSUIdx)
{
    if(m_bPwrRatingNotSet)
    {
        int iRetval = m_obj_CPSUWrapper->DP_PSU_PowerRating(in_iPSUIdx + 1);
        if(iRetval)
        {
            sprintf(m_errString,"PSU%d : PSU Voltage-Current Configuration failed", in_iPSUIdx+1);
            emit Sig_PrintLog (m_errString, MSGTYPE_ERROR);
        }
        m_bPwrRatingNotSet = false;
        msleep(DP_PSU_RESTTIME);
    }
}

void CTestThread :: run()
{
    int iRetVal = 0;
    int iRetVal2 = 0;
    m_iSyncSNOTestNo = 0;
    int iChannelSel =0;
    int iResult = 0;
    int iCommType = 0;
    bool bCOSSts = true;
    QString qsDispInfo = "";

    m_fLLSloadImpedance = 14.0;/*Need to remove after adding impedance value in configuration file and to be updated in ReadConfig function*/


    do{
        if(m_bTestTypeAuto)
        {
            initReport();
            m_iCountIndex = 0;
            m_iTestStart = 1;
            m_iNextChnStartTest = 1;

            if(m_ucMainTestCaseSelection[0] || m_ucMainTestCaseSelection[1] || m_ucMainTestCaseSelection[2] || \
                    m_ucMainTestCaseSelection[3] || m_ucMainTestCaseSelection[4])
            {
                m_obj_CPSUWrapper->DP_PSU_Open("ttyS0", m_stAutomodeIp.usCOM1_Baudrate, m_stAutomodeIp.ucCOM1_StopBit, m_stAutomodeIp.ucCOM1_DataBit, m_stAutomodeIp.ucCOM1_Parity);

                iRetVal = StartStopADCAcquisition(START_ACQUISITION);
                if(!iRetVal)
                {
                    emit Sig_PrintLog("Unable to Start ADC Acquisition", Failure);
                    break;
                }

                emit Sig_MsgBox("Kindly ensure that the COS POWER SUPPLY is switched ON", MSGTYPE_INFO);

                bCOSSts = COSPowerON();
                if(!bCOSSts)
                {
                    emit Sig_PrintLog("Unable to Power ON COS Relay.", Failure);
                    break;
                }

                emit Sig_MsgBox("Kindly ensure that Power Supply(s) is(are) Switched ON corresponding to selected test cases", MSGTYPE_INFO);

                if(m_ucTestSelect[DP_J1_PSU1_OUT1_Test] || m_ucTestSelect[DP_J1_PSU1_OUT2_Test] || \
                        m_ucTestSelect[DP_J1_PSU1_DEMG_Test] || m_ucTestSelect[DP_J1_PSU_TELE_CMD_Test] || \
                        m_ucTestSelect[DP_J1_TELECOMMAND_Test] || m_ucTestSelect[DP_J1_THERMISTORCH1] || \
                        m_ucTestSelect[DP_J1_THERMISTORCH2] || m_ucTestSelect[DP_J1_THERMISTORCH3] || \
                        m_ucTestSelect[DP_J1_THERMISTORCH4])
                {
                    qsDispInfo.sprintf("Kindly ensure circular connector <b>P-123</b> is Connected to <b>J1</b> of the system.");
                    emit Sig_MsgBox(qsDispInfo,MSGTYPE_QUEST);

                    if(!m_bJigConnected)
                    {
                        emit Sig_PrintLog("Circular connector P-123 is Not-Connected to J1 of the system.", MSGTYPE_ERROR);
                    }
                    else
                    {
                        if(m_ucTestSelect[DP_J1_PSU1_OUT1_Test] || \
                                m_ucTestSelect[DP_J1_PSU1_OUT2_Test] || \
                                m_ucTestSelect[DP_J1_PSU1_DEMG_Test])
                        {
                            readPowerRating(0);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J1_PSU1_OUT1_Test] == LINSCM_ENABLE))
                        {
                            iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J1_PSU1_OUT1_Test);
                            emit Sig_PrintLog("J1 PSU1-Ch01 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_PSU, MSGTYPE_TEXT);

                            reportAddSection(DP_J1_PSU1_OUT1_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[0], DP_J1_PSU1_OUT1_Test);
                            m_SReportData.m_iTestCaseId = DP_J1_PSU1_OUT1_Test;
                            DP_LINS_PowerControlTest(0, 0, &iResult);
                            DP_LINS_PowerControlReset(0, 0);
                            reportFinishTable();

                            emit Sig_PrintLog("J1 PSU1-Ch01 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J1_PSU1_OUT1_Test,(bool)iResult);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J1_PSU1_OUT2_Test] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J1_PSU1_OUT2_Test);
                            emit Sig_PrintLog("J1 PSU1-Ch02 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_PSU, MSGTYPE_TEXT);

                            reportAddSection(DP_J1_PSU1_OUT2_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[0], DP_J1_PSU1_OUT2_Test);
                            m_SReportData.m_iTestCaseId = DP_J1_PSU1_OUT2_Test;
                            DP_LINS_PowerControlTest(0, 1, &iResult);
                            DP_LINS_PowerControlReset(0, 1);
                            reportFinishTable();

                            emit Sig_PrintLog("J1 PSU1-Ch02 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J1_PSU1_OUT2_Test,(bool)iResult);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J1_PSU1_DEMG_Test] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J1_PSU1_DEMG_Test);
                            emit Sig_PrintLog("J1 PSU1-Ch03 Test Completed", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_PSU, MSGTYPE_TEXT);

                            reportAddSection(DP_J1_PSU1_DEMG_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[0], DP_J1_PSU1_DEMG_Test);
                            m_SReportData.m_iTestCaseId = DP_J1_PSU1_DEMG_Test;
                            DP_LINS_PowerControlTest(0, 2, &iResult);
                            DP_LINS_PowerControlReset(0, 2);
                            reportFinishTable();

                            emit Sig_PrintLog("J1 PSU1-Ch03 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J1_PSU1_DEMG_Test,(bool)iResult);
                        }

                        if(m_ucTestSelect[DP_J1_PSU_TELE_CMD_Test] || m_ucTestSelect[DP_J1_TELECOMMAND_Test])
                        {
                            readPowerRating(3);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J1_PSU_TELE_CMD_Test] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J1_PSU_TELE_CMD_Test);
                            emit Sig_PrintLog("J1 Telecommand PSU Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_TELECMD_PSU, MSGTYPE_TEXT);

                            reportAddSection(DP_J1_PSU_TELE_CMD_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[0], DP_J1_PSU_TELE_CMD_Test);
                            m_SReportData.m_iTestCaseId = DP_J1_PSU_TELE_CMD_Test;
                            DP_LINS_TeleCmdPSUTest(3, 0, &iResult);
                            DP_LINS_PowerControlReset(3, 0);
                            reportFinishTable();

                            emit Sig_PrintLog("J1 Telecommand PSU Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J1_PSU_TELE_CMD_Test,(bool)iResult);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J1_TELECOMMAND_Test] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            int iOverallResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J1_TELECOMMAND_Test);
                            emit Sig_PrintLog("J1 Telecommand Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_TELECMD, MSGTYPE_TEXT);

                            m_SReportData.m_iTestCaseId = DP_J1_TELECOMMAND_Test;
                            m_SReportData.m_iSubTestId = 0;
                            reportAddSection(DP_J1_TELECOMMAND_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[0], DP_J1_TELECOMMAND_Test);
                            DP_LINS_TeleCmdTest(3, 0, &iResult);
                            reportFinishTable();
                            iOverallResult = iResult;
                            sleep(1);

                            emit Sig_PrintLog(LOG_HEADER_TELECMD_READBACK, MSGTYPE_TEXT);
                            m_SReportData.m_iTestCaseId = DP_J1_TELECOMMAND_Test;
                            m_SReportData.m_iSubTestId = 1;
                            reportAddSection(DP_J1_TELECOMMAND_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[0], DP_REPORT_TC_STS_READBACK);
                            DP_LINS_TeleCmdStsReadbackTest(3, 0, &iResult);
                            reportFinishTable();
                            iOverallResult |= iResult;

                            emit Sig_PrintLog("J1 Telecommand Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J1_TELECOMMAND_Test,(bool)iOverallResult);
                        }

                        if(m_ucTestSelect[DP_J1_THERMISTORCH1] || m_ucTestSelect[DP_J1_THERMISTORCH2] || \
                                m_ucTestSelect[DP_J1_THERMISTORCH3] || m_ucTestSelect[DP_J1_THERMISTORCH4])
                        {
                            qsDispInfo.sprintf("Connect the D-Type Connector <b>PL1</b> of JIG1 to <b>SK12</b> of the Test-Rig");
                            emit Sig_MsgBox(qsDispInfo,MSGTYPE_INFO);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J1_THERMISTORCH1] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J1_THERMISTORCH1);
                            emit Sig_PrintLog ("J1 Thermistor-Ch01 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_THERMISTOR, MSGTYPE_TEXT);

                            reportAddSection(DP_J1_THERMISTORCH1, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[0], DP_J1_THERMISTORCH1);
                            m_SReportData.m_iTestCaseId = DP_J1_THERMISTORCH1;
                            DP_LINS_ThermistorTest (TH_BRD1_CH1, 0, 1, &iResult);
                            reportFinishTable();

                            emit Sig_PrintLog ("J1 Thermistor-Ch01 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J1_THERMISTORCH1,(bool)iResult);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J1_THERMISTORCH2] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J1_THERMISTORCH2);
                            emit Sig_PrintLog ("J1 Thermistor-Ch02 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_THERMISTOR, MSGTYPE_TEXT);

                            if(!m_ucTestSelect[DP_J1_THERMISTORCH1])
                            {
                                reportAddSection(DP_J1_THERMISTORCH2, m_iCountIndex);
                            }
                            reportInsertTable((int)m_bPSU_LoadSelect[0], DP_J1_THERMISTORCH2);
                            m_SReportData.m_iTestCaseId = DP_J1_THERMISTORCH2;
                            DP_LINS_ThermistorTest (TH_BRD1_CH2, 0, 2, &iResult);
                            reportFinishTable();

                            emit Sig_PrintLog ("J1 Thermistor-Ch02 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J1_THERMISTORCH2,(bool)iResult);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J1_THERMISTORCH3] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J1_THERMISTORCH3);
                            emit Sig_PrintLog ("J1 Thermistor-Ch03 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_THERMISTOR, MSGTYPE_TEXT);

                            if(!(m_ucTestSelect[DP_J1_THERMISTORCH1] || m_ucTestSelect[DP_J1_THERMISTORCH2]))
                            {
                                reportAddSection(DP_J1_THERMISTORCH3, m_iCountIndex);
                            }
                            reportInsertTable((int)m_bPSU_LoadSelect[0], DP_J1_THERMISTORCH3);
                            m_SReportData.m_iTestCaseId = DP_J1_THERMISTORCH3;
                            DP_LINS_ThermistorTest (TH_BRD1_CH3, 0, 3, &iResult);
                            reportFinishTable();

                            emit Sig_PrintLog ("J1 Thermistor-Ch03 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J1_THERMISTORCH3,(bool)iResult);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J1_THERMISTORCH4] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J1_THERMISTORCH4);
                            emit Sig_PrintLog ("J1 Thermistor-Ch04 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_THERMISTOR, MSGTYPE_TEXT);

                            if(!(m_ucTestSelect[DP_J1_THERMISTORCH1] || m_ucTestSelect[DP_J1_THERMISTORCH2] ||m_ucTestSelect[DP_J1_THERMISTORCH3]))
                            {
                                reportAddSection(DP_J1_THERMISTORCH4, m_iCountIndex);
                            }
                            reportInsertTable((int)m_bPSU_LoadSelect[0], DP_J1_THERMISTORCH4);
                            m_SReportData.m_iTestCaseId = DP_J1_THERMISTORCH4;
                            DP_LINS_ThermistorTest (TH_BRD2_CH1, 0, 4, &iResult);
                            reportFinishTable();

                            emit Sig_PrintLog ("J1 Thermistor-Ch04 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J1_THERMISTORCH4,(bool)iResult);
                        }
                    }
                }

                if(m_ucTestSelect[DP_J2_PSU2_OUT1_Test] || m_ucTestSelect[DP_J2_PSU2_OUT2_Test] || \
                        m_ucTestSelect[DP_J2_PSU2_DEMG_Test] || m_ucTestSelect[DP_J2_PSU_TELE_CMD_Test] || \
                        m_ucTestSelect[DP_J2_TELECOMMAND_Test] || m_ucTestSelect[DP_J2_THERMISTORCH1] || \
                        m_ucTestSelect[DP_J2_THERMISTORCH2] || m_ucTestSelect[DP_J2_THERMISTORCH3] || \
                        m_ucTestSelect[DP_J2_THERMISTORCH4])
                {
                    qsDispInfo.sprintf("Kindly ensure circular connector <b>P-123</b> is Connected to <b>J2</b> of the system.");
                    emit Sig_MsgBox(qsDispInfo,MSGTYPE_QUEST);

                    if(!m_bJigConnected)
                    {
                        emit Sig_PrintLog("Circular connector P-123 is Not-Connected to J2 of the system.", MSGTYPE_ERROR);
                    }
                    else
                    {
                        if(m_ucTestSelect[DP_J2_PSU2_OUT1_Test] || \
                                m_ucTestSelect[DP_J2_PSU2_OUT2_Test] || \
                                m_ucTestSelect[DP_J2_PSU2_DEMG_Test])
                        {
                            readPowerRating(1);
                        }
                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J2_PSU2_OUT1_Test] == LINSCM_ENABLE))
                        {
                            iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J2_PSU2_OUT1_Test);
                            emit Sig_PrintLog("J2 PSU2-Ch01 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_PSU, MSGTYPE_TEXT);

                            reportAddSection(DP_J2_PSU2_OUT1_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[1], DP_J2_PSU2_OUT1_Test);
                            m_SReportData.m_iTestCaseId = DP_J2_PSU2_OUT1_Test;
                            DP_LINS_PowerControlTest(1, 0, &iResult);
                            DP_LINS_PowerControlReset(1, 0);
                            reportFinishTable();

                            emit Sig_PrintLog("J2 PSU2-Ch01 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J2_PSU2_OUT1_Test,(bool)iResult);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J2_PSU2_OUT2_Test] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J2_PSU2_OUT2_Test);
                            emit Sig_PrintLog("J2 PSU2-Ch02 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_PSU, MSGTYPE_TEXT);

                            reportAddSection(DP_J2_PSU2_OUT2_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[1], DP_J2_PSU2_OUT2_Test);
                            m_SReportData.m_iTestCaseId = DP_J2_PSU2_OUT2_Test;
                            DP_LINS_PowerControlTest(1, 1, &iResult);
                            DP_LINS_PowerControlReset(1, 1);
                            reportFinishTable();

                            emit Sig_PrintLog("J2 PSU2-Ch02 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J2_PSU2_OUT2_Test,(bool)iResult);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J2_PSU2_DEMG_Test] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J2_PSU2_DEMG_Test);
                            emit Sig_PrintLog("J2 PSU2-Ch03 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_PSU, MSGTYPE_TEXT);

                            reportAddSection(DP_J2_PSU2_DEMG_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[1], DP_J2_PSU2_DEMG_Test);
                            m_SReportData.m_iTestCaseId = DP_J2_PSU2_DEMG_Test;
                            DP_LINS_PowerControlTest(1, 2, &iResult);
                            DP_LINS_PowerControlReset(1, 2);
                            reportFinishTable();

                            emit Sig_PrintLog("J2 PSU2-Ch03 Test Completed", MSGTYPE_INFO);
                            emit SigTestResult(DP_J2_PSU2_DEMG_Test,(bool)iResult);
                        }

                        if(m_ucTestSelect[DP_J2_PSU_TELE_CMD_Test] || m_ucTestSelect[DP_J2_TELECOMMAND_Test])
                        {
                            readPowerRating(3);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J2_PSU_TELE_CMD_Test] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J2_PSU_TELE_CMD_Test);
                            emit Sig_PrintLog("J2 Telecommand PSU Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_TELECMD_PSU, MSGTYPE_TEXT);

                            reportAddSection(DP_J2_PSU_TELE_CMD_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[1], DP_J2_PSU_TELE_CMD_Test);
                            m_SReportData.m_iTestCaseId = DP_J2_PSU_TELE_CMD_Test;
                            DP_LINS_TeleCmdPSUTest(3, 1, &iResult);
                            DP_LINS_PowerControlReset(3, 1);
                            reportFinishTable();

                            emit Sig_PrintLog("J2 Telecommand PSU Test Completed", MSGTYPE_INFO);
                            emit SigTestResult(DP_J2_PSU_TELE_CMD_Test,(bool)iResult);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J2_TELECOMMAND_Test] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            int iOverallResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J2_TELECOMMAND_Test);
                            emit Sig_PrintLog("J2 Telecommand Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_TELECMD, MSGTYPE_TEXT);

                            m_SReportData.m_iTestCaseId = DP_J2_TELECOMMAND_Test;
                            m_SReportData.m_iSubTestId = 0;
                            reportAddSection(DP_J2_TELECOMMAND_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[1], DP_J2_TELECOMMAND_Test);
                            DP_LINS_TeleCmdTest(3, 1, &iResult);
                            reportFinishTable();
                            iOverallResult = iResult;
                            sleep(1);

                            emit Sig_PrintLog(LOG_HEADER_TELECMD_READBACK, MSGTYPE_TEXT);
                            m_SReportData.m_iTestCaseId = DP_J2_TELECOMMAND_Test;
                            m_SReportData.m_iSubTestId = 1;
                            reportAddSection(DP_J2_TELECOMMAND_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[0], DP_REPORT_TC_STS_READBACK);
                            DP_LINS_TeleCmdStsReadbackTest(3, 1, &iResult);
                            reportFinishTable();
                            iOverallResult |= iResult;

                            emit Sig_PrintLog("J2 Telecommand Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J2_TELECOMMAND_Test,(bool)iOverallResult);
                        }


                        if(m_ucTestSelect[DP_J2_THERMISTORCH1] || m_ucTestSelect[DP_J2_THERMISTORCH2] || \
                                m_ucTestSelect[DP_J2_THERMISTORCH3] || m_ucTestSelect[DP_J2_THERMISTORCH4])
                        {
                            qsDispInfo.sprintf("Connect the D-Type Connector <b>PL1</b> of JIG1 to <b>SK12</b> of the Test-Rig");
                            emit Sig_MsgBox(qsDispInfo,MSGTYPE_INFO);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J2_THERMISTORCH1] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J2_THERMISTORCH1);
                            emit Sig_PrintLog("J2 Thermistor-Ch01 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_THERMISTOR, MSGTYPE_TEXT);

                            reportAddSection(DP_J2_THERMISTORCH1, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[1], DP_J2_THERMISTORCH1);
                            m_SReportData.m_iTestCaseId = DP_J2_THERMISTORCH1;
                            DP_LINS_ThermistorTest (TH_BRD2_CH2, 1, 1, &iResult);
                            reportFinishTable();

                            emit Sig_PrintLog ("J2 Thermistor-Ch01 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J2_THERMISTORCH1,(bool)iResult);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J2_THERMISTORCH2] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J2_THERMISTORCH2);
                            emit Sig_PrintLog("J2 Thermistor-Ch02 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_THERMISTOR, MSGTYPE_TEXT);

                            if(!m_ucTestSelect[DP_J2_THERMISTORCH1])
                            {
                                reportAddSection(DP_J2_THERMISTORCH2, m_iCountIndex);
                            }
                            reportInsertTable((int)m_bPSU_LoadSelect[1], DP_J2_THERMISTORCH2);
                            m_SReportData.m_iTestCaseId = DP_J2_THERMISTORCH2;
                            DP_LINS_ThermistorTest (TH_BRD2_CH3, 1, 2, &iResult);
                            reportFinishTable();

                            emit Sig_PrintLog ("J2 Thermistor-Ch02 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J2_THERMISTORCH2,(bool)iResult);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J2_THERMISTORCH3] == LINSCM_ENABLE) && (m_p1123Wrapper->m_u16NoOfDetBoards >= 3))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J2_THERMISTORCH3);
                            emit Sig_PrintLog("J2 Thermistor-Ch03 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_THERMISTOR, MSGTYPE_TEXT);

                            if(!(m_ucTestSelect[DP_J2_THERMISTORCH1] || m_ucTestSelect[DP_J2_THERMISTORCH2]))
                            {
                                reportAddSection(DP_J2_THERMISTORCH3, m_iCountIndex);
                            }
                            reportInsertTable((int)m_bPSU_LoadSelect[1], DP_J2_THERMISTORCH3);
                            m_SReportData.m_iTestCaseId = DP_J2_THERMISTORCH3;
                            DP_LINS_ThermistorTest (TH_BRD3_CH1, 1, 3, &iResult);
                            reportFinishTable();

                            emit Sig_PrintLog ("J2 Thermistor-Ch03 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J2_THERMISTORCH3,(bool)iResult);
                        }
                        else
                        {
                            if(m_ucTestSelect[DP_J2_THERMISTORCH3])
                            {
                                emit Sig_PrintLog ("DP-MM-1123-300 Board-3 is not detected.", MSGTYPE_ERROR);
                                emit Sig_PrintLog ("J2 Thermistor-Ch03 Test was skipped.", MSGTYPE_INFO);
                            }
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J2_THERMISTORCH4] == LINSCM_ENABLE) && (m_p1123Wrapper->m_u16NoOfDetBoards >= 3))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J2_THERMISTORCH4);
                            emit Sig_PrintLog("J2 Thermistor-Ch04 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_THERMISTOR, MSGTYPE_TEXT);

                            if(!(m_ucTestSelect[DP_J2_THERMISTORCH1] || m_ucTestSelect[DP_J2_THERMISTORCH2] \
                                 || m_ucTestSelect[DP_J2_THERMISTORCH3]))
                            {
                                reportAddSection(DP_J2_THERMISTORCH4, m_iCountIndex);
                            }
                            reportInsertTable((int)m_bPSU_LoadSelect[1], DP_J2_THERMISTORCH4);
                            m_SReportData.m_iTestCaseId = DP_J2_THERMISTORCH4;
                            DP_LINS_ThermistorTest (TH_BRD3_CH2, 1, 4, &iResult);
                            reportFinishTable();

                            emit Sig_PrintLog ("J2 Thermistor-Ch04 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J2_THERMISTORCH4,(bool)iResult);
                        }
                        else
                        {
                            if(m_ucTestSelect[DP_J2_THERMISTORCH4])
                            {
                                if(m_ucTestSelect[DP_J2_THERMISTORCH3])
                                {
                                    emit Sig_PrintLog ("DP-MM-1123-300 Board-3 is not detected.", MSGTYPE_ERROR);
                                }
                                emit Sig_PrintLog ("J2 Thermistor-Ch04 Test was skipped.", MSGTYPE_INFO);
                            }
                        }
                    }
                }

                if(m_ucTestSelect[DP_J3_PSU3_OUT1_Test] || m_ucTestSelect[DP_J3_PSU3_OUT2_Test] || \
                        m_ucTestSelect[DP_J3_PSU3_DEMG_Test] || m_ucTestSelect[DP_J3_PSU_TELE_CMD_Test] || \
                        m_ucTestSelect[DP_J3_TELECOMMAND_Test] || m_ucTestSelect[DP_J3_THERMISTORCH1] || \
                        m_ucTestSelect[DP_J3_THERMISTORCH2] || m_ucTestSelect[DP_J3_THERMISTORCH3] || \
                        m_ucTestSelect[DP_J3_THERMISTORCH4])
                {
                    qsDispInfo.sprintf("Kindly ensure circular connector <b>P-123</b> is Connected to J3 of the system.");
                    emit Sig_MsgBox(qsDispInfo,MSGTYPE_QUEST);

                    if(!m_bJigConnected)
                    {
                        emit Sig_PrintLog("Circular connector P-123 is Not-Connected to J3 of the system.", MSGTYPE_ERROR);
                    }
                    else
                    {
                        if(m_ucTestSelect[DP_J3_PSU3_OUT1_Test] || \
                                m_ucTestSelect[DP_J3_PSU3_OUT2_Test] || \
                                m_ucTestSelect[DP_J3_PSU3_DEMG_Test])
                        {
                            readPowerRating(2);
                        }
                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J3_PSU3_OUT1_Test] == LINSCM_ENABLE))
                        {
                            iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J3_PSU3_OUT1_Test);
                            emit Sig_PrintLog("J3 PSU3-Ch01 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_PSU, MSGTYPE_TEXT);

                            reportAddSection(DP_J3_PSU3_OUT1_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[2], DP_J3_PSU3_OUT1_Test);
                            m_SReportData.m_iTestCaseId = DP_J3_PSU3_OUT1_Test;
                            DP_LINS_PowerControlTest(2, 0, &iResult);
                            DP_LINS_PowerControlReset(2, 0);
                            reportFinishTable();

                            emit Sig_PrintLog("J3 PSU3-Ch01 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J3_PSU3_OUT1_Test,(bool)iResult);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J3_PSU3_OUT2_Test] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J3_PSU3_OUT2_Test);
                            emit Sig_PrintLog("J3 PSU3-Ch02 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_PSU, MSGTYPE_TEXT);

                            reportAddSection(DP_J3_PSU3_OUT2_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[2], DP_J3_PSU3_OUT2_Test);
                            m_SReportData.m_iTestCaseId = DP_J3_PSU3_OUT2_Test;
                            DP_LINS_PowerControlTest(2, 1, &iResult);
                            DP_LINS_PowerControlReset(2, 1);
                            reportFinishTable();

                            emit Sig_PrintLog("J3 PSU3-Ch02 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J3_PSU3_OUT2_Test,(bool)iResult);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J3_PSU3_DEMG_Test] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J3_PSU3_DEMG_Test);
                            emit Sig_PrintLog("J3 PSU3-Ch03 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_PSU, MSGTYPE_TEXT);

                            reportAddSection(DP_J3_PSU3_DEMG_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[2], DP_J3_PSU3_DEMG_Test);
                            m_SReportData.m_iTestCaseId = DP_J3_PSU3_DEMG_Test;
                            DP_LINS_PowerControlTest(2, 2, &iResult);
                            DP_LINS_PowerControlReset(2, 2);
                            reportFinishTable();

                            emit Sig_PrintLog("J3 PSU3-Ch03 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J3_PSU3_DEMG_Test,(bool)iResult);
                        }

                        if(m_ucTestSelect[DP_J3_PSU_TELE_CMD_Test] || m_ucTestSelect[DP_J3_TELECOMMAND_Test])
                        {
                            readPowerRating(3);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J3_PSU_TELE_CMD_Test] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J3_PSU_TELE_CMD_Test);
                            emit Sig_PrintLog("J3 PSU Telecommand Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_TELECMD_PSU, MSGTYPE_TEXT);

                            reportAddSection(DP_J3_PSU_TELE_CMD_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[2], DP_J3_PSU_TELE_CMD_Test);
                            m_SReportData.m_iTestCaseId = DP_J3_PSU_TELE_CMD_Test;
                            DP_LINS_TeleCmdPSUTest(3, 2, &iResult);
                            DP_LINS_PowerControlReset(3, 2);
                            reportFinishTable();

                            emit Sig_PrintLog("J3 PSU Telecommand Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J3_PSU_TELE_CMD_Test,(bool)iResult);
                        }


                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J3_TELECOMMAND_Test] == LINSCM_ENABLE))
                        {
                            int iResult = 0;
                            int iOverallResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J3_TELECOMMAND_Test);
                            emit Sig_PrintLog("J3 Telecommand Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_TELECMD, MSGTYPE_TEXT);

                            m_SReportData.m_iTestCaseId = DP_J3_TELECOMMAND_Test;
                            m_SReportData.m_iSubTestId = 0;
                            reportAddSection(DP_J3_TELECOMMAND_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[2], DP_J3_TELECOMMAND_Test);
                            DP_LINS_TeleCmdTest(3, 2, &iResult);
                            reportFinishTable();
                            iOverallResult = iResult;
                            sleep(1);

                            emit Sig_PrintLog(LOG_HEADER_TELECMD_READBACK, MSGTYPE_TEXT);
                            m_SReportData.m_iTestCaseId = DP_J3_TELECOMMAND_Test;
                            m_SReportData.m_iSubTestId = 1;
                            reportAddSection(DP_J3_TELECOMMAND_Test, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[0], DP_REPORT_TC_STS_READBACK);
                            DP_LINS_TeleCmdStsReadbackTest(3, 2, &iResult);
                            reportFinishTable();
                            iOverallResult |= iResult;

                            emit Sig_PrintLog("J3 Telecommand Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J3_TELECOMMAND_Test,(bool)iOverallResult);
                        }


                        if(m_ucTestSelect[DP_J3_THERMISTORCH1] || m_ucTestSelect[DP_J3_THERMISTORCH2] || \
                                m_ucTestSelect[DP_J3_THERMISTORCH3] || m_ucTestSelect[DP_J3_THERMISTORCH4])
                        {
                            qsDispInfo.sprintf("Connect the D-Type Connector <b>PL1</b> of JIG1 to <b>SK12</b> of the Test-Rig");
                            emit Sig_MsgBox(qsDispInfo,MSGTYPE_INFO);
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J3_THERMISTORCH1] == LINSCM_ENABLE) && (m_p1123Wrapper->m_u16NoOfDetBoards >= 3))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J3_THERMISTORCH1);
                            emit Sig_PrintLog("J3 Thermistor-Ch01 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_THERMISTOR, MSGTYPE_TEXT);

                            reportAddSection(DP_J3_THERMISTORCH1, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[2], DP_J3_THERMISTORCH1);
                            m_SReportData.m_iTestCaseId = DP_J3_THERMISTORCH1;
                            DP_LINS_ThermistorTest (TH_BRD3_CH3, 2, 1, &iResult);
                            reportFinishTable();

                            emit Sig_PrintLog ("J3 Thermistor-Ch01 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J3_THERMISTORCH1,(bool)iResult);
                        }
                        else
                        {
                            if(m_ucTestSelect[DP_J3_THERMISTORCH1])
                            {
                                emit Sig_PrintLog ("DP-MM-1123-300 Board-3 is not detected.", MSGTYPE_ERROR);
                                emit Sig_PrintLog ("J2 Thermistor-Ch04 Test was skipped.", MSGTYPE_INFO);
                            }
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J3_THERMISTORCH2] == LINSCM_ENABLE) && (m_p1123Wrapper->m_u16NoOfDetBoards >= 4))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J3_THERMISTORCH2);
                            emit Sig_PrintLog("J3 Thermistor-Ch02 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_THERMISTOR, MSGTYPE_TEXT);

                            if(!(m_ucTestSelect[DP_J3_THERMISTORCH1]))
                            {
                                reportAddSection(DP_J3_THERMISTORCH2, m_iCountIndex);
                            }
                            reportInsertTable((int)m_bPSU_LoadSelect[2], DP_J3_THERMISTORCH2);
                            m_SReportData.m_iTestCaseId = DP_J3_THERMISTORCH2;
                            DP_LINS_ThermistorTest (TH_BRD4_CH1, 2, 2, &iResult);
                            reportFinishTable();

                            emit Sig_PrintLog ("J3 Thermistor-Ch02 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J3_THERMISTORCH2,(bool)iResult);
                        }
                        else
                        {
                            if(m_ucTestSelect[DP_J3_THERMISTORCH2])
                            {
                                emit Sig_PrintLog ("DP-MM-1123-300 Board-4 is not detected.", MSGTYPE_ERROR);
                                emit Sig_PrintLog ("J2 Thermistor-Ch02 Test was skipped.", MSGTYPE_INFO);
                            }
                        }

                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J3_THERMISTORCH3] == LINSCM_ENABLE) && (m_p1123Wrapper->m_u16NoOfDetBoards >= 4))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J3_THERMISTORCH3);
                            emit Sig_PrintLog("J3 Thermistor-Ch03 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_THERMISTOR, MSGTYPE_TEXT);

                            if(!(m_ucTestSelect[DP_J3_THERMISTORCH1] || m_ucTestSelect[DP_J3_THERMISTORCH2]))
                            {
                                reportAddSection(DP_J3_THERMISTORCH3, m_iCountIndex);
                            }
                            reportInsertTable((int)m_bPSU_LoadSelect[2], DP_J3_THERMISTORCH3);
                            m_SReportData.m_iTestCaseId = DP_J3_THERMISTORCH3;
                            DP_LINS_ThermistorTest (TH_BRD4_CH2, 2, 3, &iResult);
                            reportFinishTable();

                            emit Sig_PrintLog ("J3 Thermistor-Ch03 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J3_THERMISTORCH3,(bool)iResult);
                        }
                        if((!m_bTestStop)&&(m_ucTestSelect[DP_J3_THERMISTORCH4] == LINSCM_ENABLE) && (m_p1123Wrapper->m_u16NoOfDetBoards >= 4))
                        {
                            int iResult = 0;
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J3_THERMISTORCH4);
                            emit Sig_PrintLog("J3 Thermistor-Ch04 Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_THERMISTOR, MSGTYPE_TEXT);

                            if(!(m_ucTestSelect[DP_J3_THERMISTORCH1] || m_ucTestSelect[DP_J3_THERMISTORCH2] \
                                 || m_ucTestSelect[DP_J3_THERMISTORCH3]))
                            {
                                reportAddSection(DP_J3_THERMISTORCH4, m_iCountIndex);
                            }
                            reportInsertTable((int)m_bPSU_LoadSelect[2], DP_J3_THERMISTORCH4);
                            m_SReportData.m_iTestCaseId = DP_J3_THERMISTORCH4;
                            DP_LINS_ThermistorTest (TH_BRD4_CH3, 2, 4, &iResult);
                            reportFinishTable();

                            emit Sig_PrintLog ("J3 Thermistor-Ch04 Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J3_THERMISTORCH4,(bool)iResult);
                        }
                    }
                }


                if(m_ucTestSelect[DP_J4_SPAREDIO_TEST])
                {
                    readPowerRating(3);

                    if((!m_bTestStop)&&(m_ucTestSelect[DP_J4_SPAREDIO_TEST] == LINSCM_ENABLE))
                    {
                        int iResult = 0;

                        qsDispInfo.sprintf("Kindly ensure circular connector <b>P4</b> of JIG2 is Connected to <b>J4</b> of the system.");
                        emit Sig_MsgBox(qsDispInfo,MSGTYPE_QUEST);

                        if(!m_bJigConnected)
                        {
                            emit Sig_PrintLog("Circular connector P4 of JIG2 is Not-Connected to J4 of the system.", MSGTYPE_ERROR);
                        }
                        else
                        {
                            m_iCountIndex++;

                            emit SigHighLightTestCase(DP_J4_SPAREDIO_TEST);
                            emit Sig_PrintLog("J4 Spare-DIO Test Started", MSGTYPE_INFO);
                            emit Sig_PrintLog(LOG_HEADER_TELECMD, MSGTYPE_TEXT);

                            reportAddSection(DP_J4_SPAREDIO_TEST, m_iCountIndex);
                            reportInsertTable((int)m_bPSU_LoadSelect[2], DP_J4_SPAREDIO_TEST);
                            m_SReportData.m_iTestCaseId = DP_J4_SPAREDIO_TEST;
                            DP_LINS_SpareDIOTest (3, 5, &iResult);
                            reportFinishTable();

                            emit Sig_PrintLog ("J4 Spare-DIO Test Completed", MSGTYPE_INFO);

                            emit SigTestResult(DP_J4_SPAREDIO_TEST,(bool)iResult);
                        }
                    }
                }

                if((!m_bTestStop)&&(m_ucTestSelect[DP_J1_PSU1_PINOUT_TEST] == LINSCM_ENABLE))
                {
                    int iResult = 0;

                    qsDispInfo.sprintf("Kindly ensure circular connector <b>J123-M</b> of JIG3 is Connected to J1 of the system and\n" \
                                       "<b>J4-M</b> of JIG3 is Connected to J4 of the system.");
                    emit Sig_MsgBox(qsDispInfo,MSGTYPE_QUEST);

                    if(!m_bJigConnected)
                    {
                        emit Sig_PrintLog("Circular connector J123 of JIG3 is Connected to J1 of the system and\n" \
                                          "J4 of JIG3 is Connected to J4 of the system.", MSGTYPE_ERROR);
                    }
                    else
                    {
                        m_iCountIndex++;

                        readPowerRating(0);

                        emit SigHighLightTestCase(DP_J1_PSU1_PINOUT_TEST);
                        emit Sig_PrintLog("J1 Powersupply Pin Validation Test Started", MSGTYPE_INFO);
                        emit Sig_PrintLog(LOG_HEADER_PINOUT, MSGTYPE_TEXT);

                        reportAddSection(DP_J1_PSU1_PINOUT_TEST, m_iCountIndex);
                        reportInsertTable((int)m_bPSU_LoadSelect[2], DP_J1_PSU1_PINOUT_TEST);
                        m_SReportData.m_iTestCaseId = DP_J1_PSU1_PINOUT_TEST;
                        DP_LINS_PSU_PinOutTest(0, 0, &iResult);
                        reportFinishTable();

                        emit Sig_PrintLog ("J1 Powersupply Pin Validation Test Completed", MSGTYPE_INFO);

                        emit SigTestResult(DP_J1_PSU1_PINOUT_TEST,(bool)iResult);
                    }
                }

                if((!m_bTestStop)&&(m_ucTestSelect[DP_J2_PSU2_PINOUT_TEST] == LINSCM_ENABLE))
                {
                    int iResult = 0;

                    qsDispInfo.sprintf("Kindly ensure circular connector <b>J123-M</b> of JIG3 is Connected to J2 of the system and\n" \
                                       "<b>J4-M</b> of JIG3 is Connected to J4 of the system.");
                    emit Sig_MsgBox(qsDispInfo,MSGTYPE_QUEST);

                    if(!m_bJigConnected)
                    {
                        emit Sig_PrintLog("Circular connector J123 of JIG3 is Connected to J2 of the system and\n" \
                                          "J4 of JIG3 is Connected to J4 of the system.", MSGTYPE_ERROR);
                    }
                    else
                    {
                        m_iCountIndex++;

                        readPowerRating(1);

                        emit SigHighLightTestCase(DP_J2_PSU2_PINOUT_TEST);
                        emit Sig_PrintLog("J2 Powersupply Pin Validation Test Started", MSGTYPE_INFO);
                        emit Sig_PrintLog(LOG_HEADER_PINOUT, MSGTYPE_TEXT);

                        reportAddSection(DP_J2_PSU2_PINOUT_TEST, m_iCountIndex);
                        reportInsertTable((int)m_bPSU_LoadSelect[2], DP_J2_PSU2_PINOUT_TEST);
                        m_SReportData.m_iTestCaseId = DP_J2_PSU2_PINOUT_TEST;
                        DP_LINS_PSU_PinOutTest(1, 1, &iResult);
                        reportFinishTable();

                        emit Sig_PrintLog ("J2 Powersupply Pin Validation Test Completed", MSGTYPE_INFO);

                        emit SigTestResult(DP_J2_PSU2_PINOUT_TEST,(bool)iResult);
                    }
                }

                if((!m_bTestStop)&&(m_ucTestSelect[DP_J3_PSU3_PINOUT_TEST] == LINSCM_ENABLE))
                {
                    int iResult = 0;

                    qsDispInfo.sprintf("Kindly ensure circular connector <b>J123-M</b> of JIG3 is Connected to J3 of the system and\n" \
                                       "<b>J4-M</b> of JIG3 is Connected to J4 of the system.");
                    emit Sig_MsgBox(qsDispInfo,MSGTYPE_QUEST);

                    if(!m_bJigConnected)
                    {
                        emit Sig_PrintLog("Circular connector J123 of JIG3 is Connected to J3 of the system and\n" \
                                          "J4 of JIG3 is Connected to J4 of the system.", MSGTYPE_ERROR);
                    }
                    else
                    {
                        m_iCountIndex++;

                        readPowerRating(2);

                        emit SigHighLightTestCase(DP_J3_PSU3_PINOUT_TEST);
                        emit Sig_PrintLog("J3 Powersupply Pin Validation Test Started", MSGTYPE_INFO);
                        emit Sig_PrintLog(LOG_HEADER_PINOUT, MSGTYPE_TEXT);

                        reportAddSection(DP_J3_PSU3_PINOUT_TEST, m_iCountIndex);
                        reportInsertTable((int)m_bPSU_LoadSelect[2], DP_J3_PSU3_PINOUT_TEST);
                        m_SReportData.m_iTestCaseId = DP_J3_PSU3_PINOUT_TEST;
                        DP_LINS_PSU_PinOutTest(2, 2, &iResult);
                        reportFinishTable();

                        emit Sig_PrintLog ("J3 Powersupply Pin Validation Test Completed", MSGTYPE_INFO);

                        emit SigTestResult(DP_J3_PSU3_PINOUT_TEST,(bool)iResult);
                    }
                }

                COSPowerOFF();
                StartStopADCAcquisition(0);
                m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_GLOBAL_MODE, DP_PSU_OUTPUT_OFF, 1);
                m_obj_CPSUWrapper->DP_PSU_Close(1);
            }

            m_iCombinedModeSNO = 0;
            m_iCombinedTestStart = 1;
            m_iDiscreteTestStart = 1;
            m_iAsyncTestStart = 1;
            m_iAsynSNOTestNo = 0;
            m_iTermiChnCombination = 0;

            if((!m_bTestStop)&&(m_ucTestSelect[DP_1553B_Internal_selfTest] == LINSCM_ENABLE))
            {
                m_iCountIndex += 1;
                SigHighLightTestCase(DP_1553B_Internal_selfTest);
                Sig_PrintLog("1553B Self Test Started",MSGTYPE_INFO);

                DP_LINS_1553B_SelfTest(&iRetVal);

                emit SigTestResult(DP_1553B_Internal_selfTest,(bool)iRetVal);

                emit Sig_PrintLog("1553B Self Test Completed",MSGTYPE_INFO);
                emit Sig_PrintLog("======================================================",MSGTYPE_INFO);
                emit Sig_PrintLog("",MSGTYPE_INFO);


                emit SigReHighLightTestCase(DP_1553B_Internal_selfTest);
            }


            if((!m_bTestStop)&&(m_ucTestSelect[DP_1553B_Terminal_Test] == LINSCM_ENABLE))
            {
                m_iCountIndex += 1;
                SigHighLightTestCase(DP_1553B_Terminal_Test);
                usTerminalTestStart = 1;
                int iChannelSel =0;
                int iCommType =0;
                unsigned char ucBusSel ;

                Sig_PrintLog("1553B Terminal Test Started", MSGTYPE_INFO);

                for(iChannelSel = 0;iChannelSel< DP_1553B_MAX_CHANNEL_SEL; iChannelSel++)
                {
#ifdef _ADDRESS_INCREMENTAL
                    m_ucTXRTSubAddr = 0;
                    m_ucRXRTSubAddr = 0;
#endif
                    m_iChnChange = 1;
                    m_uiMTMsgNo = 1;
                    m_uiMT2MsgNo = 1;
                    m_uiRTMsgNo = 1;
                    m_uiMsgCnt = 0;

                    ////
                    ucBusSel = m_stAutomodeIp.carr1553B_BusSelect[iChannelSel];

                    if(m_iChnChange == LINSCM_ENABLE)
                    {
                        m_iTermiChnCombination += 1;
                    }

                    iCommType = DP_1553B_RT_COMM_RX_TYPE;
                    iRetVal = DP_1553B_BC_RT_MT_Test(iChannelSel,iCommType,ucBusSel,DP_MIN_SA_VAL);
                    if(iRetVal)
                    {
                        emit SigErrorNo(iRetVal);
                    }

#ifdef _ADDRESS_INCREMENTAL
                    m_ucTXRTSubAddr = 0;
                    m_ucRXRTSubAddr = 0;
#endif
                    m_iChnChange = 1;
                    m_uiMTMsgNo = 1;
                    m_uiMT2MsgNo = 1;
                    m_uiRTMsgNo = 1;
                    m_uiMsgCnt = 0;

                    iCommType = DP_1553B_RT_COMM_TX_TYPE;
                    iRetVal2 = DP_1553B_BC_RT_MT_Test(iChannelSel,iCommType,ucBusSel,DP_MIN_SA_VAL);
                    if(iRetVal2)
                    {
                        emit SigErrorNo(iRetVal2);
                    }

                }

                if(m_iTerminalChnTestPassCnt == 6)
                {
                    SigTestResult(DP_1553B_Terminal_Test,LINS_TEST_PASS);
                }
                else
                {
                    SigTestResult(DP_1553B_Terminal_Test,LINS_TEST_FAIL);
                }
                ////
                m_iTerminalChnTestPassCnt = 0;

                emit SigReHighLightTestCase(DP_1553B_Terminal_Test);

                Sig_PrintLog("1553B Terminal Test Completed",MSGTYPE_INFO);
                Sig_PrintLog("======================================================",MSGTYPE_INFO);
                Sig_PrintLog("",MSGTYPE_INFO);
            }

            if((!m_bTestStop)&&(m_ucTestSelect[DP_1553B_Combined_Mode_Test] == LINSCM_ENABLE))
            {
                m_iCountIndex += 1;
                m_iCombinedModeSNO = 0;

                emit Sig_PrintLog("1553B Combined Mode Test Started", MSGTYPE_INFO);

                emit SigHighLightTestCase(DP_1553B_Combined_Mode_Test);
                unsigned char ucBusSel;
                usCombinedTestStart = 1;

                for(iChannelSel = 0;iChannelSel< DP_1553B_MAX_CHANNEL_SEL; iChannelSel++)
                {
                    m_iCombinedChnChange = 1;
                    m_iCombinedModeSNO += 1;
                    m_uiMTMsgNo = 1;
                    m_uiRTMsgNo = 1;

                    ucBusSel = m_stAutomodeIp.carr1553B_BusSelect[iChannelSel];

                    iRetVal = DP_1553B_CombinedModeTest(iChannelSel,ucBusSel,iCommType);//add bus selection from file
                    if(iRetVal)
                    {
                        emit SigErrorNo(iRetVal);
                    }
                }

                if(m_iCombinedChnTestPassCnt == 3)
                {
                    emit SigTestResult(DP_1553B_Combined_Mode_Test,LINS_TEST_PASS);
                }
                else
                {
                    emit SigTestResult(DP_1553B_Combined_Mode_Test,LINS_TEST_FAIL);
                }
                ////
                m_iCombinedChnTestPassCnt = 0;

                emit SigReHighLightTestCase(DP_1553B_Combined_Mode_Test);

                emit Sig_PrintLog("1553B Combined Mode Test Completed", MSGTYPE_INFO);
                emit Sig_PrintLog("======================================================",MSGTYPE_INFO);
                emit Sig_PrintLog("",MSGTYPE_INFO);
            }

            if((!m_bTestStop)&&(m_ucTestSelect[DP_1553B_Sync_Test] == LINSCM_ENABLE))
            {
                unsigned char ucBusSel = 0;

                m_iCountIndex += 1;
                emit Sig_PrintLog("1553B Sync Test Started", MSGTYPE_INFO);

                ////
                ucBusSel = m_stAutomodeIp.carr1553B_BusSelect[iChannelSel];

                emit SigHighLightTestCase(DP_1553B_Sync_Test);
                iRetVal = DP_1553B_Sync_Start_Test(DP_1553B_ZERO);
                if(iRetVal)
                {
                    emit SigErrorNo(iRetVal);
                }

                emit SigTestResult(DP_1553B_Sync_Test, m_bSyncTestSts);

                emit Sig_PrintLog("1553B Sync Test Completed", MSGTYPE_INFO);
                emit Sig_PrintLog("======================================================",MSGTYPE_INFO);
                emit Sig_PrintLog("",MSGTYPE_INFO);
            }

            if((!m_bTestStop)&&(m_ucTestSelect[DP_1553B_Async_Test] == LINSCM_ENABLE))
            {
                unsigned char ucBusSel = 0;
                m_iCountIndex += 1;

                emit Sig_PrintLog("1553B Async Test Started", MSGTYPE_INFO);

                emit SigHighLightTestCase(DP_1553B_Async_Test);
                m_pobjC1553BWrapper->usTestSel = DP_1553B_Async_Test;
                for(iChannelSel = 0;iChannelSel< DP_1553B_MAX_CHANNEL_SEL; iChannelSel++)
                {
                    ////
                    ucBusSel = m_stAutomodeIp.carr1553B_BusSelect[iChannelSel];

                    iRetVal = DP_1553B_Async_Trans_Test((unsigned short)iChannelSel,iCommType,ucBusSel);
                    if(iRetVal)
                    {
                        emit SigErrorNo(iRetVal);
                    }
                }

                if(m_iAsyncChnTestPassCnt == 3)
                {
                    emit SigTestResult(DP_1553B_Async_Test,LINS_TEST_PASS);
                }
                else
                {
                    emit SigTestResult(DP_1553B_Async_Test,LINS_TEST_FAIL);
                }
                m_iAsyncChnTestPassCnt = 0;

                emit SigReHighLightTestCase(DP_1553B_Async_Test);

                emit Sig_PrintLog("1553B Async Test Completed", MSGTYPE_INFO);
                emit Sig_PrintLog("======================================================",MSGTYPE_INFO);
                emit Sig_PrintLog("",MSGTYPE_INFO);
            }

            if((!m_bTestStop)&&(m_ucTestSelect[DP_RS232_CH1_Loopback_Test] == LINSCM_ENABLE))
            {
                int iResult = 0;
                m_iCountIndex++;

                emit SigHighLightTestCase(DP_RS232_CH1_Loopback_Test);

                reportAddTableHeader(0, DP_RS232_CH1_Loopback_Test);
                //                m_qfReport.write("<table>\n");
                emit Sig_MsgBox("Kindly Verify the loop back jig is connected for RS232 CH1", MSGTYPE_INFO);
                DP_LINS_RS232_LoopbackTest(DP_RS232_CH1_Loopback_Test,&iResult);
                //                m_qfReport.write("</table>\n");

                emit Sig_PrintLog("COM1 Loopback Test Completed", MSGTYPE_INFO);

                emit SigTestResult(DP_RS232_CH1_Loopback_Test,(bool)iResult);
            }

            if((!m_bTestStop)&&(m_ucTestSelect[DP_RS232_CH2_Loopback_Test] == LINSCM_ENABLE))
            {
                int iResult = 0;
                m_iCountIndex++;

                emit SigHighLightTestCase(DP_RS232_CH2_Loopback_Test);

                reportAddTableHeader(0, DP_RS232_CH2_Loopback_Test);
                //                m_qfReport.write("<table>\n");
                emit Sig_MsgBox("Kindly Verify the loop back jig is connected for RS232 CH2", MSGTYPE_INFO);
                DP_LINS_RS232_LoopbackTest(DP_RS232_CH2_Loopback_Test,&iResult);
                //                m_qfReport.write("</table>\n");

                emit Sig_PrintLog("COM2 Loopback Test Completed", MSGTYPE_INFO);

                emit SigTestResult(DP_RS232_CH2_Loopback_Test,(bool)iResult);

            }

            if((!m_bTestStop)&&(m_ucTestSelect[DP_RS232_CH1_CH2_Loopback_Test] == LINSCM_ENABLE))
            {
                int iResult = 0;
                m_iCountIndex++;

                emit SigHighLightTestCase(DP_RS232_CH1_CH2_Loopback_Test);

                emit Sig_MsgBox("Kindly Verify the loop back jig is connected between RS232 CH1 & RS232 CH2", MSGTYPE_INFO);
                DP_LINS_RS232_LoopbackTest(DP_RS232_CH1_CH2_Loopback_Test,&iResult);
                emit Sig_PrintLog("COM1-Tx and COM2-Rx Loopback Test Completed", MSGTYPE_INFO);

                //                DP_LINS_RS232_LoopbackTest(4,&iResult);
                //                emit Sig_PrintLog("COM2-Tx and COM1-Rx Loopback Test Completed", MSGTYPE_INFO);

                emit SigTestResult(DP_RS232_CH1_CH2_Loopback_Test,(bool)iResult);
            }

            closeReport();
        }
        else
        {
            if((!m_bTestStop)&&(m_ucTestSelect[DP_COS_Power_Test] == LINSCM_ENABLE))
            {
                iRetVal = StartStopADCAcquisition (START_ACQUISITION);
                if(!iRetVal)
                    break;

                int iResult = 0;

                emit Sig_PrintLog("COS Power Test Started", MSGTYPE_INFO);

                DP_LINS_COSPowerTest (&iResult);

                emit Sig_PrintLog("COS Power Test Completed", MSGTYPE_INFO);

                iRetVal = StartStopADCAcquisition (STOP_ACQUISITION);
                if(!iRetVal)
                    break;
            }

            if((!m_bTestStop)&&(m_ucTestSelect[DP_WDT_Alarm_Test] == LINSCM_ENABLE))
            {
                int iResult = 0;

                emit Sig_PrintLog("WDT and Alarm Test Started", MSGTYPE_INFO);
                DP_LINS_WDTAlarmTest(&iResult);

                emit Sig_PrintLog("WDT and Alarm Test Completed", MSGTYPE_INFO);
            }

            if((!m_bTestStop)&&(m_ucTestSelect[DP_Bypass_Test] == LINSCM_ENABLE))
            {
                iRetVal = StartStopADCAcquisition (START_ACQUISITION);
                if(!iRetVal)
                    break;

                int iResult = 0;

                emit Sig_PrintLog("Bypass Test Started", MSGTYPE_INFO);
                DP_LINS_BypassTest(&iResult);

                emit Sig_PrintLog("Bypass Test Completed", MSGTYPE_INFO);

                iRetVal = StartStopADCAcquisition (STOP_ACQUISITION);
                if(!iRetVal)
                    break;
            }

            if((!m_bTestStop)&&(m_ucTestSelect[DP_Emergency_Switch_Test] == LINSCM_ENABLE))
            {
                int iResult = 0;

                Sig_PrintLog("Emergency Switch Test Started", MSGTYPE_INFO);
                DP_LINS_BypassTest(&iResult);
                //                DP_LINS_EmergencyTest(&iResult);

                Sig_PrintLog("Emergency Switch Test Completed", MSGTYPE_INFO);
            }
        }
    }while(0);

    emit SigTestComplete();
}

bool CTestThread::COSPowerON()
{
    int iRetval = 0;
    iRetval = m_p3096Wrapper->SetOutput(DO_COS_PWR_OFF, 0);
    if(iRetval)
    {
        Sig_PrintLog("Unable to set COS OFF relay status", Failure);
        return false;
    }
    msleep(DP_CPCI_3096_SET_OP_DELAY);

    iRetval = m_p3096Wrapper->SetOutput(DO_COS_PWR_ON, 1);
    if(iRetval)
    {
        Sig_PrintLog("Unable to set COS ON relay status", Failure);
        return false;
    }
    msleep(DP_CPCI_3096_SET_OP_DELAY);

    iRetval = m_p3096Wrapper->SetOutput(DO_COS_PWR_ON, 0);
    if(iRetval)
    {
        Sig_PrintLog("Unable to set COS ON relay status", Failure);
        return false;
    }
    msleep(DP_CPCI_3096_SET_OP_DELAY);
    return true;
}

bool CTestThread::COSPowerOFF()
{
    int iRetval = 0;

    iRetval = m_p3096Wrapper->SetOutput(DO_COS_PWR_ON, 0);
    if(iRetval)
    {
        Sig_PrintLog("Unable to set COS ON relay status", Failure);
        return false;
    }
    msleep(DP_CPCI_3096_SET_OP_DELAY);

    iRetval = m_p3096Wrapper->SetOutput(DO_COS_PWR_OFF, 1);
    if(iRetval)
    {
        Sig_PrintLog("Unable to set COS OFF relay status", Failure);
        return false;
    }
    msleep(DP_CPCI_3096_SET_OP_DELAY);

    iRetval = m_p3096Wrapper->SetOutput(DO_COS_PWR_OFF, 0);
    if(iRetval)
    {
        Sig_PrintLog("Unable to set COS OFF relay status", Failure);
        return false;
    }
    msleep(DP_CPCI_3096_SET_OP_DELAY);
    return true;
}

void CTestThread::DP_LINS_RS232_LoopbackTest(int opt, int *out_piStatus)
{
    QString qsErrDesc = "";
    char  cTxData[256] = {0}, cRxData[256] = {0}, cRxData2[256] = {0};
    QSerialPort *writeCOM, *readCOM;
    short sRetVal= 0;
    int iResult = LINS_TEST_FAIL, iWrByteCnt = 0, iRdByteCnt = 0;
    SDP_All_Msg SDP_All_Rslt;
    QString qsPass = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
    QString qsFail = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
    QString QStrTxData = "", QStrRxData = "";
    SDP_All_Rslt.qsRS232TxData = "";
    SDP_All_Rslt.qsRS232RxData = "";

    switch(opt)
    {
    case DP_RS232_CH1_Loopback_Test:{
        sRetVal = openCOMPort("ttyS0",m_stAutomodeIp.usCOM1_Baudrate, m_stAutomodeIp.ucCOM1_StopBit, m_stAutomodeIp.ucCOM1_Parity, m_stAutomodeIp.ucCOM1_DataBit);
        if(sRetVal != 0)
        {
            emit Sig_PrintLog("COM1 Open Failed", MSGTYPE_ERROR);
            iResult = LINS_TEST_FAIL;
        }
        writeCOM = &m_objCOM1;
        readCOM = &m_objCOM1;
    }break;
    case DP_RS232_CH2_Loopback_Test:{
        sRetVal = openCOMPort("ttyS1",m_stAutomodeIp.usCOM2_Baudrate, m_stAutomodeIp.ucCOM2_StopBit, m_stAutomodeIp.ucCOM2_Parity, m_stAutomodeIp.ucCOM2_DataBit);
        if(sRetVal != 0)
        {
            emit Sig_PrintLog("COM2 Open Failed", MSGTYPE_ERROR);
            iResult = LINS_TEST_FAIL;
        }
        writeCOM = &m_objCOM2;
        readCOM = &m_objCOM2;
    }break;
    case DP_RS232_CH1_CH2_Loopback_Test:{
        sRetVal = openCOMPort("ttyS0",m_stAutomodeIp.usCOM1_Baudrate, m_stAutomodeIp.ucCOM1_StopBit, m_stAutomodeIp.ucCOM1_Parity, m_stAutomodeIp.ucCOM1_DataBit);
        if(sRetVal != 0)
        {
            emit Sig_PrintLog("COM1 Open Failed", MSGTYPE_ERROR);
            iResult = LINS_TEST_FAIL;
        }
        sRetVal = openCOMPort("ttyS1",m_stAutomodeIp.usCOM2_Baudrate, m_stAutomodeIp.ucCOM2_StopBit, m_stAutomodeIp.ucCOM2_Parity, m_stAutomodeIp.ucCOM2_DataBit);
        if(sRetVal != 0)
        {
            emit Sig_PrintLog("COM2 Open Failed", MSGTYPE_ERROR);
            iResult = LINS_TEST_FAIL;
        }
        writeCOM = &m_objCOM1;
        readCOM = &m_objCOM2;
    }break;
    case 4:{
        sRetVal = openCOMPort("ttyS0",m_stAutomodeIp.usCOM1_Baudrate, m_stAutomodeIp.ucCOM1_StopBit, m_stAutomodeIp.ucCOM1_Parity, m_stAutomodeIp.ucCOM1_DataBit);
        if(sRetVal != 0)
        {
            emit Sig_PrintLog("COM1 Open Failed", MSGTYPE_ERROR);
            iResult = LINS_TEST_FAIL;
        }
        sRetVal = openCOMPort("ttyS1",m_stAutomodeIp.usCOM2_Baudrate, m_stAutomodeIp.ucCOM2_StopBit, m_stAutomodeIp.ucCOM2_Parity, m_stAutomodeIp.ucCOM2_DataBit);
        if(sRetVal != 0)
        {
            emit Sig_PrintLog("COM2 Open Failed", MSGTYPE_ERROR);
            iResult = LINS_TEST_FAIL;
        }
        writeCOM = &m_objCOM2;
        readCOM = &m_objCOM1;
    }break;
    }

    if(iResult != LINS_TEST_PASS)
    {
        for(int iIdx = 0; iIdx <= 256; iIdx++)
        {
            if(m_stAutomodeIp.ucCOM1_DataType)
            {
                cTxData[iIdx] = m_stAutomodeIp.ucCOM1_PatternData;
            }
            else
            {
                cTxData[iIdx] = iIdx+1;
            }
        }

        iWrByteCnt = 0;//COM Tx
        iRdByteCnt = 0;

        iResult = LINS_TEST_FAIL;

        for(int iIndex = 0; iIndex < 256; iIndex+=8)
        {
            iWrByteCnt += writeCOM->write(&cTxData[iIndex], 8);
            writeCOM->waitForBytesWritten(10);

            readCOM->waitForReadyRead(20);
            iRdByteCnt += readCOM->read(&cRxData[iIndex], 8);
        }

        for(int iAllignCnt = 0, iIndex1 = 0; iIndex1 < 256; iIndex1++, iAllignCnt++)
        {
            if(iAllignCnt == 15)//for printing variables in a line
            {
                QStrTxData.sprintf("%.2X<br>", (unsigned char)cTxData[iIndex1]);
                QStrRxData.sprintf("%.2X<br>", (unsigned char)cRxData[iIndex1]);
                iAllignCnt = -1;
            }
            else
            {
                QStrTxData.sprintf("%.2X   ", (unsigned char)cTxData[iIndex1]);
                QStrRxData.sprintf("%.2X   ", (unsigned char)cRxData[iIndex1]);
            }
            SDP_All_Rslt.qsRS232TxData += QStrTxData;
            SDP_All_Rslt.qsRS232RxData += QStrRxData;
            QStrRxData = "";
        }

        if(opt == DP_RS232_CH1_CH2_Loopback_Test)
        {
            for(int iIndex = 0; iIndex < 256; iIndex+=8)
            {
                readCOM->write(&cRxData[iIndex], 8);
                readCOM->waitForBytesWritten(10);
                writeCOM->waitForReadyRead(20);
                writeCOM->read(cRxData2+iIndex, 8);
            }

            for(int iAllignCnt = 0, iIndex1 = 0; iIndex1 < 256; iIndex1++, iAllignCnt++)
            {
                if(iAllignCnt == 15)//for printing variables in a line
                {
                    QStrRxData.sprintf("%.2X<br>", (unsigned char)cRxData2[iIndex1]);
                    iAllignCnt = -1;
                }
                else
                {
                    QStrRxData.sprintf("%.2X   ", (unsigned char)cRxData2[iIndex1]);
                }
                SDP_All_Rslt.qsRS232RxData2 += QStrRxData;
                QStrRxData = "";
            }
        }

        if(iWrByteCnt == 256)
        {
            if(iWrByteCnt == iRdByteCnt)
            {
                //Compare the Tx and Rx Data
                if(strcmp((const char *)cRxData, (const char *)cTxData) == 0)
                {
                    iResult = LINS_TEST_PASS;
                    SDP_All_Rslt.qsRS232Rslt = qsPass;
                }
                else
                {
                    emit Sig_PrintLog("RS232 Loopback Data Mis-Matched.", MSGTYPE_ERROR);
                    SDP_All_Rslt.qsRS232Rslt = qsFail;
                }
            }
            else
            {
                qsErrDesc.sprintf("Read Count Failed (exp 256) : %d",iRdByteCnt);
                emit Sig_PrintLog(qsErrDesc, MSGTYPE_ERROR);
                SDP_All_Rslt.qsRS232Rslt = qsFail;
            }
        }
        else
        {
            qsErrDesc.sprintf("Write Count Failed (exp 256) : %d",iWrByteCnt);
            emit Sig_PrintLog(qsErrDesc, MSGTYPE_ERROR);
            SDP_All_Rslt.qsRS232Rslt = qsFail;
        }
    }

    //Reconfig COM1 to default setting
    //    m_obj_CPSUWrapper->ConfigCOM1Port();

    DigitalTestReportCreation(&SDP_All_Rslt, opt, 0, m_iCycleCnt);
    *out_piStatus = iResult;
}

short CTestThread::openCOMPort(QString in_qsComNo, unsigned int in_uiBaudRate, unsigned char in_ucStopBit, unsigned char in_ucParity, unsigned char in_ucDataBits)
{
    short sRetVal = 0;
    QSerialPort *tempCOM;

    tempCOM = (in_qsComNo.compare("ttyS0") == 0)? &m_objCOM1:&m_objCOM2;

    if(tempCOM->isOpen())
    {
        qDebug()<<tempCOM->portName()<<" is Already Open";
        tempCOM->close();
    }

    tempCOM->setPortName(in_qsComNo);

    //Set Baudrate
    switch(in_uiBaudRate)
    {
    case 1200:tempCOM->setBaudRate(QSerialPort::Baud1200);break;
    case 2400:tempCOM->setBaudRate(QSerialPort::Baud2400);break;
    case 4800:tempCOM->setBaudRate(QSerialPort::Baud4800);break;
    case 9600:tempCOM->setBaudRate(QSerialPort::Baud9600);break;
    case 19200:tempCOM->setBaudRate(QSerialPort::Baud19200);break;
    case 38400:tempCOM->setBaudRate(QSerialPort::Baud38400);break;
    case 57600:tempCOM->setBaudRate(QSerialPort::Baud57600 );break;
    case 115200:tempCOM->setBaudRate(QSerialPort::Baud115200);break;

    default:tempCOM->setBaudRate(QSerialPort::Baud9600);
    }

    //Set Data Bits
    switch(in_ucDataBits)
    {
    case 5: tempCOM->setDataBits(QSerialPort::Data5);break;
    case 6: tempCOM->setDataBits(QSerialPort::Data6);break;
    case 7: tempCOM->setDataBits(QSerialPort::Data7);break;
    case 8: tempCOM->setDataBits(QSerialPort::Data8);break;

    default:tempCOM->setDataBits(QSerialPort::Data8);
    }

    //Set Parity Bit
    switch(in_ucParity)
    {
    case 3:tempCOM->setParity(QSerialPort::OddParity);break;
    case 2:tempCOM->setParity(QSerialPort::EvenParity);break;
    case 0:tempCOM->setParity(QSerialPort::NoParity);break;

    default:tempCOM->setParity(QSerialPort::NoParity);
    }

    //Set stop bit
    switch(in_ucStopBit)
    {
    case 1:tempCOM->setStopBits(QSerialPort::OneStop);break;
    case 3:tempCOM->setStopBits(QSerialPort::OneAndHalfStop);break;
    case 2:tempCOM->setStopBits(QSerialPort::TwoStop);break;

    default:tempCOM->setStopBits(QSerialPort::OneStop);
    }

    tempCOM->setFlowControl(QSerialPort::NoFlowControl);

    if(!tempCOM->open(QIODevice::ReadWrite))
    {
        qDebug()<<tempCOM->errorString();
        qDebug()<<tempCOM->portName() + " Not Opened";
        sRetVal = DP_PSU_COM_PORT_NOT_OPENED;
    }
    else
    {
        qDebug()<<tempCOM->portName() + " Opened";
        sRetVal = DP_PSU_SUCCESS;
    }

    return sRetVal;
}

short CTestThread::enablePSUOutput(unsigned char in_ucPSUID)
{
    QString str;
    short sRetVal = 0;
    float fVoltage = 0.0f, fReadVolt = 0.0f;
    float fCurrent = 0.0f, fReadCurr = 0.0f;
    float fUnderVoltage = 0.0f, fReadUV = 0.0f;
    float fOverVoltage = 0.0f, fReadOV = 0.0f;

    fVoltage = m_SPSUConfig[in_ucPSUID].m_fNominalVolt;
    fCurrent = m_SPSUConfig[in_ucPSUID].m_fCurrentLimit;
    fUnderVoltage = m_SPSUConfig[in_ucPSUID].m_fUnderVolt;
    fOverVoltage = m_SPSUConfig[in_ucPSUID].m_fOverVolt;

    sRetVal = m_obj_CPSUWrapper->DP_PSU_OV_UV_Config(fOverVoltage, fUnderVoltage, in_ucPSUID);
    if(sRetVal)
    {
        str.sprintf("PS-1   :    Under Voltage = %f, Over Volage = %f", fOverVoltage, fUnderVoltage);
        emit Sig_PrintLog(str.toStdString().c_str(),MSGTYPE_INFO);
    }
    else
    {
        sRetVal = 1;
        emit Sig_PrintLog("PS-1 Configuration FAILURE",MSGTYPE_ERROR);
    }

    m_obj_CPSUWrapper->DP_PSU_VoltCurrConfig(DP_PSU_DAISY_CHAIN_MODE, fVoltage, fCurrent,in_ucPSUID);
    if(sRetVal)
    {
        str.sprintf("PS-1   :    Voltage =  %f, Current = %f", fOverVoltage, fUnderVoltage);
        emit Sig_PrintLog(str.toStdString().c_str(),MSGTYPE_INFO);
    }
    else
    {
        sRetVal = 1;
        emit Sig_PrintLog("PS-1 Configuration FAILURE",MSGTYPE_ERROR);
    }

    m_obj_CPSUWrapper->DP_PSU_Readback_Config(&fReadVolt, &fReadCurr, &fReadUV, &fReadOV,in_ucPSUID);

    if ((fReadOV == fOverVoltage) || (fReadUV == fUnderVoltage) /
            (fReadVolt == fVoltage) || (fReadCurr == fCurrent))
    {
        emit Sig_PrintLog("PS-1 Configuration Verification SUCCESS",MSGTYPE_SUCCESS);
    }
    else
    {
        sRetVal = 1;
        emit Sig_PrintLog("PS-1 Configuration Verification FAILURE",MSGTYPE_ERROR);
    }

    m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_LOCAL_MODE, DP_PSU_OUTPUT_ON, in_ucPSUID);

    return sRetVal;
}

// Added by Aravinth R
bool CTestThread::StartStopADCAcquisition(unsigned char in_ucStrStp)
{
    int iRetval = 0;
    QString qsErrorDesc = "";

    if(in_ucStrStp)
    {
        iRetval = m_p1105Wrapper->StartAcquisition();
        if(iRetval)
        {
            qsErrorDesc = "Initialize : Unable to start ADC acquisition";
            emit Sig_PrintLog(qsErrorDesc, MSGTYPE_ERROR);
            return false;
        }
    }
    else
    {
        iRetval = m_p1105Wrapper->StopAcquisition();
        if(iRetval)
        {
            qsErrorDesc = "De-initialize : Unable to stop ADC acquisition";
            emit Sig_PrintLog(qsErrorDesc, MSGTYPE_ERROR);
            return false;
        }
    }
    return true;
}

void CTestThread::logTestData(SReportStruct in_SReportData)
{
    QString Str;
    QString qsTemp;

    if(in_SReportData.m_iTestCaseId >= DP_J1_PSU1_PINOUT_TEST)
    {
        in_SReportData.m_iTestCaseId = DP_J1_PSU1_PINOUT_TEST;
    }

    if(in_SReportData.m_iTestCaseId == DP_J4_SPAREDIO_TEST)
    {
        in_SReportData.m_iTestCaseId = DP_J1_TELECOMMAND_Test;
    }

    if((in_SReportData.m_iTestCaseId >= DP_J3_PSU3_OUT1_Test) && (in_SReportData.m_iTestCaseId <= DP_J3_THERMISTORCH4))
    {
        in_SReportData.m_iTestCaseId -= 18;
    }

    if((in_SReportData.m_iTestCaseId >= DP_J2_PSU2_OUT1_Test) && (in_SReportData.m_iTestCaseId <= DP_J2_THERMISTORCH4))
    {
        in_SReportData.m_iTestCaseId -= 9;
    }

    switch(in_SReportData.m_iTestCaseId)
    {
    case DP_J1_PSU1_OUT1_Test:
    case DP_J1_PSU1_OUT2_Test:
    case DP_J1_PSU1_DEMG_Test: {
        //        Str.append(QString(QString::number(in_SReportData.UTestData.SPsuData.m_fConfigVolt,'f',2))+LOG_SPACES_INTER);
        Str.append(LOG_SPACES_BEGIN + QString::number(in_SReportData.UTestData.SPsuData.m_fPSU232Volt, 'f', 2)+LOG_SPACES_INTER);
        Str.append(QString::number(in_SReportData.UTestData.SPsuData.m_fPSUADCVolt, 'f', 2)+LOG_SPACES_INTER);
        qsTemp = (in_SReportData.UTestData.SPsuData.m_ucRelayStatus == LINSCM_ENABLE)?"OFF":"ON";
        Str.append(QString(qsTemp)+LOG_SPACES_INTER);
        qsTemp = (in_SReportData.m_iLoadStatus == LINSCM_ENABLE)?"With Load":"No Load";
        Str.append(QString(qsTemp)+LOG_SPACES_INTER);

        if(in_SReportData.m_iTestCaseId == DP_J1_PSU1_OUT1_Test)
        {
            Str.append(QString::number(in_SReportData.UTestData.SPsuData.m_fLoadVolt1, 'f', 2)+LOG_SPACES_INTER);
        }
        else if(in_SReportData.m_iTestCaseId == DP_J1_PSU1_OUT2_Test)
        {
            Str.append(QString::number(in_SReportData.UTestData.SPsuData.m_fLoadVolt2, 'f', 2)+LOG_SPACES_INTER);
        }
        else
        {
            Str.append(QString::number(in_SReportData.UTestData.SPsuData.m_fLoadVolt3, 'f', 2)+LOG_SPACES_INTER);
        }

        if((in_SReportData.UTestData.SPsuData.m_ucCurrLimitNA) || \
                (in_SReportData.UTestData.SPsuData.m_ucRelayStatus == LINSCM_ENABLE))
        {
            Str.append(QString("     NA    ")+LOG_SPACES_INTER);
        }
        else
        {
            Str.append(QString(QString::number(in_SReportData.UTestData.SPsuData.m_fExpMinCurr,'f',2) + " - " + \
                               QString::number(in_SReportData.UTestData.SPsuData.m_fExpMaxCurr,'f',2))+LOG_SPACES_INTER);
        }

        Str.append(QString::number(in_SReportData.UTestData.SPsuData.m_fPSU232Curr, 'f', 2)+LOG_SPACES_INTER);

        if(in_SReportData.m_iTestCaseId == DP_J1_PSU1_OUT1_Test)
        {
            Str.append(QString::number(in_SReportData.UTestData.SPsuData.m_fLoadCurr1, 'f', 2)+LOG_SPACES_INTER);
        }
        else if(in_SReportData.m_iTestCaseId == DP_J1_PSU1_OUT2_Test)
        {
            Str.append(QString::number(in_SReportData.UTestData.SPsuData.m_fLoadCurr2, 'f', 2)+LOG_SPACES_INTER);
        }
        else
        {
            Str.append(QString::number(in_SReportData.UTestData.SPsuData.m_fLoadCurr3, 'f', 2)+LOG_SPACES_INTER);
        }

        Str.append(in_SReportData.m_iTestResult?" PASS":" FAIL");
    } break;

    case DP_J1_PSU_TELE_CMD_Test: {
        //        Str.append(LOG_SPACES_BEGIN + QString(QString::number(in_SReportData.UTestData.SPsuData.m_fConfigVolt,'f',2))+LOG_SPACES_INTER);
        Str.append(LOG_SPACES_BEGIN + QString::number(in_SReportData.UTestData.SPsuData.m_fPSU232Volt, 'f', 2)+LOG_SPACES_INTER);
        Str.append(QString::number(in_SReportData.UTestData.SPsuData.m_fPSUADCVolt, 'f', 2)+LOG_SPACES_INTER);
        qsTemp = (in_SReportData.UTestData.SPsuData.m_ucRelayStatus == LINSCM_ENABLE)?"OFF":"ON";
        Str.append(QString(qsTemp)+LOG_SPACES_INTER);
        qsTemp = (in_SReportData.m_iLoadStatus == LINSCM_ENABLE)?"With Load":"No Load";
        Str.append(QString(qsTemp)+LOG_SPACES_INTER);

        if(in_SReportData.m_iTestCaseId == DP_J1_PSU_TELE_CMD_Test)
        {
            Str.append(QString::number(in_SReportData.UTestData.SPsuData.m_fLoadVolt1, 'f', 2)+LOG_SPACES_INTER);
        }
        else if(in_SReportData.m_iTestCaseId == DP_J2_PSU_TELE_CMD_Test)
        {
            Str.append(QString::number(in_SReportData.UTestData.SPsuData.m_fLoadVolt2, 'f', 2)+LOG_SPACES_INTER);
        }
        else
        {
            Str.append(QString::number(in_SReportData.UTestData.SPsuData.m_fLoadVolt3, 'f', 2)+LOG_SPACES_INTER);
        }

        if((in_SReportData.UTestData.SPsuData.m_ucCurrLimitNA) || \
                (in_SReportData.UTestData.SPsuData.m_ucRelayStatus == LINSCM_ENABLE))
        {
            Str.append(QString("    NA    ")+LOG_SPACES_INTER);
        }
        else
        {
            Str.append(QString(QString::number(in_SReportData.UTestData.SPsuData.m_fExpMinCurr,'f',2) + " - " + \
                               QString::number(in_SReportData.UTestData.SPsuData.m_fExpMaxCurr,'f',2))+LOG_SPACES_INTER);
        }

        Str.append(QString::number(in_SReportData.UTestData.SPsuData.m_fPSU232Curr,'f',2)+LOG_SPACES_INTER);
        Str.append(in_SReportData.m_iTestResult?" PASS":" FAIL");
    } break;

    case DP_J1_TELECOMMAND_Test: {
        if(in_SReportData.m_iSubTestId == 0)
        {
            qsTemp.sprintf("3096-B2-DO-CH%02d",in_SReportData.UTestData.STeleCmdData.m_ucDOChnNo);
            Str.append(LOG_SPACES_BEGIN + QString(qsTemp)+LOG_SPACES_INTER);
            qsTemp.sprintf("3096-B2-DI-CH%02d",in_SReportData.UTestData.STeleCmdData.m_ucDIChnNo);
            Str.append(QString(qsTemp)+LOG_SPACES_INTER);
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucExpOFFSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(QString(qsTemp)+LOG_SPACES_INTER);
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucObsOFFSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(QString(qsTemp)+LOG_SPACES_INTER);
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucExpONSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(QString(qsTemp)+LOG_SPACES_INTER);
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucObsONSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(QString(qsTemp)+LOG_SPACES_INTER);
            Str.append(in_SReportData.m_iTestResult?" PASS":" FAIL");
        }
        else
        {
            qsTemp.sprintf("3096-B2-DI-CH%02d",in_SReportData.UTestData.STeleCmdData.m_ucDIChnNo);
            Str.append(LOG_SPACES_BEGIN + QString(qsTemp)+LOG_SPACES_INTER);
            qsTemp.sprintf("3096-B2-DO-CH%02d",in_SReportData.UTestData.STeleCmdData.m_ucDOChnNo);
            Str.append(QString(qsTemp)+LOG_SPACES_INTER);
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucExpOFFSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(QString(qsTemp)+LOG_SPACES_INTER);
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucObsOFFSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(QString(qsTemp)+LOG_SPACES_INTER);
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucExpONSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(QString(qsTemp)+LOG_SPACES_INTER);
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucObsONSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(QString(qsTemp)+LOG_SPACES_INTER);
            Str.append(in_SReportData.m_iTestResult?" PASS":" FAIL");
        }
    } break;

    case DP_J1_THERMISTORCH1:
    case DP_J1_THERMISTORCH2:
    case DP_J1_THERMISTORCH3:
    case DP_J1_THERMISTORCH4: {
        qsTemp.sprintf("1123-B%d-CH%d",in_SReportData.UTestData.SThermodata.m_ucBrdNo, \
                       in_SReportData.UTestData.SThermodata.m_ucChnNo);
        Str.append(LOG_SPACES_BEGIN + QString(qsTemp)+LOG_SPACES_THERM);
        qsTemp.sprintf("SWT%d-Position%2d",in_SReportData.UTestData.SThermodata.m_ucSWNum, \
                       in_SReportData.UTestData.SThermodata.m_ucSWPos);
        Str.append(QString(qsTemp)+LOG_SPACES_THERM);
        qsTemp.sprintf("%.2fK Ohm",in_SReportData.UTestData.SThermodata.m_dObsRes);
        Str.append(QString(qsTemp)+LOG_SPACES_THERM);
        qsTemp.sprintf("%.2f degC +/-%.1f degC",in_SReportData.UTestData.SThermodata.m_dExpTemp, \
                       in_SReportData.UTestData.SThermodata.m_dTolTemp);
        Str.append(QString(qsTemp)+LOG_SPACES_THERM);
        qsTemp.sprintf("%.2f degC",in_SReportData.UTestData.SThermodata.m_dObsTemp);
        Str.append(QString(qsTemp)+LOG_SPACES_THERM);
        Str.append(in_SReportData.m_iTestResult?" PASS":" FAIL");
    } break;

    case DP_J1_PSU1_PINOUT_TEST:{
        Str.append(LOG_SPACES_BEGIN + QString(in_SReportData.UTestData.SPSUOutData.qsPSChainRef)+LOG_SPACES_INTER);
        Str.append(QString(in_SReportData.UTestData.SPSUOutData.qsRLYRef)+LOG_SPACES_INTER);
        qsTemp = (in_SReportData.UTestData.SPSUOutData.iRlyObsSts != LINSCM_ENABLE)?"OFF":"ON";
        Str.append(QString(qsTemp)+LOG_SPACES_INTER);
        Str.append(QString(in_SReportData.UTestData.SPSUOutData.qsDIChRef)+LOG_SPACES_INTER);
        qsTemp = (in_SReportData.UTestData.SPSUOutData.iDIObsSts == DIO_ENABLE)?"HIGH":"LOW";
        Str.append(QString(qsTemp)+LOG_SPACES_INTER);
        Str.append(in_SReportData.m_iTestResult?" PASS":" FAIL");
    }break;

    }

    emit Sig_PrintLog(Str,MSGTYPE_TEXT);
}
