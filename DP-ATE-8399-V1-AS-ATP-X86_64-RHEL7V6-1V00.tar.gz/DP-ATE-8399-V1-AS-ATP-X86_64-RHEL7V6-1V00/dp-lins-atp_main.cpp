/*******************************************************************************
 File Name    : Dp_Hcrr_ODU_ILevel_Testthread.cpp
 Author       : Manikandan K
 Created Date : Mar 11,2019
 Description  : Test Thread function definitions.
*******************************************************************************/

/*******************************************************************************
 Company Name : DATA PATTERNS INDIA PRIVATE LIMITED
 Address      : No. H9,4th MainRoad,SIPCOT IT Park,Siruseri,Chennai-603103
 Email        : support@datapatterns.co.in
 Phone        : +91 44 47414000
 Fax          : +91 44 47414444
*******************************************************************************/

/******************************************************************************
 Copyright (c) 2019 DATA PATTERNS

 All rights reserved. These materials are confidential and proprietary to
 DATA PATTERNS and no part of these materials should be reproduced or published
 in any form by any means, electronic or mechanical, including photocopy, on any
 information storage or retrieval system, nor should the materials be disclosed
 to third parties without the explicit written authorization of DATA PATTERNS.

*******************************************************************************/

#include "dp-lins-atp_mainwindow.h"
#include "crc32checksum.h"

#include "./User_Authentication/authentication.h"

SGLOBAL g_SGlobal;

short g_sReturn;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QFile qf(DP_FILE_ATP_AUTH);
    qf.open (QIODevice::ReadWrite);
    qf.close ();

    CAuthentication Auth;
    if(!Auth.lock())
    {
        QMessageBox::warning(&Auth,"Error","Another Instance of the application is already running");
        return 0;
    }

    Auth.exec();

    if(!g_sReturn)
    {
        return 0;
    }

    QString strCmd = qApp->applicationDirPath()+"/insert_modules.sh";

    system("chmod +x insert_modules.sh");
    system(strCmd.toLatin1().data());

    Crc32_ComputeFile(argv[0],&g_SGlobal.ulAppChecksum);

    MainWindow w;
    w.showMaximized();

    return a.exec();
}
