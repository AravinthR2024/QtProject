#ifndef DPLINSATP_INCLUDES_H
#define DPLINSATP_INCLUDES_H

#include "dp-lins-atp_macros.h"
#include "dp-lins-atp_structures.h"

#include "includes/dp-lins_1553b_wrapper.h"
#include "includes/dp1553bxt_err.h"
#include "includes/dp-lins_cpci3096_wrapper.h"
#include "includes/dp-lins_mm1105_wrapper.h"
#include "includes/dp-lins_mm1123_wrapper.h"
#include "includes/dp-lins_psu_wrapper.h"

#endif // DPLINSATP_INCLUDES_H

