#include "dp-lins-atp_about.h"
#include "ui_dp-lins-atp_about.h"

extern SGLOBAL g_SGlobal;

CAbout::CAbout(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CAbout)
{
    ui->setupUi(this);
    this->setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);

    ui->lbVersion->setText("1.00");
    ui->lbChecksum->setText("0X"+QString::number(g_SGlobal.ulAppChecksum,16).toUpper());
    m_strAppVer = ui->lbVersion->text();
}

CAbout::~CAbout()
{
    delete ui;
}

void CAbout::on_pb_Ok_clicked()
{
    this->close();
}
