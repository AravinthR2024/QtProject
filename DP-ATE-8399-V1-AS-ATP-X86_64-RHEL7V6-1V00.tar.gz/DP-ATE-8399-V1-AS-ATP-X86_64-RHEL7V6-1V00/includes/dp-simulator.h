#ifndef DPSIMULATOR_H
#define DPSIMULATOR_H


#define OPRN_TYPE_GET   1
#define OPRN_TYPE_SET   2

#define SIG_TYPE_DI		1   /* DIP */
#define SIG_TYPE_DO		2   /* DOP */
#define SIG_TYPE_ADC	3	/* ADC */
#define SIG_TYPE_1553B	4	/* 1553B */
#define SIG_TYPE_RS232	5	/* RS232 */

typedef struct _S_SIG_OPERATION
{
 unsigned char ucOperation;
 unsigned char ucSigType;
 unsigned short usSigID;
 float  fSigvalue;
 int iStatus;
}S_SIG_OPERATION;


#endif // DPSIMULATOR_H

