/**
 *	\file dpcpci3096_err.h
 *	\brief This file contains the  error code definition
 *
 *	This file contains the  error code definition
 *
 *	\author Mahesh S 
 *	\date 03:13PM on August 24, 2019
 *
 *	\version
 *	- Initial version
 *
 *	Copyright (C) 2019 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
 *	All Rights Reserved.\n
 *	Address:	Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
 *				Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
 *				Chennai-603103 | India\n
 *				Website : http://www.datapatternsindia.com/\n
 *				Phone: 91-44-4741-4000\n
 *				FAX: 91-44-4741-4444 \n
 *
	////////////////////////////REVISION LOG ENTRY//////////////////////////////////
	Date		Version Number	     Reason for Revision	Revised by 
	----		--------------		 -------------------	----------
									 

	 
*/
#ifndef _DPCPCI3096_ERR_H
#define _DPCPCI3096_ERR_H

#define DPCPCI3096_SUCCESS		0


/**
* This list the enumeration of driver error values 
*/ 
enum{
	DPCPCI3096_ERR_MEM_CREATE = -1999,  	/*!< -1999	Memory creation for Buffer Error*/
	DPCPCI3096_ERR_MEM_NOT_CREATED,			/*!< -1998	Memory not created error*/
	DPCPCI3096_ERR_DATA_NULL,				/*!< -1997	Memory written count zero error*/
	DPCPCI3096_ERR_BUFFER_FULL,				/*!< -1996	Memory buffer is full*/
	DP_DRV_ERR_INVALID_HANDLE = -999,		/*!<-999	Invalid Handle*/
	DP_DRV_ERR_INVALID_POINTER,				/*!<-998	Invalid Pointer*/
	DP_DRV_ERR_INVALID_PARAM,				/*!<-997	Invalid Param*/
	DP_DRV_ERR_MEM_ALLOCATION,				/*!<-996	Mem Allocation*/
	DP_DRV_ERR_NO_ZEROTH_DEVICE,			/*!<-995	No Zeroth Device*/
	DP_DRV_ERR_DEVICE_NOT_OPEN,				/*!<-994	Device Is Not Open*/
	DP_DRV_ERR_INVALID_SHARE_VALUE,			/*!<-993	Invalid Share Value*/
	DP_DRV_ERR_INVALID_DEVICE_REQUEST,		/*!<-992	Invalid Device Request*/
	DP_DRV_ERR_INVALID_MAXDEVICES,			/*!<-991	Invalid Maxdevices*/
	DPCPCI3096_ERR_IOCTL,					/*!<-990	Ioctl*/
	DPCPCI3096_ERR_INVALID_PARAM,			/*!<-989	Invalid Param*/
	DPCPCI3096_ERR_DEVICE_BUSY,				/*!<-988	Device Busy*/
	DPCPCI3096_ERR_NO_DEVICE_FOUND,			/*!<-987	No Device Found*/
	DPCPCI3096_ERR_INVALID_MAXDEVICES,		/*!<-986	Invalid Maxdevices*/
	DPCPCI3096_ERR_INVALID_HANDLE,			/*!<-985	Invalid Handle*/
	DPCPCI3096_ERR_INVALID_ERRCODE,			/*!<-984	Invalid Errcode*/
	DPCPCI3096_ERR_INVALID_BUFSIZE,			/*!<-983	Invalid Bufsize*/
	DPCPCI3096_ERR_INVALID_DEVSHAREENDIS,	/*!<-982	Invalid Devshareendis*/
	DPCPCI3096_ERR_INVALID_GRPNUM,			/*!<-981	Invalid Grpnum*/
	DPCPCI3096_ERR_INVALID_INPUTMODE,		/*!<-980	Invalid Inputmode*/
	DPCPCI3096_ERR_INVALID_STROBESEL,		/*!<-979	Invalid Strobesel*/
	DPCPCI3096_ERR_INVALID_SELFTESTENDIS,	/*!<-978	Invalid Selftestendis*/
	DPCPCI3096_ERR_INVALID_POLARITY,		/*!<-977	Invalid Polarity*/
	DPCPCI3096_ERR_INVALID_EDGESELECT,		/*!<-976	Invalid Edgeselect*/
	DPCPCI3096_ERR_INVALID_DEBOUNCETIME,	/*!<-975	Invalid Debouncetime*/
	DPCPCI3096_ERR_INVALID_CHNNUM,			/*!<-974	Invalid Chnnum*/
	DPCPCI3096_ERR_INVALID_MASK,			/*!<-973	Invalid Mask*/
	DPCPCI3096_ERR_INVALID_MASKCHANNELSEL,	/*!<-972	Invalid Maskchannelsel*/
	DPCPCI3096_ERR_INVALID_EDGESEL,			/*!<-971	Invalid Edgesel*/
	DPCPCI3096_ERR_INVALID_EDGECHNSEL,		/*!<-970	Invalid Edgechnsel*/
	DPCPCI3096_ERR_INVALID_CHANNELNO,		/*!<-969	Invalid Channelno*/
	DPCPCI3096_ERR_INVALID_CHANNELSTATUS,	/*!<-968	Invalid Channelstatus*/
	DPCPCI3096_ERR_INVALID_GROUPSEL,		/*!<-967	Invalid Groupsel*/
	DPCPCI3096_ERR_INVALID_TRIGSEL,			/*!<-966	Invalid Trigsel*/
	DPCPCI3096_ERR_INVALID_PRISECSEL,		/*!<-965	Invalid Prisecsel*/
	DPCPCI3096_ERR_INVALID_MODE,			/*!<-964	Invalid Mode*/
	DPCPCI3096_ERR_INVALID_INTENDIS,		/*!<-963	Invalid Intendis*/
	DPCPCI3096_ERR_INVALID_INTPROPAGATE,	/*!<-962	Invalid Intpropagate*/
	DPCPCI3096_ERR_INVALID_OPTIONS,			/*!<-961	Invalid Options*/
	DPCPCI3096_ERR_INVALID_SELFTESTCONFIG,	/*!<-960	Invalid Selftest configuration*/
	DPCPCI3096_ERR_INVALID_BUFFSIZE,		/*!<-959	Invalid buffsize*/
	DPCPCI3096_ERR_INVALID_GRPSTROBE_CONFIG, /*!<-958	Invalid group strobe configuration*/
	DPCPCI3096_ERR_INVALID_MAXCOUNT, 	/*!<-957       Invalid maximum count*/
	DPCPCI3096_ERR_EVENT_WAIT,				/*!<-956	Invalid event wait*/	
	DPCPCI3096_ERR_TIMEOUT				/*!<-955	Invalid Timeout*/
	
};
#endif
