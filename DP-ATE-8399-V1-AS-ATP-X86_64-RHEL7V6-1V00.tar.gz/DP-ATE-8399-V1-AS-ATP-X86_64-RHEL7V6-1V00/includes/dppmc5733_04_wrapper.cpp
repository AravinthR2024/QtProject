/**************************************************************************
// File Name:dppmc5733_04_wrapper.cpp
// Author:
// Created Date:30/06/2020
// Description: Defined for the Wrapper Function.
**************************************************************************/
#include "dppmc5733_04_wrapper.h"
#include "string.h"

#define LIB  0

/**************************************************************************
// Name                         : Init
// Author                       :
// Global Variables affected	:
// Created Date					: 30/06/2020
// Revision Date				:
// Reason for Revising			:
// Description					: This Function is used to Initialize the 5733 PMC Board
**************************************************************************/
S16BIT DPPMC5733_Wrapper::Init(PSDPPMC5733_04_DEVICE_LOCATION out_pSDevLocation)
{
    U8BIT u8ChannelNo  = LINS_5733_INITIALIZE_0;
    U8BIT u8Loop	 = LINS_5733_INITIALIZE_0;
    SDPPMC5733_04_GLUE_LOGIC_DETAILS SGlueLogicDetails;

#if LIB

    /* find the available boards as per the filter */
    m_s32RetVal = DPPMC5733_04_GetTotalDeviceFound(&m_u16NoOfBrds);
    if(m_s32RetVal != DP_LINS_5733_SUCCESS)
    {
        DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_5733_FAILURE;
    }

    /* Get All device Location Details */
    m_s32RetVal = DPPMC5733_04_GetAllDeviceLocations(out_pSDevLocation, m_u16NoOfBrds);
    if(m_s32RetVal != DP_LINS_5733_SUCCESS)
    {
        DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_5733_FAILURE;
    }

    for(u8ChannelNo = 0; u8ChannelNo < DP_5733_MAX_CHANNELS; u8ChannelNo++)
    {
        /* open the found Channels */
		out_pSDevLocation[u8ChannelNo].m_u8ChannelNo = u8ChannelNo+1;
        m_s32RetVal = DPPMC5733_04_Open(&out_pSDevLocation[u8ChannelNo], &m_hHandle[u8ChannelNo]);
//qDebug() << "Handle:" << hex << m_hHandle[u8ChannelNo];
        if(m_s32RetVal != DP_LINS_5733_SUCCESS)
        {
            DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_5733_FAILURE;
        }

        m_s32RetVal = DPPMC5733_04_GetGlueLogicDetails(m_hHandle[u8ChannelNo], &SGlueLogicDetails);
        if(m_s32RetVal != DP_LINS_5733_SUCCESS)
        {
            DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_5733_FAILURE;
        }
    }

    m_u16FPGATypeId = (SGlueLogicDetails.m_u16FPGATypeId & 0xFF);
#endif

    return DP_LINS_5733_SUCCESS;
}

/**************************************************************************
// Name                         : Config
// Author                       :
// Global Variables affected	:
// Created Date					: 30/06/2020
// Revision Date				:
// Reason for Revising			:
// Description					: This Function is used to config the 5733 PMC Board
**************************************************************************/
S16BIT DPPMC5733_Wrapper::Configure(U16BIT in_u16ChannelNo, S_DPU_CONFIGURATION_VALUE in_sConfigValues)
{

    U8BIT u8Loop = LINS_5733_INITIALIZE_0;
#if LIB
    m_s32RetVal = DPPMC5733_04_SetBaudrate(m_hHandle[in_u16ChannelNo-1], in_sConfigValues.u8BaudRate);
    if(m_s32RetVal != DP_LINS_5733_SUCCESS)
    {
        DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_5733_FAILURE;
    }

    m_SFrame[in_u16ChannelNo-1].m_u8StartStopBitSel = in_sConfigValues.u8StartStopBit;
    m_SFrame[in_u16ChannelNo-1].m_u8ModeBitSel = in_sConfigValues.u8ModeBit;
    m_SFrame[in_u16ChannelNo-1].m_u8RspDataTypeSel = in_sConfigValues.u8RspDataType;
    m_SFrame[in_u16ChannelNo-1].m_u8DataByteSel = in_sConfigValues.u8DataByte;

    m_s32RetVal = DPPMC5733_04_SetConfiguration(m_hHandle[in_u16ChannelNo-1], &m_SFrame[in_u16ChannelNo-1]);
    if(m_s32RetVal != DP_LINS_5733_SUCCESS)
    {
        DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_5733_FAILURE;
    }

    m_s32RetVal = DPPMC5733_04_SetMode(m_hHandle[in_u16ChannelNo-1], in_sConfigValues.u8ModeSel);
    if(m_s32RetVal != DP_LINS_5733_SUCCESS)
    {
        DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_5733_FAILURE;
    }

    m_s32RetVal = DPPMC5733_04_SetMessageTime(m_hHandle[in_u16ChannelNo-1], in_sConfigValues.u8MsgTime);
    if(m_s32RetVal != DP_LINS_5733_SUCCESS)
    {
        DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_5733_FAILURE;
    }

    m_s32RetVal = DPPMC5733_04_SetFrameTime(m_hHandle[in_u16ChannelNo-1], in_sConfigValues.u8FrameTime);
    if(m_s32RetVal != DP_LINS_5733_SUCCESS)
    {
        DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_5733_FAILURE;
    }

    m_s32RetVal = DPPMC5733_04_TimeOutConfig(m_hHandle[in_u16ChannelNo-1], in_sConfigValues.fRxTimeOut);
    if(m_s32RetVal != DP_LINS_5733_SUCCESS)
    {
        DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_5733_FAILURE;
    }

    if(in_sConfigValues.u8ModeSel)
    {
        m_s32RetVal = DPPMC5733_04_ResponseTime(m_hHandle[in_u16ChannelNo-1], in_sConfigValues.fRxRespTime);
        if(m_s32RetVal != DP_LINS_5733_SUCCESS)
        {
            DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_5733_FAILURE;
        }
    }

    m_s32RetVal = DPPMC5733_04_SetThreshold(m_hHandle[in_u16ChannelNo-1], 510/*in_sConfigValues.u32Threshold*/);
    if(m_s32RetVal != DP_LINS_5733_SUCCESS)
    {
        DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_5733_FAILURE;
    }

    m_s32RetVal =DPPMC5733_04_EnableInterrupt(m_hHandle[in_u16ChannelNo-1], 8 ,8192);// 8 - for setting interrupt when reaching  threshold value
    if(m_s32RetVal != DP_LINS_5733_SUCCESS)
    {
        DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_5733_FAILURE;
    }
#endif
    return DP_LINS_5733_SUCCESS;
}

/**************************************************************************
// Name                         : RamSelection
// Author                       :
// Global Variables affected	:
// Created Date					: 30/06/2020
// Revision Date				:
// Reason for Revising			:
// Description					: This Function is used to select RAM for 5733 PMC Board transmission
**************************************************************************/
S16BIT DPPMC5733_Wrapper::RamSelection(U16BIT in_u16ChannelNo, U8BIT in_u8BuffSel, U8BIT in_u8StartOffset, U8BIT in_u8EndOffset, PU8BIT in_pu8CmdData)
{
#if LIB
    if (in_u16ChannelNo >= 1 && in_u16ChannelNo <= m_u16NoOfBrds)
    {
        m_s32RetVal = DPPMC5733_04_RAMSelection(m_hHandle[in_u16ChannelNo-1], in_u8BuffSel);
        if(m_s32RetVal != DP_LINS_5733_SUCCESS)
        {
            DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_5733_FAILURE;
        }

        m_s32RetVal = DPPMC5733_04_TxRAMSelection(m_hHandle[in_u16ChannelNo-1], in_u8BuffSel);
        if(m_s32RetVal != DP_LINS_5733_SUCCESS)
        {
            DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_5733_FAILURE;
        }

        m_s32RetVal = DPPMC5733_04_TxCmdSelect(m_hHandle[in_u16ChannelNo-1], in_u8StartOffset, in_u8EndOffset);
        if(m_s32RetVal != DP_LINS_5733_SUCCESS)
        {
            DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_5733_FAILURE;
        }

        m_s32RetVal = DPPMC5733_04_TxCmdWrite(m_hHandle[in_u16ChannelNo-1], in_u8StartOffset, ((in_u8EndOffset - in_u8StartOffset) + 1), in_pu8CmdData);
        if(m_s32RetVal != DP_LINS_5733_SUCCESS)
        {
            DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_5733_FAILURE;
        }
    }
    else
    {
        sprintf(m_szErrorMsg, "Invalid Channel Number");
        return DP_LINS_5733_FAILURE;
    }
#endif
    return DP_LINS_5733_SUCCESS;
}

/**************************************************************************
// Name                         : TxCmdSelectWrite
// Author                       :
// Global Variables affected	:
// Created Date					: 30/06/2020
// Revision Date				:
// Reason for Revising			:
// Description					: This Function is used to Initialize the commands for 5733 PMC Board
**************************************************************************/
S16BIT DPPMC5733_Wrapper::TxRamSelection(U16BIT in_u16ChannelNo, U8BIT in_u8BuffSel)
{
#if LIB
    if (in_u16ChannelNo >= 1 && in_u16ChannelNo <= m_u16NoOfBrds)
    {
        m_s32RetVal = DPPMC5733_04_TxRAMSelection(m_hHandle[in_u16ChannelNo-1], in_u8BuffSel);
        if(m_s32RetVal != DP_LINS_5733_SUCCESS)
        {
            DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_5733_FAILURE;
        }
    }
    else
    {
        sprintf(m_szErrorMsg, "Invalid Channel Number");
        return DP_LINS_5733_FAILURE;
    }
#endif
    return DP_LINS_5733_SUCCESS;
}

/**************************************************************************
// Name                         : StartStopTransmission
// Author                       :
// Global Variables affected	:
// Created Date					: 30/06/2020
// Revision Date				:
// Reason for Revising			:
// Description					: This Function is used to Start or Stop the transmission of 5733 PMC Board
**************************************************************************/
S16BIT DPPMC5733_Wrapper::StartStopTransmission(U16BIT in_u16ChannelNo, U8BIT in_u8TxRxSel, U8BIT in_u8TxRxStartStop)
{
#if LIB
    if (in_u16ChannelNo >= 1 && in_u16ChannelNo <= m_u16NoOfBrds)
    {
        m_s32RetVal =DPPMC5733_04_RxFifoReset(m_hHandle[in_u16ChannelNo-1], 1);
        if(m_s32RetVal != DP_LINS_5733_SUCCESS)
        {
            DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_5733_FAILURE;
        }

        m_s32RetVal = DPPMC5733_04_StartStopTransmission(m_hHandle[in_u16ChannelNo-1], in_u8TxRxSel, in_u8TxRxStartStop);
        if(m_s32RetVal != DP_LINS_5733_SUCCESS)
        {
            DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_5733_FAILURE;
        }
    }
    else
    {
        sprintf(m_szErrorMsg, "Invalid Channel Number");
        return DP_LINS_5733_FAILURE;
    }
#endif
    return DP_LINS_5733_SUCCESS;
}

/**************************************************************************
// Name                         : RxReadMessage
// Author                       :
// Global Variables affected	:
// Created Date					: 30/06/2020
// Revision Date				:
// Reason for Revising			:
// Description					: This Function is used to read data from the hardware
**************************************************************************/
S16BIT DPPMC5733_Wrapper::RxReadMessage(U16BIT in_u16ChannelNo, U8BIT u8ReadOpt, U32BIT u32Timeout, U16BIT u16DataToRead, U16BIT *pu16AvailData, U8BIT *pu8ReadData)
{
    unsigned int Fifocnt=0;
#if LIB
    if(!(in_u16ChannelNo >= 1 && in_u16ChannelNo <= m_u16NoOfBrds+1))
    {
        sprintf(m_szErrorMsg, "Invalid Channel Number");
        return DP_LINS_5733_FAILURE;
    }

    m_s32RetVal = DPPMC5733_04_RxReadMessage(m_hHandle[in_u16ChannelNo-1],  u8ReadOpt, &u32Timeout, u16DataToRead, pu16AvailData, pu8ReadData);
    /* m_u8ReadOpt - '0' to get one data, '1' to wait untill specified number of data received within m_pu32Timeout period */
    if(m_s32RetVal)
    {
        DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_5733_FAILURE;
    }
#endif
    return DP_LINS_5733_SUCCESS;
}

/**************************************************************************
// Name                         : Reset
// Author                       :
// Global Variables affected    : 1
// Created Date                 : 30/06/2020
// Revision Date                :
// Reason for Revising          :
// Description                  : This Function is used to reset the 5733 PMC Board
**************************************************************************/
S16BIT DPPMC5733_Wrapper::Reset(U16BIT in_u16ChannelNo)
{
    U8BIT u8ChannelNo = LINS_5733_INITIALIZE_0;
#if LIB
    if(in_u16ChannelNo)
    {
        if (in_u16ChannelNo >= 1 && in_u16ChannelNo <= m_u16NoOfBrds)
        {
            m_s32RetVal = DPPMC5733_04_DisableInterrupt(m_hHandle[in_u16ChannelNo-1],0);
            if((m_s32RetVal != DP_LINS_5733_SUCCESS)&& (m_s32RetVal != -965))
            {
                DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_LINS_5733_FAILURE;
            }

            m_s32RetVal = DPPMC5733_04_Reset(m_hHandle[in_u16ChannelNo-1]);
            if(m_s32RetVal != DP_LINS_5733_SUCCESS)
            {
                DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_LINS_5733_FAILURE;
            }
        }
        else
        {
            sprintf(m_szErrorMsg, "Invalid Channel Number");
            return DP_LINS_5733_FAILURE;
        }
    }
    else
    {
        for(u8ChannelNo = 0; u8ChannelNo < (m_u16NoOfBrds); u8ChannelNo++)
        {
            m_s32RetVal = DPPMC5733_04_DisableInterrupt(m_hHandle[u8ChannelNo],0);
            if((m_s32RetVal != DP_LINS_5733_SUCCESS)&& (m_s32RetVal != -965))
            {
                DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_LINS_5733_FAILURE;
            }

            m_s32RetVal = DPPMC5733_04_Reset(m_hHandle[u8ChannelNo]);
            if(m_s32RetVal != DP_LINS_5733_SUCCESS)
            {
                DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_LINS_5733_FAILURE;
            }
        }
    }
#endif
    return DP_LINS_5733_SUCCESS;
}

/**************************************************************************
// Name                         : Close
// Author                       :
// Global Variables affected    : 1
// Created Date                 : 30/06/2020
// Revision Date                :
// Reason for Revising          :
// Description                  : This Function is used to Close the 5733 PMC Board
**************************************************************************/
S16BIT DPPMC5733_Wrapper::Close(U16BIT in_u16ChannelNo)
{
    U8BIT u8ChannelNo = LINS_5733_INITIALIZE_0;
#if LIB
    if(in_u16ChannelNo)
    {
        if (in_u16ChannelNo >= 1 && in_u16ChannelNo <= m_u16NoOfBrds)
        {
            m_s32RetVal = DPPMC5733_04_Close(m_hHandle[in_u16ChannelNo-1]);
            if(m_s32RetVal != DP_LINS_5733_SUCCESS)
            {
                DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_LINS_5733_FAILURE;
            }
        }
        else
        {
            sprintf(m_szErrorMsg, "Invalid Bord Number");
            return DP_LINS_5733_FAILURE;
        }
    }
    else
    {
        for(u8ChannelNo = LINS_5733_INITIALIZE_0; u8ChannelNo < m_u16NoOfBrds; u8ChannelNo++)
        {
            m_s32RetVal = DPPMC5733_04_Close(m_hHandle[u8ChannelNo]);
            if(m_s32RetVal != DP_LINS_5733_SUCCESS)
            {
                DPPMC5733_04_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_LINS_5733_FAILURE;
            }
        }
    }
#endif
    return DP_LINS_5733_SUCCESS;
}

/**************************************************************************
// Name                         : GetLastErrorMsg
// Author                       :
// Global Variables affected    :
// Created Date					: 30/06/2020
// Revision Date				:
// Reason for Revising          :
// Description					: This Function is used to get last error message
**************************************************************************/
QString DPPMC5733_Wrapper::GetLastErrorMsg()
{
    QString sErrStr;

    sErrStr.sprintf("%s",m_szErrorMsg);

    return sErrStr;
}
