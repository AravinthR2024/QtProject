#include "dp-lins_psu_wrapper.h"
#include "QDebug"
#include "QThread"

CDP_PSU_Wrapper::CDP_PSU_Wrapper(unsigned char in_ucMode)
{
    m_ucIsDaisyChain = in_ucMode;
    memset(m_fCurrentRating, 0.0, sizeof(m_fCurrentRating));
    memset(m_fVoltRating, 0.0, sizeof(m_fVoltRating));
}

/**************************************************************************
// Name						:  DP_GetDaisyChainMode
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  Get Daisy Chain Mode
**************************************************************************/
short CDP_PSU_Wrapper::DP_GetDaisyChainMode(unsigned char *out_pucMode)
{
    *out_pucMode = m_ucIsDaisyChain;

    return DP_PSU_SUCCESS;
}
/**************************************************************************
// Name						:  ConfigCOM1Port
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  COM port Open
**************************************************************************/
short CDP_PSU_Wrapper::ConfigCOM1Port(QString in_qsComNo, unsigned int in_ulBaudRate, unsigned char in_ucStopBit, unsigned char in_ucDataBits, unsigned char in_ucParity)
{
    if(m_objqserialportUART.isOpen())
        m_objqserialportUART.close();

    m_objqserialportUART.setPortName(in_qsComNo);

    switch(in_ulBaudRate)
    {
    case QSerialPort::Baud1200:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud1200);
        break;
    }
    case QSerialPort::Baud2400:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud2400);
        break;
    }
    case QSerialPort::Baud4800:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud4800);
        break;
    }
    case QSerialPort::Baud9600:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud9600);
        break;
    }
    case QSerialPort::Baud19200:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud19200);
        break;
    }
    case QSerialPort::Baud38400:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud38400);
        break;
    }
    case QSerialPort::Baud57600:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud57600);
        break;
    }
    case QSerialPort::Baud115200:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::Baud115200);
        break;
    }
    default:
    {
        m_objqserialportUART.setBaudRate(QSerialPort::UnknownBaud);
        return DP_PSU_INVALID_BAUDRATE;
    }
    }

    //Set Data Bits
    if(in_ucDataBits == QSerialPort::Data5)
    {
        m_objqserialportUART.setDataBits(QSerialPort::Data8);
    }
    else if(in_ucDataBits == QSerialPort::Data6)
    {
        m_objqserialportUART.setDataBits(QSerialPort::Data8);
    }
    else if(in_ucDataBits == QSerialPort::Data7)
    {
        m_objqserialportUART.setDataBits(QSerialPort::Data8);
    }
    else if(in_ucDataBits == QSerialPort::Data8)
    {
        m_objqserialportUART.setDataBits(QSerialPort::Data8);
    }
    else
    {
        m_objqserialportUART.setDataBits(QSerialPort::UnknownDataBits);
        return DP_PSU_INVALID_DATABITS;
    }

    //Set Parity Bit
    if(in_ucParity == QSerialPort::NoParity)
    {
        m_objqserialportUART.setParity(QSerialPort::NoParity);
    }
    else if(in_ucParity == QSerialPort::EvenParity)
    {
        m_objqserialportUART.setParity(QSerialPort::EvenParity);
    }
    else if(in_ucParity == QSerialPort::OddParity)
    {
        m_objqserialportUART.setParity(QSerialPort::OddParity);
    }
    else if(in_ucParity == QSerialPort::SpaceParity)
    {
        m_objqserialportUART.setParity(QSerialPort::SpaceParity);
    }
    else if(in_ucParity == QSerialPort::MarkParity)
    {
        m_objqserialportUART.setParity(QSerialPort::MarkParity);
    }
    else
    {
        m_objqserialportUART.setParity(QSerialPort::UnknownParity);
        return DP_PSU_INVALID_PARITY;
    }

    //Set stop bit
    if(in_ucStopBit == QSerialPort::OneStop)
    {
        m_objqserialportUART.setStopBits(QSerialPort::OneStop);
    }
    else if(in_ucStopBit == QSerialPort::OneAndHalfStop)
    {
        m_objqserialportUART.setStopBits(QSerialPort::OneAndHalfStop);
    }
    else if(in_ucStopBit == QSerialPort::TwoStop)
    {
        m_objqserialportUART.setStopBits(QSerialPort::TwoStop);
    }
    else
    {
        m_objqserialportUART.setStopBits(QSerialPort::UnknownStopBits);
        return DP_PSU_INVALID_DATABITS;
    }

    //Set flow control
    m_objqserialportUART.setFlowControl(QSerialPort::NoFlowControl);

    if(m_objqserialportUART.open(QIODevice::ReadWrite))
    {
        qDebug()<<m_objqserialportUART.portName() + " Opened";
    }
    else
    {
        qDebug()<<m_objqserialportUART.portName() + " Not Opened";
        return DP_PSU_COM_PORT_NOT_OPENED;
    }

    return DP_PSU_SUCCESS;
}

/**************************************************************************
// Name						:  DP_PSU_PowerRating
// Author					:  Manoj L
// Global Variables affected:  NIL
// Created Date				:  28-01-2021
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  To read the Power Supply details such as
                               Voltage and Current Ratings (*IDN query)
**************************************************************************/
short CDP_PSU_Wrapper::DP_PSU_PowerRating(unsigned char in_ucPSUaddress)
{
    short sRetVal = DP_PSU_ZERO;
    QString qsReadData;
    QString qsData;
    qint64 qi64Size = 0;
    int iLength = 0;

    qsData.clear();
#if 1
    for(int iPSUIdx = 0; iPSUIdx < 4; iPSUIdx++)
    {
        /*** Set Address for the Device ***/
        qsData.sprintf("ADR %02d\r", iPSUIdx+1);

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.readAll();

        sRetVal = DP_PSU_ValidateACK(m_qbReadData);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }

        m_qbReadData.clear();

        m_objqserialportUART.clear(QSerialPort::AllDirections);

        qsData.clear();
#endif
        /*** Identification Query ***/

        qsData.sprintf("IDN?\r\n");

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(200);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.readAll();

        qsReadData = m_qbReadData.split(',').first();
        sscanf(m_qbReadData.data(),"LAMBDA,GEN%f-%f, ", &m_fVoltRating[iPSUIdx], &m_fCurrentRating[iPSUIdx]);

        if(strcmp(qsReadData.toLatin1().data(),"LAMBDA") != 0)
        {
            return DP_PSU_INVALID_SESSION_DEVICE;
        }

        m_qbReadData.clear();

        m_objqserialportUART.clear(QSerialPort::AllDirections);

        /*** PSU RESET ***/
        sRetVal = DP_PSU_Reset(DP_PSU_LOCAL_MODE, iPSUIdx+1);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }

        qsData.clear();
        /*** Set Remote Mode ***/
        qsData.sprintf("RMT 1\r");

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        sRetVal = DP_PSU_ValidateACK(m_qbReadData);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }
        m_qbReadData.clear();
    }

    return DP_PSU_SUCCESS;
}

/**************************************************************************
// Name						:  DP_PSU_Open
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  Initiating communication with Power supply
**************************************************************************/
short CDP_PSU_Wrapper::DP_PSU_Open(QString in_qsComNo, unsigned long in_ulBaudRate, unsigned char in_ucStopBit, unsigned char in_ucDataBits, unsigned char in_ucParity)
{
    short sRetVal = DP_PSU_ZERO;
    QString qsReadData;
    QString qsData;
    qint64 qi64Size = 0;
    int iLength = 0;
#if 1
    sRetVal = ConfigCOM1Port(in_qsComNo, in_ulBaudRate, in_ucStopBit, in_ucDataBits, in_ucParity);
    if(sRetVal != DP_PSU_SUCCESS)
    {
        return sRetVal;
    }

    DP_PSU_Reset(DP_PSU_GLOBAL_MODE, 0);
#endif
    return DP_PSU_SUCCESS;
}
/**************************************************************************
// Name						:  DP_PSU_Close
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  Close the communication with Power supply
**************************************************************************/
short CDP_PSU_Wrapper::DP_PSU_Close(unsigned char ucAddress)
{
    QString qsData;
    qint64 qiSize = 0;
    int iLength = 0;
    short sRetVal = 0;

    for(int iPSUIdx = 0; iPSUIdx < 4; iPSUIdx++)
    {
        sRetVal = DP_PSU_Reset(DP_PSU_LOCAL_MODE,iPSUIdx+1);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }

        /*** Close ***/
        qsData.sprintf("RMT 0\r");

        iLength = qsData.length();

        qiSize = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qiSize != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(100);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        sRetVal = DP_PSU_ValidateACK(m_qbReadData);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }
        m_qbReadData.clear();
    }

    m_objqserialportUART.close();

    return DP_PSU_SUCCESS;
}
/**************************************************************************
// Name						:  DP_PSU_Reset
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  Reset of the Power supply
**************************************************************************/
short CDP_PSU_Wrapper::DP_PSU_Reset(unsigned char in_ucLocalorGlobalReset, unsigned char in_ucPsuAddr)
{
    QString qsData;
    qint64 qi64Size = 0;
    int iLength = 0;
    short sRetVal = 0;

    if(in_ucLocalorGlobalReset == DP_PSU_GLOBAL_MODE)
    {
        /*** Global Reset Command ***/
        m_objqserialportUART.clear(QSerialPort::AllDirections);

        qsData.sprintf("GRST\r");

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        sRetVal = DP_PSU_ValidateACK(m_qbReadData);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }

        m_qbReadData.clear();
    }
    else
    {
        if(m_ucIsDaisyChain == DP_PSU_DAISY_CHAIN_MODE)
        {
            m_objqserialportUART.clear(QSerialPort::AllDirections);

            qsData.clear();

            /*** Address of the Device ***/
            qsData.sprintf("ADR %02d\r",in_ucPsuAddr);

            iLength = qsData.length();

            qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
            m_objqserialportUART.waitForBytesWritten(200);

            if(qi64Size != iLength)
            {
                return DP_PSU_CMD_NOT_TRANSMITED;
            }
            QThread::msleep(100);

            m_objqserialportUART.waitForReadyRead(1000);

            m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

            sRetVal = DP_PSU_ValidateACK(m_qbReadData);
            if(sRetVal != DP_PSU_SUCCESS)
            {
                return sRetVal;
            }

            m_qbReadData.clear();
        }

        m_objqserialportUART.clear(QSerialPort::AllDirections);

        qsData.clear();
        /*** Reset Command ***/
        qsData.sprintf("RST\r");

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        sRetVal = DP_PSU_ValidateACK(m_qbReadData);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }

        m_qbReadData.clear();
    }

    return DP_PSU_SUCCESS;
}
/**************************************************************************
// Name						:  DP_PSU_OV_UV_Config
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  Set Over and Under Voltage
**************************************************************************/
short CDP_PSU_Wrapper::DP_PSU_OV_UV_Config(float in_fOverVolt, float in_fUnderVolt, unsigned char in_ucPsuAddr)
{
    qint64 qi64Size = 0;
    QString qsData;
    int iLength = 0;
    short sRetVal = 0;

    if(m_ucIsDaisyChain == DP_PSU_DAISY_CHAIN_MODE)
    {
        m_objqserialportUART.clear(QSerialPort::AllDirections);

        qsData.clear();

        /*** Address of the Device ***/
        qsData.sprintf("ADR %02d\r",in_ucPsuAddr);

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        sRetVal = DP_PSU_ValidateACK(m_qbReadData);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }

        m_qbReadData.clear();
    }

    if(in_ucPsuAddr <= 4)
    {
        if((in_fOverVolt < 0 )||  (in_fOverVolt >= (m_fVoltRating[in_ucPsuAddr-1] * 1.05)) ||  (in_fUnderVolt > in_fOverVolt) || (in_fOverVolt <= (in_fUnderVolt * 1.1)))
        {
            return DP_PSU_INVALID_OVER_UNDER_VOLT_INPUT;
        }
    }

    /*** Over Voltage Set ***/
    if(in_fOverVolt > 0 && in_fOverVolt < 10)
    {
        qsData.sprintf("OVP 0%2.2f\r", in_fOverVolt);
    }
    else
    {
        qsData.sprintf("OVP %.2f\r", in_fOverVolt);
    }

    iLength = qsData.length();

    qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
    m_objqserialportUART.waitForBytesWritten(200);

    if(qi64Size != iLength)
    {
        return DP_PSU_CMD_NOT_TRANSMITED;
    }
    QThread::msleep(100);

    m_objqserialportUART.waitForReadyRead(1000);

    m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

    sRetVal = DP_PSU_ValidateACK(m_qbReadData);
    if(sRetVal != DP_PSU_SUCCESS)
    {
        return sRetVal;
    }

    m_qbReadData.clear();

    /*** Under Voltage Set ***/

    m_objqserialportUART.clear(QSerialPort::AllDirections);
    qsData.clear();

    if(in_fUnderVolt > 0 && in_fUnderVolt < 10)
    {
        qsData.sprintf("UVL 0%2.2f\r", in_fUnderVolt);
    }
    else
    {
        qsData.sprintf("UVL %.2f\r", in_fUnderVolt);
    }

    iLength = qsData.length();

    qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
    m_objqserialportUART.waitForBytesWritten(200);

    if(qi64Size != iLength)
    {
        return DP_PSU_CMD_NOT_TRANSMITED;
    }
    QThread::msleep(100);

    m_objqserialportUART.waitForReadyRead(1000);

    m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

    sRetVal = DP_PSU_ValidateACK(m_qbReadData);
    if(sRetVal != DP_PSU_SUCCESS)
    {
        return sRetVal;
    }

    m_qbReadData.clear();

    return DP_PSU_SUCCESS;
}
/**************************************************************************
// Name						:  DP_PSU_VoltCurrConfig
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  set Voltage and current
**************************************************************************/
short CDP_PSU_Wrapper::DP_PSU_VoltCurrConfig(unsigned char in_ucLocalorGlobalConfig, float in_fvoltage,float in_fcurrent, unsigned char in_ucPsuAddr)
{
    qint64 qi64Size = 0;
    QString qsData;
    int iLength = 0;
    short sRetVal = 0;

    if(in_ucPsuAddr <= 4)
    {
        if(in_fvoltage > m_fVoltRating[in_ucPsuAddr-1] || in_fcurrent > m_fCurrentRating[in_ucPsuAddr-1])
        {
            return DP_PSU_INVALID_VOLT_CURR_INPUT;
        }
    }

    if(in_ucLocalorGlobalConfig == DP_PSU_GLOBAL_MODE)
    {
        m_objqserialportUART.clear(QSerialPort::AllDirections);

        if(in_fvoltage > 0 && in_fvoltage < 10)
        {
            qsData.sprintf("GPV %2.2f\r", in_fvoltage);
        }
        else
        {
            qsData.sprintf("GPV %.2f\r", in_fvoltage);
        }

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        sRetVal = DP_PSU_ValidateACK(m_qbReadData);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }

        m_qbReadData.clear();

        m_objqserialportUART.clear(QSerialPort::AllDirections);

        qsData.clear();

        qsData.sprintf("GPC %1.3f\r", in_fcurrent);

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        sRetVal = DP_PSU_ValidateACK(m_qbReadData);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }

        m_qbReadData.clear();
    }
    else
    {
        if(m_ucIsDaisyChain == DP_PSU_DAISY_CHAIN_MODE)
        {
            m_objqserialportUART.clear(QSerialPort::AllDirections);

            qsData.clear();

            /*** Address of the Device ***/
            qsData.sprintf("ADR %02d\r",in_ucPsuAddr);

            iLength = qsData.length();

            qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
            m_objqserialportUART.waitForBytesWritten(200);

            if(qi64Size != iLength)
            {
                return DP_PSU_CMD_NOT_TRANSMITED;
            }
            QThread::msleep(100);

            m_objqserialportUART.waitForReadyRead(1000);

            m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

            sRetVal = DP_PSU_ValidateACK(m_qbReadData);
            if(sRetVal != DP_PSU_SUCCESS)
            {
                return sRetVal;
            }
            m_qbReadData.clear();
        }

        m_objqserialportUART.clear(QSerialPort::AllDirections);

        qsData.clear();

        if(in_fvoltage > 0 && in_fvoltage < 10)
        {
            qsData.sprintf("PV %2.2f\r", in_fvoltage);
        }
        else
        {
            qsData.sprintf("PV %.2f\r", in_fvoltage);
        }

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        sRetVal = DP_PSU_ValidateACK(m_qbReadData);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }

        m_qbReadData.clear();

        m_objqserialportUART.clear(QSerialPort::AllDirections);

        qsData.clear();

        if(in_fcurrent < DP_PSU_MIN_CURRENT_VAL || in_fcurrent > DP_PSU_MAX_CURRENT_VAL)
            return DP_PSU_INVALID_CURRENT;

        qsData.sprintf("PC %1.3f\r", in_fcurrent);

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        sRetVal = DP_PSU_ValidateACK(m_qbReadData);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }

        m_qbReadData.clear();
    }
    return DP_PSU_SUCCESS;
}


/**************************************************************************
// Name						:  DP_PSU_Readback_Config
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  Read Back Configuration
**************************************************************************/
short CDP_PSU_Wrapper::DP_PSU_Readback_Config(float *out_pfVoltage, float *out_pfCurrent, float *out_pfUnderVoltage, float *out_pfOverVoltage, unsigned char in_ucPsuAddr)
{
    qint64 qi64Size = 0;
    QString qsData;
    int iLength = 0;
    float fMeasVolt = 0;
    float fMeasCurr = 0;
    short sRetVal = 0;

    if(out_pfVoltage == NULL || out_pfCurrent == NULL || out_pfUnderVoltage == NULL)
    {
        return DP_PSU_INVALID_PTR;
    }


    if(m_ucIsDaisyChain == DP_PSU_DAISY_CHAIN_MODE)
    {
        m_objqserialportUART.clear(QSerialPort::AllDirections);

        qsData.clear();

        /*** Address of the Device ***/
        qsData.sprintf("ADR %02d\r",in_ucPsuAddr);

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        sRetVal = DP_PSU_ValidateACK(m_qbReadData);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }

        m_qbReadData.clear();
    }

    qsData.sprintf("DVC?\r");

    iLength = qsData.length();

    qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
    m_objqserialportUART.waitForBytesWritten(200);

    if(qi64Size != iLength)
    {
        return DP_PSU_CMD_NOT_TRANSMITED;
    }
    QThread::msleep(100);

    m_objqserialportUART.waitForReadyRead(1000);

    m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

    sscanf(m_qbReadData.data(),"%f,%f,%f,%f,%f,%f\r",&fMeasVolt,out_pfVoltage,&fMeasCurr,out_pfCurrent,out_pfUnderVoltage,out_pfOverVoltage);

    m_qbReadData.clear();

    return DP_PSU_SUCCESS;
}
/**************************************************************************
// Name						:  DP_PSU_Output
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  OutPut ON/OFF
**************************************************************************/
short CDP_PSU_Wrapper::DP_PSU_Output(unsigned char in_ucLocalorGlobalOutput, unsigned char in_ucOnOff, unsigned char in_ucPsuAddr)
{
    qint64 qi64Size = 0;
    QString qsData;
    int iLength = 0;
    short sRetVal = 0;

    m_qbReadData.clear();

    if(in_ucLocalorGlobalOutput == DP_PSU_GLOBAL_MODE)
    {
        m_objqserialportUART.clear(QSerialPort::AllDirections);

        qsData.clear();

        if(in_ucOnOff == DP_PSU_OUTPUT_ON)
        {
            qsData.sprintf("GOUT 1\r");
        }
        else if(in_ucOnOff == DP_PSU_OUTPUT_OFF)
        {
            qsData.sprintf("GOUT 0\r");
        }

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        sRetVal = DP_PSU_ValidateACK(m_qbReadData);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }

        m_qbReadData.clear();
    }
    else
    {
        m_qbReadData.clear();

        if(m_ucIsDaisyChain == DP_PSU_DAISY_CHAIN_MODE)
        {
            m_objqserialportUART.clear(QSerialPort::AllDirections);

            qsData.clear();

            /*** Address of the Device ***/
            qsData.sprintf("ADR %02d\r",in_ucPsuAddr);

            iLength = qsData.length();

            qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
            m_objqserialportUART.waitForBytesWritten(200);

            if(qi64Size != iLength)
            {
                return DP_PSU_CMD_NOT_TRANSMITED;
            }
            QThread::msleep(100);

            m_objqserialportUART.waitForReadyRead(1000);

            m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

            sRetVal = DP_PSU_ValidateACK(m_qbReadData);
            if(sRetVal != DP_PSU_SUCCESS)
            {
                return sRetVal;
            }

            m_qbReadData.clear();
        }

        m_objqserialportUART.clear(QSerialPort::AllDirections);

        qsData.clear();

        if(in_ucOnOff == DP_PSU_OUTPUT_ON)
        {
            qsData.sprintf("OUT 1\r");
        }
        else if(in_ucOnOff == DP_PSU_OUTPUT_OFF)
        {
            qsData.sprintf("OUT 0\r");
        }

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        sRetVal = DP_PSU_ValidateACK(m_qbReadData);
        if(sRetVal != DP_PSU_SUCCESS)
        {
            return sRetVal;
        }

        m_qbReadData.clear();
    }

    return DP_PSU_SUCCESS;

}

/**************************************************************************
// Name						:  DP_PSU_Measure_Ouput
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  Get Measured Output Voltage and current
**************************************************************************/

short CDP_PSU_Wrapper::DP_PSU_Measure_Ouput(float *out_fVoltage, float *out_fCurrent, unsigned char in_ucPsuAddr)
{
    qint64 qi64Size = 0;
    QString qsData;
    int iLength = 0;
    float fSetVolt = 0;
    float fSetCurr = 0;
    float fOVP = 0;
    float fUVL = 0;

    if(out_fVoltage == NULL || out_fCurrent == NULL)
    {
        return DP_PSU_INVALID_PTR;
    }

    qsData.clear();
    if(m_ucIsDaisyChain == DP_PSU_DAISY_CHAIN_MODE)
    {
        m_objqserialportUART.clear(QSerialPort::AllDirections);

        /*** Address of the Device ***/
        qsData.sprintf("ADR %02d\r",in_ucPsuAddr);

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        if(strcmp(m_qbReadData.data(),"OK\r") != 0)
        {
            return DP_PSU_ACK_NOT_RECEIVED;
        }

        m_qbReadData.clear();
        qsData.clear();
    }

    qsData.sprintf("DVC?\r");

    iLength = qsData.length();

    qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
    m_objqserialportUART.waitForBytesWritten(200);

    if(qi64Size != iLength)
    {
        return DP_PSU_CMD_NOT_TRANSMITED;
    }
    QThread::msleep(100);

    m_objqserialportUART.waitForReadyRead(1000);

    m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

    sscanf(m_qbReadData.data(),"%f,%f,%f,%f,%f,%f\r",out_fVoltage,&fSetVolt,out_fCurrent,&fSetCurr,&fOVP,&fUVL);

    /*** ERROR CHECKING TO BE IMPLEMENTED ***/

    m_qbReadData.clear();

    return DP_PSU_SUCCESS;
}

/**************************************************************************
// Name						:  DP_PSU_ReadStatus
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  Read the status
**************************************************************************/
short CDP_PSU_Wrapper::DP_PSU_ReadStatus(S_DP_PSU_STATUS *out_pSReadStatusVal, unsigned char in_ucPsuAddr)
{
    qint64 qi64Size = 0;
    QString qsData;
    int iLength = 0;

    if(out_pSReadStatusVal == NULL)
    {
        return DP_PSU_INVALID_PTR;
    }

    qsData.clear();

    if(m_ucIsDaisyChain == DP_PSU_DAISY_CHAIN_MODE)
    {
        m_objqserialportUART.clear(QSerialPort::AllDirections);

        /*** Address of the Device ***/
        qsData.sprintf("ADR %02d\r",in_ucPsuAddr);

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        if(strcmp(m_qbReadData.data(),"OK\r") != 0)
        {
            return DP_PSU_ACK_NOT_RECEIVED;
        }

        m_qbReadData.clear();
        qsData.clear();
    }

    qsData.sprintf("STT?\r");

    iLength = qsData.length();

    qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
    m_objqserialportUART.waitForBytesWritten(200);

    if(qi64Size != iLength)
    {
        return DP_PSU_CMD_NOT_TRANSMITED;
    }
    QThread::msleep(100);

    m_objqserialportUART.waitForReadyRead(1000);

    m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

    sscanf(m_qbReadData.data(),"MV(%f),PV(%f),MC(%f),PC(%f),SR(%hu),FR(%hu)\r",&out_pSReadStatusVal->fMeasuredVoltage,&out_pSReadStatusVal->fSetVoltage,&out_pSReadStatusVal->fMeasuredCurrent,&out_pSReadStatusVal->fSetCurrent,&out_pSReadStatusVal->usStatusRegister,&out_pSReadStatusVal->usFaultRegister);

    /*** ERROR CHECKING TO BE IMPLEMENTED ***/

    return DP_PSU_SUCCESS;

}
/**************************************************************************
// Name						:  DP_PSU_Command_Transmit
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  Command Transmit
**************************************************************************/
short CDP_PSU_Wrapper::DP_PSU_Command_Transmit(QString in_qsWriteData, int in_iDataSize, unsigned char in_ucPsuAddr)
{
    qint64 qi64Size = 0;
    QString qsData ;
    int iLength = 0;

    if(m_ucIsDaisyChain == DP_PSU_DAISY_CHAIN_MODE)
    {
        m_objqserialportUART.clear(QSerialPort::AllDirections);

        /*** Address of the Device ***/
        qsData.sprintf("ADR %02d\r",in_ucPsuAddr);

        iLength = qsData.length();

        qi64Size = m_objqserialportUART.write(qsData.toLatin1().data(),iLength);
        m_objqserialportUART.waitForBytesWritten(200);

        if(qi64Size != iLength)
        {
            return DP_PSU_CMD_NOT_TRANSMITED;
        }
        QThread::msleep(100);

        m_objqserialportUART.waitForReadyRead(1000);

        m_qbReadData = m_objqserialportUART.read(DP_PSU_MAX_LEN_READ);

        if(strcmp(m_qbReadData.data(),"OK\r") != 0)
        {
            return DP_PSU_ACK_NOT_RECEIVED;
        }

        m_qbReadData.clear();
        qsData.clear();
    }

    in_qsWriteData += "\r";

    qi64Size = m_objqserialportUART.write(in_qsWriteData.toLatin1().data(),in_iDataSize);
    m_objqserialportUART.waitForBytesWritten(200);

    if(qi64Size != in_iDataSize)
    {
        return DP_PSU_CMD_NOT_TRANSMITED;
    }
    QThread::msleep(150);

    return DP_PSU_SUCCESS;
}

/**************************************************************************
// Name						:  DP_PSU_Command_Transmit
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  Command Transmit
**************************************************************************/
short CDP_PSU_Wrapper::DP_PSU_Command_Reception(int in_iDataSizeToRead, QByteArray *out_pqbaWriteData)
{
    if(out_pqbaWriteData == NULL)
    {
        return DP_PSU_INVALID_PTR;
    }

    m_objqserialportUART.waitForReadyRead(1000);

    *out_pqbaWriteData = m_objqserialportUART.read(in_iDataSizeToRead);

    return DP_PSU_SUCCESS;
}

/**************************************************************************
// Name						:  DP_PSU_ErrorCodeMessage
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  Read the status
**************************************************************************/
short CDP_PSU_Wrapper::DP_PSU_ValidateACK(QByteArray qbaErrorCode)
{
    if(strcmp(qbaErrorCode.data(),"E01\r") == 0)
    {
        return DP_PSU_ERROR_E01;
    }
    else if(strcmp(qbaErrorCode.data(),"E02\r") == 0)
    {
        return DP_PSU_ERROR_E02;
    }
    else if(strcmp(qbaErrorCode.data(),"E04\r") == 0)
    {
        return DP_PSU_ERROR_E04;
    }
    else if(strcmp(qbaErrorCode.data(),"E06\r") == 0)
    {
        return DP_PSU_ERROR_E06;
    }
    else if(strcmp(qbaErrorCode.data(),"E07\r") == 0)
    {
        return DP_PSU_ERROR_E07;
    }
    else if(strcmp(qbaErrorCode.data(),"E08\r") == 0)
    {
        return DP_PSU_ERROR_E08;
    }
    else if(strcmp(qbaErrorCode.data(),"C01\r") == 0)
    {
        return DP_PSU_ERROR_C01;
    }
    else if(strcmp(qbaErrorCode.data(),"C02\r") == 0)
    {
        return DP_PSU_ERROR_C02;
    }
    else if(strcmp(qbaErrorCode.data(),"C03\r") == 0)
    {
        return DP_PSU_ERROR_C03;
    }
    else if(strcmp(qbaErrorCode.data(),"C04\r") == 0)
    {
        return DP_PSU_ERROR_C04;
    }
    else if(strcmp(qbaErrorCode.data(),"C05\r") == 0)
    {
        return DP_PSU_ERROR_C05;
    }
    else if(strcmp(m_qbReadData.data(),"OK\r") != 0)
    {
        return DP_PSU_ACK_NOT_RECEIVED;
    }
    else if(strcmp(m_qbReadData.data(),"OK\r") == 0)
    {
        return DP_PSU_SUCCESS;
    }

    return DP_PSU_SUCCESS;
}
/**************************************************************************
// Name						:  DP_PSU_GetErrorMessage
// Author					:  Manikandan K
// Global Variables affected:  NIL
// Created Date				:  17-01-2020
// Revision Date			:  NIL
// Reason for Revising		:  NIL
// Description				:  Error String return
**************************************************************************/
short CDP_PSU_Wrapper::DP_PSU_GetErrorMessage(short in_sErrorCode, QString *out_pqsErrMsg)
{
    switch(in_sErrorCode)
    {
    case DP_PSU_COM_PORT_NOT_OPENED:
    {
        out_pqsErrMsg->sprintf("Port Not Opened");
        break;
    }
    case DP_PSU_CMD_NOT_TRANSMITED:
    {
        out_pqsErrMsg->sprintf("Data Not Transmitted");
        break;
    }
    case DP_PSU_INVALID_BAUDRATE:
    {
        out_pqsErrMsg->sprintf("Invalid Baud Rate");
        break;
    }
    case DP_PSU_INVALID_DATABITS:
    {
        out_pqsErrMsg->sprintf("Invalid Data Bits");
        break;
    }
    case DP_PSU_INVALID_PARITY:
    {
        out_pqsErrMsg->sprintf("Invalid Parity");
        break;
    }
    case DP_PSU_INVALID_SESSION_DEVICE:
    {
        out_pqsErrMsg->sprintf("Invalid Device");
        break;
    }
    case DP_PSU_ACK_NOT_RECEIVED:
    {
        out_pqsErrMsg->sprintf("Acknowledgement not received");
        break;
    }
    case DP_PSU_INVALID_CURRENT:
    {
        out_pqsErrMsg->sprintf("Invalid Input Current");
        break;
    }
    case DP_PSU_INVALID_PTR:
    {
        out_pqsErrMsg->sprintf("Invalid Pointer");
        break;
    }
    case DP_PSU_INVALID_OVER_UNDER_VOLT_INPUT:
    {
        out_pqsErrMsg->sprintf("Invalid Over or Under Voltage");
        break;
    }
    case DP_PSU_INVALID_VOLT_CURR_INPUT:
    {
        out_pqsErrMsg->sprintf("Invalid Voltage or Current input");
        break;
    }
    case DP_PSU_ERROR_E01:
    {
        out_pqsErrMsg->sprintf("Program voltage (PV) is programmed above acceptable range");
        break;
    }
    case DP_PSU_ERROR_E02:
    {
        out_pqsErrMsg->sprintf(" programming output voltage below under voltage setting");
        break;
    }
    case DP_PSU_ERROR_E04:
    {
        out_pqsErrMsg->sprintf("Over voltage is programmed below acceptable range");
        break;
    }
    case DP_PSU_ERROR_E06:
    {
        out_pqsErrMsg->sprintf("Under Voltage value is programmed above the programmed output voltage");
        break;
    }
    case DP_PSU_ERROR_E07:
    {
        out_pqsErrMsg->sprintf("Programming the Output to ON during a latched fault shut down");
        break;
    }
    case DP_PSU_ERROR_E08:
    {
        out_pqsErrMsg->sprintf("Cannot execute command via Advanced Slave Parallel mode");
        break;
    }
    case DP_PSU_ERROR_C01:
    {
        out_pqsErrMsg->sprintf("Illegal command or query");
        break;
    }
    case DP_PSU_ERROR_C02:
    {
        out_pqsErrMsg->sprintf("Missing parameter");
        break;
    }
    case DP_PSU_ERROR_C03:
    {
        out_pqsErrMsg->sprintf("Illegal parameter");
        break;
    }
    case DP_PSU_ERROR_C04:
    {
        out_pqsErrMsg->sprintf("Checksum error");
        break;
    }
    case DP_PSU_ERROR_C05:
    {
        out_pqsErrMsg->sprintf("Setting out of range");
        break;
    }
    default:
    {
        out_pqsErrMsg->sprintf("Unknown Error");
        break;
    }
    }
    return DP_PSU_SUCCESS;
}
