/**
* \file dpmm1105_pro.h
* \brief This file contains the function prototypes of all the functions or API's are available in this file
*
* \author Giriprakash K
* \date  18 August, 2021
*
* \version   1.00
*
* \copyright Copyright (C) 2019 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
* Phone: 91-44-4741-4000\n
* FAX: 91-44-4741-4444 \n
*
*/

#ifndef _DPMM1123_PRO_H_
#define _DPMM1123_PRO_H_

#include "dp_types.h"

#if defined(__cplusplus) || defined(__cplusplus__)
extern "C" {
#endif

	/*!
		This maxiumum bar macro is defined as six and used to carrier bar information
	*/
#define DPMM1123_MAX_BARS 6

	/***********************************Structures************************/
#pragma pack(push,1)

/**
*\struct    _SDPMM1123_DEVICE_LOCATION
*\brief  	This structure contains members to hold the device locations details
*
*			The device location details includes the bus number, slot number, function number and channel number.
*
*\var		typedef struct _SDPMM1123_DEVICE_LOCATION SDPMM1123_DEVICE_LOCATION
*\brief		Indicates type definition for device location structure
*
*			This SDPMM1123_DEVICE_LOCATION type definition macro is used in all place instead of struct _SDPMM1123_DEVICE_LOCATION.
*
*\var 		typedef struct _SDPMM1123_DEVICE_LOCATION *PSDPMM1123_DEVICE_LOCATION
*\brief 	Indicates type definition for device location structure pointer
*
*			This PSDPMM1123_DEVICE_LOCATION type definition macro is used in all place instead of struct _SDPMM1123_DEVICE_LOCATION pointer.
*/
typedef struct _SDPMM1123_DEVICE_LOCATION
{
	U8BIT m_u8BusType;				/*!< Device bus type */
	union
	{
		struct
		{
			U8BIT m_u8BusNo;		/*!< Bus number */
			U8BIT m_u8SlotNo;		/*!< Slot number */
			U8BIT m_u8FunctionNo;	/*!< Function number */
		}pci;
	}u;
	U8BIT 	m_u8MMSlotNo;	/*!< Slot number */                             /* function number */
}SDPMM1123_DEVICE_LOCATION, *PSDPMM1123_DEVICE_LOCATION;

/**
*\struct    _SDPMM1123_DRIVER_DETAILS
*\brief  	This structure contains members to hold the driver details
*
*			The driver details includes the driver version.
*
*\var		typedef struct _SDPMM1123_DRIVER_DETAILS SDPMM1123_DRIVER_DETAILS
*\brief		Indicates type definition for driver details structure
*
*			This SDPMM1123_DRIVER_DETAILS type definition macro is used in all place instead of struct _SDPMM1123_DRIVER_DETAILS.
*
*\var 		typedef struct _SDPMM1123_DRIVER_DETAILS *PSDPMM1123_DRIVER_DETAILS
*\brief 	Indicates type definition for driver details structure pointer
*
*			This _SDPMM1123_DRIVER_DETAILS type definition macro is used in all place instead of struct PSDPMM1123_DRIVER_DETAILS pointer.
*/
typedef struct _SDPMM1123_DRIVER_DETAILS
{
	U32BIT m_u32Version;	/*!< Driver version */                                   /* Driver Version */
}SDPMM1123_DRIVER_DETAILS, *PSDPMM1123_DRIVER_DETAILS;

/**
*\struct 	_SDPMM1123_DEVICE_DETAILS
*\brief		This structure contains members to hold the device details
*
*			This device details includes device Id
*
*\var		typedef struct _SDPMM1123_DEVICE_DETAILS SDPMM1123_DEVICE_DETAILS
*\brief		Indicates type definition for device details structure
*
*			This SDPMM1123_DEVICE_DETAILS type definition macro is used in all place instead of struct _SDPMM1123_DEVICE_DETAILS.
*
*\var 		typedef struct _SDPMM1123_DEVICE_DETAILS *PSDPMM1123_DEVICE_DETAILS
*\brief 	Indicates type definition for device details structure pointer
*
*			This _SDPMM1123_DEVICE_DETAILS type definition macro is used in all place instead of struct PSDPMM1123_DEVICE_DETAILS pointer.
*/
typedef struct _SDPMM1123_DEVICE_DETAILS
{
        U16BIT  m_u16DeviceId;                                   /*!< Board ID*/
}SDPMM1123_DEVICE_DETAILS, *PSDPMM1123_DEVICE_DETAILS;

/**
*\struct 	_SDPMM1123_BAR_INFO
*\brief		This structure contains members to hold the bar information details
*
*			This bar information includes io or memory mapped, physical address, bar size
*
*\var		typedef struct _SDPMM1123_BAR_INFO SDPMM1123_BAR_INFO
*\brief		Indicates type definition for bar information structure
*
*			This SDPMM1123_BAR_INFO type definition macro is used in all place instead of struct _SDPMM1123_BAR_INFO.
*
*\var 		typedef struct _SDPMM1123_BAR_INFO *PSDPMM1123_BAR_INFO
*\brief 	Indicates type definition for bar information structure pointer
*
*			This PSDPMM1123_BAR_INFO type definition macro is used in all place instead of struct _SDPMM1123_BAR_INFO pointer.
*/
typedef struct _SDPMM1123_BAR_INFO
{
	U8BIT   m_u8IsIoMapped;				/*!< Io mapped or Memory mapped */
	U32BIT  m_u32BarSize;				/*!< Bar Size */
	U32BIT  m_u32PhysicalAddressLSB;	/*!< Physical address of LSB */
	U32BIT  m_u32PhysicalAddressMSB;	/*!< Physical address of MSB */
	U32BIT  m_u32VirtualAddressLSB;		/*!< Virtual Address of LSB*/
	U32BIT  m_u32VirtualAddressMSB;		/*!< Virtual Address of MSB*/			/*!< bar size */
}SDPMM1123_BAR_INFO, *PSDPMM1123_BAR_INFO;

/**
*\struct 	_SDPMM1123_CARRIER_DEVICE_INFO
*\brief		This structure contains members to hold the carrier device information details
*
*			This carrier device information includes device Id, Irq line, bar information and device location
*
*\var		typedef struct _SDPMM1123_CARRIER_DEVICE_INFO SDPMM1123_CARRIER_DEVICE_INFO
*\brief		Indicates type definition for carrier device information structure
*
*			This SDPMM1123_CARRIER_DEVICE_INFO type definition macro is used in all place instead of struct _SDPMM1123_CARRIER_DEVICE_INFO.
*
*\var 		typedef struct _SDPMM1123_CARRIER_DEVICE_INFO *PSDPMM1123_CARRIER_DEVICE_INFO
*\brief 	Indicates type definition for carrier device information structure pointer
*
*			This PSDPMM1123_CARRIER_DEVICE_INFO type definition macro is used in all place instead of struct _SDPMM1123_CARRIER_DEVICE_INFO pointer.
*/
typedef struct _SDPMM1123_CARRIER_DEVICE_INFO
{
        U8BIT                           m_u8IrqLine;            		/*!< carrier irq line number */
        U16BIT                          m_u16DeviceId;           		/*!< carrier device id */
        SDPMM1123_BAR_INFO              m_SBarInfo[DPMM1123_MAX_BARS];	/*!< Bar information */
        SDPMM1123_DEVICE_LOCATION       m_SMMDeviceLocation;				/*!< device location */
}SDPMM1123_CARRIER_DEVICE_INFO, *PSDPMM1123_CARRIER_DEVICE_INFO;

/**
*\struct 	_SDPMM1123_INT_STATUS
*\brief		This structure contains members to hold the interrupt enable status
*
*			This interrupt status includes interrupt mode and channel number
*
*\var		typedef struct _SDPMM1123_INT_STATUS SDPMM1123_INT_STATUS
*\brief		Indicates type definition for interrupt status information structure
*
*			This SDPMM1123_INT_STATUS type definition macro is used in all place instead of struct _SDPMM1123_INT_STATUS.
*
*\var 		typedef struct _SDPMM1123_INT_STATUS *PSDPMM1123_INT_STATUS
*\brief 	Indicates type definition for interrupt status information structure pointer
*
*			This PSDPMM1123_INT_STATUS type definition macro is used in all place instead of struct _SDPMM1123_INT_STATUS pointer.
*/
typedef struct _SDPMM1123_INT_STATUS
{
        U8BIT  m_u8InterruptMode;
        U8BIT  m_u8InterruptChannel;
}SDPMM1123_INT_STATUS, *PSDPMM1123_INT_STATUS;


/**
*\struct	_SDPMM1123_INTERRUPT_ENABLE_REG
*\brief		This structure contains members to hold the Interrupt Enable details.
*
*			The Interrupt Enable details include the FIFOEmpty, FIFOFull, FIFOHalffull and FIFOThreshold:
*
*\var		typedef struct _SDPMM1123_INTERRUPT_ENABLE_REG SDPMM1123_INTERRUPT_ENABLE_REG
*\brief		Indicates type definition for Interrupt Enable structure
*
*			This SDPMM1123_INTERRUPT_ENABLE_REG type definition macro is used in all place instead of struct _SDPMM1123_INTERRUPT_ENABLE_REG.
*
*\var 		typedef struct _SDPMM1123_INTERRUPT_ENABLE_REG *PSDPMM1123_INTERRUPT_ENABLE_REG
*\brief 	Indicates type definition for Interrupt Enable structure pointer
*
*			This PSDPMM1123_INTERRUPT_ENABLE_REG type definition macro is used in all place instead of struct _SDPMM1123_INTERRUPT_ENABLE_REG pointer.
*/
typedef struct _SDPMM1123_INTERRUPT_ENABLE_REG   
{
	U32BIT FIFOEmpty:1;         /*!< Enables or disables the FIFO Empty Interrupt */
	U32BIT FIFOFull:1;          /*!< Enables or disables the FIFO Full Interrupt  */
	U32BIT FIFOHalffull:1;      /*!< Enables or disables the FIFO Half full Interupt */
	U32BIT FIFOThreshold:1;     /*!< Enables or disables the FIFO Threshold Interrupt */
	U32BIT Reserved:24;         /*!< Reserved */
}SDPMM1123_INTERRUPT_ENABLE_REG, *PSDPMM1123_INTERRUPT_ENABLE_REG;

/**
*\struct 	_SDPMM1123_GLUE_LOGIC_DETAILS
*\brief		This structure contains members to hold the FPGA details
*
*			This FPGA details includes the FPGA version
*
*\var		typedef struct _SDPMM1123_GLUE_LOGIC_DETAILS SDPMM1123_GLUE_LOGIC_DETAILS
*\brief		Indicates type definition for FPGA details structure
*
*			This SDPMM1123_GLUE_LOGIC_DETAILS type definition macro is used in all place instead of struct _SDPMM1123_GLUE_LOGIC_DETAILS.
*
*\var 		typedef struct _SDPMM1123_GLUE_LOGIC_DETAILS *PSDPMM1123_GLUE_LOGIC_DETAILS
*\brief 	Indicates type definition for FPGA details structure pointer
*
*			This PSDPMM1123_GLUE_LOGIC_DETAILS type definition macro is used in all place instead of struct _SDPMM1123_GLUE_LOGIC_DETAILS pointer.
*/
typedef struct _SDPMM1123_GLUE_LOGIC_DETAILS
{
	U16BIT m_u16FpgaVer;
}SDPMM1123_GLUE_LOGIC_DETAILS, *PSDPMM1123_GLUE_LOGIC_DETAILS;

/**
*\struct	_SDPMM1123_CONFIGURATION
*\brief		This structure contains members to hold the ADC configuration details.
*
*			The ADC configuration details include the Mode, Bridge Completion, Excitation Voltage, Shumnt Calibration, Gausge Factor, Acqusition Rate
*
*\var		typedef struct _SDPMM1123_CONFIGURATION SDPMM1123_CONFIGURATION
*\brief		Indicates type definition for ADC configuration structure
*
*			This SDPMM1123_CONFIGURATION type definition macro is used in all place instead of struct _SDPMM1123_CONFIGURATION.
*
*\var 		typedef struct _SDPMM1123_CONFIGURATION *PSDPMM1123_CONFIGURATION
*\brief 	Indicates type definition for ADC configuration structure pointer
*
*			This PSDPMM1123_CONFIGURATION type definition macro is used in all place instead of struct _SDPMM1123_CONFIGURATION pointer.
*/
typedef struct _SDPMM1123_CONFIGURATION
{
        U8BIT m_u8Mode;   				/*!< Hi accuracy : 1 or normal mode : 0 */
        U8BIT m_u8BridgeCompletion;		/*!< Min : 0 or Max : 1 */
        U8BIT m_u8ExcitationVoltage;	/*!< Min : 0V or Max : 5V */
        U8BIT m_u8ShuntCalibration;		/*!< Min : 0 or Max : 1 */
        FDOUBLE m_dGaugeFactor;
        U16BIT m_u16AcquisitionRate;	/*!< 7Hz to 3516Hz */
}SDPMM1123_CONFIGURATION ,*PSDPMM1123_CONFIGURATION;

/**
*\struct	_SDPMM1123_THERMISTORVALUES
*\brief		This structure contains members to hold the Thermistor Values.
*
*			The Thermistor Values include the Volate, Resistance and Temperature
*
*\var		typedef struct _SDPMM1123_THERMISTORVALUES SDPMM1123_THERMISTORVALUES
*\brief		Indicates type definition for Thermistor Value structure
*
*			This SDPMM1123_THERMISTORVALUES type definition macro is used in all place instead of struct _SDPMM1123_THERMISTORVALUES.
*
*\var 		typedef struct _SDPMM1123_THERMISTORVALUES *PSDPMM1123_THERMISTORVALUES
*\brief 	Indicates type definition for Thermistor Value structure pointer
*
*			This PSDPMM1123_THERMISTORVALUES type definition macro is used in all place instead of struct _SDPMM1123_THERMISTORVALUES pointer.
*/
typedef struct _SDPMM1123_THERMISTORVALUES
{
        FDOUBLE  m_dVoltage;
        FDOUBLE  m_dResistance;
        FDOUBLE  m_dTemperature;
}SDPMM1123_THERMISTORVALUES ,*PSDPMM1123_THERMISTORVALUES;

/**
*\struct	_SDPMM1123_LOADCALIBCONSTANTS
*\brief		This structure contains members to hold the LoadCalibration Values.
*
*			The LoadCalibration Values include the Calibration type and slope & constants
*
*\var		typedef struct _SDPMM1123_LOADCALIBCONSTANTS SDPMM1123_LOADCALIBCONSTANTS
*\brief		Indicates type definition for LoadCalibration Constant structure
*
*			This SDPMM1123_LOADCALIBCONSTANTS type definition macro is used in all place instead of struct _SDPMM1123_LOADCALIBCONSTANTS.
*
*\var 		typedef struct _SDPMM1123_LOADCALIBCONSTANTS *PSDPMM1123_LOADCALIBCONSTANTS
*\brief 	Indicates type definition for LoadCalibration Constant structure pointer
*
*			This PSDPMM1123_LOADCALIBCONSTANTS type definition macro is used in all place instead of struct _SDPMM1123_LOADCALIBCONSTANTS pointer.
*/
typedef struct _SDPMM1123_LOADCALIBCONSTANTS
{
	U8BIT m_u8CalibType;    		/*!< End points or 2 segment calibration (3 points)*/
    FSINGLE m_fSlope1[3][2][5];		/*!< [Max Channel] x [Max Accuracy Mode] x [Max Excitation Volt] */
	FSINGLE m_fSlope2[3][2][5];		/*!< [Max Channel] x [Max Accuracy Mode] x [Max Excitation Volt] */
	FSINGLE m_fConstant[3][2][5];	/*!< [Max Channel] x [Max Accuracy Mode] x [Max Excitation Volt] */
}SLOADCALIBCONSTANTS,*PSLOADCALIBCONSTANTS;

/**
*\struct	_SDPMM1123_CALIBCONSTANTS
*\brief		This structure contains members to hold the Calibration Values.
*
*			The Calibration Values include the Calibration type and slope & constants
*
*\var		typedef struct _SDPMM1123_CALIBCONSTANTS SDPMM1123_CALIBCONSTANTS
*\brief		Indicates type definition for Calibration Constant structure
*
*			This SDPMM1123_CALIBCONSTANTS type definition macro is used in all place instead of struct _SDPMM1123_CALIBCONSTANTS.
*
*\var 		typedef struct _SDPMM1123_CALIBCONSTANTS *PSDPMM1123_CALIBCONSTANTS
*\brief 	Indicates type definition for Calibration Constant structure pointer
*
*			This PSDPMM1123_CALIBCONSTANTS type definition macro is used in all place instead of struct _SDPMM1123_CALIBCONSTANTS pointer.
*/
typedef struct _SDPMM1123_CALIBCONSTANTS
{ 
	U8BIT m_u8CalibType; 	/*!< End points or 2 segment (3 point) calibration */
	FSINGLE m_fSlope1;		/*!< Negative voltge's slopes, if 2 segment calib. if End points calib, Full range slope */
	FSINGLE m_fSlope2;		/*!< Positive voltge's slopes, if 2 segment calib. if End points calib, invalid */
	FSINGLE m_fConstant;	/*!< Constant value */
}SDPMM1123_CALIBCONSTANTS,*PSDPMM1123_CALIBCONSTANTS;

/**
*\struct 	_SDPMM1123_INTERRUPT_INFO
*\brief		This structure contains members to hold the interrupt enable details
*
*			This interrupt details includes interrupt enable and FIFO threshold values
*
*\var		typedef struct _SDPMM1105_INTERRUPT_INFO SDPMM1105_INTERRUPT_INFO
*\brief		Indicates type definition for interrupt details information structure
*
*			This SDPMM1105_INTERRUPT_INFO type definition macro is used in all place instead of struct _SDPMM1105_INTERRUPT_INFO.
*
*\var 		typedef struct _SDPMM1105_INTERRUPT_INFO *PSDPMM1105_INTERRUPT_INFO
*\brief 	Indicates type definition for carrier device information structure pointer
*
*			This PSDPMM1105_INTERRUPT_INFO type definition macro is used in all place instead of struct _SDPMM1105_INTERRUPT_INFO pointer.
*/
typedef struct _SDPMM1123_INTERRUPT_INFO
{
	U32BIT      m_uiIrqNo;
	U8BIT		m_ucIsInterruptEnabled;
	U8BIT		m_u8InterruptEnable;	/*!< Interrupt Enable */
	U16BIT 		m_u16FIFOThreshold;		/*!< FIFO Threshold Val */
	U16BIT 		m_u16BuffSize;			/*!< create buffer in the driver to store interrupt data, minimum 4KB and maximum 16KB*/
}SDPMM1123_INTERRUPT_INFO, *PSDPMM1123_INTERRUPT_INFO;

/**
*\struct	_SDPMM1123_CALIBCONFIG
*\brief		This structure contains members to hold the Calibration Configuration Values.
*
*			The Calibration Configuration Values include the Channel number, Accuracy Mode, Excitation Voltage
*
*\var		typedef struct _SDPMM1123_CALIBCONFIG SDPMM1123_CALIBCONFIG
*\brief		Indicates type definition for Calibration Configuration structure
*
*			This SDPMM1123_CALIBCONFIG type definition macro is used in all place instead of struct _SDPMM1123_CALIBCONFIG.
*
*\var 		typedef struct _SDPMM1123_CALIBCONFIG *PSDPMM1123_CALIBCONFIG
*\brief 	Indicates type definition for Calibration Configuration structure pointer
*
*			This PSDPMM1123_CALIBCONFIG type definition macro is used in all place instead of struct _SDPMM1123_CALIBCONFIG pointer.
*/
typedef struct _SDPMM1123_CALIBCONFIG
{ 
	U8BIT m_u8ChannelNo;		/*!< Min : 1 , Max : 3 */
	U8BIT m_u8AccuracyMode;		/*!< Normal : 0 , High-Accuracy : 1 */
	U8BIT m_u8ExcitationVolt;	/*!< Min : 0 , Max: 5 */
	U8BIT m_u8EEPROMorDriver;	/*!< update to driver : 0 , update to EEPROM : 1 */
}SDPMM1123_CALIBCONFIG,*PSDPMM1123_CALIBCONFIG;

/**
*\struct	_SDPMM1123_SAMPLE_INFO
*\brief		This structure contains members to hold the Sample value.
*
*			The Sample Info include the Sample value, channel number and gain value
*
*\var		typedef struct _SDPMM1123_SAMPLE_INFO SDPMM1123_SAMPLE_INFO
*\brief		Indicates type definition for SampleInfo structure
*
*			This SDPMM1123_SAMPLE_INFO type definition macro is used in all place instead of struct _SDPMM1123_SAMPLE_INFO.
*
*\var 		typedef struct _SDPMM1123_SAMPLE_INFO *PSDPMM1123_SAMPLE_INFO
*\brief 	Indicates type definition for SampleInfo structure pointer
*
*			This PSDPMM1123_SAMPLE_INFO type definition macro is used in all place instead of struct _SDPMM1123_SAMPLE_INFO pointer.
*/
typedef struct _SDPMM1123_SAMPLE_INFO
{
	FDOUBLE	m_dSample;
	U16BIT	m_usChannelNo;
	U16BIT	m_usGain;
}SDPMM1123_SAMPLE_INFO, *PSDPMM1123_SAMPLE_INFO;

/**
*\struct	_SDPMM1123_SAMPLE_INFO_HEX
*\brief		This structure contains members to hold the Sample HEX value.
*
*			The Sample Info include the Sample HEX value, channel number and gain value
*
*\var		typedef struct _SDPMM1123_SAMPLE_INFO_HEX SDPMM1123_SAMPLE_INFO_HEX
*\brief		Indicates type definition for SampleInfo HEX structure
*
*			This SDPMM1123_SAMPLE_INFO_HEX type definition macro is used in all place instead of struct _SDPMM1123_SAMPLE_INFO_HEX.
*
*\var 		typedef struct _SDPMM1123_SAMPLE_INFO_HEX *PSDPMM1123_SAMPLE_INFO_HEX
*\brief 	Indicates type definition for SampleInfo HEX structure pointer
*
*			This PSDPMM1123_SAMPLE_INFO_HEX type definition macro is used in all place instead of struct _SDPMM1123_SAMPLE_INFO_HEX pointer.
*/
typedef struct _SDPMM1123_SAMPLE_INFO_HEX
{
	U16BIT m_usSample;
	U16BIT m_usChannelNo;
	U16BIT m_usGain;
}SDPMM1123_SAMPLE_INFO_HEX, *PSDPMM1123_SAMPLE_INFO_HEX;
#pragma pack(pop)

/**************************** function  prototypes ******************************/
/*!
*	\addtogroup Common_Functions List of common driver functions
* @{
*/

/**
*\brief		This function is used to detect all the MM module and register the 1123 module
*
*\param[in]	in_u16TotalCarrierBoards	It specifies the total carrier boards
*\param[in] in_pSAllDevInfoDetails		It specifies the all carrier boards device location details
*\param[in] in_u8Flag					It specifies whether the carrier device is DP boards or other customer boards(max:1)(0 - DP Boards 1 - Other Boards)
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the input device location pointer is null
*\retval	::DPMM1123_ERR_INVALID_FLAG is returned if the flag value is out of limit(0 to 1)
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_SetResource(U16BIT in_u16TotalCarrierBoards, PSDPMM1123_CARRIER_DEVICE_INFO in_pSAllDevInfoDetails, U8BIT in_u8Flag);

/**
*\brief		This function is used to find the total number of DP-MM-1123 device(s) present in the system
*
*\param[out] out_pu16TotalDevices	It specifies the output pointer to hold the number of DP-MM-1123 device(s) found
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified total devices output pointer is null
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_GetTotalDeviceFound(U16BIT *out_pu16TotalDevices);

/**
*\brief		This function is used to get pci details such as bus number, slot number and function number for the DP-MM-1123 device(s)
*
*\param[out] out_pSAllDevLocDetails		It specifies the output pointer to hold the device location details(size:in_u16MaxDevices)
*\param[in]  in_u16MaxDevices			It specifies the total number of DP-MM-1123 device(s) found
*
*\retval	 ::DPMM1123_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_POINTER is returned if the output device location details structure pointer is null
*
*\pre		 ::DPMM1123_GetTotalDeviceFound
*\post		 ::DPMM1123_GetErrorMessage
*
*\author	 Giriprakash K
*\date		 18 August, 2021
*/
S32BIT DPMM1123_GetAllDeviceLocations(PSDPMM1123_DEVICE_LOCATION out_pSAllDevLocDetails, U16BIT in_u16MaxDevices);

/**
*\brief 	 This function is used to open the specified DP-MM-1105 device.
*
*\param[in]	 in_pSDeviceOpenInfo	It specifies the MM Slot Number, bus number, slot number and function number
*\param[out] out_phDeviceHandle		It specifies the pointer to hold output device handle
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the device location structure pointer is null
*\retval	::DPMM1123_ERR_DEVICE_BUSY is returned if the the device is already opened
*
* \pre		::DPMM1123_GetAllDeviceLocations
* \post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_Open(PSDPMM1123_DEVICE_LOCATION in_pSDeviceOpenInfo, DP_DRV_HANDLE out_phDeviceHandle);

/**
*\brief		This function is used to close the opened device. Any opened device has to be closed before the application is exited.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_DEVICE_NOT_OPEN is returned if the device is not opened
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_Close(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	 This function is used to reset the device to initial state
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	 ::DPMM1123_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		 ::DPMM1123_Open
*\post		 ::DPMM1123_GetErrorMessage
*
*\author	 Giriprakash K
*\date		 18 August, 2021
*/
S32BIT DPMM1123_Reset(DP_DRV_HANDLE in_hHandle);

/**
*\brief		This function is used to get opened device location details(MM Slot number, bus number, slot number and function number)
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_pSDeviceLocation	It specifies the pointer to hold the device location details
*
*\retval	::DPMM1123_SUCCESS	is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output device location pointer is null
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	 Giriprakash K
*\date		 18 August, 2021
*/
S32BIT DPMM1123_GetDeviceLocation(DP_DRV_HANDLE in_hHandle, PSDPMM1123_DEVICE_LOCATION out_pSDeviceLocation);

/**
*\brief		This function is used to get the driver details(Driver Version)
*
*\param[out] out_pSDriverDetails 	It specifies the structure pointer to read the driver details(Driver Version)
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output driver details pointer is null
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_GetDriverDetails(PSDPMM1123_DRIVER_DETAILS out_pSDriverDetails);

/**
*\brief         This function is used to get board ID
*
*\param[in]     in_hHandle	      It specifies the device handle which got from device open function
*\param[out]  	out_pSDeviceDetails   It specifies the pointer to read the board ID
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\return    ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output driver details pointer is null
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_GetDeviceDetails( DP_DRV_HANDLE in_hHandle, PSDPMM1123_DEVICE_DETAILS out_pSDeviceDetails);

/**
*\brief		 This function is used to get the error message corresponding to the error code. The error message specify briefly the cause of the error.
*
*\param[in]  in_s32ErrCode	It specifies the error code returned by the functions
*\param[out] out_ps8ErrMsg	It specifies the pointer to hold the error message(size:in_u16BufSize)
*\param[in]  in_u16BufSize	It specifies buffer size to hold the error message
*
*\retval	 ::DPMM1123_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_POINTER is returned if the output error message pointer is null
*
*\pre	 	 ::DPMM1123_Open
*\post	 	 NA
*
*\author	 Giriprakash K
*\date		 18 August, 2021
*/
S32BIT DPMM1123_GetErrorMessage(S32BIT in_s32ErrCode, PS8BIT out_ps8ErrMsg, U16BIT in_u16BufSize);

/**
*\brief		This function is used to write data into the specified FPGA register offset
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_u32Offset	It specifies the offset value of selected device
*\param[in] in_u32WriteData	It specifies the the data to be written in specified register offset
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT STDCALL DPMM1123_WriteReg(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, U32BIT in_u32WriteData);

/**
*\brief 	 This function is used to read data from the specified FPGA register offset
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[out] out_pu32ReadData	It specifies the pointer to read data from specified register offset
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified read data output pointer is null
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT STDCALL DPMM1123_ReadReg(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, PU32BIT out_pu32ReadData);

/**
*\brief		This function is used to enable or disable(1 - Enable, 0 - Disable) the device share option(opening same device more than one time)
*
*\param[in]	in_hHandle	It specifies the device handle which is obtained from device open function
*\param[in]	in_u8EnDis	It specifies the enable / disable value(max:1)
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1123_ERR_INVALID_ENDIS is returned if the enable / disable device share option is out of limit(0 or 1)
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT STDCALL DPMM1123_SetDeviceShare(DP_DRV_HANDLE in_hHandle, U8BIT in_u8EnDis);

/**
*\brief		This function is used to read the driver version
*
*\param[out]	out_pulMMDrvVer		It specifies the driver version
*\param[out]	out_pulCarrierVer	It specifies the carrier version
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified read data output pointer is null
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_GetDriverVersion( U32BIT *out_pulMMDrvVer, U32BIT *out_pulCarrierVer );

/**
*\brief		This function is used to read the FPGA version
*
*\param[in]		in_hHandle	It specifies the device handle which is obtained from device open function
*\param[out]	out_pSGlueLogicDetails	It specifies the FPGA Version
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified read data output pointer is null
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_GetGlueLogicDetails(DP_DRV_HANDLE in_hHandle,PSDPMM1123_GLUE_LOGIC_DETAILS out_pSGlueLogicDetails);

/*!
* @}
*/

/******************************* Board Specific ************************************/
/*!
*	\addtogroup Board_Functions List of device specific driver functions
* @{
*/

/**
*\brief		This function is used to configure the device. The ADC configuration structure details are mentioned below
* <ul>
*			<li> <b> Mode </b> member is used to configure the device input type as either <b> High-Accuracy </b> or <b> Normal Mode</b>.
*			<li> <b> Bridge Completion </b> member is used to select the bridge selection.
*			<li> <b> Excitation Voltage </b> member is used to configure the excitation voltage.
*			<li> <b> Shunt Calibration </b> member is used to select shunt calibartion.
*			<li> <b> Gauge Factor </b> member is used to configure the gauge factor.
*			<li> <b> Acqusition Rate </b> member is used to select the acquisition rate.
*</ul>
*
*\param[in]	in_hHandle 		It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8ChannelNo 	It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]	pSConfiguration	It specifies the structure pointer to hold the configuration details. Refer _SDPMM1123_CONFIGURATION structure for details.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1123_ERR_ACQURACY_MODE is returned if the Accuracy Mode selection is out of limit(0 or 1).
*\retval	::DPMM1123_ERR_BRIDGE_COMPLETION is returned if the bridge selection is out of limit(0 to 2)
*\retval	::DPMM1123_ERR_MAX_EXCITATION is returned if the excitation voltage selection is out of limit(0 to 5)
*\retval	::DPMM1123_ERR_SHUNT_CALIB_SELECTION is returned if the shunt calibration selection is out of limit(0 or 1).
*\retval	::DPMM1123_ERR_INVALID_ACQUISITIONRATE is returned if the aquisition rate selection is out of limit(6 to 3515).
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_Configure(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,SDPMM1123_CONFIGURATION * pSConfiguration);

/**
*\brief		This function is used to configure the ADC. Here the acquisition rate and the acquracy modes are been configred.
*
*\param[in]	in_hHandle 				It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8ChannelNo 			It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]	in_u8AcquracyMode 		It specifies the accuracy mode of acquisition (Normal:0 & High-Accuracy:1).
*\param[in]	in_u16AcquisitionRate 	It specifies the acquisition rate of the device(min:7Hz to max:3516Hz).
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_ACQURACY_MODE is returned if the Accuracy Mode selection is out of limit(0 or 1).
*\retval	::DPMM1123_ERR_INVALID_ACQUISITIONRATE is returned if the aquisition rate selection is out of limit(7Hz to 3516Hz).
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_ConfigureADC(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,U8BIT in_u8AcquracyMode,U16BIT in_u16AcquisitionRate);

/**
*\brief		This function is used to select the bridge completion.For quater and half bridge the bridge completion has to be enabled. For Full bridge it has to be disabled
*
*\param[in]	in_hHandle 				It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8ChannelNo 			It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]	in_u8BridgeCompletion 	It specifies the bridge selection(Full-Bridge:0, Half-Bridge:1, Quater-Bridge:2).
*\param[in]	in_dGaugeFactor 		It specifies the gauge factor of channel specified in the in_u8ChannelNo argument.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_BRIDGE_COMPLETION is returned if the bridge completion selection is invalid(0 to 2).
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_BridgeCompletion(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,U8BIT in_u8BridgeCompletion,FDOUBLE in_dGaugeFactor);

/**
*\brief		This function is used to select the excitagtion votage to the bridge circuit
*
*\param[in]	in_hHandle 				It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8ChannelNo 			It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]	in_u8ExcitationVolt 	It specifies the excitagtion votage to the bridge circuit(min:0 to max:5).
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_MAX_EXCITATION is returned if the excitation voltage selection is out of limit(0 to 5)
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_ConfigureExcitationVolt(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,U8BIT in_u8ExcitationVolt );

/**
*\brief		This function is used to enable or disable shunt for specified channel
*
*\param[in]	in_hHandle 				It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8ChannelNo 			It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]	in_u8EnaDisShunt 		It specifies the Shunt enable or disable(enable:1 to disable:0).
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_ENADIS_VALUE is returned if the shunt selection is invalid(0 or 1)
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_EnableDisableShunt(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo, U8BIT in_u8EnaDisShunt);

/**
*\brief		This function is used to enable or disable the calibration for specified channel
*
*\param[in]	in_hHandle 				It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8ChannelNo 			It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]	in_u8FromEEPROM 		It specifies the EEPROM selection enable or disable(enable:1 to disable:0).
*\param[in]	in_u8EnaDisCalib 		It specifies the calibration selection enable or disable(enable:1 to disable:0).
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_ENADIS_VALUE is returned if the EEPROM selection is invalid(0 or 1)
*\retval	::DPMM1123_ERR_ENADIS_VALUE is returned if the calibration selection is invalid(0 or 1)
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_EnableDisableCalibration( DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,U8BIT in_u8FromEEPROM,U8BIT in_u8EnaDisCalib);

/**
*\brief		This function is used to enable or disable tare. If tare is enabled tare value will be calulated and the flag will be set
*
*\param[in]	in_hHandle 				It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8ChannelNo 			It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]	in_u8EnableDisableTare 	It specifies the Tare selection enable or disable(enable:1 to disable:0).
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_ENADIS_VALUE is returned if the Tare selection is invalid(0 or 1)
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_EnableDisableTare(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,U8BIT in_u8EnableDisableTare);

/**
*\brief		This function is used to set the FIFO mode, whether output of FIFO is voltage or strain.
*
*\param[in]	in_hHandle 				It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8ChannelNo 			It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]	in_u8StrainOrVolt 	It specifies the Tare selection enable or disable(strain:0 to voltage:1).
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_FIFO_OUTPUT_MODE is returned if the FIFO mode selection is invalid(0 or 1)
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_SetFIFOMode(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo, U8BIT in_u8StrainOrVolt);

/**
*\brief		To start acquisition for specified channel or starts for whole channels, if channel number is 0.
*
*\param[in]	in_hHandle 				It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8ChannelNo 			It specifies the device channel number(min:1 to max:3, all-Channel:0).
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_StartAcquisition(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo);

/**
*\brief		To cancel trigger and swith to normal mode.
*
*\param[in]	in_hHandle 				It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8ChannelNo 			It specifies the device channel number(min:1 to max:3, all-Channel:0).
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*
*\pre		::DPMM1123_SetFIFOMode
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_StopAcquisition(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo);

/**
*\brief		Used to check whether the conversion of analog to digtial is completed in ADC
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[out] out_u8Complete 		It holds the output for check conversion is complete.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		::DPMM1123_StartAcquisition
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_CheckIsConversionComplete(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,U8BIT *out_u8Complete);

/**
*\brief		Used to get the read status in the polling mode
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[out] out_pu8Status 			It holds the output status selection.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		::DPMM1123_StartAcquisition
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_ReadFIFOStatus(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,U8BIT *out_pu8Status );

/**
*\brief		Used to get a sample for the specified channel from the current value register
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[out] out_dSample 			It holds the output sample value.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		::DPMM1123_SetFIFOMode
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_ReadRecentSample(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,FDOUBLE *out_dSample);

/**
*\brief		Used to get a sample for the specified channel from the fifo
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]	 in_u8IntType 			It specifies the type of Interrupt(empty:1, full:2, half-fill:3 and threshold:4).
*\param[out] io_u16NoOfSamples 		It specifies the Nunber of sample to read as input and nuber of samples read from FIFO as output(min:1 to max:256, all-sample:0).
*\param[out] out_dSample 			It holds the output sample value.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_INT_VALUE is returned if the interrupt selection is out of limit(1 to 4) 
*\retval	::DPMM1123_E_NO_OF_SAMPLES is returned if the sample number is out of limit(0 to 256)
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_ReadFIFOData(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,U8BIT in_u8IntType,U16BIT *io_u16NoOfSamples,FDOUBLE *out_dSample);

/**
*\brief		This function returns the strain value of read voltage
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[out] out_pdStrain 			It holds the strain value of read voltage.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_GetStrain(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,FDOUBLE *out_pdStrain);

/**
*\brief		This function is used to get the Voltage, Temperature and resistance values
* <ul>
*			<li> <b> Voltage </b> member holds the Voltage Value.
*			<li> <b> Resistance </b> member holds the Resistance Value.
*			<li> <b> Temperature </b> member holds the Temperature Value.
*</ul>
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[out] out_pSReadVal			It specifies the structure pointer to hold the Thermistor value. Refer _SDPMM1123_THERMISTORVALUES structure for details.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_GetThermistorValues(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,PSDPMM1123_THERMISTORVALUES out_pSReadVal);

/**
*\brief		This function is used to get the resistance value of read voltage to application
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[out] out_dResistance		It holds the resistance value of read voltage.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_GetResistance(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,FDOUBLE *out_dResistance);

/**
*\brief		This function is used to get the temperature value of read voltage to application
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[out] out_pdTemperature		It holds the temperature value of read voltage.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_GetTemperature(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,FDOUBLE *out_pdTemperature);
/******************************Board Specific Functions Ends *****************************/

/***************************** FIFO Related Functions Starts *****************************/
/**
*\brief		This function is used to configure the threshold level of the FIFO for specified Channel
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]  in_u8Threshold			It specifies the threshold value of FIFO(min:25 to max:240)
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_FIFO_THREASHOLD_VALUE is returned if the threshold value is out of limit(25 to 240).
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_ConfigFifoThreshold(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,U8BIT in_u8Threshold);

/**
*\brief		This function is used to reset all the FIFOs in the specified module
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_ResetFIFO(DP_DRV_HANDLE in_hHandle);

/**
*\brief		This function is used to enable/disable the fifo 
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]  in_u8EnaDisFIFO		It specifies the FIFO enable or disable selection(min:0 to max:1)
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_ENADIS_VALUE is returned if the FIFO selection is invalid(0 or 1)
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_EnableDisableFIFO(DP_DRV_HANDLE in_hHandle, U8BIT in_u8ChannelNo, U8BIT in_u8EnaDisFIFO);
/********************************* FIFO Functions Ends ********************************/

/******************************* Interrupt related Functions starts ******************************/
/**
*\brief		This function is used to enable/disable the interrupt
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8IntEnDis 			It specifies the enable/disable of interrupt(min:0 to max:1).
*\param[in]  in_u16SWBufferSize		It specifies specifies the Software buffer size(min:1024 to max:5124)
*
*\retval	::DPMM1123_SUCCESS is returned upon Enable/Disable Interrupt successfully
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_ENADIS_VALUE is returned if the FIFO selection is invalid(0 or 1)
*\retval 	::DPMM1123_E_ISR_REG is returned upon Enable Interrupt Failed
*\retval 	::DPMM1123_E_DETACH is returned upon Disable Interrupt Failed
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_EnableInterrupt(DP_DRV_HANDLE in_hHandle, U8BIT in_u8IntEnDis, U16BIT in_u16SWBufferSize);

/**
*\brief		This function is used to enable/disable the fifo interrupt
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]  in_u8InterruptMode		It specifies the type of Interrupt(empty:1, full:2, half-fill:3 and threshold:4).
*\param[in]  in_u8EnaDis			It specifies the FIFO enable or disable selection(min:0 to max:1)
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_INT_VALUE is returned if the interrupt selection is out of limit(1 to 4).
*\retval	::DPMM1123_ERR_ENADIS_VALUE is returned if the FIFO selection is invalid(0 or 1)
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_EnableDisableFIFOInterrupt(DP_DRV_HANDLE in_hHandle, U8BIT in_u8ChannelNo,U8BIT in_u8InterruptMode, U8BIT in_u8EnaDis);
/************************** Interrupt Related Functions Ends ************************/

/************************ Calibration Related Functions Starts **********************/
/**
*\brief		This function is used to calculate the the calibration constants for getting more acquirate samples 
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]  in_u8Mode				It specifies the accuracy mode of calibration (Normal:0 & High-Accuracy:1).
*\param[in]  in_u8ExcitationVolt	It specifies the excitagtion votage to the channel(min:0 to max:5).
*\param[in]  in_u8RefVoltFlag		It specifies the reference votage enable or disable selection(min:0 to max:1)
*\param[in]  in_fRefVolt			It specifies the reference votage to the channel(min:0 to max:1)
*\param[out]  out_fSlope			It holds the calibrated output slope value
*\param[out]  out_fConstant			It holds the calibrated output constant value
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_VOLT_REFERENCE is returned if any error in voltage refence for calibration(0 or 1)
*\retval	::DPMM1123_ERR_CALIB_LOW_NOT_DONE is returned if Low reference voltage calibration is not yet done
*\retval	::DPMM1123_ERR_ACQURACY_MODE is returned if Accuracy Mode is Invalid(0 or 1)
*\retval	::DPMM1123_ERR_MAX_EXCITATION is returned if excitation voltage selection is Invalid(0 to 5)
*
*\pre		::DPMM1123_Open
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_Calibrate(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,U8BIT in_u8Mode, U8BIT in_u8ExcitationVolt,U8BIT in_u8RefVoltFlag, FSINGLE in_fRefVolt, FSINGLE *out_fSlope, FSINGLE *out_fConstant);

/**
*\brief		This function is used to write the slope and constant to EEProm for specified channel
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]  in_u8Mode				It specifies the accuracy mode of calibration table(Normal:0 & High-Accuracy:1).
*\param[in]  in_u8ExcitationVolt	It specifies the excitagtion votage to the channel(min:0 to max:5).
*\param[in]  in_fSlope				It specifies the slope value
*\param[in]  in_fConstant			It specifies the constant value
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_ACQURACY_MODE is returned if Accuracy Mode is Invalid 
*\retval	::DPMM1123_ERR_MAX_EXCITATION is returned if excitation voltage selection is Invalid(0 to 5)
*
*\pre		::DPMM1123_Calibrate
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_WriteCalibrationTable(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo, U8BIT in_u8Mode, U8BIT in_u8ExcitationVolt, FSINGLE in_fSlope, FSINGLE in_fConstant);

/**
*\brief		This function is used to write the slope and constant to EEProm for specified channel
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]  in_u8Mode				It specifies the accuracy mode of calibration table(Normal:0 & High-Accuracy:1).
*\param[in]  in_u8ExcitationVolt	It specifies the excitagtion votage to the channel(min:0 to max:5).
*\param[in]  in_fSlope				It specifies the slope value
*\param[in]  in_fConstant			It specifies the constant value
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_ACQURACY_MODE is returned if Accuracy Mode is Invalid 
*\retval	::DPMM1123_ERR_MAX_EXCITATION is returned if excitation voltage selection is Invalid (0 to 5)
*
*\pre		::DPMM1123_Calibrate
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_UpdateCalibrationConstants( DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo,U8BIT in_u8Mode, U8BIT in_u8ExcitationVolt,FSINGLE in_fSlope, FSINGLE in_fConstant);

/**
*\brief		This function is used to load the calibration constants from the file
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]  in_SCalibConstants 	It specifies the structure contains the calibration data. Refer _SLOADCALIBCONSTANTS structure for details.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_LoadCalibrationConstants( DP_DRV_HANDLE in_hHandle, SLOADCALIBCONSTANTS in_SCalibConstants);

/**
*\brief		This function is used to read the slope and constant from the EEProm for specified channel
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]  in_u8Mode				It specifies the accuracy mode of calibration table(Normal:0 & High-Accuracy:1).
*\param[in]  in_u8ExcitationVolt	It specifies the excitagtion votage to the channel(min:0 to max:5).
*\param[out]  out_fSlope			It holds the read EEPROM slope value
*\param[out]  out_fConstant			It holds the read EEPROM constant value
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_ACQURACY_MODE is returned if Accuracy Mode is Invalid (0 to 1)
*\retval	::DPMM1123_ERR_MAX_EXCITATION is returned if excitation voltage selection is Invalid (0 to 5)
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_ReadCalibrationTable( DP_DRV_HANDLE in_hHandle, U8BIT in_u8ChannelNo, U8BIT in_u8Mode, U8BIT in_u8ExcitationVolt,FSINGLE *out_pfSlope, FSINGLE *out_pfConstant );

/**
*\brief		This function is used to read the slope and constant from the EEProm for specified channel
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8ChannelNo 		It specifies the device channel number(min:1 to max:3, all-Channel:0).
*\param[in]  in_u8Mode				It specifies the accuracy mode of calibration table(Normal:0 & High-Accuracy:1).
*\param[in]  in_u8ExcitationVolt	It specifies the excitagtion votage to the channel(min:0 to max:5).
*\param[out]  out_fSlope			It holds the read EEPROM slope value
*\param[out]  out_fConstant			It holds the read EEPROM constant value
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CHANNEL_NUMBER is returned if the channel selection is out of limit(0 to 3)
*\retval	::DPMM1123_ERR_ACQURACY_MODE is returned if Accuracy Mode is Invalid(0 to 1)
*\retval	::DPMM1123_ERR_MAX_EXCITATION is returned if excitation voltage selection is Invalid(0 to 5)
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_GetCalibrationConstants(DP_DRV_HANDLE in_hHandle,U8BIT in_u8ChannelNo, U8BIT in_u8Mode, U8BIT in_u8ExcitationVolt,FSINGLE *out_fSlope, FSINGLE *out_fConstant);

/**
*\brief		This function is used to calculate and write the calibration ckecksum along with EEprom write count and date&time of write in to the EEPROM.
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8Day 				It specifies the day of checksum write.
*\param[in]  in_u8Month				It specifies the month of checksum write.
*\param[in]  in_u16Year				It specifies the year of checksum write.
*\param[in]  in_u8Hour				It specifies the hour of checksum write.
*\param[in]  in_u8Minute			It specifies the minute of checksum write.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_WriteChecksum(DP_DRV_HANDLE in_hHandle,U8BIT in_u8Day,U8BIT in_u8Month,U16BIT in_u16Year,U8BIT in_u8Hour,U8BIT in_u8Minute);

/**
*\brief		This function is used to read the check sum value from EEPROM for checking the EEPROM.
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[out]  out_pu16Checksum		It holds the checksum value read from EEPROM.
*\param[out]  out_pu8EEPROMStatus	It holds the EEPROM checksum write status
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		::DPMM1123_WriteChecksum
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_VerifyChecksum(DP_DRV_HANDLE in_hHandle,U16BIT *out_pu16Checksum, U8BIT *out_pu8EEPROMStatus);

/**
*\brief		This function is used to read the EEprom write count and date&time from EEPROM for checking the EEPROM.
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[out]  out_pucDay 			It holds the day read from EEprom.
*\param[out]  out_pucMonth			It holds the month read from EEprom.
*\param[out]  out_pusYear			It holds the year read from EEprom.
*\param[out]  out_pucHour			It holds the hour read from EEprom.
*\param[out]  out_pucMinutes		It holds the minute read from EEprom.
*\param[out]  out_pusWriteCount		It holds the minute read from EEprom.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_ReadDateAndWriteCount( DP_DRV_HANDLE in_hHandle,U8BIT *out_pu8Day, U8BIT *out_pu8Month, U16BIT *out_pu16Year, U8BIT *out_pu8Hour, U8BIT *out_pu8Minutes, U16BIT *out_pu16WriteCount);

/**
*\brief		This function is used to gives the samples read from the hardware FIFO
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u16Reqsamples 		It specifies the number of samples read from FIFO.
*\param[out]  out_pSBuffer			It holds the sample data.
*\param[out]  out_pu16NoOfSamples	It holds the read sample count.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_ReadSamples(DP_DRV_HANDLE in_hHandle,U16BIT in_u16Reqsamples,SDPMM1123_SAMPLE_INFO *out_pSBuffer,U16BIT *out_pu16NoOfSamples);

/**
*\brief		This function is used to gives the samples read from the hardware FIFO
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_pulTimeOut 			It specifies the timeout value in miliseconds.
*\param[out]  out_pSIntStatus		It holds the interrupt details. Refer _SDPMM1123_INT_STATUS structure for details.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		::DPMM1123_EnableInterrupt
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_GetInterruptStatus(DP_DRV_HANDLE in_hHandle, U32BIT *in_pulTimeOut, PSDPMM1123_INT_STATUS out_pSIntStatus);

/**
*\brief      This function is used to wait until the interrupt specified event occurs.
*
*\param[in]  in_hHandle      		It specifies the device handle which is obtained from device open function
*\param[in]  in_u32EventMasks   	It specifies for which interrupt events the application to be notified
			<ol>
			<li> 0x03 -  Channel 1 Interrupt (BIT1 : Half-Full, BIT2 : Threshold)
			<li> 0x0c -  Channel 2 Interrupt (BIT3 : Half-Full, BIT4 : Threshold)
			<li> 0x30 -  Channel 3 Interrupt (BIT5 : Half-Full, BIT6 : Threshold)
			</ol>	
*\param[in]  in_u16Options      	It specifies wait for event have until any one interrupt came or all interrupts came(max:2)
			<ol>
			<li> 0 -  No wait.
			<li> 1 -  waiting for any specified event occurs.
			<li> 2 - waiting for occurring all the specified event occurs.
			</ol>	
*\param[in]  in_pu32Timeout     	It specifies the pointer which holds the time-out value. if time out is null then wait for infinite, else specified wait until specified time-out over.
*\param[out] out_pu16InterrupStatus It specifies the pointer which holds the interrupt status
*
*\retval     ::DPMM1123_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	 ::DPMM1123_ERR_INVALID_OPTIONS is returned if the option is out of limit(0 to 2)
*\retval	 ::DP_DRV_ERR_INVALID_POINTER is returned if the input pointer time-out or output interrupt status pointer is null
*
*\pre        ::DPMM1123_Open
*\post       ::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT STDCALL DPMM1123_WaitForEvents(DP_DRV_HANDLE in_hHandle, U32BIT in_u32EventMasks, U16BIT in_u16Options, PU32BIT in_pu32Timeout, PU16BIT out_pu16InterrupStatus);

/**
*\brief		This function is used to set the calibration type i.e., One segment or two segment calibration
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]	 in_u8CalibrationType 	It specifies the calibration type either One segment or two segment calibration(min:1 to max:2)
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_CALIB_TYPE is returned if the pointer is invalid. 
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_SetCalibrationType(DP_DRV_HANDLE in_hHandle, U8BIT in_u8CalibrationType);

/**
*\brief		This function is used to read the calibration type i.e., One segment or two segment calibration
*
*\param[in]  in_hHandle 				It specifies the device handle which is obtained from device open function.
*\param[out] out_pu8CalibrationType 	It specifies the calibration type either One segment or two segment calibration(min:1 to max:2)
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_POINTER is returned if the calibration selection is out of limit(1 to 2)
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_ReadCalibrationType(DP_DRV_HANDLE in_hHandle, U8BIT *out_pu8CalibrationType);

/**
*\brief		This function is used to write the slope and constant to EEPROM or driver for 2-segment calibration as well as single segment calibrations
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]  in_pSCalibConfig 		It specifies the structure contains the calibration configuration data. Refer _SSDPMM1123_CALIBCONFIG structure for details.
*\param[in]  in_pSCalibConstants 	It specifies the structure contains the calibration constatnts data. Refer _SSDPMM1123_CALIBCONSTANTS structure for details.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_WriteCalibrationConstants(DP_DRV_HANDLE in_hHandle, PSDPMM1123_CALIBCONFIG in_pSCalibConfig, PSDPMM1123_CALIBCONSTANTS in_pSCalibConstants );

/**
*\brief		This function is used to write the slope and constant to EEPROM or driver for 2-segment calibration as well as single segment calibrations
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]  in_pSCalibConfig 		It specifies the structure contains the calibration configuration data. Refer _SSDPMM1123_CALIBCONFIG structure for details.
*\param[out]  out_pSCalibConstants 	It holds the calibration constatnts data read from EERPOM or Driver. Refer _SSDPMM1123_CALIBCONSTANTS structure for details.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*\retval	::DPMM1123_ERR_POINTER is returned if the pointer is invalid.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_ReadCalibrationConstants(DP_DRV_HANDLE in_hHandle, PSDPMM1123_CALIBCONFIG in_pSCalibConfig,  PSDPMM1123_CALIBCONSTANTS out_pSCalibConstants);

/**
*\brief		This function is used to write the slope and constant to EEPROM or driver for 2-segment calibration as well as single segment calibrations
*
*\param[in]  in_hHandle 			It specifies the device handle which is obtained from device open function.
*\param[in]  in_SCalibConstants 	It specifies the structure contains the calibration data. Refer _SLOADCALIBCONSTANTS structure for details.
*
*\retval	::DPMM1123_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null.
*
*\pre		NA
*\post		::DPMM1123_GetErrorMessage
*
*\author	Giriprakash K
*\date		18 August, 2021
*/
S32BIT DPMM1123_LoadCalibration( DP_DRV_HANDLE in_hHandle, SLOADCALIBCONSTANTS in_SCalibConstants);
/************************* Calibration Related Functions Ends ***********************/

#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif
#endif

                                     







