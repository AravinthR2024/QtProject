/**
* \file dp1553b_wrapper.h
* \brief This file contains the wrapper function declaration and macros
*
* author Tamizharasan K
* \date  28 January, 2020
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
* Phone: 91-44-4741-4000\n
* FAX: 91-44-4741-4444 \n
*
*/

#ifndef _DP1553B_WRAPPER_H_
#define _DP1553B_WRAPPER_H_

#include "dp1553bxt_pro.h"

#if defined(__cplusplus) || defined(__cplusplus__)
extern 	"C" {
#endif

#define DP1553B_SUCCESS		0
#define DP1553B_INIT_ZERO	0
#define DP1553B_ZERO		0
#define DP1553B_ONE			1
#define DP1553B_TWO			2
#define DP1553B_THREE		3
#define DP1553B_FOUR		4
#define DP1553B_FIVE		5
#define DP1553B_SIX			6
#define DP1553B_SEVEN		7

#define DP_DIS_EXT_TRIG     0
#define DP_ENA_EXT_TRIG     1

#define DP_DIS_WDT     0
#define DP_ENA_WDT     1

#define DP1553B_5019_MAX_CHNLS 	8 /* (2 Boards * 4 Channels Each) */

#define DP1553B_SINGLE_RT       0
#define DP1553B_MULTI_RT      	1

#define DP1553B_RT_SRC_INTERNAL		1
#define DP1553B_RT_SRC_EXTERNAL		0

#define DP1553B_TIMETAG_INIT_VALUE			0

#define DP1553B_BC_MSG_TYPE_BCTORT				0		/*	0		0		0		0   */
#define DP1553B_BC_MSG_TYPE_RTTORT         	 	1		/*	0    	0     	0      	1   */
#define DP1553B_BC_MSG_TYPE_BCTORT_BCST       	2		/*	0    	0     	1      	0   */
#define DP1553B_BC_MSG_TYPE_RTTORT_BCST       	3		/*	0    	0     	1      	1   */
#define DP1553B_BC_MSG_TYPE_BCTORT_MODE			4		/*	0    	1     	0      	0   */
#define DP1553B_BC_MSG_TYPE_MODE_BCST      		6		/* 	0    	1    	1      	0   */
#define DP1553B_BC_MSG_TYPE_RTTOBC            	8  	 	/* 	1    	0     	0      	0   */
#define DP1553B_BC_MSG_TYPE_RTTOBC_MODE    		12  	/* 	1    	1     	0      	0   */

#define DP1553B_MSG_TYPE_SEL(Msgtype, TxRxSelRxCmd, TxRxSelTxCmd) {\
    if(Msgtype == DP1553B_BC_MSG_TYPE_BCTORT)\
{\
    TxRxSelRxCmd = DP1553B_ZERO;\
}\
    if(Msgtype == DP1553B_BC_MSG_TYPE_RTTOBC)\
{\
    TxRxSelRxCmd = DP1553B_ONE;\
}\
    if(Msgtype == DP1553B_BC_MSG_TYPE_BCTORT_BCST)\
{\
    TxRxSelRxCmd = DP1553B_ZERO;\
}\
    if(Msgtype == DP1553B_BC_MSG_TYPE_RTTORT)\
{\
    TxRxSelRxCmd = DP1553B_ZERO;\
    TxRxSelTxCmd = DP1553B_ONE;\
}\
    if(Msgtype == DP1553B_BC_MSG_TYPE_RTTORT_BCST)\
{\
    TxRxSelRxCmd = DP1553B_ZERO;\
    TxRxSelTxCmd = DP1553B_ONE;\
}\
    if(Msgtype == DP1553B_BC_MSG_TYPE_RTTOBC_MODE)\
{\
    TxRxSelRxCmd = DP1553B_ONE;\
}\
    if(Msgtype == DP1553B_BC_MSG_TYPE_BCTORT_MODE)\
{\
    TxRxSelRxCmd = DP1553B_ZERO;\
}\
    if(Msgtype == DP1553B_BC_MSG_TYPE_MODE_BCST)\
{\
    TxRxSelRxCmd = DP1553B_ZERO;\
}\
}

/***********************************Structures************************/
#pragma pack(push,1)


typedef struct _SDP1553_BC_INIT
{
    U8BIT  u8BCCombinedRT;	 /*!< 0 - not combined with BC, 1 - Combined with BC mode operation*/
    U8BIT  u8BCCombinedMT;	 /*!< 0 - not combined with BC, 1 - Combined with BC mode operation*/
    U16BIT u16HPQSize;           /*!< High Priority Queue size */
    U16BIT u16LPQSize;           /*!< Low Priority Queue size */
    U16BIT u16MaxMsgBlocks;	 /*!< Maximum message blocks can be created for the frame (0 to 1400) */
    U16BIT u16MaxDataBlocks;	 /*!< Maximum data blocks can be created for messages (0 to 1400) */
    U16BIT u16HostMsgBufSize;	 /*!< Host buffer size in number of messages used to store the received message - this buffer will be used in interrupt mode only
                                      0 - No software buffer used
                                      256 to 65535  - minimum size is 256 messages */
}SDP1553_BC_INIT, *PSDP1553_BC_INIT;


typedef struct _SDP1553_BC_CONFIG
{
    U16BIT u16ConfigOptions;	/*!< 0x0 - Acts as Total Message Time, 0x1 - Acts as Message Gap Time */
    U16BIT u16NoRespTimeout;	/*!< No response time-out
                                     Range is from 0[18.5microsec],1[500ns], 2[1us] upto 1023[511.5microsec], resolution is in 500ns */
    U16BIT u16NumOfRetries;     /*!< Message retry count[0-Single Retry / 1-Double Retry] */
    U16BIT u16ChannelSelect;	/*!< 0-First and Second retry on the original 1553 channel,
                                     1-First retry on original channel,Second retry on alternate channel,
                                     2-First retry on alternate channel,Second retry on alternate channel,
                                     3-First retry on alternate channel,Second retry on original channel */
    U16BIT u16RetryOnErr;	/*!< 0-BC Retry on Message Error (ME) or No response Timeout (NR),
                                     1-BC Retry on Status Set,
                                     2-BC Retry on 1553A Message Error (ME),
                                     3-BC Retry on All above */

}SDP1553_BC_CONFIG, *PSDP1553_BC_CONFIG;


typedef struct _SDP1553B_BC_MSG_DEF
{
    U16BIT u16MsgBlkID;		/*!< */
    U8BIT  u8MsgType;		/*!< 0-BC-RT, 1-RT-RT, 2-BC-BCST, 3-RT-BCST, 4-MC-RX, 6-MC-BCST, 8-RT-BC, 12-MC-TX */
    U8BIT  u8RxRTAddress;	/*!< Receive RT address (0 to 31) */
    U8BIT  u8RxRTSubAddress;	/*!< Receive RT Sub address (0 to 31) */
    U8BIT  u8RxWordCount;	/*!< Receive Word Count / Mode Code (0 to 31) */
    U8BIT  u8TxRTAddress;	/*!< Transmit RT address (0 to 31) */
    U8BIT  u8TxRTSubAddress;    /*!< Transmit RT Sub address (0 to 31) */
    U8BIT  u8TxWordCount;       /*!< Transmit Word Count / Mode Code (0 to 31) */
    U8BIT  u8BusSelection;	/*!< Bus Selection (0 - A, 1 - B) */
    U16BIT u16TimeToNextMsg;    /*!< Time to next message */
    U8BIT  u8MsgRetrySel;	/*!< 0 - Disable / 1 - Enable */
    U8BIT  u8DontBufferSel;	/*!< 0 - Disable / 1 - Enable */
    U8BIT  u8DoubleBufferSel;	/*!< 0 - Disable / 1 - Enable */
    U16BIT u16DataBlkID;	/*!< Data block id for the message */

}SDP1553B_BC_MSG_DEF, *PDP1553B_BC_MSG_DEF;

typedef struct _SDP1553B_BC_INT
{
    U8BIT  u8EnaDis;            /*!< 0 - Disable / 1 - Enable */
    U32BIT u32IntEventMasks;
}SDP1553B_BC_INT, *PSDP1553B_BC_INT;


typedef struct _SDP1553_RT_INIT
{
    U8BIT   u8RTCombinedBC;	 /*!< 0 - not combined with RT, 1 - Combined with RT mode operation*/
    U8BIT   u8RTCombinedMT;	 /*!< 0 - not combined with RT, 1 - Combined with RT mode operation*/
    U8BIT   u8RTtype;            /*!< 0 - Single-RT, 1 - Multi-RT */
    U32BIT  u32MutiRTSel;        /*!< Multiple RT Selection range is from 0x1 to 0xffffffff (each bit represents corresponding RT) */
    U8BIT   u8RTAddress;         /*!< (0 - 31) RT address */
    U16BIT  u16RTStackSize;      /*!< RT Stack size */
    U8BIT   u8GlobalCirBuffSize; /*!< Global circular buffer size*/
    U8BIT   u8TimetagAtEOM;      /*!< Timetag at EOM */
    U8BIT   u8ModeCodeResetIO;	 /*!< Mode code reset I/O */
    U8BIT   u8BroadcastDisable;	 /*!< Broadcast Disable */
    U16BIT  u16HostMsgBufSize;	 /*!< Host buffer size in number of messages used to store the received message (global circular buffer to store all received messages).
                                      this buffer will be used in interrupt mode only. The value can be double the stack size.
                                       0 - No software buffer used
                                       256 to 65535  - minimum size is 256 messages */
}SDP1553_RT_INIT, *PSDP1553_RT_INIT;

typedef struct _SDP1553B_MRT_CONFIG
{
    U8BIT 	u8RTType;	/*!< 0 - Single-RT, 1 - Multi-RT */
    U8BIT 	u8RTNumber;	/*!< (0 - 31) RT address */

}SDP1553B_MRT_CONFIG, *PSDP1553B_MRT_CONFIG;

typedef struct _SDP1553B_RT_INT
{
    U8BIT  u8EnaDis;            /*!< 0 - Disable / 1 - Enable */
    U32BIT u32IntEventMasks;
}SDP1553B_RT_INT, *PSDP1553B_RT_INT;

typedef struct _SDP1553_MT_INIT
{
    U8BIT   u8RTCombinedBC;	 /*!< 0 - not combined with MT, 1 - Combined with MT mode operation*/
    U8BIT   u8RTCombinedRT;	 /*!< 0 - not combined with MT, 1 - Combined with MT mode operation*/
    U8BIT   u8EnaSeleciveMon;    /*!< Enable selective monitoring mode [1- Enable, 0-Disable] */
    U32BIT  u32InteQueBufSize;   /*!< Interrupt Queue Buffer size [17 - 65535] */
}SDP1553_MT_INIT, *PSDP1553_MT_INIT;

typedef struct _SDP1553_MT_CONFIG
{
    U8BIT   u8MTStackSize;      /*!< (0x0 - DP1553BXT_MT_STACK_SIZE_MAX_AVAIL, \n 0x1 - DP1553BXT_MT_STACK_SIZE_500,  \n 0x2 - DP1553BXT_MT_STACK_SIZE_1K,  \n 0x3 - DP1553BXT_MT_STACK_SIZE_2K,  \n 0x4 - DP1553BXT_MT_STACK_SIZE_4K,  \n 0x5 - DP1553BXT_MT_STACK_SIZE_8K,  \n 0x6 - DP1553BXT_MT_STACK_SIZE_16K,  \n 0x7 - DP1553BXT_MT_STACK_SIZE_32K,  \n 0x8 - DP1553BXT_MT_STACK_SIZE_64K,  \n 0x9 - DP1553BXT_MT_STACK_SIZE_128K,  \n 0xA - DP1553BXT_MT_STACK_SIZE_256K,  \n 0xB - DP1553BXT_MT_STACK_SIZE_512K,  \n 0xC - DP1553BXT_MT_STACK_SIZE_1024K,  \n 0xD - DP1553BXT_MT_STACK_SIZE_2048K). */
    U8BIT   u8MinGapChkEna;     /*!< Mininum gap check enable [1- Enable, 0- Disable] */
    U8BIT   u8Broadcast;        /*!< Broadcast disable [1- Disable, 0- Enable]*/
    U8BIT   u81553A_Format;     /*!< 1553A format Enable [1-Enable, 0- Disable]*/
    U8BIT   u8EOMTimeTagEna;    /*!< EOM Time tag Enable [1- Enable, 0-Disable]*/
    U8BIT   u8BusSwEnbDis;      /*!< Bus Switch disable [1-Disable, 0- Enable]*/
    U8BIT   u8BusSelction;      /*!< Selection of bus-A,B or both [Bus A - 1, Bus B - 2, Both - 0] */
    U8BIT   u8EnaBlkStsComp;    /*!< Set IRIGB block status word compliance enable [0 - Disable , 1 - Enable] */
    U8BIT   u8NoResTimeout;     /*!< Response time range is from 0[18.5microsec],1[500ns] to 511[255.5microsec], resolution is in 500ns */
}SDP1553_MT_CONFIG, *PSDP1553_MT_CONFIG;

typedef struct _SDP1553B_MT_INT
{
    U8BIT  u8EnaDis;            /*!< 0 - Disable / 1 - Enable */
    U32BIT u32IntEventMasks;
    U32BIT u32MsgCntThreshold;  /*!< Threshold message count value[0 to 131071] */
    U32BIT u32WrdCntThreshold;  /*!< Threshold word count value [0 to 1048575]*/
    U32BIT u32TimeIntThreshold; /*!< Threshold timer value [0 to 65535]. The resolution is 100us*/
}SDP1553B_MT_INT, *PSDP1553B_MT_INT;

typedef struct _SDP1553_BOARD_OPER
{
    U8BIT  u8BoardID;
    U8BIT  u8BusNo;
    U8BIT  u8SlotNo;
    U8BIT  u8FunctionNo;
    U8BIT  u8ChannelNo;
    U8BIT  u8ChnlSts;
}SDP1553_DEVICE_LOC, *PSDP1553_DEVICE_LOC;

typedef struct _S_APP_TIMETAG_TIME
{
    U32BIT u32Hour;
    U8BIT  u8Min;
    U8BIT  u8Sec;
    U16BIT u16MilliSec;
    double fMicroSec;
}S_APP_TIMETAG_TIME;

typedef struct DP1553_SELFTEST
{
SDP1553BXT_RAM_BIST_STATUS SBIST_Sts;
unsigned int uiRAMSelfTestDataBusSts;
unsigned int uiRAMSelfTestAddrBusSts;
unsigned int uiRAMSelfTestIntergritySts;


}S_DP_SELF_TEST_STATUS;


#pragma pack(pop)

class cDP1553BWrapper
{

public:
    //Channel Handle
    U16BIT  m_u16NoOfDeviceFound;
    unsigned int m_usMsgCnt;
    unsigned short usData[32];
    unsigned short usCombinedData[32];
    unsigned short usAsynData[32];
    unsigned short usCombinedDataRT[32];
    unsigned short usRTBCTest;
    unsigned short usTestSel;
    DP_DRV_HANDLE m_vpHandle[DP1553B_5019_MAX_CHNLS];
    // Common Functions
    S32BIT DP1553B_Open(U16BIT u16NoOfDevice, PSDP1553_DEVICE_LOC in_pSDeviceLoc[], PSDP1553_DEVICE_LOC out_pSDeviceLoc[]);
    S32BIT DP1553B_Close();
    S32BIT DP1553B_Reset(U8BIT in_u8ResetOption);
    S32BIT DP1553B_InitializeMode(U16BIT in_u16DeviceNo, U32BIT in_u32OprMode, U32BIT u32Options);
    S32BIT DP1553B_BC_Init(U16BIT in_u16DeviceNo, SDP1553_BC_INIT in_BCInitInfo);
    S32BIT DP1553B_BC_Config(U16BIT in_u16DeviceNo, SDP1553_BC_CONFIG in_BCConfig);
    S32BIT DP1553B_BC_EnableExtTriggerStart(U16BIT in_u16DeviceNo, U16BIT in_u16ExtTrigEnDis);
    S32BIT DP1553B_GenerateSWExtTrigger(U16BIT in_u16DeviceNo);
    // BC Functions
    S32BIT DP1553B_BC_CreateDataBlock(U16BIT in_u16DeviceNo, U16BIT in_u16DataBlkID, U16BIT *in_pu16DataBuffer, U16BIT in_u16DataSize);
    S32BIT DP1553B_BC_CreateMessage(U16BIT in_u16DeviceNo, U16BIT in_u16MsgBlkID, PDP1553B_BC_MSG_DEF in_pBCMsgDef, PDP1553B_BC_MSG_DEF in_pBCAlternateMsgDef, U16BIT in_u16DoubBufEnDiS);
    S32BIT DP1553B_BC_WriteMessageData(U16BIT in_u16DeviceNo, U16BIT in_u16MsgBlkID, U16BIT *in_pu16DataBuffer, U16BIT in_u16DataSize,  U16BIT in_u16Offset,  U16BIT in_u16Option);
    S32BIT DP1553B_BC_CreateMinorFrame(U16BIT in_u16DeviceNo, U16BIT in_u16FrameID, U16BIT in_u16NoOfMsgs, U16BIT *in_pu16MsgIDList, U16BIT in_u16FrameTime);
    S32BIT DP1553B_BC_CreateMinorFrameEx(U16BIT in_u16DeviceNo, U16BIT in_u16FrameID, U16BIT in_u16NoOfOpcodes, DP1553BXT_BC_OPCODE_DEF *in_pOpcodeList);
    S32BIT DP1553B_BC_CreateMajorFrame(U16BIT in_u16DeviceNo, U16BIT in_u16FrameID, U16BIT in_u16NoOfMinorFrm, U16BIT *in_pu16MinorFrmIDList, U32BIT in_u32FrameCount, U16BIT in_u16Options);
    S32BIT DP1553B_BC_CreateMajorFrameEx(U16BIT in_u16DeviceNo, U16BIT in_u16FrameID, U16BIT in_u16NoOfOpcodes, DP1553BXT_BC_OPCODE_DEF *in_pOpcodeList, U32BIT in_u32FrameCount, U16BIT in_u16FrameRepeatAt);
    S32BIT DP1553B_BC_Destroy(U16BIT in_u16DeviceNo, U16BIT in_u16DestSel);
    S32BIT DP1553B_BC_Start_Stop(U16BIT in_u16DeviceNo, U16BIT in_u16StartStop, U16BIT in_u16MajorFrmID, U8BIT  in_u8UnblockWait);
    S32BIT DP1553B_BC_WaitForEvents(U16BIT in_u16DeviceNo, U32BIT in_u32EventMasks, U16BIT in_u16Options, U32BIT *in_pu32Timeout, U32BIT *out_u32EventStatus);
    S32BIT DP1553B_BC_ReadMessage(U16BIT in_u16DeviceNo, SDP1553BXT_BC_MSG *out_pSBCMsg, U16BIT in_u16MsgsToRead, U16BIT *out_u16AvailMsgs, U32BIT *in_u32Timeout);
    S32BIT DP1553B_BC_ReadMessageFromID(U16BIT in_u16DeviceNo, U16BIT in_u16MsgBlkID, PSDP1553BXT_BC_MSG out_pSBCMsg,  U16BIT *out_pu16MsgAvail);
    S32BIT DP1553B_BC_SendAsyncMessage(U16BIT in_u16DeviceNo, U16BIT in_u16Queue, U16BIT in_pu16MsgCount, U16BIT *in_pu16MsgBlkIDList, U16BIT *out_pu16QueueCount);
    S32BIT DP1553B_BC_GetAsyncMessageCount(U16BIT in_u16DeviceNo, U16BIT in_u16Queue, U16BIT *out_pu16QueueCount);
    S32BIT DP1553B_BC_ResetAsyncMessageQueue(U16BIT in_u16DeviceNo, U16BIT in_u16Queue);
    S32BIT DP1553B_BC_EnableDisableInt(U16BIT in_u16DeviceNo, PSDP1553B_BC_INT in_pSBC_INT);
    S32BIT DP1553B_BC_GetBufferInfo(U16BIT in_u16DeviceNo,U32BIT *out_pu32MsgsCount,U32BIT *out_pu32LostCount);
    S32BIT DP1553B_BC_SetTimeTagResolution(U16BIT in_u16DeviceNo, U16BIT u16SetResolution);
    // RT Functions
    S32BIT DP1553B_RT_Init(U16BIT in_u16DeviceNo, PSDP1553_RT_INIT in_pSRTInitInfo);
    S32BIT DP1553B_RT_Configure(U16BIT in_u16DeviceNo, U32BIT in_u32ConfigOption, PSDP1553B_MRT_CONFIG in_pSMRT_Config);
    S32BIT DP1553B_RT_SetNoRespTimeOut(U16BIT in_u16DeviceNo, U16BIT in_u16NoRespTimeOut, PSDP1553B_MRT_CONFIG in_pSMRT_Config);
    S32BIT DP1553B_RT_ConfigSubAddress(U16BIT in_u16DeviceNo, U32BIT in_u32SubAddrMask, U8BIT in_u8MsgType, U8BIT in_u8DataBufType, U32BIT in_u32Options, PSDP1553B_MRT_CONFIG in_pSMRT_Config);
    S32BIT DP1553B_RT_WriteSAData(U16BIT in_u16DeviceNo, U8BIT in_u8SubAddr, U16BIT *in_pu16DataBuffer, U16BIT in_u16DataSize,U16BIT in_u16Offset, PSDP1553B_MRT_CONFIG in_pSMRT_Config);
    S32BIT DP1553B_RT_EnableDisableInt(U16BIT in_u16DeviceNo, PSDP1553B_RT_INT in_pSRT_INT);
    S32BIT DP1553B_RT_Start_Stop(U16BIT in_u16DeviceNo, U16BIT in_u16StartStop, PSDP1553B_MRT_CONFIG in_pSMRT_Config);
    S32BIT DP1553B_RT_WaitForEvents(U16BIT in_u16DeviceNo, U32BIT in_u32EventMasks, U16BIT in_u16Options, U32BIT *in_pu32Timeout, U32BIT *out_pu32EventStatus);
    S32BIT DP1553B_RT_ReadMessage(U16BIT in_u16DeviceNo, SDP1553BXT_RT_MSG *out_pSRTMsg, U16BIT in_u16MsgsToRead, U16BIT *out_u16AvailMsgs, U32BIT *in_pu32Timeout, PSDP1553B_MRT_CONFIG in_pSMRT_Config);
    // MT Functions
    S32BIT DP1553B_MT_Init(U16BIT in_u16DeviceNo, PSDP1553_MT_INIT in_pSMTInitInfo);
    S32BIT DP1553B_MT_Config(U16BIT in_u16DeviceNo, PSDP1553_MT_CONFIG in_pSMTConfig);
    S32BIT DP1553B_MT_SetSelectiveMonitorOptions(U16BIT in_u16DeviceNo, U8BIT in_u8RTs, U32BIT in_u32SAs, U8BIT in_u8TxRx);
    S32BIT DP1553B_MT_EnableDisableInt(U16BIT in_u16DeviceNo, PSDP1553B_MT_INT in_pSMT_INT);
    S32BIT DP1553B_MT_WaitForEvents(U16BIT in_u16DeviceNo, U32BIT in_u32EventForWait, U32BIT in_u32Option, U32BIT *in_pu32Timeout, U32BIT *out_pu32Status);
    S32BIT DP1553B_MT_ReadMessage(U16BIT in_u16DeviceNo, U16BIT in_u16NoOfMsg, U32BIT *in_u32Timeout, SDP1553BXT_MT_MSG *out_pMsg, U16BIT *out_pu16AvalibleMsg);
    S32BIT DP1553B_MT_StartStopMonitor(U16BIT in_u16DeviceNo, U16BIT in_u16StartStop);
    S32BIT DP1553B_Internal_Self_Test(U16BIT in_u16DeviceNo,S_DP_SELF_TEST_STATUS *out_pSSelfTestStatus);


    S16BIT GetTimeFromTimetag(U64BIT in_u64Timetag, U16BIT in_u16TTRes, S_APP_TIMETAG_TIME *out_pTime, char *out_pszTime, QString *out_qsTime);

};

/*!
* @}
*/
#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif

#endif //#ifndef _DP1553BXT_PRO_H_
