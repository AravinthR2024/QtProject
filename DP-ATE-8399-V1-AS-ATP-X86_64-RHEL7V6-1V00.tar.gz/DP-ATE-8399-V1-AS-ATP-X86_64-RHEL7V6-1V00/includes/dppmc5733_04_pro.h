/**
* \file DPPMC5733_04_pro.h
* \brief This file contains the function prototypes of all the functions or API's are available in this file
*
* \author Tamizharasan K
* \date  11 February, 2020
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
* Phone: 91-44-4741-4000\n
* FAX: 91-44-4741-4444 \n
*
*/
#ifndef _DPPMC5733_04_PRO_H_
#define _DPPMC5733_04_PRO_H_

#include "dp_types.h"

#if defined(__cplusplus) || defined(__cplusplus__)
extern 	"C" {
#endif

/***********************************Structures************************/
#pragma pack(push,1)

/**
*\struct    _SDPPMC5733_04_DEVICE_LOCATION
*\brief  	This structure contains members to hold the device locations details
*
*			The device location details includes the bus number, slot number, function number and channel number.
*
*/
typedef struct _SDPPMC5733_04_DEVICE_LOCATION
{
	U8BIT m_u8BusType;				/*!< Device bus type */
    U8BIT m_u8ChannelNo;			/*!< Channel number */	
    union
    {
        struct
        {
            U8BIT m_u8BusNo;		/*!< Bus number */
            U8BIT m_u8SlotNo;		/*!< Slot number */
            U8BIT m_u8FunctionNo;	/*!< Function number */
        }pci;
    }u; 
}SDPPMC5733_04_DEVICE_LOCATION, *PSDPPMC5733_04_DEVICE_LOCATION;

/**
*\struct    _SDPPMC5733_04_DRIVER_DETAILS
*\brief  	This structure contains members to hold the driver details
*
*			The driver details includes the driver version.
*
*/
typedef struct _SDPPMC5733_04_DRIVER_DETAILS
{
    U32BIT m_u32Version;	/*!< Driver version */
}SDPPMC5733_04_DRIVER_DETAILS, *PSDPPMC5733_04_DRIVER_DETAILS;

/**
*\struct    _SDPPMC5733_04_GLUE_LOGIC_DETAILS
*\brief  	This structure contains members to hold the glue logic details
*
*			The glue logic details includes the Board ID, Board Version, FPGA version and FPGA type ID.
*
*/
typedef struct _SDPPMC5733_04_GLUE_LOGIC_DETAILS
{
	U16BIT 	m_u16BoardId;			/*!< Board ID */
	U16BIT 	m_u16BoardVer;			/*!< Board Version */
	U16BIT 	m_u16FPGAVersion;		/*!< FPGA Version */
	U16BIT 	m_u16FPGATypeId;		/*!< FPGA Type ID */
}SDPPMC5733_04_GLUE_LOGIC_DETAILS, *PSDPPMC5733_04_GLUE_LOGIC_DETAILS;

/**
*\struct	_SDPPMC5733_04_CONFIG_INFO
*\brief		 This structure is used for the configuration details
*
*			The configuration details are RxEnable, TxEnable, Operational mode.				
*
*/
typedef struct _SDPPMC5733_04_CONFIG_INFO
{
	U8BIT 	m_u8StartStopBitSel;	/*!< Start Stop bit 0 or 1 (0 - Start bit then stop bit will be 1), (1 - Start bit then stop bit will be 0)*/
	U8BIT	m_u8ModeBitSel;			/*!< Mode bit 0 or 1 */
	U8BIT	m_u8DataByteSel;		/*!< Data bytes selection (0 - Command with LS & MS byte, 1 - Command with LS byte , 2 - Command with MS byte) */
	U8BIT	m_u8RspDataTypeSel;		/*!< Data type selection (0 - Inverted Data, 1 - Counter Data) */

}SDPPMC5733_04_CONFIG_INFO, *PSDPPMC5733_04_CONFIG_INFO;

#pragma pack(pop)

/****************************function  prototypes ******************************/
/*!
*	\addtogroup Common_Functions List of common driver functions
* @{
*/
/**
*\brief 	 This function is used to find the total number of DP-PMC-5733 device(s) present in the system
*
*\param[out] out_pu16TotalDevices	It specifies the output pointer to hold the number of DP-PMC-5733 device(s) found
*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified total devices output pointer is null
*
*\pre		NA
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_GetTotalDeviceFound(PU16BIT out_pu16TotalDevices);

/** 
*\brief 	 This function is used to get pci details such as bus number, slot number, function number and channel number for the DP-PMC-5733 device(s)
*
*\param[out]  out_pSAllDevLocDetails	It specifies the output pointer to hold the device location details(size: in_u16MaxDevices)
*\param[in]   in_u16MaxDevices			It specifies the total number of DP-PMC-5733 device(s) found
*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output device location details structure pointer is null
*
*\pre		::DPPMC5733_04_GetTotalDeviceFound
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_GetAllDeviceLocations(PSDPPMC5733_04_DEVICE_LOCATION out_pSAllDevLocDetails, U16BIT in_u16MaxDevices);

/**
*\brief 		This function is used to open the specified DP-PMC-5733 device.
*
*\param[in]		in_pSDeviceOpenInfo		It specifies the bus number, slot number, function number and channel number
*\param[out]	out_phDeviceHandle		It specifies the pointer to hold output device handle
*
*\retval		::DPPMC5733_04_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_POINTER is returned if the device locataion structure pointer is null
*\retval		::DPPMC5733_04_ERR_DEVICE_BUSY is returned if the the device is already opened
*
* \pre			::DPPMC5733_04_GetAllDeviceLocations
* \post    	  	::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_Open(PSDPPMC5733_04_DEVICE_LOCATION in_pSDeviceOpenInfo, DP_DRV_HANDLE out_phDeviceHandle);

/**
*\brief 	 This function is used to close the opened device. Any opened device has to be closed before the application is exited.
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_DEVICE_NOT_OPEN is returned if the device is not opened
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_Close(DP_DRV_HANDLE in_hHandle);

/** 
*\brief		This function is used to get opened device location details(bus number, slot number, function number and channel number)
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_pSDeviceLocation	It specifies the pointer to hold the device location details
*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output device location pointer is null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_GetDeviceLocation(DP_DRV_HANDLE in_hHandle, PSDPPMC5733_04_DEVICE_LOCATION out_pSDeviceLocation);

/**
*\brief 	 This function is used to reset the device to initial state
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_Reset(DP_DRV_HANDLE in_hHandle);

/**
*\brief		This function is used to get the error message corresponding to the error code. The error message specify briefly the cause of the error.
*
*\param[in]  in_s32ErrCode	It specifies the error code returned by the functions
*\param[out] out_ps8ErrMsg	It specifies the pointer to hold the error message(size:in_u16BufSize)
*\param[in]  in_u16BufSize	It specifies buffer size to hold the error message
*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output error message pointer is null
*
*\pre	 	::DPPMC5733_04_Open
*\post	 	NA
*
*
*/
S32BIT STDCALL DPPMC5733_04_GetErrorMessage(S32BIT in_s32ErrCode, PS8BIT out_ps8ErrMsg, U16BIT in_u16BufSize);

/**
*\brief 	 This function is used to get the driver details(Driver Version)
*
*\param[out] out_pSDriverDetails 	It specifies the structure pointer to read the driver details(Driver Version)
*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output driver details pointer is null
*
*\pre		NA
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_GetDriverDetails(PSDPPMC5733_04_DRIVER_DETAILS out_pSDriverDetails);

/**
*\brief		This function is used to get FPGA version
*
*\param[in]	 in_hDevHandle		It specifies the device handle which got from device open function
*\param[out] out_pSGlueLogicDetails	It specifies the pointer to read the FPGA version
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DPPMC5733_04_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPPMC5733_04_ERR_INVALID_PTR is returned if the output FPGA version pointer is null
* 
*\pre		:: DPPMC5733_04_Open
*\post		:: DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_GetGlueLogicDetails(DP_DRV_HANDLE in_hHandle, PSDPPMC5733_04_GLUE_LOGIC_DETAILS out_pSGlueLogicDetails);

/**
*\brief		 This function is used to write data into the specified FPGA scratch pad register offset.
			 \n(This ::DPPMC5733_04_ScratchPadWrite & ::DPPMC5733_04_ScratchPadRead is used to self test the FPGA regiters)
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[in]  in_u16WriteData	It specifies the the data to be written in specified register offset
*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_ScratchPadWrite(DP_DRV_HANDLE in_hHandle, U32BIT in_u32WriteData);

/**
*\brief 	 This function is used to read data from the specified FPGA scratch pad register offset
			 \n(This ::DPPMC5733_04_ScratchPadWrite & ::DPPMC5733_04_ScratchPadRead is used to self test the FPGA regiters)
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[out] out_pu32ReadData	It specifies the pointer to read data from specified register offset
*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified read data output pointer is null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_ScratchPadRead(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32ReadData);

/**
*\brief		 This function is used to write data into the specified FPGA register offset
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[in]  in_u32WriteData	It specifies the the data to be written in specified register offset
*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_WriteReg(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, U32BIT in_u32WriteData);

/**
*\brief 	 This function is used to read data from the specified FPGA register offset
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[out] out_pu32ReadData	It specifies the pointer to read data from specified register offset
*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified read data output pointer is null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_ReadReg(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, PU32BIT out_pu32ReadData);

/**
*\brief		This function is used to enable or disable(1 - Enable, 0 - Disable) the device share option(opening same device more than one time)
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	 in_u8EnDis		It specifies the enable / disable value(max:1)
*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_SHARE_VALUE is returned if the enable / disable device share option is out of limit(0 to 1)
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_SetDeviceShare(DP_DRV_HANDLE in_hHandle, U8BIT in_u8EnDis);

/*!
* @}
*/

/******************************* Board Specific ************************************/
/*!
*	\addtogroup Board_Functions List of device specific driver functions
* @{
*/

/**
*\brief		  This function is used to set the clock signal to the UART Transmitter and Receiver with the user required baud rate
			  \n(0 - 4Mbps,
			  \n 1 - 2Mbps,
			  \n 4 - 1Mbps).
*
*\param[in]	  in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]   in_u8SetBaudrate	It specifies the value to hold the buad rate
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output receiver data count pointer is null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_SetBaudrate(DP_DRV_HANDLE in_hHandle, U8BIT in_u8SetBaudrate);

/**
*\brief		  This function is used to set the Threshold range 
			  
*
*\param[in]	  in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]   in_u32SetThreshold	It specifies the value to hold the threshold data
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output receiver data count pointer is null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_SetThreshold(DP_DRV_HANDLE in_hHandle, U32BIT in_u32SetThreshold);

/**
*\brief		  This function is used to select the mode either the flight mode or external loop back mode
*
*\param[in]	  in_hHandle	It specifies the device handle which is obtained from device open function
*\param[in]   in_u8SetMode	It specifies the value to select the mode(max:1)
							\n 0 - Flight Mode,
							\n 1 - External Loop Back Mode
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output receiver data count pointer is null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_SetMode(DP_DRV_HANDLE in_hHandle, U8BIT in_u8SetMode);

/**
*\brief		  This function is used to select the response time 
*
*\param[in]	  in_hHandle	It specifies the device handle which is obtained from device open function
*\param[in]   in_u8SetMode	It specifies the value to select the mode(max:1)
							\n 0 - Flight Mode,
							\n 1 - External Loop Back Mode
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output receiver data count pointer is null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_ResponseTime(DP_DRV_HANDLE in_hHandle, FSINGLE in_fRespTime);

/**
*\brief 	 This function is used to configure a particular channel with mode selection (Tx Mode or Rx Mode) and self test selection of the specified channel
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_sConfigInfo		It specifies the input structure to write configuration details which consist of RxEnable(0 - Disable the receiver / 1 - Enable the receiver),\n
								TxEnable(0 - Disable the transmitter / 1 - Enable the transmitter), Mode bit 0 or 1\n
								StartStopBitSel (0 - Start bit then stop bit will be 1, 1 - Start bit then stop bit will be 0),\n
								Mode selection (0 -  Flight mode / 1 - External loop back mode), Data bytes selection (0 - Command with LS & MS byte, 1 - Command with LS byte , 2 - Command with MS byte)

*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPPMC5733_04_ERR_INVALID_RXENABLE is returned if the receiver enable is out of limit(0 to 1)
*\retval	::DPPMC5733_04_ERR_INVALID_TXENABLE is returned if the transmitter enable is out of limit(0 to 1)
*\retval	::DPPMC5733_04_ERR_INVALID_SELFTEST is returned if the self test selection value is out of limit(0 to 1)
*\retval	::DPPMC5733_04_ERR_INVALID_MODE is returned if the mode selection value is out of limit(0 to 1)
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_SetConfiguration(DP_DRV_HANDLE in_hHandle, PSDPPMC5733_04_CONFIG_INFO in_psConfigInfo);

/**
*\brief 	 This function is used to get the configuration details such as mode selection(master or slave), transmitter and receiver bit rate,\n 
			 command and reply word, self test selection of a particular channel of the board
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_psConfigInfo	It specifies the input structure to write configuration details which consist of RxEnable(0 - Disable the receiver / 1 - Enable the receiver),\n
								TxEnable(0 - Disable the transmitter / 1 - Enable the transmitter),\n
								StartStopBitSel (0 - Start bit then stop bit will be 1, 1 - Start bit then stop bit will be 0),\n
								, Mode selection (0 - Tx mode / 1 - Rx Mode),\n DataByte selection(00' →  COMMAND BYTE ,MS BYTE ,LS BYTE
				                '01' →  COMMAND BYTE ,LS BYTE 
				                '10' →  COMMAND BYTE ,MS BYTE)*
*\retval	::DPPMC5733_04_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified read configuration details output pointer is null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_GetConfiguration(DP_DRV_HANDLE in_hHandle, PSDPPMC5733_04_CONFIG_INFO out_psConfigInfo);
/**
*\brief		  This function is used to select the RAM, which is going to be read / write command data
*
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	  in_u8RAMSel			It specifies the value to the select the active RAM(max:2)(1 - RAM A, 2 - RAM B)
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPMC5733_04_ERR_INVALID_RAMSEL is returned if the ram selection is invalid(max:2)
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_RAMSelection(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RAMSel);
/**
*\brief		  This function is used to select the RAM, which is going to be transmit command
*
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	  in_u8RAMSel			It specifies the value to the select the active RAM(max:2)(1 - RAM A, 2 - RAM B)
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPMC5733_04_ERR_INVALID_RAMSEL is returned if the ram selection is invalid(max:2)
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*
*/
S32BIT STDCALL DPPMC5733_04_TxRAMSelection(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RAMSel);

/**
*\brief		  This function is used to write the data into the Transmitter RAM(256bytes) for the selected channel
*
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	  in_u8StartIndex		It specifies the start index of the selected RAM(min:0 to max:255)
*\param[in]	  in_u8TotCmdtoWrite 	It specifies the total bytes of command to be written to the RAM(min:1 to max:256)
*\param[in]   in_pu8CmdData			It specifies the input pointer to transmit the command data.(size:in_u8TotCmdtoRead)
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPMC5733_04_ERR_INVALID_STARTADDR is returned if the start index is invalid(max:255)
*\return	::DPPMC5733_04_ERR_INVALID_TOTBYTSTOWRITE is returned if the total bytes to write is invalid(min:0 to max:256)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the input transmitter command data pointer is null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_TxCmdWrite(DP_DRV_HANDLE in_hHandle, U8BIT in_u8StartIndex, U8BIT in_u8TotCmdtoWrite, PU8BIT in_pu8CmdData);

/**
*\brief		  This function is used to read the data from the Transmitter RAM(256bytes) for the selected channel
*
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	  in_u8StartIndex		It specifies the start index of the selected RAM(min:0 to max:255)
*\param[in]	  in_u8TotCmdtoRead 	It specifies the total bytes of command to be read from the RAM(min:1 to max:256)
*\param[out]  out_pu8CmdData		It specifies the output pointer to hold the transmit command data.(size:in_u8TotCmdtoRead)
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPMC5733_04_ERR_INVALID_STARTADDR is returned if the start index is invalid(max:255)
*\return	::DPPMC5733_04_ERR_INVALID_TOTBYTSTOWRITE is returned if the total bytes to read is invalid(min:0 to max:256)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output transmitter command data pointer is null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_TxCmdRead(DP_DRV_HANDLE in_hHandle, U8BIT in_u8StartIndex, U8BIT in_u8TotCmdtoRead, PU8BIT out_pu8CmdData);

/**
*\brief		  This function is used to select the start and end index of command to be transmitted for the configured transmitter channel
*
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	  in_u8StartIndex		It specifies the start index of the selected RAM(min:0 to max:255)
*\param[in]	  in_u8EndIndex 		It specifies the stop index of the selected RAM(min:0 to max:255)
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPMC5733_04_ERR_INVALID_STARTADDR is returned if the start index is invalid(max:255)
*\return	::DPPMC5733_04_ERR_INVALID_ENDADDR is returned if the total bytes to read is invalid(min:0 to max:256)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output transmitter command data pointer is null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_TxCmdSelect(DP_DRV_HANDLE in_hHandle, U8BIT in_u8StartIndex, U8BIT in_u8EndIndex);

/**
*\brief		This function is used to set the message time configured for the specified channel.
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]  in_u32MsgTime	It specifies the message time
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_SetMessageTime(DP_DRV_HANDLE in_hHandle, U32BIT in_u32MsgTime);

/**
*\brief		This function is used to get the message time configured for the specified channel.
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*\param[out] out_u32MsgTime	It specifies the pointer to read the message time
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_GetMessageTime(DP_DRV_HANDLE in_hHandle, PU32BIT out_u32MsgTime);

/**
*\brief		This function is used to set the frame time between the one frame to next frame
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32FrameTime	It specifies the the frame time
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_SetFrameTime(DP_DRV_HANDLE in_hHandle, U32BIT in_u32FrameTime);

/**
*\brief		This function is used to get the frame time between the one frame to next frame
*
*\param[in]	  in_hHandle		It specifies the device handle which is obtained from device open function
*\param[out]  out_pu32FrameTime	It specifies the frame time
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_GetFrameTime(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32FrameTime);

/**
*\brief		  This function is used to Start or Stop the transmission
*
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]   in_u8TxRxSel      	It specifies the Selection of Tx or Rx or both (max:1)
*\param[in]   in_u8TxRxStartStop	It specifies the Start or Stop the transmission of selected mode (max:1)(0 - Stop / 1 - Start)
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPMC5733_04_ERR_INVALID_STARTSTOPTRANS is returned if the transmission Start / Stop is invalid (max:1)
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_StartStopTransmission(DP_DRV_HANDLE in_hHandle, U8BIT in_u8TxRxSel, U8BIT in_u8TxRxStartStop);

/**
*\brief		  This function is used to get the number of dwords available in the receiver FIFO of specified channel of the DP-PMC-5733 device
*
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out]  out_pu32RxFifoCnt		It specifies the pointer to hold receiver FIFO data count
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output receiver fifo count pointer is null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_GetRxFifoCount(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32RxFifoCnt);

/**
*\brief		  This function is used to Reset the RX FIFO
*
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]   in_u8Reset            It specifies the reset bit 1 - enable  
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPMC5733_04_ERR_INVALID_RESET is returned if the RESET is invalid (max:1)
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*/
S32BIT STDCALL DPPMC5733_04_RxFifoReset(DP_DRV_HANDLE in_hHandle, U8BIT in_u8Reset);
/**
*\brief		  This function is used to configurate timeout error for reply
*
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]   in_u32Timeout        It specifies the timeout value for rx to reply
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPMC5733_04_ERR_INVALID_RESET is returned if the  timeout is invalid (max:1)
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*/

S32BIT STDCALL DPPMC5733_04_TimeOutConfig(DP_DRV_HANDLE in_hHandle, FSINGLE in_fTimeout);
/**
*\brief	   This function is used to read the FIFO data of the particular channel, which is configured as receiver.
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]   in_u16Options 		It specifies whether the function to be unblocked if any events occurred or all specified events. Any of the following option can be used, DPPMC5733_04_EVT_OPT_WAIT_ANY or DPPMC5733_04_EVT_OPT_WAIT_ALL (max:1).
*\param[in]   in_pu32Timeout 		It specifies the address of the timeout value. 
*\param[in]	 in_u16DataToRead		It specifies the number of data's to be read. It should not be more than the buffer size
*\param[out] out_pu16AvailDataRead	It specifies the output pointer to read the total number of data's actually read
*\param[out] out_pu32ReadData		It specifies the pointer to read the receiver data(size:in_u16DataToRead)
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output receiver data pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the receiver count pointer is null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
* 
*/
S32BIT STDCALL DPPMC5733_04_RxReadMessage(DP_DRV_HANDLE in_hHandle, U16BIT in_u16Option, PU32BIT in_pu32Timeout, U16BIT in_u16DataToRead, PU16BIT out_pu16AvailDataRead, PU8BIT out_pu8ReadData);

/**
*\brief		This function is used to enable the interrupts and requested (masked) interrupt events for application to receive the events through 'DPPMC5733_04_WaitForEvents' function
*
*\param[in]	in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in] in_u32IntEventMasks		It specifies the interrupt event mask to generate events to application
*\param[in] in_u32BufSize			It specifies value to create the ring buffer in driver
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_EnableInterrupt(DP_DRV_HANDLE in_hHandle, U32BIT in_u32IntEventMasks, U32BIT in_u32BufSize);
/**
*\brief		This function is used to check the interrupt status
*
*\param[in]	in_hHandle	It specifies the device handle which is obtained from device open function
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DPPMC5733_04_ConnectInterrupt
*\post		::DPPMC5733_04_GetErrorMessage
*
*/

S32BIT STDCALL DPPMC5733_04_InterruptStatus(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32IntSts);
/**
*\brief		This function is used to disable the interrupt for the selected device
*
*\param[in]	  in_hHandle	   It specifies the device handle which is obtained from device open function
*\param[out]  in_u32EventMasks   It specifies the input for disable event interrupt
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DPPMC5733_04_ConnectInterrupt
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_DisableInterrupt(DP_DRV_HANDLE in_hHandle,U32BIT in_u32EventMasks);

/**
*\brief       This function will wait (block / non-block / timeout) for the specified events mask which are the interrupt events enabled in the 'DPPMC5733_04_ConnectInterrupt' function. This function can be used only if the interrupt(s) are enabled.
*
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]   in_u32EventMasks 		It specifies for which interrupt events the application to be notified(min:0x1 to max:0x3)
*\param[in]   in_u16Options 		It specifies whether the function to be unblocked if any events occurred or all specified events. Any of the following option can be used, DPPMC5733_04_EVT_OPT_WAIT_ANY or DPPMC5733_04_EVT_OPT_WAIT_ALL (max:1).
*\param[in]   in_pu32Timeout 		It specifies the address of the timeout value.
*\param[out]  out_u32EventStatus 	It specifies the pointer to store current events which all are occurred recently.
*
*\return	::DPPMC5733_04_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\return	::DPPMC5733_04_ERR_INVALID_TX_EVENTMASKS is returned if the event wait option is out of limit(0x1 to 0x3) 
* 	
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_WaitForEvents(DP_DRV_HANDLE in_hHandle, U32BIT in_u32EventMasks, U16BIT in_u16Options, PU32BIT in_pu32Timeout, PU32BIT out_u32EventStatus);
/**
*\brief		This function is used to get ringbuffer count  
*
*\param[in]  in_hHandle		It specifies the device handle which is obtained from device open function
*\param[out] out_pu16RingBuffCnt 	It specifies the ouptu pointer to store ring buffer count 
*
*\retval    ::DPPMC5733_05_SUCCESS is returned upon success
*\retval    ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DPPMC5733_04_Open
*\post		::DPPMC5733_04_GetErrorMessage
*
*/
S32BIT STDCALL DPPMC5733_04_GetRingBuffCnt(DP_DRV_HANDLE in_hHandle, PU16BIT out_pu16RingBuffCnt);

/*!
* @}
*/
#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif

#endif
