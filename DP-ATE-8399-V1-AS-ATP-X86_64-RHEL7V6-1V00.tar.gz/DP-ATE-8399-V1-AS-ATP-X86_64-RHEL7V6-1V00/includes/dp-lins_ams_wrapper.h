#ifndef AMS_CONTROLLER_H
#define AMS_CONTROLLER_H

#include <QObject>
#include <QSerialPort>

#define _AMS_DEBUG_
//#define _AMS_AVAILABLE_

#define AMS_WRAPPER_SUCCESS         1
#define AMS_WRAPPER_FAILURE         -1

#define AMS_SUCCESS         1
#define AMS_FAILURE         -1

#define DP_AMS_ZERO                                     0
#define DP_AMS_MAX_LEN_READ                             25

#define DP_AMS_GLOBAL_MODE                              1
#define DP_AMS_LOCAL_MODE                               0

#define DP_AMS_DAISY_CHAIN_MODE                         1
#define DP_AMS_NORMAL_MODE                              0

#define AMS_POSITION_TOL_VALUE 5

#define DEMAG_PORT_NO           0
#define AMS_PORT_NO             1
#define AMS_DATA_PACK_SIZE      35
#define AMS_MAX_ERROR_MSG_SIZE  200

#define MAX_COM_PORTS				22
#define MAX_COM_PORT_LEN			15

#define DP_AMS_ERR_NO                                   -1000
#define DP_AMS_COM_PORT_NOT_OPENED                      DP_AMS_ERR_NO + 1
#define DP_AMS_INVALID_BAUDRATE                         DP_AMS_ERR_NO + 3
#define DP_AMS_INVALID_DATABITS                         DP_AMS_ERR_NO + 4
#define DP_AMS_INVALID_PARITY                           DP_AMS_ERR_NO + 5

class CAMS_Wrapper : public QObject
{
    Q_OBJECT

public:
    explicit CAMS_Wrapper(QObject *parent = 0);

    QSerialPort m_objqserialport;
    QByteArray m_qbReadData;
    unsigned char m_ucIsDaisyChain;

    int m_iPortHandle[MAX_COM_PORTS];
    unsigned char m_ucCommand;
    char m_szData[30];                      /* Data Bytes: (Axis1 -> 10) + (Axis2 -> 10) + (Axis3 -> 10) = 30 bytes  */
    char m_szTxPacket[AMS_DATA_PACK_SIZE];
    char m_szRxPacket[AMS_DATA_PACK_SIZE+1];
    char m_szErrorMsg[AMS_MAX_ERROR_MSG_SIZE];

public:
    short ConfigureComPort(QString in_qsComNo, unsigned long in_ulBaudRate, unsigned char in_ucDataBits, unsigned char in_ucParity);
    short OpenComport(QString in_qsComNo, unsigned long in_ulBaudRate, unsigned char in_ucDataBits, unsigned char in_ucParity);
    int ReadAxesPositions(float *out_pfAxis1, float *out_pfAxis2, float *out_pfAxis3);
    int SendPacket();
    int ReadCommandRate(float *out_pfCommandRate);
    int CommandAxesPositions(float in_fAxis1, float in_fAxis2, float in_fAxis3);
    int CommandRate(float in_pfCommandRate);
    int ReadStatus();
    int GetAcknowledgement(void);
    void GetErrorMsg(char *out_szErrMsg);
    int CheckAxesPositions(float in_fAxis1, float in_fAxis2, float in_fAxis3);
    int CheckCommandRate(float in_fRate);
    int StartAcquisition();
    int StopAcquisition(float *out_pfMean, float *out_pfSD);
    int ReadBuf(char *in_cptrBuf, int in_iBufSize);
    int SendBuf(char *in_cptrBuf, int in_iBufSize);
    short CloseComport();

private:
    void CheckSum(char in_szPacket[AMS_DATA_PACK_SIZE], int in_iULimit, char *in_cChecksumHigh, char *in_cChecksumLow);
    char ByteComplement(char in_cByte);
};

#endif // AMS_CONTROLLERR_H
