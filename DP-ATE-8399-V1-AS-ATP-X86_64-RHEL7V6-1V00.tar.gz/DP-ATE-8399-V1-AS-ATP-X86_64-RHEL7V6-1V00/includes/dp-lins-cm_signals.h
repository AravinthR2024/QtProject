/**
* \file dp_lins_g_signals.h
* \brief This file contains the signal ID details for LINS-CM Checkout System
*
* author Sathishkumar K
* \date  2 March, 2020
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
*
*/

#ifndef _DP_LINS_CM_SIGNALS_H_
#define _DP_LINS_CM_SIGNALS_H_

/* Maximum boards */

#define LINS_MAX_CPCI3096_BRDS		2
#define LINS_MAX_MM1105_BRDS		4
#define LINS_MAX_MM1123_BRDS		2
#define LINS_MAX_XMC5019_BRDS		1
#define LINS_MAX_RS232_CHANNELS		2

#define SID_GET_CHANNEL(usSignalId) 	(usSignalId & 0x00FF) 		/* get the Channel number from the signal ID (bit 0 to 7) */
#define SID_GET_BOARD_NUM(usSignalId) 	((usSignalId >> 8) & 0x000F) 	/* get the board number from the signal ID (bit 8 to 11)*/
#define SID_GET_BOARD_ID(usSignalId) 	((usSignalId >> 12) & 0x000F) 	/* get the board ID from the signal ID (12 to 15)*/

/* To define unique signal ID based on Channel number, board number & board ID */
/* In signal ID the 8th to 11th bits are used as board number for corresponding channel */
#define SID_BOARD_1			0x0100 	/* 1st board */
#define SID_BOARD_2			0x0200 	/* 2nd board */
#define SID_BOARD_3			0x0300	/* 3rd board */
#define SID_BOARD_4			0x0400	/* 4th board */
#define SID_BOARD_5			0x0500	/* 5th board */
#define SID_BOARD_6			0x0600 	/* 6th board */
#define SID_BOARD_7			0x0700  /* 7th board */
#define SID_BOARD_8			0x0800  /* 8th board */
#define SID_BOARD_9			0x0900  /* 9th board */
#define SID_BOARD_10                    0x0A00  /* 10th board */

/* In signal ID the bit 12 to 15 are used as board ID */
#define BRD_CPCI3096_DI			0x1000   /* DP-cPCI-3096 - DIP */
#define BRD_CPCI3096_DO			0x2000   /* DP-cPCI-3096 - DOP */
#define BRD_MM1105_ADC			0x3000	 /* DP-MM-1105 - ADC */
#define BRD_XMC5019_1553B		0x4000	 /* DP-XMC-5019 - 1553B */
#define BRD_MM1123_THERM		0x5000	 /* DP-MM-1123 - Thermistor */

#define BRD_TYPE_CPCI3096_DI		0x1   /* DP-cPCI-3096 - DIP */
#define BRD_TYPE_CPCI3096_DO		0x2   /* DP-cPCI-3096 - DOP */
#define BRD_TYPE_MM1105_ADC		0x3	 /* DP-MM-1105 - ADC */
#define BRD_TYPE_XMC5019_1553B          0x4	 /* DP-XMC-5019 - 1553B */
#define BRD_TYPE_MM1123_THERM           0x5	 /* DP-MM-1123 - Thermistor */

/* ############################################################################################################## */

/*********  Signal ID  ***************************  Channel Mapping  **************  Description  *************/

/* DP-cPCI-3096 - Digital Output */
#define	DO_COS_PWR_ON  			( BRD_CPCI3096_DO + SID_BOARD_1 + 47 )	/* COS Power ON */
#define	DO_COS_PWR_OFF 			( BRD_CPCI3096_DO + SID_BOARD_1 + 48 )	/* COS Power OFF */
#define	DO_PS1_C1_PWR    		( BRD_CPCI3096_DO + SID_BOARD_1 + 33 )	/* PS1-Chain1 Power Control */
#define	DO_PS1_C2_PWR    		( BRD_CPCI3096_DO + SID_BOARD_1 + 34 )	/* PS1-Chain2 Power Control */
#define	DO_PS1_DEMAG_PWR                ( BRD_CPCI3096_DO + SID_BOARD_1 + 35 )	/* PS1-Demag Power Control */
#define	DO_PS2_C1_PWR    		( BRD_CPCI3096_DO + SID_BOARD_1 + 36 )	/* PS2-Chain2 Power Control */
#define	DO_PS2_C2_PWR      		( BRD_CPCI3096_DO + SID_BOARD_1 + 37 )	/* PS2-Chain3 Power Control */
#define	DO_PS2_C3_PWR      		( BRD_CPCI3096_DO + SID_BOARD_1 + 38 )	/* PS2-Chain3 Power Control */
#define	DO_PS3_C1_PWR      		( BRD_CPCI3096_DO + SID_BOARD_1 + 39 )	/* PS3-Chain3 Power Control */
#define	DO_PS3_C2_PWR 			( BRD_CPCI3096_DO + SID_BOARD_1 + 40 )	/* PS3-Chain1 Power Control */
#define	DO_PS3_C3_PWR 			( BRD_CPCI3096_DO + SID_BOARD_1 + 41 )	/* PS3-Chain1 Power Control */
#define	DO_TC_PWR 			( BRD_CPCI3096_DO + SID_BOARD_1 + 42 )	/* Telecommand Power Control */
#define	DO_WDT_RESET 			( BRD_CPCI3096_DO + SID_BOARD_1 + 44)	/* Watchdog Timer Reset - Pulse */
#define	DO_SURVEIL_ERROR 		( BRD_CPCI3096_DO + SID_BOARD_1 + 45)	/* Surveillance Error - Pulse */
#define	DO_BUZZER_DISABLE 		( BRD_CPCI3096_DO + SID_BOARD_1 + 43)	/* Alarm Dissable */
#define	DO_TC_S1_BAT1_SEL 		( BRD_CPCI3096_DO + SID_BOARD_2 + 1)	/* Select Battery 1 for Sensor Channel 1 */
#define	DO_TC_S1_BAT2_SEL 		( BRD_CPCI3096_DO + SID_BOARD_2 + 2)	/* Select Battery 2 for Sensor Channel 1 */
#define	DO_TC_S4_BAT1_SEL 		( BRD_CPCI3096_DO + SID_BOARD_2 + 3)	/* Select Battery 1 for Sensor Channel 4 */
#define	DO_TC_S4_BAT2_SEL 		( BRD_CPCI3096_DO + SID_BOARD_2 + 4)	/* Select Battery 2 for Sensor Channel 4 */
#define	DO_TC_LCE1_BAT1_SEL             ( BRD_CPCI3096_DO + SID_BOARD_2 + 5)	/* Select Battery 1 for LINSCE-1 */
#define	DO_TC_LCE1_BAT2_SEL             ( BRD_CPCI3096_DO + SID_BOARD_2 + 6)	/* Select Battery 2 for LINSCE-1 */
#define	DO_TC_S3_BAT2_SEL 		( BRD_CPCI3096_DO + SID_BOARD_2 + 7)	/* Select Battery 2 for Sensor Channel 3 */
#define	DO_TC_S3_BAT3_SEL 		( BRD_CPCI3096_DO + SID_BOARD_2 + 8)	/* Select Battery 3 for Sensor Channel 3 */
#define	DO_TC_S6_BAT2_SEL 		( BRD_CPCI3096_DO + SID_BOARD_2 + 9)	/* Select Battery 2 for Sensor Channel 6 */
#define	DO_TC_S6_BAT3_SEL 		( BRD_CPCI3096_DO + SID_BOARD_2 + 10)	/* Select Battery 3 for Sensor Channel 6 */
#define	DO_TC_LCE2_BAT2_SEL             ( BRD_CPCI3096_DO + SID_BOARD_2 + 11)	/* Select Battery 2 for LINSCE-2 */
#define	DO_TC_LCE2_BAT3_SEL             ( BRD_CPCI3096_DO + SID_BOARD_2 + 12)	/* Select Battery 3 for LINSCE-2 */
#define	DO_TC_S5_BAT3_SEL 		( BRD_CPCI3096_DO + SID_BOARD_2 + 13)	/* Select Battery 3 for Sensor Channel 5 */
#define	DO_TC_S5_BAT1_SEL 		( BRD_CPCI3096_DO + SID_BOARD_2 + 14)	/* Select Battery 1 for Sensor Channel 5 */
#define	DO_TC_S2_BAT3_SEL 		( BRD_CPCI3096_DO + SID_BOARD_2 + 15)	/* Select Battery 3 for Sensor Channel 2 */
#define	DO_TC_S2_BAT1_SEL 		( BRD_CPCI3096_DO + SID_BOARD_2 + 16)	/* Select Battery 1 for Sensor Channel 2 */
#define	DO_TC_LCE3_BAT3_SEL             ( BRD_CPCI3096_DO + SID_BOARD_2 + 17)	/* Select Battery 3 for LINSCE-3 */
#define	DO_TC_LCE3_BAT1_SEL             ( BRD_CPCI3096_DO + SID_BOARD_2 + 18)	/* Select Battery 1 for LINSCE-3 */
#define	DO_TC_LCE1_ON 			( BRD_CPCI3096_DO + SID_BOARD_2 + 19)	/* Switch ON LINCE-1 */
#define	DO_TC_LCE1_OFF 			( BRD_CPCI3096_DO + SID_BOARD_2 + 20)	/* Switch OFF LINCE-1 */
#define	DO_TC_LCE2_ON 			( BRD_CPCI3096_DO + SID_BOARD_2 + 21)	/* Switch ON LINCE-2 */
#define	DO_TC_LCE2_OFF 			( BRD_CPCI3096_DO + SID_BOARD_2 + 22)	/* Switch OFF LINCE-2 */
#define	DO_TC_LCE3_ON 			( BRD_CPCI3096_DO + SID_BOARD_2 + 23)	/* Switch ON LINCE-3 */
#define	DO_TC_LCE3_OFF 			( BRD_CPCI3096_DO + SID_BOARD_2 + 24)	/* Switch OFF LINCE-3 */
#define	DO_TC_LCE1_RESET 		( BRD_CPCI3096_DO + SID_BOARD_2 + 25)	/* RESET LINCE-1 */
#define	DO_TC_LCE2_RESET 		( BRD_CPCI3096_DO + SID_BOARD_2 + 26)	/* RESET LINCE-2 */
#define	DO_TC_LCE3_RESET 		( BRD_CPCI3096_DO + SID_BOARD_2 + 27)	/* RESET LINCE-3 */
#define	DO_TC_DEMAG_ON 			( BRD_CPCI3096_DO + SID_BOARD_2 + 28)	/* Switch ON Demag */
#define	DO_TC_DEMAG_OFF 		( BRD_CPCI3096_DO + SID_BOARD_2 + 29)	/* Switch OFF Demag */
#define	DO_TC_SPARE1                    ( BRD_CPCI3096_DO + SID_BOARD_2 + 30)	/* Spare - 1 */
#define	DO_TC_SPARE2                    ( BRD_CPCI3096_DO + SID_BOARD_2 + 31)	/* Spare - 2 */
#define	DO_TC_SPARE3                    ( BRD_CPCI3096_DO + SID_BOARD_2 + 32)	/* Spare - 3 */

#define	DO_TC_SPARE4                     ( BRD_CPCI3096_DO + SID_BOARD_2 + 33)	/* Spare - 4 */
#define	DO_TC_SPARE5                     ( BRD_CPCI3096_DO + SID_BOARD_2 + 34)	/* Spare - 5 */
#define	DO_TC_SPARE6                     ( BRD_CPCI3096_DO + SID_BOARD_2 + 35)	/* Spare - 6 */
#define	DO_TC_SPARE7                     ( BRD_CPCI3096_DO + SID_BOARD_2 + 36)	/* Spare - 7 */
#define	DO_TC_SPARE8                     ( BRD_CPCI3096_DO + SID_BOARD_2 + 37)	/* Spare - 8 */
#define	DO_TC_SPARE9                     ( BRD_CPCI3096_DO + SID_BOARD_2 + 38)	/* Spare - 9 */
#define	DO_TC_SPARE10                    ( BRD_CPCI3096_DO + SID_BOARD_2 + 39)	/* Spare - 10*/
#define	DO_TC_SPARE11                    ( BRD_CPCI3096_DO + SID_BOARD_2 + 40)	/* Spare - 11*/
#define	DO_TC_SPARE12                    ( BRD_CPCI3096_DO + SID_BOARD_2 + 41)	/* Spare - 12*/
#define	DO_TC_SPARE13                    ( BRD_CPCI3096_DO + SID_BOARD_2 + 42)	/* Spare - 13*/
#define	DO_TC_SPARE14                    ( BRD_CPCI3096_DO + SID_BOARD_2 + 43)	/* Spare - 14*/
#define	DO_TC_SPARE15                    ( BRD_CPCI3096_DO + SID_BOARD_2 + 44)	/* Spare - 15*/
#define	DO_TC_SPARE16                    ( BRD_CPCI3096_DO + SID_BOARD_2 + 45)	/* Spare - 16*/
#define	DO_TC_SPARE17                    ( BRD_CPCI3096_DO + SID_BOARD_2 + 46)	/* Spare - 17*/
#define	DO_TC_SPARE18                    ( BRD_CPCI3096_DO + SID_BOARD_2 + 47)	/* Spare - 18*/
#define	DO_TC_SPARE19                    ( BRD_CPCI3096_DO + SID_BOARD_2 + 48)	/* Spare - 19*/

/* DP-cPCI-3096 - Digital Input */			                             	
#define	DI_COS_PWR_STS 			( BRD_CPCI3096_DI + SID_BOARD_1 + 48 )	/* COS Power Control Status */
#define	DI_PS1_C1_PWR_STS		( BRD_CPCI3096_DI + SID_BOARD_1 + 33 )	/* PS1-Chain1 Power Control Status */
#define	DI_PS1_C2_PWR_STS		( BRD_CPCI3096_DI + SID_BOARD_1 + 34 )	/* PS1-Chain2 Power Control Status */
#define	DI_PS1_DEMAG_PWR_STS            ( BRD_CPCI3096_DI + SID_BOARD_1 + 35 )	/* PS1-Demag Power Control Status */
#define	DI_PS2_C1_PWR_STS		( BRD_CPCI3096_DI + SID_BOARD_1 + 36 )	/* PS2-Chain2 Power Control Status */
#define	DI_PS2_C2_PWR_STS  		( BRD_CPCI3096_DI + SID_BOARD_1 + 37 )	/* PS2-Chain3 Power Control Status */
#define	DI_PS2_C3_PWR_STS  		( BRD_CPCI3096_DI + SID_BOARD_1 + 38 )	/* PS2-Chain1 Power Control Status */
#define	DI_PS3_C1_PWR_STS  		( BRD_CPCI3096_DI + SID_BOARD_1 + 39 )	/* PS3-Chain3 Power Control Status */
#define	DI_PS3_C2_PWR_STS  		( BRD_CPCI3096_DI + SID_BOARD_1 + 40 )	/* PS3-Chain1 Power Control Status */
#define	DI_PS3_C3_PWR_STS  		( BRD_CPCI3096_DI + SID_BOARD_1 + 41 )	/* PS3-Chain2 Power Control Status */
#define	DI_TC_PWR_STS			( BRD_CPCI3096_DI + SID_BOARD_1 + 42 )	/* Telecommand Power Control Status */
//#define	DI_WDT_RESET_STS 		( BRD_CPCI3096_DI + SID_BOARD_1 + 43 )	/* Watchdog Timer Reset - Status */
//#define	DI_SURVEIL_ERROR_STS            ( BRD_CPCI3096_DI + SID_BOARD_1 + 44 )	/* Surveillance Error - Status */
//#define	DI_BUZZER_DISABLE_STS           ( BRD_CPCI3096_DI + SID_BOARD_1 + 45 )	/* Buzzer Dissable - Status */
//#define	DI_BUZZER_ENABLED 		( BRD_CPCI3096_DI + SID_BOARD_1 + 46 )	/* Buzzer Enabled Status */
#define	DI_BYPASS_SWITCH_STS            ( BRD_CPCI3096_DI + SID_BOARD_1 + 46 )	/* Bypass Switch - Status */
#define	DI_TC_S1_BAT1_SEL_STS           ( BRD_CPCI3096_DI + SID_BOARD_2 + 1 )	/* Select Battery 1 for Sensor Channel 1 - Status */
#define	DI_TC_S1_BAT2_SEL_STS           ( BRD_CPCI3096_DI + SID_BOARD_2 + 2 )	/* Select Battery 2 for Sensor Channel 1 - Status */
#define	DI_TC_S4_BAT1_SEL_STS           ( BRD_CPCI3096_DI + SID_BOARD_2 + 3 )	/* Select Battery 1 for Sensor Channel 4 - Status */
#define	DI_TC_S4_BAT2_SEL_STS           ( BRD_CPCI3096_DI + SID_BOARD_2 + 4 )	/* Select Battery 2 for Sensor Channel 4 - Status */
#define	DI_TC_LCE1_BAT1_SEL_STS         ( BRD_CPCI3096_DI + SID_BOARD_2 + 5 )	/* Select Battery 1 for LINSCE-1 - Status  */
#define	DI_TC_LCE1_BAT2_SEL_STS         ( BRD_CPCI3096_DI + SID_BOARD_2 + 6 )	/* Select Battery 2 for LINSCE-1 - Status  */
#define	DI_TC_S3_BAT2_SEL_STS           ( BRD_CPCI3096_DI + SID_BOARD_2 + 7 )	/* Select Battery 2 for Sensor Channel 3 - Status */
#define	DI_TC_S3_BAT3_SEL_STS           ( BRD_CPCI3096_DI + SID_BOARD_2 + 8 )	/* Select Battery 3 for Sensor Channel 3 - Status */
#define	DI_TC_S6_BAT2_SEL_STS           ( BRD_CPCI3096_DI + SID_BOARD_2 + 9 )	/* Select Battery 2 for Sensor Channel 6 - Status */
#define	DI_TC_S6_BAT3_SEL_STS           ( BRD_CPCI3096_DI + SID_BOARD_2 + 10 )	/* Select Battery 3 for Sensor Channel 6 - Status */
#define	DI_TC_LCE2_BAT2_SEL_STS         ( BRD_CPCI3096_DI + SID_BOARD_2 + 11 )	/* Select Battery 2 for LINSCE-2 - Status  */
#define	DI_TC_LCE2_BAT3_SEL_STS         ( BRD_CPCI3096_DI + SID_BOARD_2 + 12 )	/* Select Battery 3 for LINSCE-2 - Status  */
#define	DI_TC_S5_BAT3_SEL_STS           ( BRD_CPCI3096_DI + SID_BOARD_2 + 13 )	/* Select Battery 3 for Sensor Channel 5 - Status */
#define	DI_TC_S5_BAT1_SEL_STS           ( BRD_CPCI3096_DI + SID_BOARD_2 + 14 )	/* Select Battery 1 for Sensor Channel 5 - Status */
#define	DI_TC_S2_BAT3_SEL_STS           ( BRD_CPCI3096_DI + SID_BOARD_2 + 15 )	/* Select Battery 3 for Sensor Channel 2 - Status */
#define	DI_TC_S2_BAT1_SEL_STS           ( BRD_CPCI3096_DI + SID_BOARD_2 + 16 )	/* Select Battery 1 for Sensor Channel 2 - Status */
#define	DI_TC_LCE3_BAT3_SEL_STS         ( BRD_CPCI3096_DI + SID_BOARD_2 + 17 )	/* Select Battery 3 for LINSCE-3 - Status  */
#define	DI_TC_LCE3_BAT1_SEL_STS         ( BRD_CPCI3096_DI + SID_BOARD_2 + 18 )	/* Select Battery 1 for LINSCE-3 - Status  */
#define	DI_TC_LCE1_ON_STS 		( BRD_CPCI3096_DI + SID_BOARD_2 + 19 )	/* Switch ON LINCE-1 - Status  */
#define	DI_TC_LCE1_OFF_STS 		( BRD_CPCI3096_DI + SID_BOARD_2 + 20 )	/* Switch OFF LINCE-1 - Status  */
#define	DI_TC_LCE2_ON_STS 		( BRD_CPCI3096_DI + SID_BOARD_2 + 21 )	/* Switch ON LINCE-2 - Status  */
#define	DI_TC_LCE2_OFF_STS 		( BRD_CPCI3096_DI + SID_BOARD_2 + 22 )	/* Switch OFF LINCE-2 - Status  */
#define	DI_TC_LCE3_ON_STS 		( BRD_CPCI3096_DI + SID_BOARD_2 + 23 )	/* Switch ON LINCE-3 - Status  */
#define	DI_TC_LCE3_OFF_STS 		( BRD_CPCI3096_DI + SID_BOARD_2 + 24 )	/* Switch OFF LINCE-3 - Status  */
#define	DI_TC_LCE1_RESET_STS            ( BRD_CPCI3096_DI + SID_BOARD_2 + 25 )	/* RESET LINCE-1 - Status  */
#define	DI_TC_LCE2_RESET_STS            ( BRD_CPCI3096_DI + SID_BOARD_2 + 26 )	/* RESET LINCE-2 - Status  */
#define	DI_TC_LCE3_RESET_STS            ( BRD_CPCI3096_DI + SID_BOARD_2 + 27 )	/* RESET LINCE-3 - Status  */
#define	DI_TC_DEMAG_ON_STS 		( BRD_CPCI3096_DI + SID_BOARD_2 + 28 )	/* Switch ON Demag - Status  */
#define	DI_TC_DEMAG_OFF_STS             ( BRD_CPCI3096_DI + SID_BOARD_2 + 29 )	/* Switch OFF Demag - Status  */


#define	DI_TC_SPARE1              ( BRD_CPCI3096_DI + SID_BOARD_2 + 30 )	/* Spare - 1   */
#define	DI_TC_SPARE2              ( BRD_CPCI3096_DI + SID_BOARD_2 + 31 )	/* Spare - 2   */
#define	DI_TC_SPARE3              ( BRD_CPCI3096_DI + SID_BOARD_2 + 32 )	/* Spare - 3   */
#define	DI_TC_SPARE4              ( BRD_CPCI3096_DI + SID_BOARD_2 + 33 )	/* Spare - 4   */
#define	DI_TC_SPARE5              ( BRD_CPCI3096_DI + SID_BOARD_2 + 34 )	/* Spare - 5   */
#define	DI_TC_SPARE6              ( BRD_CPCI3096_DI + SID_BOARD_2 + 35 )	/* Spare - 6   */
#define	DI_TC_SPARE7              ( BRD_CPCI3096_DI + SID_BOARD_2 + 36 )	/* Spare - 7   */
#define	DI_TC_SPARE8              ( BRD_CPCI3096_DI + SID_BOARD_2 + 37 )	/* Spare - 8   */
#define	DI_TC_SPARE9              ( BRD_CPCI3096_DI + SID_BOARD_2 + 38 )	/* Spare - 9   */
#define	DI_TC_SPARE10             ( BRD_CPCI3096_DI + SID_BOARD_2 + 39 )	/* Spare - 10  */
#define	DI_TC_SPARE11             ( BRD_CPCI3096_DI + SID_BOARD_2 + 40 )	/* Spare - 11  */
#define	DI_TC_SPARE12             ( BRD_CPCI3096_DI + SID_BOARD_2 + 41 )	/* Spare - 12  */
#define	DI_TC_SPARE13             ( BRD_CPCI3096_DI + SID_BOARD_2 + 42 )	/* Spare - 13  */
#define	DI_TC_SPARE14             ( BRD_CPCI3096_DI + SID_BOARD_2 + 43 )	/* Spare - 14  */
#define	DI_TC_SPARE15             ( BRD_CPCI3096_DI + SID_BOARD_2 + 44 )	/* Spare - 15  */
#define	DI_TC_SPARE16             ( BRD_CPCI3096_DI + SID_BOARD_2 + 45 )	/* Spare - 16  */
#define	DI_TC_SPARE17             ( BRD_CPCI3096_DI + SID_BOARD_2 + 46 )	/* Spare - 17  */
#define	DI_TC_SPARE18             ( BRD_CPCI3096_DI + SID_BOARD_2 + 47 )	/* Spare - 18  */
#define	DI_TC_SPARE19             ( BRD_CPCI3096_DI + SID_BOARD_2 + 48 )	/* Spare - 19  */

/* DP-MM-1105 - 8 channel ADC */		                                        	
#define	AI_PSO_PS1_V     		( BRD_MM1105_ADC + SID_BOARD_1 + 1 )	/* PSU1 Output Volatge */
#define	AI_PSO_PS2_V     		( BRD_MM1105_ADC + SID_BOARD_2 + 1 )	/* PSU2 Output Volatge */
#define	AI_PSO_PS3_V    		( BRD_MM1105_ADC + SID_BOARD_3 + 1 )	/* PSU3 Output Volatge */
#define	AI_PSO_TC_V     		( BRD_MM1105_ADC + SID_BOARD_4 + 3 )	/* PSU4 Output Volatge */
#define	AI_PS_COS_V	      		( BRD_MM1105_ADC + SID_BOARD_4 + 1 )	/* COS PSU Output Volatge */
#define	AI_PKG_PS1_C1_C                 ( BRD_MM1105_ADC + SID_BOARD_1 + 2 )	/* PS1-Chain1 Current at Package End */
#define	AI_PKG_PS1_C1_V                 ( BRD_MM1105_ADC + SID_BOARD_1 + 3 )	/* PS1-Chain1 Voltage at Package End */
#define	AI_PKG_PS1_C2_C                 ( BRD_MM1105_ADC + SID_BOARD_1 + 4 )	/* PS1-Chain2 Current at Package End */
#define	AI_PKG_PS1_C2_V                 ( BRD_MM1105_ADC + SID_BOARD_1 + 5 )	/* PS1-Chain2 Voltage at Package End */
#define	AI_PKG_PS1_SP1_C                ( BRD_MM1105_ADC + SID_BOARD_1 + 6 )	/* Spare-1 Current at Package End */
#define	AI_PKG_PS1_SP1_V                ( BRD_MM1105_ADC + SID_BOARD_1 + 7 )	/* Spare-1 Voltage at Package End */
#define	AI_PKG_PS2_C1_C                 ( BRD_MM1105_ADC + SID_BOARD_2 + 2 )	/* PS2-Chain1 Current at Package End */
#define	AI_PKG_PS2_C1_V                 ( BRD_MM1105_ADC + SID_BOARD_2 + 3 )	/* PS2-Chain1 Voltage at Package End */
#define	AI_PKG_PS2_C2_C    		( BRD_MM1105_ADC + SID_BOARD_2 + 4 )	/* PS2-Chain2 Current at Package End */
#define	AI_PKG_PS2_C2_V    		( BRD_MM1105_ADC + SID_BOARD_2 + 5 )	/* PS2-Chain2 Voltage at Package End */

#define	AI_PKG_PS2_SP2_C    		( BRD_MM1105_ADC + SID_BOARD_2 + 6 )	/* Spare-2 Current at Package End */
#define	AI_PKG_PS2_SP2_V    		( BRD_MM1105_ADC + SID_BOARD_2 + 7 )	/* Spare-2 Voltage at Package End */

#define	AI_PKG_PS3_C1_C    		( BRD_MM1105_ADC + SID_BOARD_3 + 2 )	/* PS3-Chain1 Current at Package End */
#define	AI_PKG_PS3_C1_V    		( BRD_MM1105_ADC + SID_BOARD_3 + 3 )	/* PS3-Chain1 Voltage at Package End */
#define	AI_PKG_PS3_C2_C    		( BRD_MM1105_ADC + SID_BOARD_3 + 4 )	/* PS3-Chain2 Current at Package End */
#define	AI_PKG_PS3_C2_V    		( BRD_MM1105_ADC + SID_BOARD_3 + 5 )	/* PS3-Chain2 Voltage at Package End */

#define	AI_PKG_PS3_DEMAG_C    		( BRD_MM1105_ADC + SID_BOARD_3 + 6 )	/* PS3-DEMAG Current at Package End */
#define	AI_PKG_PS3_DEMAG_V    		( BRD_MM1105_ADC + SID_BOARD_3 + 7 )	/* PS3-DEMAG Voltage at Package End */

#define	AI_COS_V      			( BRD_MM1105_ADC + SID_BOARD_4 + 2 )	/* COS Rleay Output Volatge */
#define	AI_PKG_TC1_V     		( BRD_MM1105_ADC + SID_BOARD_4 + 4 )	/* Telecommand Power Control-1 */
#define	AI_PKG_TC2_V     		( BRD_MM1105_ADC + SID_BOARD_4 + 5 )	/* Telecommand Power Control-2 */
#define	AI_PKG_TC3_V     		( BRD_MM1105_ADC + SID_BOARD_4 + 6 )	/* Telecommand Power Control-3 */
#define	AI_PKG_TC4_V     		( BRD_MM1105_ADC + SID_BOARD_4 + 7 )	/* Telecommand Power Control-4 for self test connection */
#define	AI_PKG_TC5                      ( BRD_MM1105_ADC + SID_BOARD_4 + 8 )	/* Extra banana connection */

#define	TH_BRD1_CH1     		( BRD_MM1123_THERM + SID_BOARD_1 + 1 )	/* Thermistor Brd-1 Ch-1 */
#define	TH_BRD1_CH2     		( BRD_MM1123_THERM + SID_BOARD_1 + 2 )	/* Thermistor Brd-1 Ch-2 */
#define	TH_BRD1_CH3     		( BRD_MM1123_THERM + SID_BOARD_1 + 3 )	/* Thermistor Brd-1 Ch-3 */
#define	TH_BRD2_CH1     		( BRD_MM1123_THERM + SID_BOARD_2 + 1 )	/* Thermistor Brd-2 Ch-1 */
#define	TH_BRD2_CH2     		( BRD_MM1123_THERM + SID_BOARD_2 + 2 )	/* Thermistor Brd-2 Ch-2 */
#define	TH_BRD2_CH3     		( BRD_MM1123_THERM + SID_BOARD_2 + 3 )	/* Thermistor Brd-2 Ch-3 */
#define	TH_BRD3_CH1     		( BRD_MM1123_THERM + SID_BOARD_3 + 1 )	/* Thermistor Brd-3 Ch-1 */
#define	TH_BRD3_CH2     		( BRD_MM1123_THERM + SID_BOARD_3 + 2 )	/* Thermistor Brd-3 Ch-2 */
#define	TH_BRD3_CH3     		( BRD_MM1123_THERM + SID_BOARD_3 + 3 )	/* Thermistor Brd-3 Ch-3 */
#define	TH_BRD4_CH1     		( BRD_MM1123_THERM + SID_BOARD_4 + 1 )	/* Thermistor Brd-4 Ch-1 */
#define	TH_BRD4_CH2     		( BRD_MM1123_THERM + SID_BOARD_4 + 2 )	/* Thermistor Brd-4 Ch-2 */
#define	TH_BRD4_CH3     		( BRD_MM1123_THERM + SID_BOARD_4 + 3 )	/* Thermistor Brd-4 Ch-3 */

#define	CI_1553B_LINK1     		( 1 )	/* 1553B Link 1 Communication Interface */
#define	CI_1553B_LINK2     		( 2 )	/* 1553B Link 2 Communication Interface */
#define	CI_1553B_LINK3     		( 3 )	/* 1553B Link 3 Communication Interface */
#define	CI_1553B_LINK4     		( 4 )	/* 1553B Link 4 Communication Interface */

#define	CI_RS232_PSU     		( 1 )	/* RS422 Link for Power Supply Configuration */
#define	CI_RS232_AMS     		( 2 )	/* RS422 Link for AMS control*/

#define	PSU_ID_PS1   			( 1 )	/* Power Supply ID for PS1 */
#define	PSU_ID_PS2   			( 2 )	/* Power Supply ID for PS2 */
#define	PSU_ID_PS3   			( 3 )	/* Power Supply ID for PS3 */
#define	PSU_ID_PS4   			( 4 )	/* Power Supply ID for PS4 */

/* ############################################################################################################## */

#endif //_DP_LINS_CM_SIGNALS_H_
