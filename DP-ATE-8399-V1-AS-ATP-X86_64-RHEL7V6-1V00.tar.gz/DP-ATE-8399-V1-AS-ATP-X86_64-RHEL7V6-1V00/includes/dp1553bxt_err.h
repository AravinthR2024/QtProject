/**
 *	\file dp1553bxt_err.h
 *	\brief This file contains the  error code definition
 *
 *	This file contains the  error code definition
 *
 *	\author Tamizharasan K 
 *	\date 04:14PM on January 11, 2020
 *
 *	\version
 *	- Initial version
 *
 *	Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
 *	All Rights Reserved.\n
 *	Address:	Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
 *				Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
 *				Chennai-603103 | India\n
 *				Website : http://www.datapatternsindia.com/\n
 *				Phone: 91-44-4741-4000\n
 *				FAX: 91-44-4741-4444 \n
 *
	////////////////////////////REVISION LOG ENTRY//////////////////////////////////
	Date		Version Number	     Reason for Revision	Revised by 
	----		--------------		 -------------------	----------
									 

	 
*/
#ifndef _DP1553BXT_ERR_H
#define _DP1553BXT_ERR_H

#define DP1553BXT_SUCCESS		0


/**
* This list the enumeration of driver error values 
*/ 
enum{
	DP_DRV_ERR_MEM_CREATE = -1999,				/*!<-1999	Error in allocating memory for ringbuffer*/
	DP_DRV_ERR_MEM_NOT_CREATED,					/*!<-1998	Ringbuffer not created*/
	DP_DRV_ERR_DATA_NULL,						/*!<-1997	Invalid Ringbuffer data pointer*/
	DP_DRV_ERR_BUFFER_FULL,						/*!<-1996	Ringbuffer is full*/
	DP_FREEMEM_ERR_MEM_ALLOCATION,				/*!<-1995	Failed to allocate free memory management*/
	DP_FREEMEM_ERR_INVALID_HANDLE,				/*!<-1994	Invalid handle passed for free memory management*/
	DP_FREEMEM_ERR_NO_MEMORY,					/*!<-1993	No memory available for free memory management*/
	DP_FREEMEM_ERR_INVALID_PARAM,				/*!<-1992	Invalid parameter passed for free memory management*/
	DP_DRV_ERR_INVALID_HANDLE = -999,		/*!<-999	Invalid Handle*/
	DP_DRV_ERR_INVALID_POINTER,			/*!<-998	Invalid Pointer*/
	DP_DRV_ERR_INVALID_PARAM,			/*!<-997	Invalid Param*/
	DP_DRV_ERR_MEM_ALLOCATION,			/*!<-996	Mem Allocation*/
	DP_DRV_ERR_NO_ZEROTH_DEVICE,			/*!<-995	No Zeroth Device*/
	DP_DRV_ERR_DEVICE_NOT_OPEN,			/*!<-994	Device Is Not Open*/
	DP_DRV_ERR_INVALID_SHARE_VALUE,			/*!<-993	Invalid Share Value*/
	DP_DRV_ERR_INVALID_DEVICE_REQUEST,			/*!<-992	Invalid Device Request*/
	DP_DRV_ERR_INVALID_MAXDEVICES,			/*!<-991	Invalid Maxdevices*/
	DP1553BXT_ERR_IOCTL,			/*!<-990	Ioctl*/
	DP1553BXT_ERR_INVALID_PARAM,			/*!<-989	Invalid Param*/
	DP1553BXT_ERR_DEVICE_BUSY,			/*!<-988	Device Busy*/
	DP1553BXT_ERR_NO_DEVICE_FOUND,			/*!<-987	No Device Found*/
	DP1553BXT_ERR_INVALID_MAXDEVICES,			/*!<-986	Invalid Maxdevices*/
	DP1553BXT_ERR_INVALID_HANDLE,			/*!<-985	Invalid Handle*/
	DP1553BXT_ERR_INVALID_ERRCODE,			/*!<-984	Invalid Errcode*/
	DP1553BXT_ERR_INVALID_BUFSIZE,			/*!<-983	Invalid Bufsize*/
	DP1553BXT_ERR_INVALID_OFFSET,			/*!<-982	Invalid Offset*/
	DP1553BXT_ERR_INVALID_WRITEDATA,			/*!<-981	Invalid Writedata*/
	DP1553BXT_ERR_INVALID_COUNT,			/*!<-980	Invalid Count*/
	DP1553BXT_ERR_INVALID_ENDIS,			/*!<-979	Invalid Endis*/
	DP1553BXT_ERR_INVALID_OPRNMODE,			/*!<-978	Invalid Oprnmode*/
	DP1553BXT_ERR_INVALID_OPTIONS,			/*!<-977	Invalid Options*/
	DP1553BXT_ERR_INVALID_IOCHANNEL,			/*!<-976	Invalid Iochannel*/
	DP1553BXT_ERR_INVALID_IODIRECTION,			/*!<-975	Invalid Iodirection*/
	DP1553BXT_ERR_INVALID_DOPCHANNEL,			/*!<-974	Invalid Dopchannel*/
	DP1553BXT_ERR_INVALID_OUTPUTSTATE,			/*!<-973	Invalid Outputstate*/
	DP1553BXT_ERR_INVALID_DIPCHANNEL,			/*!<-972	Invalid Dipchannel*/
	DP1553BXT_ERR_INVALID_BISTSEL,			/*!<-971	Invalid Bistsel*/
	DP1553BXT_ERR_INVALID_ASBISTSTATUS,			/*!<-970	Invalid Asbiststatus*/
	DP1553BXT_ERR_INVALID_TTROLLOVERSEL,			/*!<-969	Invalid Ttrolloversel*/
	DP1553BXT_ERR_INVALID_TIMETAGRES,			/*!<-968	Invalid Timetagres*/
	DP1553BXT_ERR_INVALID_TIMETAGVAL,			/*!<-967	Invalid Timetagval*/
	DP1553BXT_ERR_INVALID_BCINITINFO,			/*!<-966	Invalid Bcinitinfo*/
	DP1553BXT_ERR_INVALID_BCOPTIONS,			/*!<-965	Invalid Bcoptions*/
	DP1553BXT_ERR_INVALID_ENABLE,			/*!<-964	Invalid Enable*/
	DP1553BXT_ERR_INVALID_TIMEOUT,			/*!<-963	Invalid Timeout*/
	DP1553BXT_ERR_INVALID_RESPTIMEOUT,			/*!<-962	Invalid Resptimeout*/
	DP1553BXT_ERR_INVALID_NUMOFRETRIES,			/*!<-961	Invalid Numofretries*/
	DP1553BXT_ERR_INVALID_CHANNELSELECT,			/*!<-960	Invalid Channelselect*/
	DP1553BXT_ERR_INVALID_RETRYONERR,			/*!<-959	Invalid Retryonerr*/
	DP1553BXT_ERR_INVALID_ENABLESTS,			/*!<-958	Invalid Enablests*/
	DP1553BXT_ERR_INVALID_MEMWORDID,			/*!<-957	Invalid Memwordid*/
	DP1553BXT_ERR_INVALID_VAL,			/*!<-956	Invalid Val*/
	DP1553BXT_ERR_INVALID_DATABLKID,			/*!<-955	Invalid Datablkid*/
	DP1553BXT_ERR_INVALID_DATASIZE,			/*!<-954	Invalid Datasize*/
	DP1553BXT_ERR_INVALID_MSGBLKID,			/*!<-953	Invalid Msgblkid*/
	DP1553BXT_ERR_INVALID_MSGOPTION,			/*!<-952	Invalid Msgoption*/
	DP1553BXT_ERR_INVALID_FRAMEID,			/*!<-951	Invalid Frameid*/
	DP1553BXT_ERR_INVALID_NOOFMSGS,			/*!<-950	Invalid Noofmsgs*/
	DP1553BXT_ERR_INVALID_FRAMETIME,			/*!<-949	Invalid Frametime*/
	DP1553BXT_ERR_INVALID_NOOFOPCODES,			/*!<-948	Invalid Noofopcodes*/
	DP1553BXT_ERR_INVALID_NOOFMINORFRM,			/*!<-947	Invalid Noofminorfrm*/
	DP1553BXT_ERR_INVALID_FRAMECOUNT,			/*!<-946	Invalid Framecount*/
	DP1553BXT_ERR_INVALID_FRAMEREPEATAT,			/*!<-945	Invalid Framerepeatat*/
	DP1553BXT_ERR_INVALID_INTEVENTMASKS,			/*!<-944	Invalid Inteventmasks*/
	DP1553BXT_ERR_INVALID_EVENTMASKS,			/*!<-943	Invalid Eventmasks*/
	DP1553BXT_ERR_INVALID_MAJORFRMID,			/*!<-942	Invalid Majorfrmid*/
	DP1553BXT_ERR_INVALID_UNBLOCKWAIT,			/*!<-941	Invalid Unblockwait*/
	DP1553BXT_ERR_INVALID_MSGSTOREAD,			/*!<-940	Invalid Msgstoread*/
	DP1553BXT_ERR_INVALID_OPTION,			/*!<-939	Invalid Option*/
	DP1553BXT_ERR_INVALID_QUEUE,			/*!<-938	Invalid Queue*/
	DP1553BXT_ERR_INVALID_MSGCOUNT,			/*!<-937	Invalid Msgcount*/
	DP1553BXT_ERR_INVALID_SETGPF,			/*!<-936	Invalid Setgpf*/
	DP1553BXT_ERR_INVALID_CLEARGPF,			/*!<-935	Invalid Cleargpf*/
	DP1553BXT_ERR_INVALID_RTINITINFO,			/*!<-934	Invalid Rtinitinfo*/
	DP1553BXT_ERR_INVALID_CONFIGOPTION,			/*!<-933	Invalid Configoption*/
	DP1553BXT_ERR_INVALID_RTADDRESS,			/*!<-932	Invalid Rtaddress*/
	DP1553BXT_ERR_INVALID_RTADDR,			/*!<-931	Invalid Rtaddr*/
	DP1553BXT_ERR_INVALID_INTEVTMASK,			/*!<-930	Invalid Intevtmask*/
	DP1553BXT_ERR_INVALID_MSGTYPE,			/*!<-929	Invalid Msgtype*/
	DP1553BXT_ERR_INVALID_MCINTEVTMASK,			/*!<-928	Invalid Mcintevtmask*/
	DP1553BXT_ERR_INVALID_SUBADDR,			/*!<-927	Invalid Subaddr*/
	DP1553BXT_ERR_INVALID_WORDCOUNTMASK,			/*!<-926	Invalid Wordcountmask*/
	DP1553BXT_ERR_INVALID_SUBADDRMASK,			/*!<-925	Invalid Subaddrmask*/
	DP1553BXT_ERR_INVALID_DATABUFTYPE,			/*!<-924	Invalid Databuftype*/
	DP1553BXT_ERR_INVALID_MODECODE,			/*!<-923	Invalid Modecode*/
	DP1553BXT_ERR_INVALID_MCDATA,			/*!<-922	Invalid Mcdata*/
	DP1553BXT_ERR_INVALID_STATUSBITS,			/*!<-921	Invalid Statusbits*/
	DP1553BXT_ERR_INVALID_NORESPTIMEOUT,			/*!<-920	Invalid Noresptimeout*/
	DP1553BXT_ERR_INVALID_LASTCMDWRDRXD,			/*!<-919	Invalid Lastcmdwrdrxd*/
	DP1553BXT_ERR_INVALID_LASTSTSWRDTXD,			/*!<-918	Invalid Laststswrdtxd*/
	DP1553BXT_ERR_INVALID_RTADDRSEL,			/*!<-917	Invalid Rtaddrsel*/
	DP1553BXT_ERR_INVALID_RTSLOT,			/*!<-916	Invalid Rtslot*/
	DP1553BXT_ERR_INVALID_MTINIT,			/*!<-915	Invalid Mtinit*/
	DP1553BXT_ERR_INVALID_STACKSIZE,			/*!<-914	Invalid Stacksize*/
	DP1553BXT_ERR_INVALID_CONFIG,			/*!<-913	Invalid Config*/
	DP1553BXT_ERR_INVALID_RTS,			/*!<-912	Invalid Rts*/
	DP1553BXT_ERR_INVALID_SAS,			/*!<-911	Invalid Sas*/
	DP1553BXT_ERR_INVALID_TXRX,			/*!<-910	Invalid Txrx*/
	DP1553BXT_ERR_INVALID_IRIGENABLE,			/*!<-909	Invalid Irigenable*/
	DP1553BXT_ERR_INVALID_CHANLTOMONITOR,			/*!<-908	Invalid Chanltomonitor*/
	DP1553BXT_ERR_INVALID_MSGCONT,			/*!<-907	Invalid Msgcont*/
	DP1553BXT_ERR_INVALID_WRDCONT,			/*!<-906	Invalid Wrdcont*/
	DP1553BXT_ERR_INVALID_TIMERVAL,			/*!<-905	Invalid Timerval*/
	DP1553BXT_ERR_INVALID_PKTBUFSIZE,			/*!<-904	Invalid Pktbufsize*/
	DP1553BXT_ERR_INVALID_NOOFMSG,			/*!<-903	Invalid Noofmsg*/
	DP1553BXT_ERR_INVALID_TIMESRC,			/*!<-902	Invalid Timesrc*/
	DP1553BXT_ERR_INVALID_IRIGTIME,			/*!<-901	Invalid Irigtime*/
	DP1553BXT_ERR_INVALID_DIO_DIRECTION,	/*!<-900	Invalid DIO direction*/
	DP1553BXT_ERR_DEV_OPRN_INITIALIZED,		/*!<-899	Invalid operational mode*/
	DP1553BXT_ERR_MT_NOT_INITIALIZED,		/*!<-898	MT not initialised*/
	DP1553BXT_ERR_HOSTBUF_NOT_INSTALL,		/*!<-897	Host buffer not initialised*/
	DP1553BXT_ERR_INTR_NOT_ENABLED,			/*!<-896	Interrupt not enabled*/
	DP1553BXT_ERR_INVALID_MT_NO_OF_MSG,		/*!<-895	Invalid MT number of message*/
	DP1553BXT_ERR_INVALID_MT_STACK_ADDR,	/*!<-894	Invalid MT stack address*/
	DP1553BXT_ERR_INPUT_BUF_OVERFLOW,		/*!<-893	Input buffer overflow*/
	DP1553BXT_ERR_INVALID_MT_STACK_SIZE,	/*!<-892	Invalid MT stack size*/
	DP1553BXT_ERR_INVALID_MT_LENGTH_WRD,	/*!<-891	Invalid message length word*/
	DP1553BXT_ERR_RT_NOT_INITIALIZED,		/*!<-890	RT not initialised*/
	DP1553BXT_ERR_INVALID_NORESP_TIMEOUT,	/*!<-889	Invalid no response time out*/
	DP1553BXT_ERR_INVALID_SA_BUF_SIZE,		/*!<-888	Invalid sub address buffer size*/
	DP1553BXT_ERR_INVALID_RAM_SIZE,			/*!<-887	Invalid ram size*/
	DP1553BXT_ERR_DEV_MEM_ALLOC,			/*!<-886	Error in device memory allocation*/
	DP1553BXT_ERR_INVALID_RT_ADDR_SRC,		/*!<-885	Invalid RT address source*/
	DP1553BXT_ERR_BC_NOT_INITIALIZED,		/*!<-884	BC mode not initialised*/
	DP1553BXT_ERR_MSG_NOT_AVAIL,			/*!<-883	Message is not available*/
	DP1553BXT_ERR_BC_RUNNING,				/*!<-882	BC is running*/
	DP1553BXT_ERR_PQUEUE_NOT_INIT,			/*!<-881	Priority queue not initialised*/
	DP1553BXT_ERR_INVALID_PQUEUE,			/*!<-880	Invalid priority queue*/
	DP1553BXT_ERR_FRAME_NOT_FOUND,			/*!<-879	Frame is not found*/
	DP1553BXT_ERR_MSGBLK_EXIST,				/*!<-878	Message block is already exist*/
	DP1553BXT_ERR_DATABLK_EXIST,			/*!<-877	Data block is already exist*/
	DP1553BXT_ERR_DATABLK_NOT_FOUND,		/*!<-876	Data block is not found*/
	DP1553BXT_ERR_INVALID_CMD_WORDS,		/*!<-875	Invalid command words*/
	DP1553BXT_ERR_INVALID_DOUBLE_BUF,		/*!<-874	Double buffering can enable only for BC to RT messages*/
	DP1553BXT_ERR_NO_MSGBLK_AVAILABLE,		/*!<-873	No message block memory to allocate*/
	DP1553BXT_ERR_FRAME_EXIST,				/*!<-872	Frame is already exist*/
	DP1553BXT_ERR_MSGBLK_NOT_FOUND,			/*!<-871	Message block is not found*/
	DP1553BXT_ERR_NO_OPCODE_MEMORY,			/*!<-870	No memory is available for opcodes*/
	DP1553BXT_ERR_INVALID_OPCODE_INDEX,		/*!<-869	Invalid opcode index in the frame*/
	DP1553BXT_ERR_INVALID_OPCODE_TYPE,		/*!<-868	Invalid opcode type in the frame*/
	DP1553BXT_ERR_PQUEUE_NO_SPACE			/*!<-867	No space in priority queue to store message*/
};
#endif