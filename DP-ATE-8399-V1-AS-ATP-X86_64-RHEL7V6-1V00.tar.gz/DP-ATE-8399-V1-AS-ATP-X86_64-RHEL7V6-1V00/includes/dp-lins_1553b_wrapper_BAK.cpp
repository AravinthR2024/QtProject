/**
* \file dp1553b_wrapper.cpp
* \brief This file contains the 1553b wrapper function definition
*
* author Tamizharasan K
* \date  28 January, 2020
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
* Phone: 91-44-4741-4000\n
* FAX: 91-44-4741-4444 \n
*
*/

#include <stdlib.h>
#include <string.h>
#include "dp-lins-atp_mainwindow.h"

#define DP_SIMULATE

/**
*\brief
*
*
*\retval	::DP1553B_SUCCESS is returned upon success
*
*
*/

extern int g_iCnt;

S32BIT cDP1553BWrapper::DP1553B_Open(U16BIT u16NoOfDevice, PSDP1553_DEVICE_LOC in_pSDeviceLoc[], PSDP1553_DEVICE_LOC out_pSDeviceLoc[])
{
    U8BIT u8DeviceNo = DP1553B_INIT_ZERO;
    S32BIT s32RetVal = DP1553B_INIT_ZERO;
    PSDP1553BXT_DEVICE_LOCATION pSAllDevLocDetails;
#ifdef DP_SIMULATE
    /* Get Total number of boards */
    s32RetVal = DP1553BXT_GetTotalDeviceFound(&m_u16NoOfDeviceFound);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }
    /* Get All device Location Details */
    pSAllDevLocDetails = (PSDP1553BXT_DEVICE_LOCATION)malloc(sizeof(SDP1553BXT_DEVICE_LOCATION) * m_u16NoOfDeviceFound);
    if(pSAllDevLocDetails == DP1553B_ZERO)
    {
        return -1;
    }

    s32RetVal = DP1553BXT_GetAllDeviceLocations(pSAllDevLocDetails, m_u16NoOfDeviceFound);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }

    if(m_u16NoOfDeviceFound < u16NoOfDevice)
    {
        u16NoOfDevice = m_u16NoOfDeviceFound;
    }

    for(u8DeviceNo = 0; u8DeviceNo < u16NoOfDevice; u8DeviceNo++)
    {
        if(in_pSDeviceLoc != NULL)
        {
            if((pSAllDevLocDetails[u8DeviceNo].ucSlotNo == in_pSDeviceLoc[u8DeviceNo]->u8SlotNo)\
                    && (pSAllDevLocDetails[u8DeviceNo].ucBusNo ==  in_pSDeviceLoc[u8DeviceNo]->u8BusNo)\
                    && (pSAllDevLocDetails[u8DeviceNo].ucFunctionNo == in_pSDeviceLoc[u8DeviceNo]->u8FunctionNo)\
                    && (pSAllDevLocDetails[u8DeviceNo].ucChannelNo == in_pSDeviceLoc[u8DeviceNo]->u8ChannelNo))
            {

                s32RetVal = DP1553BXT_Open(&pSAllDevLocDetails[u8DeviceNo], &m_vpHandle[u8DeviceNo]);
                if(s32RetVal != DP1553B_SUCCESS)
                {
                    return s32RetVal;
                }
                else
                {
                    out_pSDeviceLoc[u8DeviceNo]->u8ChnlSts = DP1553B_ONE;
                    out_pSDeviceLoc[u8DeviceNo]->u8SlotNo = in_pSDeviceLoc[u8DeviceNo]->u8SlotNo;
                    out_pSDeviceLoc[u8DeviceNo]->u8BusNo = in_pSDeviceLoc[u8DeviceNo]->u8BusNo;
                    out_pSDeviceLoc[u8DeviceNo]->u8FunctionNo = in_pSDeviceLoc[u8DeviceNo]->u8FunctionNo;
                    out_pSDeviceLoc[u8DeviceNo]->u8ChannelNo = in_pSDeviceLoc[u8DeviceNo]->u8ChannelNo;
                    out_pSDeviceLoc[u8DeviceNo]->u8BoardID = in_pSDeviceLoc[u8DeviceNo]->u8BoardID;
                }
            }
            else
            {
                out_pSDeviceLoc[u8DeviceNo]->u8ChnlSts = DP1553B_ZERO;
                out_pSDeviceLoc[u8DeviceNo]->u8BoardID = in_pSDeviceLoc[u8DeviceNo]->u8BoardID;
            }
        }
        else
        {

            s32RetVal = DP1553BXT_Open(&pSAllDevLocDetails[u8DeviceNo], &m_vpHandle[u8DeviceNo]);
            if(s32RetVal != DP1553B_SUCCESS)
            {
                return s32RetVal;
            }
            else
            {
                out_pSDeviceLoc[u8DeviceNo]->u8ChnlSts = DP1553B_ONE;
                out_pSDeviceLoc[u8DeviceNo]->u8SlotNo = pSAllDevLocDetails[u8DeviceNo].ucSlotNo;
                out_pSDeviceLoc[u8DeviceNo]->u8BusNo = pSAllDevLocDetails[u8DeviceNo].ucBusNo;
                out_pSDeviceLoc[u8DeviceNo]->u8FunctionNo = pSAllDevLocDetails[u8DeviceNo].ucFunctionNo;
                out_pSDeviceLoc[u8DeviceNo]->u8ChannelNo = pSAllDevLocDetails[u8DeviceNo].ucChannelNo;
                out_pSDeviceLoc[u8DeviceNo]->u8BoardID = u8DeviceNo + 1;
            }
        }

    }
#endif
    return s32RetVal;
}


/**
*\brief
*
*
*\retval	::DP1553B_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_Close()
{
    U8BIT u8DeviceNo = DP1553B_INIT_ZERO;
    S32BIT s32RetVal = DP1553B_INIT_ZERO;
#ifdef DP_SIMULATE
    for(u8DeviceNo = 0; u8DeviceNo < m_u16NoOfDeviceFound; u8DeviceNo++)
    {
        s32RetVal = DP1553BXT_Close(m_vpHandle[u8DeviceNo]);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }
    }
#endif
    return s32RetVal;
}

/**
*\brief
*
* \Param[in]  in_u8ResetOption  This parameter provides option to reset device register or device memory or both.
                                 \n(Bit 0 - DP1553BXT_RESET_REGISTER - Only Device Registers will be reseted
                                 \n Bit 1 - DP1553BXT_RESET_MEMORY - Only Device Memory will be reseted
                                 \n Bit 0|Bit 1 - DP1553BXT_RESET_REGISTER | DP1553BXT_RESET_MEMORY  - Both Device registers and Memory will be reseted).
*
*\retval	::DP1553B_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_Reset(U8BIT in_u8ResetOption)
{

    U8BIT u8DeviceNo = DP1553B_INIT_ZERO;
    S32BIT s32RetVal = DP1553B_INIT_ZERO;
#ifdef DP_SIMULATE
    for(u8DeviceNo = 0; u8DeviceNo < m_u16NoOfDeviceFound; u8DeviceNo++)
    {
        s32RetVal = DP1553BXT_Reset(m_vpHandle[u8DeviceNo], in_u8ResetOption);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }
    }
#endif
    return s32RetVal;
}

/**
*\brief
*
*
*\retval	::DP1553B_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_Init(U16BIT in_u16DeviceNo, SDP1553_BC_INIT in_BCInitInfo)
{
    S32BIT s32RetVal = DP1553B_INIT_ZERO;
    U32BIT u32Options = DP1553B_INIT_ZERO;
    U32BIT u32OprnMode = DP1553BXT_OPRN_MODE_BC;
    SDP1553BXT_BC_INIT S_BcInit;

    memset(&S_BcInit, DP1553B_INIT_ZERO, sizeof(SDP1553BXT_BC_INIT));
#ifdef DP_SIMULATE
    // BC_Init function call
    S_BcInit.u16GPQSize = 0; // 0 - 256 dwords
    S_BcInit.u16HPQSize = in_BCInitInfo.u16HPQSize;
    S_BcInit.u16LPQSize = in_BCInitInfo.u16LPQSize;
    S_BcInit.u16MaxMsgBlocks = in_BCInitInfo.u16MaxMsgBlocks;
    S_BcInit.u16MaxDataBlocks = in_BCInitInfo.u16MaxDataBlocks;
    S_BcInit.u16MaxMemoryDWords = 256;
    S_BcInit.u16HostMsgBufSize = in_BCInitInfo.u16HostMsgBufSize;

    /*function Objective starts*/
    if(in_BCInitInfo.u8BCCombinedRT == DP1553B_ONE)
    {
        u32OprnMode = u32OprnMode | DP1553BXT_OPRN_MODE_RT;
    }
    if(in_BCInitInfo.u8BCCombinedMT == DP1553B_ONE)
    {
        u32OprnMode = u32OprnMode | DP1553BXT_OPRN_MODE_MT;
    }

    if(u32OprnMode == DP1553BXT_OPRN_MODE_BC)
    {
        u32Options = DP1553B_ZERO;
    }
    else
    {
        u32Options = DP1553BXT_MODEOPT_SHARED | DP1553BXT_MODEOPT_DONOT_OVERWRITE;
    }

    s32RetVal = DP1553BXT_SetDeviceShare(m_vpHandle[in_u16DeviceNo], 1);
    if(s32RetVal )
    {
        return s32RetVal;
    }


    s32RetVal = DP1553BXT_InitializeMode(m_vpHandle[in_u16DeviceNo], u32OprnMode, u32Options);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }

    s32RetVal = DP1553BXT_BC_Initialize(m_vpHandle[in_u16DeviceNo], S_BcInit);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }
#endif
    /*function Objective ends*/
    return 0;
}


/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_Config(U16BIT in_u16DeviceNo, SDP1553_BC_CONFIG in_BCConfig)
{
    S32BIT s32RetVal = DP1553B_INIT_ZERO;
#ifdef DP_SIMULATE
    /*function Objective starts*/
    s32RetVal = DP1553BXT_BC_Configure(m_vpHandle[in_u16DeviceNo], in_BCConfig.u16ConfigOptions);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }

    s32RetVal = DP1553BXT_BC_SetNoResponseTimeOut(m_vpHandle[in_u16DeviceNo], in_BCConfig.u16NoRespTimeout);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }
    
    s32RetVal = DP1553BXT_SetTimeTagResolution(m_vpHandle[in_u16DeviceNo], DP1553BXT_TIMETAG_RES_100NS);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }
    
    s32RetVal = DP1553BXT_SetTimeTagValue(m_vpHandle[in_u16DeviceNo], DP1553B_TIMETAG_INIT_VALUE);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }

    s32RetVal = DP1553BXT_SetTimeTagRollover(m_vpHandle[in_u16DeviceNo], DP1553B_ONE); //Time tag rollover interrupt at 17 bits
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }
    
    s32RetVal = DP1553BXT_BC_SetMessageRetry(m_vpHandle[in_u16DeviceNo], in_BCConfig.u16NumOfRetries, in_BCConfig.u16ChannelSelect, in_BCConfig.u16RetryOnErr);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }
    
    s32RetVal = DP1553BXT_BC_SetWatchdogTimer(m_vpHandle[in_u16DeviceNo], DP1553B_ZERO, DP1553B_ZERO);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }
    /*function Objective ends*/
#endif
    return s32RetVal;
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_EnableExtTriggerStart(U16BIT in_u16DeviceNo, U16BIT in_u16ExtTrigEnDis)
{
#ifdef DP_SIMULATE
    return DP1553BXT_BC_EnableExtTriggerStart(m_vpHandle[in_u16DeviceNo], in_u16ExtTrigEnDis);
#endif
    return 0;
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_GenerateSWExtTrigger(U16BIT in_u16DeviceNo)
{
#ifdef DP_SIMULATE
    return DP1553BXT_GenerateSWExtTrigger(m_vpHandle[in_u16DeviceNo]);
#else
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_CreateDataBlock(U16BIT in_u16DeviceNo, U16BIT in_u16DataBlkID, U16BIT *in_pu16DataBuffer, U16BIT in_u16DataSize)
{
#ifdef EN_DRV_1553B
#ifdef DP_SIMULATE
    return DP1553BXT_BC_CreateDataBlock(m_vpHandle[in_u16DeviceNo], in_u16DataBlkID, in_pu16DataBuffer, in_u16DataSize);
#else
    if(usTestSel == DP_1553B_Combined_Mode_Test)
    {
        memcpy(usCombinedData,in_pu16DataBuffer,sizeof(usCombinedData));
        memcpy(usCombinedDataRT,in_pu16DataBuffer,sizeof(usCombinedDataRT));

    }
    else if(usTestSel == DP_1553B_Terminal_Test)
    {
        memcpy(usData,in_pu16DataBuffer,sizeof(usData));
    }

    return 0;
#endif
#endif
}

/**
*\brief
*
*\param[in]	in_u16MsgBlkID		It specifies the message block id for the message
*\param[in]	m_vpHandle[in_u16DeviceNo]		It specifies the device handle which is obtained from device open function
*\param[in]	in_u16DoubBufEnDiS	It specifies the parameter to enable / disable the double buffer
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_CreateMessage(U16BIT in_u16DeviceNo, U16BIT in_u16MsgBlkID, PDP1553B_BC_MSG_DEF in_pBCMsgDef, PDP1553B_BC_MSG_DEF in_pBCAlternateMsgDef, U16BIT in_u16DoubBufEnDiS)
{
    S32BIT s32RetVal = DP1553B_INIT_ZERO;
    U16BIT u8MsgType = DP1553B_INIT_ZERO;
    U16BIT u8AltMsgType = DP1553B_INIT_ZERO;
    U16BIT u16TxRxSelRxCmd =  DP1553B_INIT_ZERO;
    U16BIT u16TxRxSelTxCmd =  DP1553B_INIT_ZERO;
    U16BIT u16AltTxRxSelRxCmd =  DP1553B_INIT_ZERO;
    U16BIT u16AltTxRxSelTxCmd =  DP1553B_INIT_ZERO;
    DP1553BXT_BC_MSG_DEF sBCMsgDefine;
    PDP1553BXT_BC_MSG_DEF psBCAlternateMsgDefine;

    /*function Objective starts*/
    memset(&sBCMsgDefine, DP1553B_ZERO, sizeof(DP1553BXT_BC_MSG_DEF));
    memset(&psBCAlternateMsgDefine, DP1553B_ZERO, sizeof(DP1553BXT_BC_MSG_DEF));

    /* Message Definition */

    /* Current Message Definition */
    if(in_pBCMsgDef != NULL)
    {
        sBCMsgDefine.u16DataBlkID = in_pBCMsgDef->u16DataBlkID;

        u8MsgType = in_pBCMsgDef->u8MsgType;
        DP1553B_MSG_TYPE_SEL(u8MsgType, u16TxRxSelRxCmd, u16TxRxSelTxCmd); //Message Type Selection (Transmit or Receive)

        sBCMsgDefine.u16CtrlWord = DP1553BXT_BC_CTRL_EOM_IRQ | DP1553BXT_BC_CTRL_BCST_MSK | DP1553BXT_BC_CTRL_RESRV_MSK | DP1553BXT_BC_CTRL_TERMFLG_MSK | \
                DP1553BXT_BC_CTRL_SSFLG_MSK | DP1553BXT_BC_CTRL_SSBUSY_MSK |DP1553BXT_BC_CTRL_SRVREQ_MSK |DP1553BXT_BC_CTRL_ME_MSK;

        if(in_pBCMsgDef->u8BusSelection)
        {
            sBCMsgDefine.u16CtrlWord |= DP1553BXT_BC_CTRL_CHANNEL_A;
        }

        if(in_pBCMsgDef->u8MsgRetrySel)
        {
            sBCMsgDefine.u16CtrlWord |= DP1553BXT_BC_CTRL_RETRY_ENA;
        }

        /* Command Word Definition */
        DP1553BXT_SET_CMD_WORD(sBCMsgDefine.u16CmdWord1, in_pBCMsgDef->u8RxRTAddress, in_pBCMsgDef->u8RxRTSubAddress, in_pBCMsgDef->u8RxWordCount, u16TxRxSelRxCmd);
        DP1553BXT_SET_CMD_WORD(sBCMsgDefine.u16CmdWord2, in_pBCMsgDef->u8TxRTAddress, in_pBCMsgDef->u8TxRTSubAddress, in_pBCMsgDef->u8TxWordCount, u16TxRxSelTxCmd);

        sBCMsgDefine.u16TimeToNextMsg = in_pBCMsgDef->u16TimeToNextMsg;
    }

    /* Alternate Message Definition */
    if(in_pBCAlternateMsgDef != NULL)
    {
        psBCAlternateMsgDefine = (DP1553BXT_BC_MSG_DEF *)malloc(sizeof(DP1553BXT_BC_MSG_DEF));
        memset(psBCAlternateMsgDefine, DP1553B_ZERO, sizeof(DP1553BXT_BC_MSG_DEF));


        psBCAlternateMsgDefine->u16DataBlkID = in_pBCAlternateMsgDef->u16DataBlkID;

        u8AltMsgType = in_pBCAlternateMsgDef->u8MsgType;
        DP1553B_MSG_TYPE_SEL(u8AltMsgType, u16AltTxRxSelRxCmd, u16AltTxRxSelTxCmd); //Message Type Selection (Transmit or Receive)

        psBCAlternateMsgDefine->u16CtrlWord = DP1553BXT_BC_CTRL_EOM_IRQ | DP1553BXT_BC_CTRL_BCST_MSK | DP1553BXT_BC_CTRL_RESRV_MSK | DP1553BXT_BC_CTRL_TERMFLG_MSK | \
                DP1553BXT_BC_CTRL_SSFLG_MSK | DP1553BXT_BC_CTRL_SSBUSY_MSK |DP1553BXT_BC_CTRL_SRVREQ_MSK |DP1553BXT_BC_CTRL_ME_MSK;

        if(in_pBCAlternateMsgDef->u8BusSelection)
        {
            psBCAlternateMsgDefine->u16CtrlWord |= DP1553BXT_BC_CTRL_CHANNEL_A;
        }

        if(in_pBCAlternateMsgDef->u8MsgRetrySel)
        {
            psBCAlternateMsgDefine->u16CtrlWord |= DP1553BXT_BC_CTRL_RETRY_ENA;
        }

        /* Command Word Definition */
        DP1553BXT_SET_CMD_WORD(psBCAlternateMsgDefine->u16CmdWord1, in_pBCAlternateMsgDef->u8RxRTAddress, in_pBCAlternateMsgDef->u8RxRTSubAddress, in_pBCAlternateMsgDef->u8RxWordCount, u16AltTxRxSelRxCmd);
        DP1553BXT_SET_CMD_WORD(psBCAlternateMsgDefine->u16CmdWord2, in_pBCAlternateMsgDef->u8TxRTAddress, in_pBCAlternateMsgDef->u8TxRTSubAddress, in_pBCAlternateMsgDef->u8TxWordCount, u16AltTxRxSelTxCmd);

        psBCAlternateMsgDefine->u16TimeToNextMsg = in_pBCAlternateMsgDef->u16TimeToNextMsg;
    }

    qDebug("Dev No : %d     Handle :  %lu\nMsgBlock ID : %d\nsBCMsgDefine.u16DataBlkID : %d\n",in_u16DeviceNo,(unsigned long)m_vpHandle[in_u16DeviceNo],in_u16MsgBlkID,sBCMsgDefine.u16DataBlkID);

    s32RetVal = DP1553BXT_BC_CreateMessage(m_vpHandle[in_u16DeviceNo], in_u16MsgBlkID, &sBCMsgDefine, psBCAlternateMsgDefine, in_u16DoubBufEnDiS);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }
    /*function Objective ends*/
}


/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_WriteMessageData(U16BIT in_u16DeviceNo, U16BIT in_u16MsgBlkID, U16BIT *in_pu16DataBuffer, U16BIT in_u16DataSize,  U16BIT in_u16Offset,  U16BIT in_u16Option)
{
#ifdef DP_SIMULATE
    return DP1553BXT_BC_WriteMessageData(m_vpHandle[in_u16DeviceNo], in_u16MsgBlkID, in_pu16DataBuffer, in_u16DataSize, in_u16Offset, in_u16Option);
#else
    memcpy(usData,in_pu16DataBuffer,sizeof(32));
#endif

    return 0;
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_CreateMinorFrame(U16BIT in_u16DeviceNo, U16BIT in_u16FrameID, U16BIT in_u16NoOfMsgs, U16BIT *in_pu16MsgIDList, U16BIT in_u16FrameTime)
{
#ifdef DP_SIMULATE
    return DP1553BXT_BC_CreateMinorFrame(m_vpHandle[in_u16DeviceNo], in_u16FrameID, in_u16NoOfMsgs, in_pu16MsgIDList, in_u16FrameTime);
#else
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_CreateMinorFrameEx(U16BIT in_u16DeviceNo, U16BIT in_u16FrameID, U16BIT in_u16NoOfOpcodes, DP1553BXT_BC_OPCODE_DEF *in_pOpcodeList)
{
#ifdef DP_SIMULATE
    return DP1553BXT_BC_CreateMinorFrameEx(m_vpHandle[in_u16DeviceNo], in_u16FrameID, in_u16NoOfOpcodes, in_pOpcodeList);
#else
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_CreateMajorFrame(U16BIT in_u16DeviceNo, U16BIT in_u16FrameID, U16BIT in_u16NoOfMinorFrm, U16BIT *in_pu16MinorFrmIDList, U32BIT in_u32FrameCount, U16BIT in_u16Options)
{
#ifdef DP_SIMULATE
    return DP1553BXT_BC_CreateMajorFrame(m_vpHandle[in_u16DeviceNo], in_u16FrameID, in_u16NoOfMinorFrm, in_pu16MinorFrmIDList, in_u32FrameCount, in_u16Options);
#else
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_CreateMajorFrameEx(U16BIT in_u16DeviceNo, U16BIT in_u16FrameID, U16BIT in_u16NoOfOpcodes, DP1553BXT_BC_OPCODE_DEF *in_pOpcodeList, U32BIT in_u32FrameCount, U16BIT in_u16FrameRepeatAt)
{
#ifdef DP_SIMULATE
    return DP1553BXT_BC_CreateMajorFrameEx(m_vpHandle[in_u16DeviceNo], in_u16FrameID, in_u16NoOfOpcodes, in_pOpcodeList, in_u32FrameCount, in_u16FrameRepeatAt);
#else
    return 0;
#endif
}

/**
*\brief
*
*\param[in]	in_u16DestSel		It specifies the destroy selection(0 - Destroy All, 1 - Destroy Frames).
                                           \n(0 - Removes all data blocks, message blocks,  minor and major frames and free the memory,
                                           \n 1 - Removes all minor and major frame and free the memory (all opcodes will be removed)

*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_Destroy(U16BIT in_u16DeviceNo, U16BIT in_u16DestSel)
{
#ifdef DP_SIMULATE
    if(in_u16DestSel)
    {
        return DP1553BXT_BC_DestroyAll(m_vpHandle[in_u16DeviceNo]);
    }
    else
    {
        return DP1553BXT_BC_DestroyAllFrames(m_vpHandle[in_u16DeviceNo]);
    }
#else
    return 0;
#endif
}

/**
*\brief
*
*\param[in]	in_u16StartStop		It specifies the BC to be start / stop.
                                            \n(0 - Stop the BC, 1 - Start the BC).
*\param[in]	in_u16MajorFrmID	It specifies the major frame ID to be transmitted at the time of (START)
                                            \n(Note: During the stop this parameter considered as dummy)
*\param[in]	in_u8UnblockWait	It will be used to unblock threads/task waiting for an event at the time of (STOP)
                                            \n(Note: During the start this parameter considered as dummy)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_Start_Stop(U16BIT in_u16DeviceNo, U16BIT in_u16StartStop, U16BIT in_u16MajorFrmID, U8BIT  in_u8UnblockWait)
{
#ifdef DP_SIMULATE
    if(in_u16StartStop)
    {
        return DP1553BXT_BC_Start(m_vpHandle[in_u16DeviceNo], in_u16MajorFrmID);
    }
    else
    {
        return DP1553BXT_BC_Stop(m_vpHandle[in_u16DeviceNo], in_u8UnblockWait);
    }
#else
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_WaitForEvents(U16BIT in_u16DeviceNo, U32BIT in_u32EventMasks, U16BIT in_u16Options, U32BIT *in_pu32Timeout, U32BIT *out_u32EventStatus)
{
#ifdef DP_SIMULATE
    return DP1553BXT_BC_WaitForEvents(m_vpHandle[in_u16DeviceNo], in_u32EventMasks, in_u16Options, in_pu32Timeout, out_u32EventStatus);
#else
    *out_u32EventStatus = 1;
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_ReadMessage(U16BIT in_u16DeviceNo, SDP1553BXT_BC_MSG *out_pSBCMsg, U16BIT in_u16MsgsToRead, U16BIT *out_u16AvailMsgs, U32BIT *in_u32Timeout)
{
#ifdef EN_DRV_1553B
#ifdef DP_SIMULATE
    return DP1553BXT_BC_ReadMessage(m_vpHandle[in_u16DeviceNo], out_pSBCMsg, in_u16MsgsToRead, out_u16AvailMsgs, in_u32Timeout);
#else
    if(usTestSel == DP_1553B_Terminal_Test)
    {
        out_pSBCMsg->u16WordCount = 32;
        out_pSBCMsg->u16BlockStsWord = 0x8000;
        if(usRTBCTest == 1)
        {
            out_pSBCMsg->u16CmdWord1 = 0x0C20;
        }
        else
        {
            out_pSBCMsg->u16CmdWord1 = 0x0820;
        }

        out_pSBCMsg->u16RTStsWord1 = 0x1510;
        memcpy(out_pSBCMsg->u16Data,usData,sizeof(usData));

    }
    else if(usTestSel == DP_1553B_Combined_Mode_Test)
    {
        out_pSBCMsg->u16WordCount = 32;
        out_pSBCMsg->u16BlockStsWord = 0x8000;
        if(usRTBCTest == 1)
        {
            out_pSBCMsg->u16CmdWord1 = 0x0C20;
        }
        else
        {
            out_pSBCMsg->u16CmdWord1 = 0x0820;
        }

        out_pSBCMsg->u16RTStsWord1 = 0x1510;
        memcpy(out_pSBCMsg->u16Data,usCombinedData,sizeof(usCombinedData));
    }
    else if(usTestSel == DP_1553B_Async_Test)
    {
        if(g_iCnt == 100)
        {
            out_pSBCMsg->u16WordCount = 32;
            out_pSBCMsg->u16BlockStsWord = 0x8000;
            out_pSBCMsg->u16MsgID = 0;
            if(usRTBCTest == 1)
            {
                out_pSBCMsg->u16CmdWord1 = 0x0C20;
            }
            else
            {
                out_pSBCMsg->u16CmdWord1 = 0x0820;
            }

            out_pSBCMsg->u16RTStsWord1 = 0x1510;
            out_pSBCMsg->u16TimetagRes = 100;
            memcpy(out_pSBCMsg->u16Data,usAsynData,sizeof(usAsynData));
        }
    }
    else if(usTestSel == DP_1553B_Sync_Test)
    {
        out_pSBCMsg->u16WordCount = 32;
        out_pSBCMsg->u16BlockStsWord = 0x8000;
        out_pSBCMsg->u16MsgID = 0;
        if(usRTBCTest == 1)
        {
            out_pSBCMsg->u16CmdWord1 = 0x0C20;
        }
        else
        {
            out_pSBCMsg->u16CmdWord1 = 0x0820;
        }

        out_pSBCMsg->u16RTStsWord1 = 0x1510;
        out_pSBCMsg->u16TimetagRes = 100;
        memcpy(out_pSBCMsg->u16Data,usAsynData,sizeof(usAsynData));
    }
    return 0;

#endif
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_ReadMessageFromID(U16BIT in_u16DeviceNo, U16BIT in_u16MsgBlkID, PSDP1553BXT_BC_MSG out_pSBCMsg,  U16BIT *out_pu16MsgAvail)
{
#ifdef EN_DRV_1553B
#ifdef DP_SIMULATE
    return DP1553BXT_BC_ReadMessageFromID(m_vpHandle[in_u16DeviceNo], in_u16MsgBlkID, out_pSBCMsg, out_pu16MsgAvail);
#else
    if(usTestSel == DP_1553B_Sync_Test)
    {
        out_pSBCMsg->u16WordCount = 32;
        out_pSBCMsg->u16BlockStsWord = 0x8000;
        out_pSBCMsg->u16MsgID = 0;
        if(usRTBCTest == 1)
        {
            out_pSBCMsg->u16CmdWord1 = 0x0C20;
        }
        else
        {
            out_pSBCMsg->u16CmdWord1 = 0x0820;
        }

        out_pSBCMsg->u16RTStsWord1 = 0x1510;
        out_pSBCMsg->u16TimetagRes = 100;
        memcpy(out_pSBCMsg->u16Data,usAsynData,sizeof(usAsynData));
    }

    return 0;
#endif
#endif
}


/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_SendAsyncMessage(U16BIT in_u16DeviceNo, U16BIT in_u16Queue, U16BIT in_pu16MsgCount, U16BIT *in_pu16MsgBlkIDList, U16BIT *out_pu16QueueCount)
{
#ifdef DP_SIMULATE
    return DP1553BXT_BC_SendAsyncMessage(m_vpHandle[in_u16DeviceNo], in_u16Queue, in_pu16MsgCount, in_pu16MsgBlkIDList, out_pu16QueueCount);
#else
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_GetAsyncMessageCount(U16BIT in_u16DeviceNo, U16BIT in_u16Queue, U16BIT *out_pu16QueueCount)
{
#ifdef DP_SIMULATE
    return DP1553BXT_BC_GetAsyncMessageCount(m_vpHandle[in_u16DeviceNo], in_u16Queue, out_pu16QueueCount);
#else
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_ResetAsyncMessageQueue(U16BIT in_u16DeviceNo, U16BIT in_u16Queue)
{
#ifdef DP_SIMULATE
    return DP1553BXT_BC_ResetAsyncMessageQueue(m_vpHandle[in_u16DeviceNo], in_u16Queue);
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_EnableDisableInt(U16BIT in_u16DeviceNo, PSDP1553B_BC_INT in_pSBC_INT)
{
#ifdef DP_SIMULATE
    S32BIT s32RetVal = DP1553B_INIT_ZERO;

    if(in_pSBC_INT->u8EnaDis)
    {
        s32RetVal = DP1553BXT_BC_EnableInterrupt(m_vpHandle[in_u16DeviceNo], in_pSBC_INT->u32IntEventMasks);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }
    }
    else
    {
        s32RetVal = DP1553BXT_BC_DisableInterrupt(m_vpHandle[in_u16DeviceNo]);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }
    }
    return s32RetVal;
#else
    return 0;
#endif
}
/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_BC_GetBufferInfo(U16BIT in_u16DeviceNo,U32BIT *out_pu32MsgsCount,U32BIT *out_pu32LostCount)
{
#ifdef DP_SIMULATE
    return DP1553BXT_BC_GetBufferInfo(m_vpHandle[in_u16DeviceNo],out_pu32MsgsCount,out_pu32LostCount);
#else

        *out_pu32MsgsCount = 5000;

    return 0;
#endif
}

S32BIT cDP1553BWrapper::DP1553B_BC_SetTimeTagResolution(U16BIT in_u16DeviceNo,U16BIT u16SetResolution)
{
#ifdef DP_SIMULATE
    return DP1553BXT_SetTimeTagResolution(m_vpHandle[in_u16DeviceNo], u16SetResolution);
    #else
    return 0;
#endif
}


/*************** RT functions *************************************/
/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_RT_Init(U16BIT in_u16DeviceNo, PSDP1553_RT_INIT in_pSRTInitInfo)
{
    U8BIT  u8RTaddsrc = DP1553B_INIT_ZERO;
    S32BIT s32RetVal = DP1553B_INIT_ZERO;
    U32BIT u32Options = DP1553B_INIT_ZERO;
    U32BIT u32OprnMode = DP1553BXT_OPRN_MODE_RT;

    SDP1553BXT_RT_INIT s_RtInit;
#ifdef DP_SIMULATE
    s_RtInit.u8BroadcastDisable = in_pSRTInitInfo->u8BroadcastDisable;
    s_RtInit.u8GlobalCirBuffSize = in_pSRTInitInfo->u8GlobalCirBuffSize;
    s_RtInit.u8ModeCodeResetIO = in_pSRTInitInfo->u8ModeCodeResetIO;
    s_RtInit.u8TimetagAtEOM = in_pSRTInitInfo->u8TimetagAtEOM;
    s_RtInit.u16HostMsgBufSize = in_pSRTInitInfo->u16HostMsgBufSize;
    s_RtInit.u16RTStackSize = in_pSRTInitInfo->u16RTStackSize;

    if(in_pSRTInitInfo->u8RTCombinedBC == 1)
    {
        u32OprnMode = u32OprnMode | DP1553BXT_OPRN_MODE_BC;
    }
    if(in_pSRTInitInfo->u8RTCombinedMT == 1)
    {
        u32OprnMode = u32OprnMode | DP1553BXT_OPRN_MODE_MT;
    }
    if(u32OprnMode == DP1553BXT_OPRN_MODE_RT)
    {
        u32Options = 0;
    }
    else
    {
        u32Options = DP1553BXT_MODEOPT_SHARED | DP1553BXT_MODEOPT_DONOT_OVERWRITE;
    }

    qDebug("hand : %lu", (unsigned long)m_vpHandle[in_u16DeviceNo]);
    s32RetVal = DP1553BXT_SetDeviceShare(m_vpHandle[in_u16DeviceNo], 1);
    if(s32RetVal )
    {
        return s32RetVal;
    }

    s32RetVal = DP1553BXT_InitializeMode(m_vpHandle[in_u16DeviceNo], u32OprnMode, u32Options);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }

    if(in_pSRTInitInfo->u8RTtype == DP1553B_SINGLE_RT)
    {
        /* initialize single RT */
        s32RetVal = DP1553BXT_RT_Initialize(m_vpHandle[in_u16DeviceNo], s_RtInit);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }

        /* This function get the RT address source as internal or External
        0 - External RT address source
        1 - Software control for RT address source */
        s32RetVal = DP1553BXT_RT_GetRTAddressSource(m_vpHandle[in_u16DeviceNo], &u8RTaddsrc);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }

        if(u8RTaddsrc == DP1553B_RT_SRC_INTERNAL)
        {
            /* This function set the user defined RT address to the device if the RT Address source is internal*/
            s32RetVal = DP1553BXT_RT_SetRTAddress(m_vpHandle[in_u16DeviceNo], in_pSRTInitInfo->u8RTAddress);
            if(s32RetVal != DP1553B_SUCCESS)
            {
                return s32RetVal;
            }
        }
    }
    else
    {
        /* initialize single RT */
        s32RetVal = DP1553BXT_MRT_Initialize(m_vpHandle[in_u16DeviceNo], s_RtInit);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }

        s32RetVal = DP1553BXT_RT_SetRTAddress(m_vpHandle[in_u16DeviceNo], 0);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }

        s32RetVal = DP1553BXT_MRT_SelectRTAddress(m_vpHandle[in_u16DeviceNo], in_pSRTInitInfo->u32MutiRTSel);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }
    }
#endif
    return s32RetVal;
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_RT_Configure(U16BIT in_u16DeviceNo, U32BIT in_u32ConfigOption, PSDP1553B_MRT_CONFIG in_pSMRT_Config)
{
#ifdef DP_SIMULATE
    if(in_pSMRT_Config->u8RTType)
    {
        return DP1553BXT_MRT_Configure(m_vpHandle[in_u16DeviceNo], in_pSMRT_Config->u8RTNumber, in_u32ConfigOption);
    }
    else
    {
        return DP1553BXT_RT_Configure(m_vpHandle[in_u16DeviceNo], in_u32ConfigOption);
    }
#else

    return 0;
#endif
}


/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_RT_SetNoRespTimeOut(U16BIT in_u16DeviceNo, U16BIT in_u16NoRespTimeOut, PSDP1553B_MRT_CONFIG in_pSMRT_Config)
{
#ifdef DP_SIMULATE
    if(in_pSMRT_Config->u8RTType)
    {
        return DP1553BXT_MRT_SetNoRespTimeOut(m_vpHandle[in_u16DeviceNo], in_pSMRT_Config->u8RTNumber, in_u16NoRespTimeOut);
    }
    else
    {
        return DP1553BXT_RT_SetNoRespTimeOut(m_vpHandle[in_u16DeviceNo], in_u16NoRespTimeOut);
    }
#else
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_RT_ConfigSubAddress(U16BIT in_u16DeviceNo, U32BIT in_u32SubAddrMask, U8BIT in_u8MsgType, U8BIT in_u8DataBufType, U32BIT in_u32Options, PSDP1553B_MRT_CONFIG in_pSMRT_Config)
{
#ifdef DP_SIMULATE
    if(in_pSMRT_Config->u8RTType)
    {
        return DP1553BXT_MRT_ConfigSubAddress(m_vpHandle[in_u16DeviceNo], in_pSMRT_Config->u8RTNumber, in_u32SubAddrMask, in_u8MsgType, in_u8DataBufType, in_u32Options);
    }
    else
    {
        return DP1553BXT_RT_ConfigSubAddress(m_vpHandle[in_u16DeviceNo], in_u32SubAddrMask, in_u8MsgType, in_u8DataBufType, in_u32Options);
    }
#else
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_RT_WriteSAData(U16BIT in_u16DeviceNo, U8BIT in_u8SubAddr, U16BIT *in_pu16DataBuffer, U16BIT in_u16DataSize,U16BIT in_u16Offset, PSDP1553B_MRT_CONFIG in_pSMRT_Config)
{
#ifdef DP_SIMULATE
    if(in_pSMRT_Config->u8RTType)
    {
        return DP1553BXT_MRT_WriteSAData(m_vpHandle[in_u16DeviceNo], in_pSMRT_Config->u8RTNumber, in_u8SubAddr, in_pu16DataBuffer, in_u16DataSize, in_u16Offset);
    }
    else
    {
        return DP1553BXT_RT_WriteSAData(m_vpHandle[in_u16DeviceNo], in_u8SubAddr, in_pu16DataBuffer, in_u16DataSize, in_u16Offset);
    }

#else
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_RT_EnableDisableInt(U16BIT in_u16DeviceNo, PSDP1553B_RT_INT in_pSRT_INT)
{
    S32BIT s32RetVal = DP1553B_INIT_ZERO;
#ifdef DP_SIMULATE
    if(in_pSRT_INT->u8EnaDis)
    {
        s32RetVal = DP1553BXT_RT_EnableInterrupt(m_vpHandle[in_u16DeviceNo], in_pSRT_INT->u32IntEventMasks);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }
    }
    else
    {
        s32RetVal = DP1553BXT_RT_DisableInterrupt(m_vpHandle[in_u16DeviceNo]);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }
    }
    return s32RetVal;
#else
    return 0;
#endif
}

/**
*\brief
*
*\param[in]	in_u16StartStop		It specifies the RT to be start / stop.
                                            \n(0 - Stop the RT, 1 - Start the RT).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_RT_Start_Stop(U16BIT in_u16DeviceNo, U16BIT in_u16StartStop, PSDP1553B_MRT_CONFIG in_pSMRT_Config)
{
#ifdef DP_SIMULATE
    if(in_u16StartStop)
    {
        if(in_pSMRT_Config->u8RTType)
        {
            return DP1553BXT_MRT_Start(m_vpHandle[in_u16DeviceNo]);
        }
        else
        {
            return DP1553BXT_RT_Start(m_vpHandle[in_u16DeviceNo]);
        }
    }
    else
    {
        if(in_pSMRT_Config->u8RTType)
        {
            return DP1553BXT_MRT_Stop(m_vpHandle[in_u16DeviceNo]);
        }
        else
        {
            return DP1553BXT_RT_Stop(m_vpHandle[in_u16DeviceNo]);
        }
    }
#else
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_RT_WaitForEvents(U16BIT in_u16DeviceNo, U32BIT in_u32EventMasks, U16BIT in_u16Options, U32BIT *in_pu32Timeout, U32BIT *out_pu32EventStatus)
{
#ifdef DP_SIMULATE
    return DP1553BXT_RT_WaitForEvents(m_vpHandle[in_u16DeviceNo], in_u32EventMasks, in_u16Options, in_pu32Timeout, out_pu32EventStatus);
#else
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_RT_ReadMessage(U16BIT in_u16DeviceNo, SDP1553BXT_RT_MSG *out_pSRTMsg, U16BIT in_u16MsgsToRead, U16BIT *out_u16AvailMsgs, U32BIT *in_pu32Timeout, PSDP1553B_MRT_CONFIG in_pSMRT_Config)
{
#ifdef EN_DRV_1553B
#ifdef DP_SIMULATE
    if(in_pSMRT_Config->u8RTType)
    {
        return DP1553BXT_MRT_ReadMessage(m_vpHandle[in_u16DeviceNo], out_pSRTMsg, in_u16MsgsToRead, out_u16AvailMsgs, in_pu32Timeout);
    }
    else
    {
        return DP1553BXT_RT_ReadMessage(m_vpHandle[in_u16DeviceNo], out_pSRTMsg, in_u16MsgsToRead, out_u16AvailMsgs, in_pu32Timeout);
    }
#else
    if(usTestSel == DP_1553B_Terminal_Test)
    {
        out_pSRTMsg->u16WordCount = 32;
        out_pSRTMsg->u16BlockStsWord = 0x8000;
        if(usRTBCTest == 1)
        {
            out_pSRTMsg->u16CmdWord = 0x0C20;
        }
        else
        {
            out_pSRTMsg->u16CmdWord = 0x0820;
        }
        memcpy(out_pSRTMsg->u16Data,usData,sizeof(usData));
    }
    else if(usTestSel == DP_1553B_Combined_Mode_Test)
    {
        out_pSRTMsg->u16WordCount = 32;
        out_pSRTMsg->u16BlockStsWord = 0x8000;
        if(usRTBCTest == 1)
        {
            out_pSRTMsg->u16CmdWord = 0x0C20;
        }
        else
        {
            out_pSRTMsg->u16CmdWord = 0x0820;
        }
        memcpy(out_pSRTMsg->u16Data,usCombinedData,sizeof(usCombinedData));
    }


    return 0;
#endif
#endif
}

/*************** MT functions *************************************/
/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_MT_Init(U16BIT in_u16DeviceNo, PSDP1553_MT_INIT in_pSMTInitInfo)
{
    S32BIT s32RetVal = DP1553B_INIT_ZERO;
    U32BIT u32Options = DP1553B_INIT_ZERO;
    U32BIT u32OprnMode = DP1553BXT_OPRN_MODE_MT;

    SDP1553BXT_MT_INIT s_MTInit;

    s_MTInit.u8SelectiveMonEnable = in_pSMTInitInfo->u8EnaSeleciveMon;
    s_MTInit.u32InteQueBufSize = in_pSMTInitInfo->u32InteQueBufSize;
    s_MTInit.u32IRIGMaxMsgCount = DP1553B_ONE;
    s_MTInit.u8IRIGEnable = DP1553B_ZERO;
    s_MTInit.u8IRIGTimePktEnable = DP1553B_ZERO;
    s_MTInit.u8IRIGTimeType = DP1553B_ZERO;
    s_MTInit.u16IRIGBChennalID = DP1553B_ONE;
    s_MTInit.u8IrigTimeFormat = DP1553B_ONE;

    if(in_pSMTInitInfo->u8RTCombinedBC == 1)
    {
        u32OprnMode = u32OprnMode | DP1553BXT_OPRN_MODE_BC;
    }
    if(in_pSMTInitInfo->u8RTCombinedRT == 1)
    {
        u32OprnMode = u32OprnMode | DP1553BXT_OPRN_MODE_RT;
    }
    if(u32OprnMode == DP1553BXT_OPRN_MODE_MT)
    {
        u32Options = 0;
    }
    else
    {
        u32Options = DP1553BXT_MODEOPT_SHARED | DP1553BXT_MODEOPT_DONOT_OVERWRITE;
    }
#ifdef DP_SIMULATE
    s32RetVal = DP1553BXT_SetDeviceShare(m_vpHandle[in_u16DeviceNo], u32OprnMode);
    if(s32RetVal)
    {
        return s32RetVal;
    }

    s32RetVal = DP1553BXT_InitializeMode(m_vpHandle[in_u16DeviceNo], u32OprnMode, u32Options);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }

    s32RetVal = DP1553BXT_MT_Initialize(m_vpHandle[in_u16DeviceNo], s_MTInit);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }
#endif
    return s32RetVal;
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_MT_Config(U16BIT in_u16DeviceNo, PSDP1553_MT_CONFIG in_pSMTConfig)
{
    S32BIT s32RetVal = DP1553B_INIT_ZERO;
    U32BIT u32Config = DP1553B_INIT_ZERO;

    if(in_pSMTConfig->u8MinGapChkEna)
        u32Config |= DP1553BXT_MT_MIN_GAP_CHECK_ENABLE ;
    if(in_pSMTConfig->u81553A_Format)
        u32Config |= DP1553BXT_MT_1553A_FORMAT_ENABLE;
    if(in_pSMTConfig->u8Broadcast)
        u32Config |= DP1553BXT_MT_BCST_DISABLE;
    if(in_pSMTConfig->u8BusSwEnbDis)
        u32Config |= DP1553BXT_MT_BUS_SW_EOM_DISABLE;
    if(in_pSMTConfig->u8EOMTimeTagEna)
        u32Config |= DP1553BXT_MT_EOM_TIMETAG_ENABLE;
#ifdef DP_SIMULATE
    s32RetVal = DP1553BXT_MT_Configure(m_vpHandle[in_u16DeviceNo], in_pSMTConfig->u8MTStackSize, u32Config); //MT_Configuration function
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }

    s32RetVal = DP1553BXT_MT_SetChannelToMonitor(m_vpHandle[in_u16DeviceNo], in_pSMTConfig->u8BusSelction); // select bus to monitor
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }

    s32RetVal = DP1553BXT_MT_SetIrigBSWCompliance(m_vpHandle[in_u16DeviceNo], in_pSMTConfig->u8EnaBlkStsComp);//Enable block status complince
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }

    s32RetVal = DP1553BXT_MT_SetNoResponseTimeOut(m_vpHandle[in_u16DeviceNo], in_pSMTConfig->u8NoResTimeout);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }

    s32RetVal = DP1553BXT_SetTimeTagResolution(m_vpHandle[in_u16DeviceNo], DP1553BXT_TIMETAG_RES_100NS);
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }

    s32RetVal = DP1553BXT_SetTimeTagRollover(m_vpHandle[in_u16DeviceNo], DP1553B_ONE); //Time tag rollover interrupt at 17 bits
    if(s32RetVal != DP1553B_SUCCESS)
    {
        return s32RetVal;
    }
#endif
    return s32RetVal;
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_MT_SetSelectiveMonitorOptions(U16BIT in_u16DeviceNo, U8BIT in_u8RTs, U32BIT in_u32SAs, U8BIT in_u8TxRx)
{
#ifdef DP_SIMULATE
    return DP1553BXT_MT_SetSelectiveMonitorOptions(m_vpHandle[in_u16DeviceNo], in_u8RTs, in_u32SAs, in_u8TxRx);
#else
    return 0;
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_MT_EnableDisableInt(U16BIT in_u16DeviceNo, PSDP1553B_MT_INT in_pSMT_INT)
{
    S32BIT s32RetVal = DP1553B_INIT_ZERO;
#ifdef DP_SIMULATE
    if(in_pSMT_INT->u8EnaDis)
    {
        s32RetVal = DP1553BXT_MT_EnableInterrupt(m_vpHandle[in_u16DeviceNo], in_pSMT_INT->u32IntEventMasks);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }

        s32RetVal =  DP1553BXT_MT_SetMessageCountThreshold(m_vpHandle[in_u16DeviceNo], in_pSMT_INT->u32MsgCntThreshold);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }

        s32RetVal =  DP1553BXT_MT_SetWordCountThreshold(m_vpHandle[in_u16DeviceNo], in_pSMT_INT->u32WrdCntThreshold);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }

        s32RetVal =  DP1553BXT_MT_SetTimerIntrThreshold(m_vpHandle[in_u16DeviceNo], in_pSMT_INT->u32TimeIntThreshold);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }
    }
    else
    {
        s32RetVal = DP1553BXT_MT_DisableInterrupt(m_vpHandle[in_u16DeviceNo]);
        if(s32RetVal != DP1553B_SUCCESS)
        {
            return s32RetVal;
        }
    }
#endif
    return s32RetVal;
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_MT_WaitForEvents(U16BIT in_u16DeviceNo, U32BIT in_u32EventForWait, U32BIT in_u32Option, U32BIT *in_pu32Timeout, U32BIT *out_pu32Status)
{
#ifdef DP_SIMULATE
    return DP1553BXT_MT_WaitForEvents(m_vpHandle[in_u16DeviceNo], in_u32EventForWait, in_u32Option, in_pu32Timeout, out_pu32Status);
#endif
}

/**
*\brief
*
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_MT_ReadMessage(U16BIT in_u16DeviceNo, U16BIT in_u16NoOfMsg, U32BIT *in_u32Timeout, SDP1553BXT_MT_MSG *out_pMsg, U16BIT *out_pu16AvalibleMsg)
{
#ifdef EN_DRV_1553B
#ifdef DP_SIMULATE
    return DP1553BXT_MT_ReadMessage(m_vpHandle[in_u16DeviceNo], in_u16NoOfMsg, in_u32Timeout, out_pMsg, out_pu16AvalibleMsg);
#else
    if(usTestSel == DP_1553B_Terminal_Test)
    {
        out_pMsg->u16LengthWord = 32;
        out_pMsg->u16BlockStatusWord =0x8000;
        if(usRTBCTest == 1)
        {
            out_pMsg->u16CmdWord1 = 0x0C20;
        }
        else
        {
            out_pMsg->u16CmdWord1 = 0x0820;
        }
        memcpy(out_pMsg->u16Data,usData,sizeof(usData));
    }
    else if(usTestSel == DP_1553B_Combined_Mode_Test)
    {
        out_pMsg->u16LengthWord = 32;
        out_pMsg->u16BlockStatusWord =0x8000;
        if(usRTBCTest == 1)
        {
            out_pMsg->u16CmdWord1 = 0x0C20;
        }
        else
        {
            out_pMsg->u16CmdWord1 = 0x0820;
        }
        memcpy(out_pMsg->u16Data,usCombinedDataRT,sizeof(usCombinedDataRT));
    }


    return 0;
#endif
#endif
}

/**
*\brief
*
*\param[in]	in_u16StartStop		It specifies the MT to be start / stop.
                                            \n(0 - Stop the MT, 1 - Start the MT).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*
*
*/
S32BIT cDP1553BWrapper::DP1553B_MT_StartStopMonitor(U16BIT in_u16DeviceNo, U16BIT in_u16StartStop)
{
#ifdef DP_SIMULATE
    if(in_u16StartStop)
    {
        return DP1553BXT_MT_StartMonitor(m_vpHandle[in_u16DeviceNo]);
    }
    else
    {
        return DP1553BXT_MT_StopMonitor(m_vpHandle[in_u16DeviceNo]);
    }
#endif

}
S32BIT cDP1553BWrapper::DP1553B_Internal_Self_Test(U16BIT in_u16DeviceNo,S_DP_SELF_TEST_STATUS *out_pSSelfTestStatus)
{
#ifdef DP_SIMULATE
    int iRetVal = 0;

    iRetVal = DP1553B_Reset(DP1553BXT_RESET_REGISTER|DP1553BXT_RESET_MEMORY);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP1553BXT_RAM_StartBIST(m_vpHandle[in_u16DeviceNo], DP1553BXT_SINGLE_PORT_RAM_BIST | DP1553BXT_RAM_BIST | DP1553BXT_ROM_BIST);

    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP1553BXT_RAM_GetBISTStatus(m_vpHandle[in_u16DeviceNo],&out_pSSelfTestStatus->SBIST_Sts);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP1553BXT_RAM_DataBusTest(m_vpHandle[in_u16DeviceNo], 0, &out_pSSelfTestStatus->uiRAMSelfTestDataBusSts);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP1553BXT_RAM_AddressBusTest(m_vpHandle[in_u16DeviceNo], &out_pSSelfTestStatus->uiRAMSelfTestAddrBusSts);

    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP1553BXT_RAM_DataIntegrityTest(m_vpHandle[in_u16DeviceNo], &out_pSSelfTestStatus->uiRAMSelfTestIntergritySts);

    if(iRetVal)
    {
        return iRetVal;
    }
#else

    out_pSSelfTestStatus->SBIST_Sts.ucRAMBistResult = 2;
    out_pSSelfTestStatus->SBIST_Sts.ucRAMBISTState = DP1553BXT_COMPLETE;
    out_pSSelfTestStatus->SBIST_Sts.ucROMBISTState = DP1553BXT_COMPLETE;
    out_pSSelfTestStatus->SBIST_Sts.ucROMBISTResult = 2;
    out_pSSelfTestStatus->SBIST_Sts.ucSinglePortResult= 2;
    out_pSSelfTestStatus->SBIST_Sts.ucSinglePortState = DP1553BXT_COMPLETE;
    out_pSSelfTestStatus->uiRAMSelfTestAddrBusSts = 0x0;
    out_pSSelfTestStatus->uiRAMSelfTestDataBusSts = 0x0;
    out_pSSelfTestStatus->uiRAMSelfTestIntergritySts = 0x0;
    return 0;
#endif
}
S16BIT cDP1553BWrapper::GetTimeFromTimetag(U64BIT in_u64Timetag, U16BIT in_u16TTRes, S_APP_TIMETAG_TIME *out_pTime, char *out_pszTime,QString *out_qsTime)
{
    double fResUs[] ={64.0, 32.0, 16.0, 8.0, 4.0, 2.0, 1.0, 0.5, 0.1, 0.0, 0.0};
    long double dTotalTime_us = 0.0;
    double fTimetag_ns;
    double fTimetag_us;
    unsigned long ulTimetag_ms = 0, ulTimetag_s = 0, ulTimetag_min = 0, ulTimetag_hr = 0;

    if(out_pTime)
    {
        memset(out_pTime, 0, sizeof(S_APP_TIMETAG_TIME));
    }
    if(in_u16TTRes > 10)
    {
        printf("\n\t Invalid Timetag Resolution.");
        return -1;
    }

    dTotalTime_us = in_u64Timetag * fResUs[in_u16TTRes];
    fTimetag_ns = (double)(dTotalTime_us - ((U64BIT)dTotalTime_us));
    fTimetag_us =  (double)((U64BIT)dTotalTime_us % 1000);
    fTimetag_us = fTimetag_us + fTimetag_ns;
    ulTimetag_ms = (double)((U64BIT)dTotalTime_us / 1000);
    ulTimetag_s = ulTimetag_ms / 1000;
    ulTimetag_ms = ulTimetag_ms % 1000;
    ulTimetag_min = ulTimetag_s / 60;
    ulTimetag_s = ulTimetag_s % 60;
    ulTimetag_hr = ulTimetag_min / 60;
    ulTimetag_min = ulTimetag_min % 60;
    #ifdef Debug
    //printf("dTotalTime_us : %Lf fTimetag_ns: %Lf ulTimetag_ms: %Lf", dTotalTime_us,fTimetag_ns,ulTimetag_ms);
    #endif

    if(out_pTime)
    {
        out_pTime->fMicroSec = fTimetag_us;
        out_pTime->u16MilliSec = (U16BIT)ulTimetag_ms;
        out_pTime->u8Sec = (U8BIT)ulTimetag_s;
        out_pTime->u8Min = (U8BIT)ulTimetag_min;
        out_pTime->u32Hour = (U32BIT)ulTimetag_hr;
    }
    if(out_pszTime)
    {
        sprintf(out_pszTime, "%u:%02d:%02d.%03d.%07.03f", (U32BIT)ulTimetag_hr,
                (U8BIT)ulTimetag_min, (U8BIT)ulTimetag_s, (U16BIT)ulTimetag_ms, fTimetag_us);

        out_qsTime->sprintf("%u:%02d:%02d.%03d.%07.03f", (U32BIT)ulTimetag_hr,
                           (U8BIT)ulTimetag_min, (U8BIT)ulTimetag_s, (U16BIT)ulTimetag_ms, fTimetag_us);
                #ifdef Debug
                //printf("out_pszTime : %s\n", out_pszTime);
                #endif
    }
    return 0;
}




