#include "dpmm1105_pro.h"
#include "dpmmcrdrv_pro.h"
#include "dp-lins-cm_signals.h"
#include "dp_types.h"

#include "dp-lins_mm1105_wrapper.h"
#include "string.h"
#include <sys/types.h>
#define _DRV5112_ENABLE

PSDPMM1105_CARRIER_DEVICE_INFO g_pSAllCarrDevLocDetails;

S16BIT DPMM1105_Wrapper::EnableSimulator(char in_Enable, char *in_pHostName, unsigned int in_iPort)
{

    m_cSimEnable = 0;
    if(/*m_cSimEnable*/0)
    {
        m_SimSocket.connectToHost(QString::fromUtf8(in_pHostName), in_iPort);
        if(m_SimSocket.waitForConnected(1000))
        {
            return DP_SYS_1105_SUCCESS;
        }
        else
        {
            return DP_SYS_1105_FAILURE;
        }
    }
    else
    {
        m_SimSocket.disconnectFromHost();
        return DP_SYS_1105_SUCCESS;
    }
}
/**************************************************************************
// Name						: Init
// Author					: 
// Created Date				: 
// Revision Date			:
// Reason for Revising		:
// Description				: This Function is used to Initialize the DPMM1105 DAC
// Global Variables affected: s_Boardinfo, m_szErrorMsg, m_ulHandle.
// Input Parameters			: 
**************************************************************************/
S16BIT DPMM1105_Wrapper::Init(U16BIT in_u16NoOfBoards, PSDPMM1105APP_DeviceLocation in_pSDevLocation, PDPMM1105_DeviceLocation out_pSDevLocation)
{
    U8BIT u8BoardNo = DP_1105_INITIALIZE_0;
    U8BIT u8Loop = DP_1105_INITIALIZE_0;
    U16BIT u16NoOfBoards = DP_1105_INITIALIZE_0;
    PSDPMM1105_DEVICE_LOCATION pSAllDevLocDetails;
    //SDPMM1105_DEVICE_LOCATION SDeviceOpenInfo;
    PSDPMMCRDRV_CARRIER_DEVICE_INFO pSAllCarrierDevInfo;
    void *g_vpCarrierHandle[2];
    m_u16NoOfDetBoards = 0;

    m_cSimEnable = 0;
    if(/*m_cSimEnable*/0)
    {
        return DP_SYS_1105_SUCCESS;
    }
    else
    {
        if(in_pSDevLocation != NULL)
        {
            for(u8Loop = 0; u8Loop < in_u16NoOfBoards; u8Loop++)
            {
                out_pSDevLocation[u8Loop].u8SlotNo = in_pSDevLocation[u8Loop].u8SlotNo;
                out_pSDevLocation[u8Loop].u8BusNo = in_pSDevLocation[u8Loop].u8BusNo;
                out_pSDevLocation[u8Loop].u8FunctionNo = in_pSDevLocation[u8Loop].u8FunctionNo;
                out_pSDevLocation[u8Loop].u8MMSlotNo = in_pSDevLocation[u8Loop].u8MMSlotNo;
                out_pSDevLocation[u8Loop].s8BoardSts = DP_BORDS_STATUS_ZERO;
            }
        }

#ifdef _DRV5112_ENABLE
        m_s32RetVal = DPMMCRDRV_GetTotalDeviceFound(&u16NoOfBoards);
        if (m_s32RetVal != DP_SYS_1105_SUCCESS)
        {
            DPMMCRDRV_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_SYS_1105_FAILURE;
        }

        if(u16NoOfBoards == 0)
        {
            strncpy(m_szErrorMsg,"No Modules Detected.",sizeof(m_szErrorMsg));
            return DP_SYS_1105_FAILURE;
        }

        /* Get All Carrier Device Location */
        pSAllCarrierDevInfo = (PSDPMMCRDRV_CARRIER_DEVICE_INFO)malloc(sizeof(SDPMMCRDRV_CARRIER_DEVICE_INFO) * u16NoOfBoards);
        if(pSAllCarrierDevInfo == NULL)
        {
            sprintf(m_szErrorMsg, "Error in memory creation for carrier device location details");
            return DP_SYS_1105_FAILURE;
        }

        m_s32RetVal = DPMMCRDRV_GetAllDeviceInformation(pSAllCarrierDevInfo, u16NoOfBoards);
        if (m_s32RetVal != DP_SYS_1105_SUCCESS)
        {
            DPMMCRDRV_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            free(pSAllCarrierDevInfo);
            return DP_SYS_1105_FAILURE;
        }

        //        u16NoOfBoards = 1;
        for(u8BoardNo = 0; u8BoardNo < (u16NoOfBoards); u8BoardNo++)
        {
            m_s32RetVal = DPMMCRDRV_Open(&pSAllCarrierDevInfo[u8BoardNo].m_SDeviceLocation, &g_vpCarrierHandle[u8BoardNo]);
            if (m_s32RetVal != DP_SYS_1105_SUCCESS)
            {
                DPMMCRDRV_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                free(pSAllCarrierDevInfo);
                return DP_SYS_1105_FAILURE;
            }
        }

        g_pSAllCarrDevLocDetails = (PSDPMM1105_CARRIER_DEVICE_INFO)malloc(sizeof(SDPMM1105_CARRIER_DEVICE_INFO) * u16NoOfBoards);
        if(g_pSAllCarrDevLocDetails == NULL)
        {
            strcpy(m_szErrorMsg, "Error in memory creation for all device location details\n");
            return DP_SYS_1105_FAILURE;
        }

        memcpy(g_pSAllCarrDevLocDetails, pSAllCarrierDevInfo, (sizeof(SDPMM1105_CARRIER_DEVICE_INFO) * u16NoOfBoards));

        for(u8BoardNo = 0; u8BoardNo < (u16NoOfBoards); u8BoardNo++)
        {
            m_s32RetVal = DPMM1105_SetResource(u16NoOfBoards, &g_pSAllCarrDevLocDetails[u8BoardNo], DP_CARR_BOARD);
            //            free(g_pSAllCarrDevLocDetails);
            //            free(pSAllCarrierDevInfo);
            if (m_s32RetVal != DP_SYS_1105_SUCCESS)
            {
                DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_SYS_1105_FAILURE;
            }

            m_s32RetVal = DPMM1105_GetTotalDeviceFound(&m_u16NoOfDetBoards);
            if (m_s32RetVal!= DP_SYS_1105_SUCCESS)
            {
                DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_SYS_1105_FAILURE;
            }
            if(m_u16NoOfDetBoards > 0)
            {
                break;
            }
        }

        if(m_u16NoOfDetBoards == 0)
        {
            strncpy(m_szErrorMsg,"No Modules Detected.",sizeof(m_szErrorMsg));
            return DP_SYS_1105_FAILURE;
        }

        /* Get All Device Location */
        pSAllDevLocDetails = (PSDPMM1105_DEVICE_LOCATION)malloc(sizeof(SDPMM1105_DEVICE_LOCATION) * m_u16NoOfDetBoards);
        if(pSAllDevLocDetails == NULL)
        {
            strcpy(m_szErrorMsg,"Error in memory creation for all device location details\n");
            return DP_SYS_1105_FAILURE;
        }

        m_s32RetVal = DPMM1105_GetAllDeviceLocations(pSAllDevLocDetails, m_u16NoOfDetBoards);
        if (m_s32RetVal != DP_SYS_1105_SUCCESS)
        {
            DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            free(pSAllDevLocDetails);
            return DP_SYS_1105_FAILURE;
        }

        m_pSAllDevLocDetails = (PDPMM1105_DeviceLocation)malloc(sizeof(SDPMM1105_DeviceLocation) * m_u16NoOfDetBoards);
        for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfDetBoards); u8BoardNo++)
        {
            m_pSAllDevLocDetails[u8BoardNo].s8BoardSts = DP_BORDS_STATUS_ZERO;
            m_pSAllDevLocDetails[u8BoardNo].u8SlotNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8SlotNo;
            m_pSAllDevLocDetails[u8BoardNo].u8BusNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8BusNo;
            m_pSAllDevLocDetails[u8BoardNo].u8FunctionNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8FunctionNo;
            m_pSAllDevLocDetails[u8BoardNo].u8MMSlotNo = pSAllDevLocDetails[u8BoardNo].m_u8MMSlotNo;
            if(u8BoardNo < in_u16NoOfBoards)
            {
                m_pSAllDevLocDetails[u8BoardNo].u8ExpSlotNo = in_pSDevLocation[u8BoardNo].u8SlotNo;
            }
            else
            {
                m_pSAllDevLocDetails[u8BoardNo].u8ExpSlotNo = 0;
            }

            for(u8Loop = 0; u8Loop < in_u16NoOfBoards; u8Loop++)
            {
                if((m_pSAllDevLocDetails[u8BoardNo].u8SlotNo == in_pSDevLocation[u8Loop].u8SlotNo) && (m_pSAllDevLocDetails[u8BoardNo].u8BusNo ==  in_pSDevLocation[u8Loop].u8BusNo) && (m_pSAllDevLocDetails[u8BoardNo].u8FunctionNo == in_pSDevLocation[u8Loop].u8FunctionNo) && (m_pSAllDevLocDetails[u8BoardNo].u8MMSlotNo == in_pSDevLocation[u8Loop].u8MMSlotNo))
                {
                    m_pSAllDevLocDetails[u8BoardNo].s8BoardSts = DP_BORDS_STATUS_ONE;
                    break;
                }
            }
        }

        if(in_pSDevLocation == NULL)
        {
            m_u16NoOfBoards = m_u16NoOfDetBoards;
            for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfDetBoards); u8BoardNo++)
            {
                /* open the found boards */
                m_s32RetVal = DPMM1105_Open((PSDPMM1105_DEVICE_LOCATION)&pSAllDevLocDetails[u8BoardNo], &m_hHandle[u8BoardNo]);
                if(m_s32RetVal != DP_SYS_1105_SUCCESS)
                {
                    DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    free(pSAllDevLocDetails);
                    return DP_SYS_1105_FAILURE;
                }

                out_pSDevLocation[u8BoardNo].s8BoardSts = DP_BORDS_STATUS_ONE;
                out_pSDevLocation[u8BoardNo].u8SlotNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8SlotNo;
                out_pSDevLocation[u8BoardNo].u8BusNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8BusNo;
                out_pSDevLocation[u8BoardNo].u8FunctionNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8FunctionNo;
                out_pSDevLocation[u8BoardNo].u8MMSlotNo = pSAllDevLocDetails[u8BoardNo].m_u8MMSlotNo;
            }
        }
        else
        {
            m_u16NoOfBoards = 0;
            for(u8Loop = 0; u8Loop < in_u16NoOfBoards; u8Loop++)
            {
                for(u8BoardNo = 0; u8BoardNo < m_u16NoOfDetBoards; u8BoardNo++)
                {
                    if((pSAllDevLocDetails[u8BoardNo].u.pci.m_u8SlotNo == in_pSDevLocation[u8Loop].u8SlotNo) && (pSAllDevLocDetails[u8BoardNo].u.pci.m_u8BusNo ==  in_pSDevLocation[u8Loop].u8BusNo) && (pSAllDevLocDetails[u8BoardNo].u.pci.m_u8FunctionNo == in_pSDevLocation[u8Loop].u8FunctionNo) && (pSAllDevLocDetails[u8BoardNo].m_u8MMSlotNo == in_pSDevLocation[u8Loop].u8MMSlotNo))
                    {
                        m_u16NoOfBoards++;
                        out_pSDevLocation[u8Loop].s8BoardSts = DP_BORDS_STATUS_ONE;
                        break;
                    }
                }

                //                qDebug("Slot Rd: %d | MMSlot : %d",in_pSDevLocation[u8Loop].u8SlotNo, in_pSDevLocation[u8Loop].u8MMSlotNo);

                out_pSDevLocation[u8Loop].u8SlotNo = in_pSDevLocation[u8Loop].u8SlotNo;
                out_pSDevLocation[u8Loop].u8BusNo = in_pSDevLocation[u8Loop].u8BusNo;
                out_pSDevLocation[u8Loop].u8FunctionNo = in_pSDevLocation[u8Loop].u8FunctionNo;
                out_pSDevLocation[u8Loop].u8MMSlotNo = in_pSDevLocation[u8Loop].u8MMSlotNo;

                if(u8BoardNo == m_u16NoOfDetBoards)
                {
                    out_pSDevLocation[u8Loop].s8BoardSts = DP_BORDS_STATUS_ZERO;
                    continue;
                }

                m_s32RetVal = DPMM1105_Open((PSDPMM1105_DEVICE_LOCATION)&pSAllDevLocDetails[u8BoardNo], &m_hHandle[u8Loop]);
                if(m_s32RetVal != DP_SYS_1105_SUCCESS)
                {
                    DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    free(pSAllDevLocDetails);
                    return DP_SYS_1105_FAILURE;
                }
            }
        }
        free(pSAllDevLocDetails);
#endif
        return DP_SYS_1105_SUCCESS;
    }
}

/**************************************************************************
// Name						: Config
// Author					: 
// Global Variables affected: 				 
// Created Date				: 24/02/2020
// Revision Date			:
// Reason for Revising		:
// Description:This Function is used to config the 1105 ADC Board
**************************************************************************/
S16BIT DPMM1105_Wrapper::Config(U16BIT in_u16BoardNo)
{
    SDPMM1105_ADC_CONFIGURATION sADCConfigure;
    U8BIT u8Loop = DP_1105_INITIALIZE_0;
    U8BIT u8BoardNo = DP_1105_INITIALIZE_0;
    if(/*m_cSimEnable*/0)
    {
        return DP_SYS_1105_SUCCESS;
    }
    else
    {
#ifdef _DRV5112_ENABLE
        if((in_u16BoardNo > 0) && (in_u16BoardNo <= m_u16NoOfBoards))
        {
            in_u16BoardNo = in_u16BoardNo -1;
            sADCConfigure.m_u8InputSignalType = DP_MM_1105_DIFFERENTIAL_MODE;
            sADCConfigure.m_u8TriggerType = DP_SYS_1105_SW_TRIGGER;
            sADCConfigure.m_u8SourceType = DP_SYS_1105_SOURCE_SELECTION;
            sADCConfigure.m_u8PacerSource = DP_SYS_1105_PACER_INTERNAL;
            sADCConfigure.m_u8ContiniousTriggerType = DP_SYS_1105_TRIGGER_CONTINUOUS;
            sADCConfigure.m_fPacerFrequency = DP_SYS_1105_PACER_FREQUENCY;
            sADCConfigure.m_u8ExternalTriggerType = DP_SYS_1105_TRIGGER_TYPE;

            m_s32RetVal = DPMM1105_ConfigureADC(m_hHandle[in_u16BoardNo], &sADCConfigure);
            if(m_s32RetVal != DP_SYS_1105_SUCCESS)
            {
                DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                //                qDebug("1:: %s",m_szErrorMsg);
                return DP_SYS_1105_FAILURE;
            }

            m_s32RetVal = DPMM1105_RawDataEnDis(m_hHandle[in_u16BoardNo], DP_MM_1105_RAWDATA_DISABLE);
            if(m_s32RetVal != DP_SYS_1105_SUCCESS)
            {
                DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                //                qDebug("2:: %s",m_szErrorMsg);
                return DP_SYS_1105_FAILURE;
            }

#if 1
            SDPMM1105_SCAN_BUFFER sScanBuffer[16];

            for(unsigned char ucChnNo = 0; ucChnNo < 8; ucChnNo++)
            {
                sScanBuffer[ucChnNo].m_u8ChannelNo =  ucChnNo + 1;
                sScanBuffer[ucChnNo].m_u8Gain =  0;
                sScanBuffer[ucChnNo].m_u8FifoWrEnb = 0;
            }

            m_s32RetVal = DPMM1105_UpdateScanList(m_hHandle[in_u16BoardNo], sScanBuffer, 8, 0);
            if(m_s32RetVal != DP_SYS_1105_SUCCESS)
            {
                DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_SYS_1105_FAILURE;
            }
#endif
        }
        else
        {
            /* Load the calibration from EEPROM */
            for(u8BoardNo = 0; u8BoardNo < m_u16NoOfBoards; u8BoardNo++)
            {
                sADCConfigure.m_u8InputSignalType = DP_MM_1105_DIFFERENTIAL_MODE;
                sADCConfigure.m_u8TriggerType = DP_SYS_1105_SW_TRIGGER;
                sADCConfigure.m_u8SourceType = DP_SYS_1105_SOURCE_SELECTION;
                sADCConfigure.m_u8PacerSource = DP_SYS_1105_PACER_INTERNAL;
                sADCConfigure.m_u8ContiniousTriggerType = DP_SYS_1105_TRIGGER_CONTINUOUS;
                if(u8BoardNo > 1)
                {
                    sADCConfigure.m_fPacerFrequency = 100;
                }
                else
                {
                    sADCConfigure.m_fPacerFrequency = DP_SYS_1105_PACER_FREQUENCY;
                }
                sADCConfigure.m_u8ExternalTriggerType = DP_SYS_1105_TRIGGER_TYPE;

                m_s32RetVal = DPMM1105_ConfigureADC(m_hHandle[u8BoardNo], &sADCConfigure);
                if(m_s32RetVal != DP_SYS_1105_SUCCESS)
                {
                    DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    return DP_SYS_1105_FAILURE;
                }

                m_s32RetVal = DPMM1105_RawDataEnDis(m_hHandle[u8BoardNo], DP_MM_1105_RAWDATA_DISABLE);
                if(m_s32RetVal != DP_SYS_1105_SUCCESS)
                {
                    DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    return DP_SYS_1105_FAILURE;
                }

#if 1
                SDPMM1105_SCAN_BUFFER sScanBuffer[16];

                for(unsigned char ucChnNo = 0; ucChnNo < 8; ucChnNo++)
                {
                    sScanBuffer[ucChnNo].m_u8ChannelNo =  ucChnNo + 1;
                    sScanBuffer[ucChnNo].m_u8Gain =  0;
                    sScanBuffer[ucChnNo].m_u8FifoWrEnb = 0;
                }

                m_s32RetVal = DPMM1105_UpdateScanList(m_hHandle[u8BoardNo], sScanBuffer, 8, 0);
                if(m_s32RetVal != DP_SYS_1105_SUCCESS)
                {
                    DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    return DP_SYS_1105_FAILURE;
                }
#endif
            }
        }
#endif
        return DP_SYS_1105_SUCCESS;
    }
}
/**************************************************************************
// Name						: StartAcquisition
// Author					: 
// Global Variables affected: 				 
// Created Date				: 24/02/2020
// Revision Date			:
// Reason for Revising		:
// Description:This Function is used to setAcquisition of 1105 ADC Board
**************************************************************************/
S16BIT DPMM1105_Wrapper::StartAcquisition(U16BIT in_u16BoardNo)
{
    U8BIT u8BoardNo = DP_1105_INITIALIZE_0;
    if(/*m_cSimEnable*/0)
    {
        return DP_SYS_1105_SUCCESS;
    }
    else
    {
#ifdef _DRV5112_ENABLE
        /*This function is used to start and stop the data Acquisition of the ADC Module after configuration */
        if(in_u16BoardNo)
        {
            if (in_u16BoardNo >= 1 && in_u16BoardNo <= m_u16NoOfBoards)
            {
                m_s32RetVal = DPMM1105_StartAcquisition(m_hHandle[in_u16BoardNo-1]);
                if(m_s32RetVal != DP_SYS_1105_SUCCESS)
                {
                    DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    return DP_SYS_1105_FAILURE;
                }
                m_s32RetVal = DPMM1105_Trigger(m_hHandle[in_u16BoardNo-1]);
                if(m_s32RetVal != DP_SYS_1105_SUCCESS)
                {
                    DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    return DP_SYS_1105_FAILURE;
                }
            }
            else
            {
                sprintf(m_szErrorMsg, "Invalid Bord Number");
                return DP_SYS_1105_FAILURE;
            }
        }
        else
        {
            for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfBoards); u8BoardNo++)
            {
                m_s32RetVal = DPMM1105_StartAcquisition(m_hHandle[u8BoardNo]);
                if(m_s32RetVal != DP_SYS_1105_SUCCESS)
                {
                    DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    return DP_SYS_1105_FAILURE;
                }
                m_s32RetVal = DPMM1105_Trigger(m_hHandle[u8BoardNo]);
                if(m_s32RetVal != DP_SYS_1105_SUCCESS)
                {
                    DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    return DP_SYS_1105_FAILURE;
                }
            }
        }
#endif
        return DP_SYS_1105_SUCCESS;
    }
}
/**************************************************************************
// Name						: StopAcquisition
// Author					: 
// Global Variables affected: 				 
// Created Date				: 24/02/2020
// Revision Date			:
// Reason for Revising		:
// Description:This Function is used to setAcquisition of 1105 ADC Board
**************************************************************************/
S16BIT DPMM1105_Wrapper::StopAcquisition(U16BIT in_u16BoardNo)
{
    U8BIT u8BoardNo = DP_1105_INITIALIZE_0;

    if(/*m_cSimEnable*/0)
    {
        return DP_SYS_1105_SUCCESS;
    }
    else
    {
#ifdef _DRV5112_ENABLE
        /*This function is used to start and stop the data Acquisition of the ADC Module after configuration */
        if(in_u16BoardNo)
        {
            if (in_u16BoardNo >= 1 && in_u16BoardNo <= m_u16NoOfBoards)
            {
                m_s32RetVal = DPMM1105_StopAcquisition(m_hHandle[in_u16BoardNo-1]);
                if(m_s32RetVal != DP_SYS_1105_SUCCESS)
                {
                    DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    return DP_SYS_1105_FAILURE;
                }
            }
            else
            {
                sprintf(m_szErrorMsg, "Invalid Bord Number");
                return DP_SYS_1105_FAILURE;
            }
        }
        else
        {
            for(u8BoardNo = 0; u8BoardNo < m_u16NoOfBoards; u8BoardNo++)
            {
                m_s32RetVal = DPMM1105_StopAcquisition(m_hHandle[u8BoardNo]);
                if(m_s32RetVal != DP_SYS_1105_SUCCESS)
                {
                    DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    return DP_SYS_1105_FAILURE;
                }
            }
        }
#endif
        return DP_SYS_1105_SUCCESS;
    }
}

/**************************************************************************
// Name						: ReadRecentSample
// Author					: 
// Global Variables affected: 				 
// Created Date				: 21/02/2020
// Revision Date			:
// Reason for Revising		:
// Description				:This function is used to read the ADC Current Value for specified channel		
**************************************************************************/
S16BIT DPMM1105_Wrapper::ReadRecentSample(U16BIT in_u16SignalId, U8BIT u8NoOfSamples, PFSINGLE out_pfADCData, U8BIT u8MeanOrAvg)
{
    U8BIT u8Loop = DP_1105_INITIALIZE_0;
    U8BIT u8Loop1 = DP_1105_INITIALIZE_0;
    U8BIT u8Loop2 = DP_1105_INITIALIZE_0;
    U16BIT u16MidValue = DP_1105_INITIALIZE_0;
    FDOUBLE dADCTotal = 0.0;
    FSINGLE fADCValue = 0.0;
    FSINGLE MidADCValue = 0.0;
    FSINGLE fGainFactor = 0.0;
    FSINGLE fADCData[30];
    FSINGLE fMidADCValue = 0.0;
    SDPMM1105_SAMPLE_INFO sSample;
    U8BIT u8IsCurrentRead = 0;

    if(MUX_1105_ValidateSignalID(in_u16SignalId) != DP_SYS_1105_SUCCESS)
    {
        strcpy(m_szErrorMsg, "Invalid Signal ID");
        return DP_SYS_1105_FAILURE;
    }

    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    U8BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);
    u8BoardNo -= 1;

    switch(in_u16SignalId)
    {
    case AI_PSO_PS1_V:
    case AI_PSO_PS2_V:
    case AI_PSO_PS3_V:
        fGainFactor = 0.1;
        break;

    case AI_PKG_PS1_C1_V:
    case AI_PKG_PS1_C2_V:
    case AI_PKG_PS1_SP1_V:
    case AI_PKG_PS2_C1_V:
    case AI_PKG_PS2_C2_V:
    case AI_PKG_PS2_SP2_V:
    case AI_PKG_PS3_C1_V:
    case AI_PKG_PS3_C2_V:
    case AI_PKG_PS3_DEMAG_V:
    case AI_PSO_TC_V:
    case AI_PS_COS_V:
    case AI_COS_V:
        fGainFactor = 0.25;
        break;

    case AI_PKG_PS1_C1_C:
    case AI_PKG_PS1_C2_C:
    case AI_PKG_PS1_SP1_C:
    case AI_PKG_PS2_C1_C:
    case AI_PKG_PS2_C2_C:
    case AI_PKG_PS2_SP2_C:
    case AI_PKG_PS3_C1_C:
    case AI_PKG_PS3_C2_C:
    case AI_PKG_PS3_DEMAG_C:
        u8IsCurrentRead = 1;
        fGainFactor = 1.94;
        break;

    case AI_PKG_TC1_V:
    case AI_PKG_TC2_V:
    case AI_PKG_TC3_V:
    case AI_PKG_TC4_V:
        fGainFactor = 0.3;
        break;
    }

    if(/*m_cSimEnable*/0)
    {
        S_SIG_OPERATION SimOprn = {OPRN_TYPE_GET, SIG_TYPE_ADC, in_u16SignalId, 0.0f, -1};
        int iRetVal = m_SimSocket.write((char *)&SimOprn,sizeof(S_SIG_OPERATION));
        m_SimSocket.waitForReadyRead(2000);
        iRetVal = m_SimSocket.read((char *)&SimOprn,sizeof(S_SIG_OPERATION));
        if(iRetVal > 0)
        {
            if(SimOprn.iStatus >=0)
            {
                *out_pfADCData = (U8BIT)SimOprn.fSigvalue;
                return DP_SYS_1105_SUCCESS;
            }
            else
            {
                strcpy(m_szErrorMsg, "Invalid operation / signal ID");
                return DP_SYS_1105_FAILURE;
            }
        }
        else
        {
            strcpy(m_szErrorMsg, "Ethernet communication error");
            return DP_SYS_1105_FAILURE;
        }

    }
    else
    {
#ifdef _DRV5112_ENABLE
        for(u8Loop1 = 0; u8Loop1 < u8NoOfSamples; u8Loop1++)
        {
            /*This function is used to read the ADC Current Value in the CVR register for corresponding Channel */
            m_s32RetVal = DPMM1105_GetRecentSample(m_hHandle[u8BoardNo], u8ChannelNo, &sSample);
            if(m_s32RetVal != DP_SYS_1105_SUCCESS)
            {
                DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_SYS_1105_FAILURE;
            }
            fADCData[u8Loop1] = (FSINGLE)sSample.m_dSample; /*Storing the no of samples for each channels*/
            dADCTotal += sSample.m_dSample;
            //qDebug() << "LoopIdx:" << u8Loop1 << "Val:" << sSample.m_dSample;
        }
        //dADCTotal = 0.0;

        if(u8MeanOrAvg == DP_MM_1105_AVERAGE)
        {
            *out_pfADCData = (dADCTotal/u8NoOfSamples)/fGainFactor; /*Calculating average of ADC samples*//*fGainFactor given by hardware*/
            if(u8IsCurrentRead)
            {
                if(*out_pfADCData < 0.0f)
                {
                    *out_pfADCData = 0.0f;
                }
            }
        }
        else
        {
#if 0
            for(u8Loop1 = 0; u8Loop1 < u8NoOfSamples; u8Loop1++)
            {
                for(u8Loop2 = 0; u8Loop2 < (u8NoOfSamples - u8Loop); u8Loop2++)
                {
                    if(fADCData[u8Loop2] > fADCData[u8Loop2 + 1])
                    {
                        fMidADCValue = fADCData[u8Loop2];
                        fADCData[u8Loop2] = fADCData[u8Loop2 + 1];
                        fADCData[u8Loop2 + 1] = fMidADCValue;
                    }
                }
            }
            u16MidValue = u8NoOfSamples/2;
#endif
            u16MidValue = 0;
            *out_pfADCData = (fADCData[u16MidValue])/fGainFactor; /*Retruning mean of ADC samples for particular channel*//*fGainFactor given by hardware*/
            //qDebug() << "ValinArr:" << fADCData[u16MidValue] << "GainF:" << fGainFactor << "Val:" << *out_pfADCData;
            if(u8IsCurrentRead)
            {
                if(*out_pfADCData < 0.0f)
                {
                    *out_pfADCData = 0.0f;
                }
            }
        }
#endif
        return DP_SYS_1105_SUCCESS;
    }
}

/**************************************************************************
// Name						: ReadRecentSamples
// Author					: 
// Global Variables affected: 				 
// Created Date				: 21/02/2020
// Revision Date			:
// Reason for Revising		:
// Description				:This function is used to read the ADC Current Value for channels
**************************************************************************/
S16BIT DPMM1105_Wrapper::ReadRecentSamples(U16BIT in_u16SignalIdList[], U16BIT in_u16NoOfSignals, U8BIT u8NoOfSamples, FSINGLE out_fADCData[], U8BIT u8MeanOrAvg)
//S16BIT DPMM1105_Wrapper::ReadRecentSamples(U16BIT in_u16SignalIdList[], U16BIT in_u16NoOfSignals, U8BIT u8NoOfSamples, PFSINGLE out_fADCData, U8BIT u8MeanOrAvg)
{
    U8BIT u8Loop = DP_1105_INITIALIZE_0;
    U8BIT u8Loop1 = DP_1105_INITIALIZE_0;
    U8BIT u8Loop2 = DP_1105_INITIALIZE_0;
    U16BIT u16MidValue = DP_1105_INITIALIZE_0;
    FDOUBLE dADCTotal = 0.0;
    FSINGLE fADCValue = 0.0;
    FSINGLE fMidADCValue = 0.0;
    //S8BIT m_szErrorMsg[50];
    FSINGLE fADCData[30];
    //FSINGLE fADCChanData[30];
    SDPMM1105_SAMPLE_INFO sSample;

    for(u8Loop = 0; u8Loop < in_u16NoOfSignals; u8Loop++)
    {
        if(MUX_1105_ValidateSignalID(in_u16SignalIdList[u8Loop]) != DP_SYS_1105_SUCCESS)
        {
            strcpy(m_szErrorMsg,"Invalid Signal ID");
            return DP_SYS_1105_FAILURE;
        }
        U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalIdList[u8Loop]);
        U8BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalIdList[u8Loop]);
        //out_dADCData[] = {0.0}f;
#ifdef _DRV5112_ENABLE
        for(u8Loop1 = 0; u8Loop1 < u8NoOfSamples; u8Loop1++)
        {
            //delay(DP_SYS_1105_READ_DELAY);
            /*This function is used to read the ADC Current Value in the CVR register for corresponding Channel */
            m_s32RetVal = DPMM1105_GetRecentSample(m_hHandle[u8BoardNo], u8ChannelNo, &sSample);
            if(m_s32RetVal != DP_SYS_1105_SUCCESS)
            {
                DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_SYS_1105_FAILURE;
            }
            fADCData[u8Loop1] = sSample.m_dSample; /*Storing the no of samples for each channels*/
            dADCTotal += sSample.m_dSample;
        }

        if(u8MeanOrAvg == DP_MM_1105_AVERAGE)
        {
            for(u8Loop = 0; u8Loop < in_u16NoOfSignals; u8Loop++)
            {
                out_fADCData[u8Loop] = dADCTotal/u8NoOfSamples; /*Receiving the Average ADC data for each channel*/
                dADCTotal = 0.0;
            }
        }
        else
        {
            for(u8Loop1 = 0; u8Loop1 < u8NoOfSamples; u8Loop1++)
            {
                for(u8Loop2 = 0; u8Loop2 < (u8NoOfSamples - u8Loop1); u8Loop2++)
                {
                    if(fADCData[u8Loop2] > fADCData[u8Loop2 + 1])
                    {
                        fMidADCValue = fADCData[u8Loop2];
                        fADCData[u8Loop2] = fADCData[u8Loop2 + 1];
                        fADCData[u8Loop2 + 1] = fMidADCValue;
                    }
                }
            }
            u16MidValue = (u8NoOfSamples + 1)/2;
            out_fADCData[u8Loop] = fADCData[u16MidValue];
        }
#endif
    }
    return DP_SYS_1105_SUCCESS;
}

/**************************************************************************
// Name						: Close
// Author					: 
// Global Variables affected: 				 
// Created Date				: 21/02/2020
// Revision Date			:
// Reason for Revising		:
// Description				:This Function is used to close the ADC Board
**************************************************************************/
S16BIT DPMM1105_Wrapper::Close(U16BIT in_u16BoardNo)
{
    U8BIT u8BoardNo = DP_1105_INITIALIZE_0;
#ifdef _DRV5112_ENABLE
    if(in_u16BoardNo)
    {
        if (in_u16BoardNo >= 1 && in_u16BoardNo <= m_u16NoOfBoards)
        {
            m_s32RetVal = DPMM1105_Close(m_hHandle[in_u16BoardNo-1]);
            if(m_s32RetVal != DP_SYS_1105_SUCCESS)
            {
                DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_SYS_1105_FAILURE;
            }
        }
        else
        {
            sprintf(m_szErrorMsg, "Invalid Bord Number");
            return DP_SYS_1105_FAILURE;
        }
    }
    else
    {
        for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfBoards); u8BoardNo++)
        {
            m_s32RetVal = DPMM1105_Close(m_hHandle[u8BoardNo]);
            if(m_s32RetVal != DP_SYS_1105_SUCCESS)
            {
                DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_SYS_1105_FAILURE;
            }
        }
    }
#endif
    return DP_SYS_1105_SUCCESS;
}
/**************************************************************************
// Name					: Reset
// Author				: 
// Global Variables affected		: 				 
// Created Date				: 21/02/2020
// Revision Date			:
// Reason for Revising			:
// Description				:This Function is used to Reset the ADC Board
**************************************************************************/
S16BIT DPMM1105_Wrapper::Reset(U16BIT in_u16BoardNo)
{
    U16BIT u8BoardNo = DP_1105_INITIALIZE_0;
#ifdef _DRV5112_ENABLE
    if(in_u16BoardNo)
    {
        if (in_u16BoardNo >= 1 && in_u16BoardNo <= m_u16NoOfBoards)
        {
            m_s32RetVal = DPMM1105_Reset(m_hHandle[in_u16BoardNo-1]);
            if(m_s32RetVal != DP_SYS_1105_SUCCESS)
            {
                DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_SYS_1105_FAILURE;
            }
        }
        else
        {
            sprintf(m_szErrorMsg, "Invalid Bord Number");
            return DP_SYS_1105_FAILURE;
        }
    }
    else
    {
        for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfBoards); u8BoardNo++)
        {
            m_s32RetVal = DPMM1105_Reset(m_hHandle[u8BoardNo]);
            if(m_s32RetVal != DP_SYS_1105_SUCCESS)
            {
                DPMM1105_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_SYS_1105_FAILURE;
            }
        }
    }
#endif
    return DP_SYS_1105_SUCCESS;
}
void DPMM1105_Wrapper::GetLastErrorMsg(PS32BIT out_ps32ErrCode, PS8BIT out_s8ErrMsg)
{
    sprintf(out_s8ErrMsg, "%s" , m_szErrorMsg);
    *out_ps32ErrCode = m_s32RetVal;
}
S16BIT DPMM1105_Wrapper::MUX_1105_ValidateSignalID(U16BIT in_usSignalId)
{
#if 1
    U8BIT u8BoardID = SID_GET_BOARD_ID(in_usSignalId);
    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_usSignalId);
    U8BIT u8ChannelNo = SID_GET_CHANNEL(in_usSignalId);


    if((u8BoardID != BRD_TYPE_MM1105_ADC) || \
            ((u8BoardNo < DP_1105_MIN_BOARDS) || (u8BoardNo > DP_1105_MAX_BOARDS)) || \
            ((u8ChannelNo < DP_1105_MIN_CHANNEL) || (u8ChannelNo > DP_1105_MAX_CHANNEL)))
    {
        return DP_SYS_1105_FAILURE;
    }
#endif	
    return DP_SYS_1105_SUCCESS;
}

