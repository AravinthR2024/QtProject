
#ifndef DPPMC5733_04_WRAPPER_H
#define DPPMC5733_04_WRAPPER_H

#include <stdio.h>
#include <stdlib.h>
#include <QString>

#include "dppmc5733_04_pro.h"
#include "dp_types.h"

#define LINS_5733_INITIALIZE_0 					0

#define DP_LINS_5733_TYPE_ID                    5

#define DP_LINS_5733_SUCCESS 					0
#define DP_LINS_5733_FAILURE 					1
#define ALL_BOARDS								0
#define DP_ALL_CHANNEL							1
#define DP_LINS_5733_TRUE						1
#define DP_LINS_5733_FALSE						0

#define DP_LINS_5733_VALUE_1					1
#define DP_LINS_5733_VALUE_0 					0

/* Configuration constants */
#define LINS_5733_ENABLE_INTERRUPT   			1
#define LINS_5733_DISABLE_INTERRUPT  			0

#define LINS_5733_SELECT_BUFFER_1               1
#define LINS_5733_SELECT_BUFFER_2               2

#define LINS_5733_START                         1
#define LINS_5733_STOP                          2

#define DP_DIO_5733_MIN_BOARDS					1
#define DP_5733_MAX_CHANNELS                		4
#define DP_DIO_5733_MAX_GROUPS					4
#define DP_BORDS_STATUS_ONE						1
#define DP_BORDS_STATUS_ZERO					0

#define DP_LINS_5733_DEVICE_NOT_FOUND			-998
#define DP_LINS_5733_DEVICE_NOT_AVAILABLE		-997


typedef struct _S_DPU_CONFIGURATION_VALUE
{
    U8BIT u8BaudRate;
    U8BIT u8StartStopBit;
    U8BIT u8ModeBit;
    U8BIT u8RspDataType;
    U8BIT u8DataByte;
    U8BIT u8MsgTime;
    U8BIT u8ModeSel;
    U8BIT u8FrameTime;
    FSINGLE fRxTimeOut;
    FSINGLE fRxRespTime;
    U32BIT u32Threshold;
}S_DPU_CONFIGURATION_VALUE;

class DPPMC5733_Wrapper
{
public:

    SDPPMC5733_04_CONFIG_INFO m_SFrame[LINS_MAX_5733_CH];
    DP_DRV_HANDLE m_hHandle[LINS_MAX_5733_BRDS];
    U16BIT m_u16NoOfBrds;
    U16BIT m_u16FPGATypeId;
    S8BIT m_szErrorMsg[100];
    S32BIT m_s32RetVal;
    U16BIT m_u16RAM_Buff_Sel;

    S16BIT Init(PSDPPMC5733_04_DEVICE_LOCATION out_pSDevLocation);
    S16BIT Configure(U16BIT in_u16ChannelNo, S_DPU_CONFIGURATION_VALUE in_sConfigValues);
    S16BIT RamSelection(U16BIT in_u16ChannelNo, U8BIT in_u8BuffSel, U8BIT in_u8StartOffset, U8BIT in_u8EndOffset, PU8BIT in_pu8CmdData);
    S16BIT TxRamSelection(U16BIT in_u16ChannelNo, U8BIT in_u8BuffSel = 1);
    S16BIT StartStopTransmission(U16BIT in_u16ChannelNo, U8BIT in_u8TxRxSel, U8BIT in_u8TxRxStartStop);
    S16BIT RxReadMessage(U16BIT in_u16ChannelNo, U8BIT u8ReadOpt, U32BIT u32Timeout, U16BIT u16DataToRead, U16BIT *pu16AvailData, U8BIT *pu8ReadData);
    QString GetLastErrorMsg();
    S16BIT Close(U16BIT in_u16ChannelNo = 0);
    S16BIT Reset(U16BIT in_u16ChannelNo = 0);
};

#endif // DPPMC5733_04_WRAPPER_H
