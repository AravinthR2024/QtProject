/**************************************************************************
// File Name:DPCPCI3096_Wrapper.c 
// Author:
// Created Date:13/02/2020
// Description:Declared for the Wrapper Function.
**************************************************************************/
#ifndef _DP_LINS_CPCI_3096_WRAPPER_H
#define _DP_LINS_CPCI_3096_WRAPPER_H

#include <stdio.h>
#include <stdlib.h>

#include "dpcpci3096_pro.h"
#include "dp_types.h"
#include "dp-lins-cm_signals.h"

#include "dp-simulator.h"
#include <QTcpSocket>


#define LINS_3096_INITIALIZE_0 					0

#define DP_LINS_3096_SUCCESS 					0
#define DP_LINS_3096_FAILURE 					1
#define ALL_BOARDS								0
#define DP_ALL_CHANNEL							1
#define DP_LINS_3096_TRUE						1
#define DP_LINS_3096_FALSE						0
				
#define DP_LINS_3096_VALUE_1					1
#define DP_LINS_3096_VALUE_0 					0

#define DP_CPCI_3096_SET_OP_DELAY               700

/* Configuration constants */
#define LINS_3096_ENABLE_INTERRUPT   			1
#define LINS_3096_DISABLE_INTERRUPT  			0

#define LINS_3096_DIP_CONFIG_ALL_GROUP			0
#define LINS_3096_DIP_CONFIG_EDGE_EVEMENT_MODE  1
#define LINS_3096_DIP_CONFIG_GROUP_STROBE_SEL  	0
#define LINS_3096_DIP_CONFIG_DIS_SELFTEST  		0

#define LINS_3096_DIP_BIT_POS_1 				0x0001


#define DP_DIO_3096_MIN_BOARDS					1
#define DP_DIO_3096_MAX_BOARDS					3
#define DP_DIO_3096_MAX_GROUPS					3
#define DP_BORDS_STATUS_ONE						1
#define DP_BORDS_STATUS_ZERO					0

#define DP_DIO_3096_MIN_CHANNEL   				1
#define DP_DIO_3096_MAX_CHANNEL   				48

#define DP_DIO_3096_MAX_SIGNALS   				144

#define LINS_3708_MAX_ERRORMSG_SIZE				256

#define LINS_3096_MAX_GRP_CHANNELS          	16
#define LINS_3096_PRIMARY_LATCH					0
#define LINS_3096_SECONDARY_LATCH				1

#define DP_DIO_3096_ENABLE_OUTPUT				1
#define DP_DIO_3096_ACTUAL_INPUT				0

#define DP_LINS_3096_DEVICE_NOT_FOUND			-998
#define DP_LINS_3096_DEVICE_NOT_AVAILABLE		-997
typedef struct
{
	U8BIT u8BusNo;
	U8BIT u8SlotNo;
	U8BIT u8FunctionNo;
	S8BIT s8BoardSts;
    U8BIT u8ExpSlotNo;
}SDPCPCI3096_DeviceLocation, *PSDPCPCI3096_DeviceLocation;

typedef struct 
{
	U8BIT u8BusNo;
	U8BIT u8SlotNo;
	U8BIT u8FunctionNo;
}SDPCPCI3096APP_DeviceLocation,*PSDPCPCI3096APP_DeviceLocation;

class DPCPCI3096_Wrapper
{

public:
    U16BIT m_u16NoOfDetBoards;
    PSDPCPCI3096_DeviceLocation m_pSAllDevLocDetails;
    QTcpSocket m_SimSocket;

    private:
        U16BIT m_u16NoOfBoards;
        char m_cSimEnable;

		DP_DRV_HANDLE m_hHandle[DP_DIO_3096_MAX_BOARDS];
		S8BIT m_szErrorMsg[100]; 
		S32BIT m_s32RetVal;	
		S16BIT CPCI3096_ValidateSignalID(U16BIT in_u16SignalId);
	public:
		//S16BIT Init(PSDPCPCI3096APP_DeviceLocation in_pSDevLocation[3], PSDPCPCI3096_DeviceLocation out_pSDevLocation[3]);
        S16BIT Init(U16BIT u16NoOfBoards, PSDPCPCI3096APP_DeviceLocation in_pSDevLocation, PSDPCPCI3096_DeviceLocation out_pSDevLocation);
		S16BIT Configure();
		S16BIT ReadInput(U16BIT in_u16SignalId, PU8BIT out_pu8InpData); /*Signal ID specifies the board number, group number and channel number*/
		S16BIT ReadGroupInput(U16BIT in_u16SignalId, PU16BIT out_pu16Data); /*Signal ID specifies the board number, group number*/
        S16BIT ReadAllInput(U16BIT in_u16SignalId, U16BIT out_u16Data[3]); /*Signal ID specifies the board number*/
		
		S16BIT SetOutput(U16BIT in_u16SignalId, U8BIT in_u8Data);/*Signal ID specifies the board number, group number and channel number*/
		S16BIT SetGroupOutput(U16BIT in_u16SignalId, U16BIT in_u16Data);/*Signal ID specifies the board number, group number*/

		S16BIT SetAllOutput(U16BIT in_u16SignalId, U16BIT in_u16Data[3]); /*Signal ID specifies the board number*/
		
		S16BIT ReadbackOutput(U16BIT in_u16SignalId, U8BIT in_u8PriSec, PU8BIT out_pu8Data); /*Signal ID specifies the board number, group number and channel number*/
		S16BIT ReadbackGroupOutput(U16BIT in_u16SignalId, U8BIT in_u8PriSec, PU16BIT out_pu16Data); /*Signal ID specifies the board number, group number*/
		S16BIT ReadbackAllOutput(U16BIT in_u16SignalId, U8BIT in_u8PriSec, U16BIT out_u16Data[3]); /*Signal ID specifies the board number*/
		void GetLastErrorMsg(PS32BIT out_ps32ErrCode, PS8BIT out_s8ErrMsg);
		S16BIT Close(U16BIT in_u16BoardNo = 0);
		S16BIT Reset(U16BIT in_u16BoardNo = 0);
		
		
        S16BIT EnableSimulator(char in_Enable, char *in_pHostName, unsigned int in_iPort);
};

#endif //_DP_LINS_VME_3096_WRAPPER_H
