/**
 *	\file dpmm1123_err.h
 *	\brief This file contains the  error code definition
 *
 *	This file contains the  error code definition
 *
 *	\author rohith.praveen 
 *	\date 05:45PM on August 19, 2021
 *
 *	\version
 *	- Initial version
 *
 *	Copyright (C) 2021 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
 *	All Rights Reserved.\n
 *	Address:	Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
 *				Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
 *				Chennai-603103 | India\n
 *				Website : http://www.datapatternsindia.com/\n
 *				Phone: 91-44-4741-4000\n
 *				FAX: 91-44-4741-4444 \n
 *
	////////////////////////////REVISION LOG ENTRY//////////////////////////////////
	Date		Version Number	     Reason for Revision	Revised by 
	----		--------------		 -------------------	----------
									 

	 
*/
#ifndef _DPMM1123_ERR_H
#define _DPMM1123_ERR_H

#define DPMM1123_SUCCESS		0
#define DPMM1123_FAILURE        -1


/**
* This list the enumeration of driver error values 
*/ 
enum DPMM1123_ERROR_MACROS{
	DP_DRV_ERR_INVALID_HANDLE = -999,				/*!< (-999) 	Invalid Handle*/
	DP_DRV_ERR_INVALID_POINTER,						/*!< (-998) Invalid Pointer*/
	DP_DRV_ERR_INVALID_PARAM,						/*!< (-997) Invalid Param*/
	DP_DRV_ERR_MEM_ALLOCATION,						/*!< (-996) Mem Allocation*/
	DP_DRV_ERR_NO_ZEROTH_DEVICE,					/*!< (-995) No Zeroth Device*/
	DP_DRV_ERR_DEVICE_NOT_OPEN,						/*!< (-994) Device Is Not Open*/
	DP_DRV_ERR_INVALID_SHARE_VALUE,					/*!< (-993) Invalid Share Value*/
	DP_DRV_ERR_INVALID_DEVICE_REQUEST,				/*!< (-992) Invalid Device Request*/
	DPMM1123_ERR_INVALID_PARAM,						/*!< (-991) Invalid Param*/
	DPMM1123_ERR_DEVICE_BUSY,						/*!< (-990) Device Busy*/
	DPMM1123_ERR_NO_DEVICE_FOUND,					/*!< (-989) No Device Found*/
	DPMM1123_ERR_INVALID_FLAG,						/*!< (-988) Invalid Flag*/
	DPMM1123_ERR_INVALID_ENDIS,						/*!< (-987) Invalid Endis*/
	DPMM1123_ERR_INVALID_CHANNELNO,					/*!< (-986) Invalid Channelno*/
	DPMM1123_ERR_INVALID_ACQURACYMODE,				/*!< (-985) Invalid Accuracymode*/
	DPMM1123_ERR_INVALID_ACQUISITIONRATE,			/*!< (-984) Invalid Acquisitionrate*/
	DPMM1123_ERR_INVALID_EXCITATIONVOLT,			/*!< (-983) Invalid Excitationvolt*/
	DPMM1123_ERR_INVALID_THRESHOLD,					/*!< (-982) Invalid Threshold*/
	DPMM1123_ERR_INVALID_ENADISFIFO,				/*!< (-981) Invalid Enadisfifo*/
	DPMM1123_ERR_INVALID_INTENDIS,					/*!< (-980) Invalid Intendis*/
	DPMM1123_ERR_INVALID_SWBUFFERSIZE,				/*!< (-979) Invalid Swbuffersize*/
	DPMM1123_ERR_INVALID_ENADIS,					/*!< (-978) Invalid Enadis*/
	DPMM1123_ERR_INVALID_REFVOLTFLAG,				/*!< (-977) Invalid Refvoltflag*/
	DPMM1123_ERR_INVALID_REFVOLT,					/*!< (-976) Invalid Refvolt*/
	DPMM1123_ERR_INVALID_CALIBRATIONTYPE,			/*!< (-975) Invalid Calibrationtype*/
	DPMM1123_ERR_INVALID_BRIDGECOMPLETION,			/*!< (-974) Invalid Bridegecompletion*/
	DPMM1123_ERR_INVALID_FIFOOUTPUTMODE,			/*!< (-973) Invalid Fifooutputmode*/
	DPMM1123_ERR_ACQUISITION_IN_PROGRESS,			/*!< (-972) Error Acquisition is in progress*/
	DPMM1123_ERR_ADC_OUT_OF_RANGE,					/*!< (-971) Error ADC Value Out of Range*/
	DPMM1123_ERR_TARE,								/*!< (-970) Error in Tare*/
	DPMM1123_ERR_ACQUISITION_NOT_STARTED,			/*!< (-969) Error Acquisition is not yet started*/
	DPMM1123_ERR_0V_EXCITATION,						/*!< (-968) Error Strain can't be calculated for excitation 0V*/
	DPMM1123_ERR_CALIB_LOW_NOT_DONE,				/*!< (-967) Error Lower reference voltage not calibrated*/
	DPMM1123_ERR_ISR_REG,							/*!< (-966) Error ISR Register*/
	DPMM1123_ERR_DETACH,							/*!< (-965) Detach Inerrupt Fail*/                      
	DPMM1123_ERR_CALIBRATION,						/*!< (-964) Calibration failed due to ADC out of Range*/ 
	DPMM1123_ERR_EEPROM_READ_FAILURE,				/*!< (-963) EEPROM Read Fail*/
	DPMM1123_ERR_EEPROM_WRITE_FAILURE,				/*!< (-962) EEPROM Write Fail*/ 
	DPMM1123_ERR_INT_NOT_ENABLED,					/*!< (-961) Interrupt not enabled */
	DPMM1123_ERR_TIMEOUT,							/*!< (-960)	Timeout error */
	DPMM1123_ERR_EVENT_WAIT,						/*!< (-959)	Event wait error */ 
};
#endif
