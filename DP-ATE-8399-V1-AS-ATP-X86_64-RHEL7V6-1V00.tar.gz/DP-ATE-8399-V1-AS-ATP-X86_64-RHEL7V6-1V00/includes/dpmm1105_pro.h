/**
* \file dpmm1105_pro.h
* \brief This file contains the function prototypes of all the functions or API's are available in this file
*
* \author Harish Babu G K
* \date  25 February, 2019
*
* \version   1.00
*
* \copyright Copyright (C) 2019 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
* Phone: 91-44-4741-4000\n
* FAX: 91-44-4741-4444 \n
*
*/

#ifndef _DPMM1105_PRO_H_
#define _DPMM1105_PRO_H_

#include "dp_types.h"

#if defined(__cplusplus) || defined(__cplusplus__)
extern 	"C" {
#endif

	/*!
		This maxiumum bar macro is defined as six and used to carrier bar information
	*/
#define DPMM1105_MAX_BARS 6

	/***********************************Structures************************/
#pragma pack(push,1)
/**
*\struct    _SDPMM1105_DEVICE_LOCATION
*\brief  	This structure contains members to hold the device locations details
*
*			The device location details includes the bus number, slot number, function number and channel number.
*
*\var		typedef struct _SDPMM1105_DEVICE_LOCATION SDPMM1105_DEVICE_LOCATION
*\brief		Indicates type definition for device location structure
*
*			This SDPMM1105_DEVICE_LOCATION type definition macro is used in all place instead of struct _SDPMM1105_DEVICE_LOCATION.
*
*\var 		typedef struct _SDPMM1105_DEVICE_LOCATION *PSDPMM1105_DEVICE_LOCATION
*\brief 	Indicates type definition for device location structure pointer
*
*			This PSDPMM1105_DEVICE_LOCATION type definition macro is used in all place instead of struct _SDPMM1105_DEVICE_LOCATION pointer.
*/
typedef struct _SDPMM1105_DEVICE_LOCATION
{
	U8BIT m_u8BusType;				/*!< Device bus type */
	union
	{
		struct
		{
			U8BIT m_u8BusNo;		/*!< Bus number */
			U8BIT m_u8SlotNo;		/*!< Slot number */
			U8BIT m_u8FunctionNo;	/*!< Function number */
		}pci;
	}u;
	U8BIT 	m_u8MMSlotNo;	/*!< Slot number */
}SDPMM1105_DEVICE_LOCATION, *PSDPMM1105_DEVICE_LOCATION;

/**
*\struct    _SDPMM1105_DRIVER_DETAILS
*\brief  	This structure contains members to hold the driver details
*
*			The driver details includes the driver version.
*
*\var		typedef struct _SDPMM1105_DRIVER_DETAILS SDPMM1105_DRIVER_DETAILS
*\brief		Indicates type definition for driver details structure
*
*			This SDPMM1105_DRIVER_DETAILS type definition macro is used in all place instead of struct _SDPMM1105_DRIVER_DETAILS.
*
*\var 		typedef struct _SDPMM1105_DRIVER_DETAILS *PSDPMM1105_DRIVER_DETAILS
*\brief 	Indicates type definition for driver details structure pointer
*
*			This _SDPMM1105_DRIVER_DETAILS type definition macro is used in all place instead of struct PSDPMM1105_DRIVER_DETAILS pointer.
*/
typedef struct _SDPMM1105_DRIVER_DETAILS
{
	U32BIT m_u32Version;	/*!< Driver version */
}SDPMM1105_DRIVER_DETAILS, *PSDPMM1105_DRIVER_DETAILS;

/**
*\struct 	_SDPMM1105_DEVICE_DETAILS
*\brief		This structure contains members to hold the device details
*
*			This device details includes device Id
*
*\var		typedef struct _SDPMM1105_DEVICE_DETAILS SDPMM1105_DEVICE_DETAILS
*\brief		Indicates type definition for device details structure
*
*			This SDPMM1105_DEVICE_DETAILS type definition macro is used in all place instead of struct _SDPMM1105_DEVICE_DETAILS.
*
*\var 		typedef struct _SDPMM1105_DEVICE_DETAILS *PSDPMM1105_DEVICE_DETAILS
*\brief 	Indicates type definition for device details structure pointer
*
*			This _SDPMM1105_DEVICE_DETAILS type definition macro is used in all place instead of struct PSDPMM1105_DEVICE_DETAILS pointer.
*/
typedef struct _SDPMM1105_DEVICE_DETAILS
{
	U16BIT	m_u16DeviceId;					/*!< Board ID*/
}SDPMM1105_DEVICE_DETAILS, *PSDPMM1105_DEVICE_DETAILS;

/**
*\struct 	_SDPMM1105_BAR_INFO
*\brief		This structure contains members to hold the bar information details
*
*			This bar information includes io or memory mapped, physical address, bar size
*
*\var		typedef struct _SDPMM1105_BAR_INFO SDPMM1105_BAR_INFO
*\brief		Indicates type definition for bar information structure
*
*			This SDPMM1105_BAR_INFO type definition macro is used in all place instead of struct _SDPMM1105_BAR_INFO.
*
*\var 		typedef struct _SDPMM1105_BAR_INFO *PSDPMM1105_BAR_INFO
*\brief 	Indicates type definition for bar information structure pointer
*
*			This PSDPMM1105_BAR_INFO type definition macro is used in all place instead of struct _SDPMM1105_BAR_INFO pointer.
*/
typedef struct _SDPMM1105_BAR_INFO
{
	U8BIT   m_u8IsIoMapped;				/*!< Io mapped or Memory mapped */
	U32BIT  m_u32BarSize;				/*!< Bar Size */
	U32BIT  m_u32PhysicalAddressLSB;	/*!< Physical address of LSB */
	U32BIT  m_u32PhysicalAddressMSB;	/*!< Physical address of MSB */
	U32BIT  m_u32VirtualAddressLSB;		/*!< Virtual Address of LSB*/
	U32BIT  m_u32VirtualAddressMSB;		/*!< Virtual Address of MSB*/
}SDPMM1105_BAR_INFO, *PSDPMM1105_BAR_INFO;

/**
*\struct 	_SDPMM1105_CARRIER_DEVICE_INFO
*\brief		This structure contains members to hold the carrier device information details
*
*			This carrier device information includes device Id, Irq line, bar information and device location
*
*\var		typedef struct _SDPMM1105_CARRIER_DEVICE_INFO SDPMM1105_CARRIER_DEVICE_INFO
*\brief		Indicates type definition for carrier device information structure
*
*			This SDPMM1105_CARRIER_DEVICE_INFO type definition macro is used in all place instead of struct _SDPMM1105_CARRIER_DEVICE_INFO.
*
*\var 		typedef struct _SDPMM1105_CARRIER_DEVICE_INFO *PSDPMM1105_CARRIER_DEVICE_INFO
*\brief 	Indicates type definition for carrier device information structure pointer
*
*			This PSDPMM1105_CARRIER_DEVICE_INFO type definition macro is used in all place instead of struct _SDPMM1105_CARRIER_DEVICE_INFO pointer.
*/
typedef struct _SDPMM1105_CARRIER_DEVICE_INFO
{
	U8BIT				m_u8IrqLine;			/*!< Carrier irq line number */
	U16BIT 				m_u16DeviceId;			/*!< Carrier device id */
	SDPMM1105_BAR_INFO	m_SBarInfo[DPMM1105_MAX_BARS];	/*!< Bar information */
	SDPMM1105_DEVICE_LOCATION	m_SMMDeviceLocation;
}SDPMM1105_CARRIER_DEVICE_INFO, *PSDPMM1105_CARRIER_DEVICE_INFO;

/**
*\struct 	_SDPMM1105_INTERRUPT_INFO
*\brief		This structure contains members to hold the interrupt enable details
*
*			This interrupt details includes interrupt enable and FIFO threshold values
*
*\var		typedef struct _SDPMM1105_INTERRUPT_INFO SDPMM1105_INTERRUPT_INFO
*\brief		Indicates type definition for interrupt details information structure
*
*			This SDPMM1105_INTERRUPT_INFO type definition macro is used in all place instead of struct _SDPMM1105_INTERRUPT_INFO.
*
*\var 		typedef struct _SDPMM1105_INTERRUPT_INFO *PSDPMM1105_INTERRUPT_INFO
*\brief 	Indicates type definition for carrier device information structure pointer
*
*			This PSDPMM1105_INTERRUPT_INFO type definition macro is used in all place instead of struct _SDPMM1105_INTERRUPT_INFO pointer.
*/
typedef struct _SDPMM1105_INTERRUPT_INFO
{
	U8BIT		m_u8InterruptEnable;	/*!< Interrupt Enable */
	U16BIT 		m_u16FIFOThreshold;		/*!< FIFO Threshold Val */
	U16BIT 		m_u16BuffSize;			/*!< create buffer in the driver to store interrupt data, minimum 4KB and maximum 16KB*/
}SDPMM1105_INTERRUPT_INFO, *PSDPMM1105_INTERRUPT_INFO;

/*!
*\struct	_SDPMM1105_ADC_CONFIGURATION
*\brief		This structure contains members to hold the ADC configuration details.
*
*			The ADC configuration details include the input signal type, pacer source, pacer frequency, trigger type, continuous trigger type, external trigger type, time period, threshold buffer level value and source type,
*
*\var		typedef struct _SDPMM1105_ADC_CONFIGURATION SDPMM1105_ADC_CONFIGURATION
*\brief		Indicates type definition for ADC configuration structure
*
*			This SDPMM1105_ADC_CONFIGURATION type definition macro is used in all place instead of struct _SDPMM1105_ADC_CONFIGURATION.
*
*\var 		typedef struct _SDPMM1105_ADC_CONFIGURATION *PSDPMM1105_ADC_CONFIGURATION
*\brief 	Indicates type definition for ADC configuration structure pointer
*
*			This PSDPMM1105_ADC_CONFIGURATION type definition macro is used in all place instead of struct _SDPMM1105_ADC_CONFIGURATION pointer.
*/
typedef struct _SDPMM1105_ADC_CONFIGURATION
{
	U8BIT	m_u8InputSignalType;		/*!< It specifies the input signal type of the board. \n 1 – Single-ended Mode,\n 0 – Differential Mode */
	U8BIT	m_u8PacerSource;			/*!< It specifies the pacer source. \n 0 – Internal, \n 1 – External, \n 2 – Software Pacer (Software Convert Command) */
	U8BIT  m_u8SourceType;				/*!< It specifies the source type. \n 1 - Voltage, \n 2 - Current. */
	U8BIT	m_u8TriggerType;			/*!< It specifies the trigger type. \n 0 – Internal Trigger (through software), \n 1 – External Trigger */
	U8BIT	m_u8ContiniousTriggerType;	/*!< It specifies the continuous trigger type. \n 0 – No continuous trigger, \n 1 – Timer Trigger, \n 2 – Continuous Internal Trigger. */
	U8BIT	m_u8ExternalTriggerType;	/*!< It specifies the external trigger type. \n 0 – Positive / Rising Edge Sensitive, \n 1 – Negative / Falling Edge Sensitive */
	U16BIT	m_u16TimePeriod;			/*!< It specifies the time period between two successive triggers, if Timer Trigger is enabled. (Timer values in multiples of 100 microseconds). */
	FSINGLE	m_fPacerFrequency;			/*!< It specifies the pacer frequency(0.01 Hz to 100000 Hz). If Pacer source is selected as internal then maximum value for pacer frequency of a particular channel can be 100000 Hz, but if more than one channel is configured then the maximum pacer frequency will be 80000 Hz. */
}SDPMM1105_ADC_CONFIGURATION, *PSDPMM1105_ADC_CONFIGURATION;

/**
*\struct	_SDPMM1105_SCAN_BUFFER
*\brief		This structure contains members to hold scan buffer details
*
*			The scan buffer details includes the channel number, gain, fifo write enable, end of scan
*
*\var		typedef struct _SDPMM1105_SCAN_BUFFER SDPMM1105_SCAN_BUFFER
*\brief		Indicates type definition for scan buffer structure
*
*			This SDPMM1105_SCAN_BUFFER type definition macro is used in all place instead of struct _SDPMM1105_SCAN_BUFFER.
*
*\var 		typedef struct _SDPMM1105_SCAN_BUFFER *PSDPMM1105_SCAN_BUFFER
*\brief 	Indicates type definition for scan buffer structure pointer
*
*			This PSDPMM1105_SCAN_BUFFER type definition macro is used in all place instead of struct _SDPMM1105_SCAN_BUFFER pointer.
*/
typedef struct _SDPMM1105_SCAN_BUFFER
{
	U8BIT  m_u8ChannelNo;		/*!< Channel number of ADC*/
	U8BIT  m_u8Gain;			/*!< Gain */
	U8BIT  m_u8FifoWrEnb;		/*!< Enable or Disable FIFO  if FIFO enable */
}SDPMM1105_SCAN_BUFFER, *PSDPMM1105_SCAN_BUFFER;

/**
*\struct	_SDPMM1105_CALIB_DATE
*\brief		This structure contains members to hold calibration details
*
*			The calibration details includes the signal type(single-ended or differential ended, gain, slope and constant)
*
*\var		typedef struct _SDPMM1105_CALIB_DATE SDPMM1105_CALIB_DATE
*\brief		Indicates type definition for calibration details structure
*
*			This SDPMM1105_CALIB_DATE type definition macro is used in all place instead of struct _SDPMM1105_CALIB_DATE.
*
*\var 		typedef struct _SDPMM1105_CALIB_DATE *PSDPMM1105_CALIB_DATE
*\brief 	Indicates type definition for scan buffer structure pointer
*
*			This PSDPMM1105_CALIB_DATE type definition macro is used in all place instead of struct _SDPMM1105_CALIB_DATE pointer.
*/
typedef struct _SDPMM1105_CALIB_DATE
{
	U8BIT m_u8Day;		/*!<Day of Calibration */
	U8BIT m_u8Month;	/*!<Month of Calibration */
	U16BIT m_u16Year;	/*!<Year of Calibration */
	U8BIT m_u8Hour;		/*!<hour of Calibration */
	U8BIT m_u8Minute;	/*!<Minute of Calibration */
	U8BIT m_u8Seconds;	/*!<Second of Calibration */
	U8BIT m_u8Reserved;	/*!<Second of Calibration */
}SDPMM1105_CALIB_DATE, *PSDPMM1105_CALIB_DATE;

/**
*\struct	_SDPMM1105_CALIB_DETAILS
*\brief		This structure contains members to hold calibration details
*
*			The calibration details includes the signal type(single-ended or differential ended, gain, slope and constant)
*
*\var		typedef struct _SDPMM1105_CALIB_DETAILS SDPMM1105_CALIB_DETAILS
*\brief		Indicates type definition for calibration details structure
*
*			This SDPMM1105_CALIB_DETAILS type definition macro is used in all place instead of struct _SDPMM1105_CALIB_DETAILS.
*
*\var 		typedef struct _SDPMM1105_CALIB_DETAILS *PSDPMM1105_CALIB_DETAILS
*\brief 	Indicates type definition for scan buffer structure pointer
*
*			This PSDPMM1105_CALIB_DETAILS type definition macro is used in all place instead of struct _SDPMM1105_CALIB_DETAILS pointer.
*/
typedef struct _SDPMM1105_CALIB_DETAILS
{
	U8BIT  m_u8InputSignalType; /*!< single type i.e single ended or differential*/
	U8BIT  m_u8SourceType;		/*!< source type i.e voltage or current*/
	U8BIT  m_u8Gain;			/*!< Gain */
	U16BIT m_u16CheckSum[2];		/*!< This will give checksum of FILE/EEPROM which contains calibration information*/
	U16BIT m_u16BoardSlNo;       /*!< Board Serial No to store in EEPROM/FILE*/
	U16BIT m_u16DeviceId;      	/*!< Device Id to store in EEPROM/FILE*/
	FSINGLE m_fSlope;			/*!< Slope*/
	FSINGLE m_fConstant;		/*!< Constant */
	SDPMM1105_CALIB_DATE	m_sCalibrationDate;	/*!< Calibration date and time*/
}SDPMM1105_CALIB_DETAILS, *PSDPMM1105_CALIB_DETAILS;

/**
*\struct	_SDPMM1105_SAMPLE_INFO
*\brief		This structure contains members to hold the ADC sample details
*
*			The sample details includes the sample, channel number and gain
*
*\var		typedef struct _SDPMM1105_SAMPLE_INFO SDPMM1105_SAMPLE_INFO
*\brief		Indicates type definition for ADC sample structure
*
*			This SDPMM1105_SAMPLE_INFO type definition macro is used in all place instead of struct _SDPMM1105_SAMPLE_INFO.
*
*\var 		typedef struct _SDPMM1105_SAMPLE_INFO *PSDPMM1105_SAMPLE_INFO
*\brief 	Indicates type definition for sADC sample structure pointer
*
*			This PSDPMM1105_SAMPLE_INFO type definition macro is used in all place instead of struct _SDPMM1105_SAMPLE_INFO pointer.
*/
typedef struct _SDPMM1105_SAMPLE_INFO
{
	FDOUBLE m_dSample;  	/*!< It holds 16 bit ADC sample data*/
	U8BIT m_u8ChannelNo;	/*!< Channel number */
	U8BIT m_u8Gain;		/*!< Gain */
}SDPMM1105_SAMPLE_INFO, *PSDPMM1105_SAMPLE_INFO;
#pragma pack(pop)

/**************************** function  prototypes ******************************/
/*!
*	\addtogroup Common_Functions List of common driver functions
* @{
*/

/**
*\brief		This function is used to detect all the MM module and register the 1105 module
*
*\param[in]	in_u16TotalCarrierBoards	It specifies the total carrier boards
*\param[in] in_pSAllDevInfoDetails		It specifies the all carrier boards device location details
*\param[in] in_u8Flag					It specifies whether the carrier device is DP boards or other customer boards(max:1)(0 - DP Boards 1 - Other Boards)
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the input device location pointer is null
*\retval	::DPMM1105_ERR_INVALID_FLAG is returned if the flag value is out of limit(0 to 1)
*
*\pre		::DPMM1105_Open
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_SetResource(U16BIT in_u16TotalCarrierBoards, PSDPMM1105_CARRIER_DEVICE_INFO in_pSAllDevInfoDetails, U8BIT in_u8Flag);

/**
*\brief		This function is used to find the total number of DP-MM-1105 device(s) present in the system
*
*\param[out] out_pu16TotalDevices	It specifies the output pointer to hold the number of DP-MM-1105 device(s) found
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified total devices output pointer is null
*
*\pre		NA
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_GetTotalDeviceFound(PU16BIT out_pu16TotalDevices);

/**
*\brief		This function is used to get pci details such as bus number, slot number and function number for the DP-MM-1105 device(s)
*
*\param[out] out_pSAllDevLocDetails		It specifies the output pointer to hold the device location details(size:in_u16MaxDevices)
*\param[in]  in_u16MaxDevices			It specifies the total number of DP-MM-1105 device(s) found
*
*\retval	 ::DPMM1105_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_POINTER is returned if the output device location details structure pointer is null
*
*\pre		 ::DPMM1105_GetTotalDeviceFound
*\post		 ::DPMM1105_GetErrorMessage
*
*\author	 Harish Babu G K
*\date		 25 February, 2019
*/
S32BIT STDCALL DPMM1105_GetAllDeviceLocations(PSDPMM1105_DEVICE_LOCATION out_pSAllDevLocDetails, U16BIT in_u16MaxDevices);

/**
*\brief 	 This function is used to open the specified DP-MM-1105 device.
*
*\param[in]	 in_pSDeviceOpenInfo	It specifies the MM Slot Number, bus number, slot number and function number
*\param[out] out_phDeviceHandle		It specifies the pointer to hold output device handle
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the device location structure pointer is null
*\retval	::DPMM1105_ERR_DEVICE_BUSY is returned if the the device is already opened
*
* \pre		::DPMM1105_GetAllDeviceLocations
* \post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_Open(PSDPMM1105_DEVICE_LOCATION in_pSDeviceOpenInfo, DP_DRV_HANDLE out_phDeviceHandle);

/**
*\brief		This function is used to close the opened device. Any opened device has to be closed before the application is exited.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_DEVICE_NOT_OPEN is returned if the device is not opened
*
*\pre		::DPMM1105_Open
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_Close(DP_DRV_HANDLE in_hHandle);

/**
*\brief		This function is used to get opened device location details(MM Slot number, bus number, slot number and function number)
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_pSDeviceLocation	It specifies the pointer to hold the device location details
*
*\retval	::DPMM1105_SUCCESS	is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output device location pointer is null
*
*\pre		::DPMM1105_Open
*\post		::DPMM1105_GetErrorMessage
*
*\author	 Harish Babu G K
*\date		 25 February, 2019
*/
S32BIT STDCALL DPMM1105_GetDeviceLocation(DP_DRV_HANDLE in_hHandle, PSDPMM1105_DEVICE_LOCATION out_pSDeviceLocation);

/**
*\brief 	 This function is used to reset the device to initial state
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	 ::DPMM1105_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		 ::DPMM1105_Open
*\post		 ::DPMM1105_GetErrorMessage
*
*\author	 Harish Babu G K
*\date		 25 February, 2019
*/
S32BIT STDCALL DPMM1105_Reset(DP_DRV_HANDLE in_hHandle);

/**
*\brief		 This function is used to get the error message corresponding to the error code. The error message specify briefly the cause of the error.
*
*\param[in]  in_s32ErrCode	It specifies the error code returned by the functions
*\param[out] out_ps8ErrMsg	It specifies the pointer to hold the error message(size:in_u16BufSize)
*\param[in]  in_u16BufSize	It specifies buffer size to hold the error message
*
*\retval	 ::DPMM1105_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_POINTER is returned if the output error message pointer is null
*
*\pre	 	 ::DPMM1105_Open
*\post	 	 NA
*
*\author	 Harish Babu G K
*\date		 25 February, 2019
*/
S32BIT STDCALL DPMM1105_GetErrorMessage(S32BIT in_s32ErrCode, PS8BIT out_ps8ErrMsg, U16BIT in_u16BufSize);

/**
*\brief		This function is used to get the driver details(Driver Version)
*
*\param[out] out_pSDriverDetails 	It specifies the structure pointer to read the driver details(Driver Version)
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output driver details pointer is null
*
*\pre		NA
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_GetDriverDetails(PSDPMM1105_DRIVER_DETAILS out_pSDriverDetails);

/**
*\brief         This function is used to get board ID
*
*\param[in]     in_hHandle	      It specifies the device handle which got from device open function
*\param[out]  	out_pSDeviceDetails   It specifies the pointer to read the board ID
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\return        ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output driver details pointer is null
*
*\pre		NA
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_GetDeviceDetails(DP_DRV_HANDLE in_hHandle, PSDPMM1105_DEVICE_DETAILS out_pSDeviceDetails);

/**
*\brief		This function is used to write data into the specified FPGA register offset
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_u32Offset	It specifies the offset value of selected device
*\param[in] in_u32WriteData	It specifies the the data to be written in specified register offset
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DPMM1105_Open
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_WriteReg(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, U32BIT in_u32WriteData);

/**
*\brief 	 This function is used to read data from the specified FPGA register offset
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[out] out_pu32ReadData	It specifies the pointer to read data from specified register offset
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified read data output pointer is null
*
*\pre		::DPMM1105_Open
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_ReadReg(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, PU32BIT out_pu32ReadData);

/**
*\brief		This function is used to enable or disable(1 - Enable, 0 - Disable) the device share option(opening same device more than one time)
*
*\param[in]	in_hHandle	It specifies the device handle which is obtained from device open function
*\param[in]	in_u8EnDis	It specifies the enable / disable value(max:1)
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1105_ERR_INVALID_ENDIS is returned if the enable / disable device share option is out of limit(0 to 1)
*
*\pre		::DPMM1105_Open
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_SetDeviceShare(DP_DRV_HANDLE in_hHandle, U8BIT in_u8EnDis);

/*!
* @}
*/

/******************************* Board Specific ************************************/
/*!
*	\addtogroup Board_Functions List of device specific driver functions
* @{
*/

/**
*\brief		This function is used to configure the ADC device. The ADC configuration structure details are mentioned below
* <ul>
*			<li> <b> Input Signal Type </b> member is used to configure the device input type as either <b> Single-ended Mode </b> or <b> Differential Mode</b>.
*			<li> <b> Pacer Source* </b> member is used to select whether the pacer source is <b> Internal </b> or <b> External</b>.
*			<li> <b> Pacer Frequency </b> member is used to configure the internal pacer source frequency. If external pacer source is selected, this value will not be considered.
*			<li> <b> Trigger Type* </b> member is used to select whether the trigger type is <b> Internal </b> or <b> External</b>.
*			<li> <b> Continuous Trigger Type </b> member is used to select any one of the following trigger.
*				<ol>
*				<li> <b> Continuous Trigger </b> is used to triggers the device continuously without delay.
*				<li> <b> Timer Trigger </b> is used to triggers the device periodically.
*				<li> <b> No Continuous </b> is used to triggers the device only once.
*				</ol>
*			<li> <b> Time Period </b> member is used to configure the delay / time if timer trigger is selected.
*			<li> <b> External Trigger Type </b> member is used to select whether <b> Positive Edge Trigger </b> or <b> Negative Edge Trigger</b>. And for external trigger type there is no continuous trigger.
*			<li> <b> Buffer Size </b> member is used to specifies the threshold value of the FIFO. When the FIFO has reached the threshold value an interrupt will be generated.
*			<li> <b> Source Type </b> member is used to select whether the input source type is <b> Voltage </b> or <b> Current </b>
*</ul>
*\note		<ul> <li> <b> External Pacer Source </b> and <b> External Trigger </b> should not be selected simultaneously. </ul>
*\note		<ul> <li> For external input, refer hardware user manual </ul>
*
*\param[in]	in_hHandle 		It specifies the device handle which is obtained from device open function.
*\param[in]	in_pSADCConfig	It specifies the structure pointer to hold the ADC configuration details. Refer _SDPMM1105_ADC_CONFIGURATION structure for details.
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1105_ERR_ACQUISITION_IN_PROGRESS is returned if the ADC acquisition already in progress
*\retval	::DPMM1105_ERR_INVALID_INPUTSIGNALTYPE is returned if the input signal type selection is out of limit(0 to 1)
*\retval	::DPMM1105_ERR_INVALID_PACER_SOURCE is returned if the pacer source type selection is out of limit(0 to 2)
*\retval	::DPMM1105_ERR_INVALID_PACER_FREQUENCY is returned if the pacer frequency selection is out of limit(0.01 Hz to 100000 Hz). If pacer source is selected as internal then maximum value for pacer frequency of a particular channel can be 100000 Hz, but if more than one channel is configured then the maximum pacer frequency will be 80000 Hz.
*\retval	::DPMM1105_ERR_INVALID_TRIGGER_SELECTION is returned if the trigger type selection is out of limit(0 to 1)
*\retval	::DPMM1105_ERR_INVALID_CONTINUOUS_TRIGGER_SELECTION is returned if the continuous trigger type selection is out of limit(0 to 2)
*\retval	::DPMM1105_ERR_INVALID_EXTERNAL_TRIGGER_SIGNAL_TYPE is returned if the external trigger signal type selection is out of limit(0 to 1)
*\retval	::DPMM1105_ERR_INVALID_THRESHOLD_LEVEL is returned if the threshold level value is out of limit(100 to 800)
*\retval	::DPMM1105_ERR_INVALID_SOURCETYPE is returned if the source type selection is out of limit(1 to 2)
*\retval	::DPMM1105_ERR_INVALID_EXT_TRIGGER_PACERSRC_SEL is returned if both external pacer source and  external trigger type are configured simultaneously
*
*\pre		::DPMM1105_Open
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_ConfigureADC(DP_DRV_HANDLE in_hHandle, PSDPMM1105_ADC_CONFIGURATION in_pSADCConfig);

/**
*\brief		This function is used to update the scan RAM area with a new scan list. The scan list structure details are mentioned below
* <ul>
*			<li> <b> Channel Number </b> member is used to specifies the ADC channel number.
			<li> <b> Gain </b> member is used to select the gain level. The four gain levels with different voltage ranges are mentioned below.
			<ol>
			<li> Gain 1 (-10v to +10v)
			<li> Gain 2 (-1v to +1v)
			<li> Gain 3 (-0.1v to +0.1v)
			<li> Gain 4 (-0.01v to +0.01v)
			</ol>
			<li> <b> FIFO Write Enable or Disable </b> member is used to select the FIFO write enable or disable. If the value is '1', the data converted should be directly read instead of storing in the FIFO. If MModule Read ADC interrupt is enabled, this bit is set to 1, else set this bit as 0.
			<li> <b> End Of Scan List </b> member is used to specifies the end of scan list.
* </ul>
*\note
* <ul>
*			<li> The maximum channel number can vary based upon the input mode in which the device is configured. If the input type is configure as single-ended mode then 16 is the maximum value, but if the input type is configured as differential mode then 8 is the maximum value.
* </ul>
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function.
*\param[in]	in_pSScanBuffer		It specifies the scan list data structure, which is to be loaded in RAM. Refer _SDPMM1105_SCAN_BUFFER structure for details(size:in_u16BufferLength).
*\param[in]	in_u16BufferLength	It specifies the buffer length of scan list(max:510).
*\param[in]	in_u8ApplyCalibType	It specifies the value to apply calibration type for Gain 1000 (max:1).
								0 - two point calibration slope and constant.
								1 - three point calibraion slope and constant.
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the scan list buffer pointer is null
*\retval	::DPMM1105_ERR_ADC_NOT_CONFIGURED is returned if the ADC is not configured
*\retval	::DPMM1105_ERR_ACQUISITION_IN_PROGRESS is returned if the ADC acquisition already in progress
*\retval	::DPMM1105_ERR_INVALID_BUFFERLENGTH is returned if the scan list buffer length value is out of limit(0 to 510)
*\retval	::DPMM1105_ERR_INVALID_CHANNELNO is returned if the ADC channel number is out of limit for single-ended mode(1 to 16) or differential mode(1 to 8)
*\retval	::DPMM1105_ERR_INVALID_GAINLEVEL is returned if the gain level selection is out of limit (0 to 3)
*\retval	::DPMM1105_ERR_INVALID_FIFO_ENDIS is returned if the ADC FIFO enable / disable selection is out of limit (0 to 1)
*\retval	::DPMM1105_ERR_INVALID_APPLY_CALIBRATION_TYPE is returned if the apply calibraion type is out of limit (0 to 1)
*
*\pre		::DPMM1105_ConfigureADC
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_UpdateScanList(DP_DRV_HANDLE in_hHandle, PSDPMM1105_SCAN_BUFFER in_pSScanBuffer, U16BIT in_u16BufferLength, U8BIT in_u8ApplyCalibType);

/**
*\brief		This function is used to switch the device from configuration mode to acquisition mode. When this function is called, the device is ready for the ADC conversion. But the conversion can be started only after applying the trigger.
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function.
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1105_ERR_ADC_NOT_CONFIGURED is returned if the ADC is not configured
*\retval	::DPMM1105_ERR_ACQUISITION_IN_PROGRESS is returned if the ADC acquisition already in progress
*
*\pre		::DPMM1105_UpdateScanList
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_StartAcquisition(DP_DRV_HANDLE in_hHandle);

/**
*\brief		This function is be used to provide trigger for ADC conversion, when the trigger type is configured as internal. In case the trigger type is configured as external then an error will occur on calling this function.
*
*\param[in]	in_hHandle 	It specifies the device handle which is obtained from device open function.
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1105_ERR_ADC_NOT_CONFIGURED is returned if the ADC is not configured
*\retval	::DPMM1105_ERR_ACQUISITION_IN_PROGRESS is returned if the ADC acquisition already in progress
*\retval	::DPMM1105_ERR_EXTERNAL_TRIGGER_SELECTED is returned if the trigger type is configured as external trigger
*
*\pre		::DPMM1105_StartAcquisition
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_Trigger(DP_DRV_HANDLE in_hHandle);

/**
*\brief		This function is used to switch the device from acquisition mode to configuration mode.
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function.
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1105_ERR_ADC_NOT_CONFIGURED is returned if the ADC is not configured
*\retval	::DPMM1105_ERR_ACQUISITION_NOT_STARTED is returned if the ADC acquisition not started
*
*\pre		::DPMM1105_Trigger
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_StopAcquisition(DP_DRV_HANDLE in_hHandle);

/**
*\brief		This function is used to obtain the ADC conversion status. The ADC conversion status is used to identify whether a following type of interrupt has occurred or not. The types of interrupt status are listed below.
* <ul>
*			<li> Bit 0 represents FIFO Empty Interrupt (1 - Occurred, 0 - Not Occurred).
*			<li> Bit 1 represents FIFO Full Interrupt (1 - Occurred, 0 - Not Occurred).
*			<li> Bit 2 represents FIFO Half Full Interrupt (1 - Occurred, 0 - Not Occurred).
*			<li> Bit 3 represents FIFO Threshold Interrupt (1 - Occurred, 0 - Not Occurred).
*			<li> Bit 4 represents ADC Conversion Interrupt (1 - Over, 0 - Not Over).
*			<li> Bit 5 represents Scan Acquisition Interrupt (1 - Over, 0 - Not Over).
*			<li> Bit 6 represents Trigger Too Fast Interrupt (1 - Occurred, 0 - Not Occurred).
*			<li> Bit 7 represents M-Module ADC Read Interrupt (1 - Occurred, 0 - Not Occurred).
* </ul>
*\note 		The conversion status does not dependent upon the interrupts configured in the function  DPMM1105_EnDisInterrupt.
*
*\param[in]		in_hHandle		It specifies the device handle which is obtained from device open function.
*\param[out]	out_ps8Status	It specifies the pointer to hold the ADC conversion status.

*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if conversion status pointer is null
*\retval	::DPMM1105_ERR_ADC_NOT_CONFIGURED is returned if the ADC is not configured
*
*\pre		::DPMM1105_Trigger
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_CheckStatus(DP_DRV_HANDLE in_hHandle, PU8BIT out_ps8Status);

/**
*\brief		This function is used to read only the recent sample information for a particular channel. To get the recent sample information for all the channels, this function can be called repeatedly using all the channel numbers.
*\note		<ul> <li> The maximum channel number can vary based upon the input mode in which the device is configured. If the input type is configure as single-ended mode then 16 is the maximum value, but if the input type is configured as differential mode then 8 is the maximum value. </ul>
*
*\param[in]		in_hHandle			It specifies the device handle which is obtained from device open function.
*\param[in]		in_u8ChannelNo	It specifies the ADC channel number(min:1 to max:16).
*\param[out]	out_pSSampleInfo	It specifies the structure pointer to hold the information of the sample information for a specific channel. Refer structure _SDPMM1105_SAMPLE_INFO for details
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1105_ERR_INVALID_CHANNELNO is returned if the ADC channel number is out of limit for single-ended mode(1 to 16) or differential mode(1 to 8)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if output sample information structure pointer is null
*
*\pre		::DPMM1105_Trigger
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_GetRecentSample(DP_DRV_HANDLE in_hHandle, U8BIT in_u8ChannelNo, PSDPMM1105_SAMPLE_INFO out_pSSampleInfo);

/**
*\brief 	  This function is used to read the required number of sample information from the hardware FIFO. If the required number of samples is 0 then all the sample information available in the hardware FIFO will be read. Also the total number of samples read will be got.
*
*\param[in]		in_hHandle			It specifies the device handle which is obtained from device open function.
*\param[out]	out_pSSampleInfo	It specifies the structure pointer to hold the samples information (size:io_pu16NoOfSamples).
*\param[in,out]	io_pu16NoOfSamples	It specifies the input pointer to hold number of samples to read and output pointer to hold number of samples read from FIFO
*
*\retval 	  ::DPMM1105_SUCCESS is returned upon success
*\retval 	  ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval 	  ::DP_DRV_ERR_INVALID_POINTER is returned if output samples information structure pointer is null
*\retval 	  ::DP_DRV_ERR_INVALID_POINTER is returned if output number of samples pointer is null
*
*\pre	 	  ::DPMM1105_Trigger
*\post	 	  ::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_ReadSamples(DP_DRV_HANDLE in_hHandle, U16BIT in_u16NoOfSamples, PU16BIT out_pu16NoOfSamples, PSDPMM1105_SAMPLE_INFO out_pSSampleInfo, U8BIT in_u8Options, PU32BIT in_pu32Timeout);

/**
*\brief		This function is used to enable or disable the different types of Interrupts. A particular type of interrupt will occur only if that type of interrupt is enabled using this function. The different types of interrupts are,
* <ul>
*			<li> <b> FIFO Empty Interrupt :</b> On enabling this interrupt will occur when the FIFO is empty.
			<li> <b> FIFO Half-Full Interrupt :</b> On enabling this interrupt will occur when the FIFO is half filled, that is when there are 512 sample information in the FIFO.
			<li> <b> FIFO Full Interrupt :</b> On enabling this interrupt will occur when the FIFO is full filled, that is when there are 1024 sample information in the FIFO.
			<li> <b> FIFO Threshold Interrupt :</b> On enabling this interrupt will occur when the FIFO reaches the threshold value. The Threshold value is given during configuration.
			<li> <b> ADC Conversion Interrupt :</b> On enabling this interrupt will occur when the ADC conversion is over.
			<li> <b> Scan Acquisition Interrupt :</b> On enabling this interrupt will occur when the acquisition is over.
			<li> <b> Trigger Too Fast Interrupt :</b> On enabling this interrupt will occur when the trigger is too fast.
			<li> <b> Read converted data by M-Module Carrier Interrupt :</b> On enabling this interrupt will occur after the ADC samples are read.
* </ul>
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]	 in_pSInterruptInfo		It specifies the sstructure pointer to hold the interrupt information.
*\param[in]	 in_u8IntPropagate		It specifies the Interrupt propagate or not(max:1)
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1105_ERR_INVALID_INTPROPAGATE is returned if the interrupt propagate is out of limit(0 to 1)
*
*\pre		::DPMM1105_Open
*\post		::DPMM1105_GetErrorMessage
*
*\author	 Harish Babu G K
*\date		 25 February, 2019
*/
S32BIT STDCALL DPMM1105_EnDisInterrupt(DP_DRV_HANDLE in_hHandle, PSDPMM1105_INTERRUPT_INFO in_pSInterruptInfo, U8BIT in_u8IntPropagate);

/**
*\brief		This function is used to read interrupt status.
*
*\param[in]		in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out]	out_pu8IntStatus	It specifies the pointer to hold the read interrupt status
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output read interrupt status pointer is null
*
*\pre		::DPMM1105_ConfigureADC
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_GetInterruptStatus(DP_DRV_HANDLE in_hHandle, PU8BIT out_pu8IntStatus);

/**
*\brief      This function is used to wait until the specified interrupt event occurs.
*
*\param[in]  in_hHandle      		It specifies the device handle which is obtained from device open function
*\param[in]  in_u32EventMasks   	It specifies for which interrupt events the application to be notified
*\param[in]  in_u16Options      	It specifies wait for event have until any one interrupt came or all interrupts came(max:2)
			<ol>
			<li> 0 -  No wait.
			<li> 1 -  waiting for any specified event occurs.
			<li> 2 - waiting for occurring all the specified event occurs.
			</ol>
*\param[in]  in_pu32Timeout     	It specifies the pointer which holds the time-out value. if time out is null then wait for infinite, else specified wait until specified time-out over.
*\param[out] out_pu16InterrupStatus It specifies the pointer which holds the interrupt status
*
*\retval     ::DPMM1105_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	 ::DPMM1105_ERR_INVALID_OPTIONS is returned if the option is out of limit(0 to 2)
*\retval	 ::DP_DRV_ERR_INVALID_POINTER is returned if the input pointer time-out or output interrupt status pointer is null
*
*\pre        ::DPMM1105_Open
*\post       ::DPMM1105_GetErrorMessage
*
*\author	 Harish Babu G K
*\date		 25 February, 2019
*/
S32BIT STDCALL DPMM1105_WaitForEvents(DP_DRV_HANDLE in_hHandle, U32BIT in_u32EventMasks, U16BIT in_u16Options, PU32BIT in_pu32Timeout, PU16BIT out_pu16InterrupStatus);

/**
*\brief      This function is used to get ringbuffer count value
*
*\param[in]  in_hHandle         It specifies the device handle which is obtained from device open function
*\param[out] out_pu32BuffCount  It specifies the output pointer to hold the ring buffer count value
*
*\retval     ::DPMM1105_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	 ::DP_DRV_ERR_INVALID_POINTER is returned if output buffer count pointer is NULL
*
*\pre        ::DPMM1105_WaitForEvents
*\post       ::DPMM1105_GetErrorMessage
*
*\author	 Harish Babu G K
*\date		 25 February, 2019
*/
S32BIT STDCALL DPMM1105_RingBuff_GetCount(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32BuffCount);

/**
*\brief		This function is used to find out the calibration slope and constant value in differential mode. These values are used to increase the accuracy of the samples. These slope and constant values should be stored in the EEPROM, using the function DPMM1105_WriteCalibrationTable(), which will be used during acquisition of the sample information. This function is called twice, first time is to set low reference voltage and second time to set the high reference voltage. This sequence should be followed otherwise an error will be returned. When this function is called for the first time with low reference voltage, low voltage should be given as input voltage. When this function is called for a second time with high reference voltage, high voltage should be given as input voltage. The slope and constant values are got only after this function is called the second time, with high reference value.
*
*\param[in]   in_hHandle 		It specifies the device handle which is obtained from device open function.
*\param[in]   in_u8GainLevel       	It specifies the gain level(max:3)
								\n 0 - Gain1 (-10v to +10v)
								\n 1 - Gain2 (-1v t0 +1v)
								\n 2 - Gain3 (-0.1v to +0.1v)
								\n 3 - Gain4 (-0.01v to +0.01v)
*\param[in]   in_s8RefValType 	It specifies the input source type(min:1 to max:2)
								\n 1 – Low Reference
								\n 2 – High Reference
*\param[in]   in_fRefVal 		It specifies the reference voltage in volts, given as input for calibration. Minimum and maximum values will vary according to gain selection, which are listed below
								\n Gain1 : -10v to +10v
								\n Gain2 : -1v to +1v
								\n Gain3 : -0.1v to +0.1v
								\n Gain4 : -0.01v to +0.01v
*\param[out]  out_pfSlope  		It specifies the pointer to hold the read calibration slope value
*\param[out]  out_pfConstant 	It specifies the pointer to hold the read calibration constant value
*
*\retval		::DPMM1105_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval		::DPMM1105_ERR_INVALID_GAINLEVEL is returned if the gain level selection is out of limit (0 to 3)
*\retval		::DPMM1105_ERR_INVALID_REFVALTYPE is returned if the input reference type selection is out of limit(1 to 2)
*\retval 	  	::DPMM1105_ERR_INVALID_REFVAL is returned if the input reference voltage is out of limit(-10 to 10)
*\retval 	  	::DP_DRV_ERR_INVALID_POINTER is returned if output slope pointer is null
*\retval 	  	::DP_DRV_ERR_INVALID_POINTER is returned if output constant pointer is null
*
*\pre		::DPMM1105_Open
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_Calibrate(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GainLevel, U8BIT in_s8RefValType, FSINGLE in_fRefVal, PFSINGLE out_pfSlope, PFSINGLE out_pfConstant);

/**
*\brief 	  This function is used to write the slope and constant value for the specified mode into the EEPROM. These values will be read using the function DPMM1105_ReadCalibrationTable() during acquisition of the sample information.
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8CalibPointType		It specifies the calibration type for G1000 to store slope and constant in EEOPROM (max:3).
										0 - two point calibration slope and constant.
										1 - Low point calibration slope and constant.
										2 - Mid point calibration slope and constant.
										3 - High point calibration slope and constant
*\param[in]	in_psCalibDetails	It specifies the calibration details to store in EEPROM.
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1105_ERR_INVALID_INPUTSIGNALTYPE is returned if the input signal type selection is out of limit(0 to 1)
*\retval	::DPMM1105_ERR_INVALID_SOURCETYPE is returned if the source type selection is out of limit(1 to 2)
*\retval	::DPMM1105_ERR_INVALID_GAINLEVEL is returned if the gain level selection is out of limit (0 to 3)
*\retval	::DPMM1105_ERR_INVALID_CALIBPOINT_TYPE is returned if calibration point type is out of limit (0 to 3)
*\retval	::DPMM1105_ERR_EEPROM_WRITE is returned if the EEPROM write operation is failed
*
*\pre		::DPMM1105_CalibrateDiffential or\n::DPMM1105_CalibrateSingleEnded
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_WriteCalibrationTable(DP_DRV_HANDLE in_hHandle, U8BIT in_u8CalibPointType, PSDPMM1105_CALIB_DETAILS in_psCalibDetails);

/**
*\brief		This function is used to read the slope and constant value for the specified mode from the EEPROM. These read values will be used for calibration of the converted data and the accurate sample will be acquired.
*
*\param[in]	in_hHandle				It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8CalibPointType		It specifies the calibration type for G1000 to store slope and constant in EEOPROM (max:3).
										0 - two point calibration slope and constant.
										1 - Low point calibration slope and constant.
										2 - Mid point calibration slope and constant.
										3 - High point calibration slope and constant.
*\param[in,out]	io_psCalibDetails	It specifies pointer to hold calibration details for selected mode(single ended or differential ended) from EEPROM.
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1105_ERR_INVALID_INPUTSIGNALTYPE is returned if the input signal type selection is out of limit(0 to 1)
*\retval	::DPMM1105_ERR_INVALID_SOURCETYPE is returned if the source type selection is out of limit(1 to 2)
*\retval	::DPMM1105_ERR_INVALID_GAINLEVEL is returned if the gain level selection is out of limit (0 to 3)
*\retval	::DPMM1105_ERR_INVALID_CALIBPOINT_TYPE is returned if calibration point type is out of limit (0 to 3)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if output slope pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if output constant pointer is null
*\retval	::DPMM1105_ERR_EEPROM_READ is returned if the EEPROM read operation is failed
*
*\pre		::DPMM1105_Open
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_ReadCalibrationTable(DP_DRV_HANDLE in_hHandle, U8BIT in_u8CalibPointType, PSDPMM1105_CALIB_DETAILS io_psCalibDetails);

/**
*\brief			This function is used to get calibration slope and constant for the specific gain value.
*
*\param[in]		in_hHandle 		It specifies the device handle which is obtained from device open function.
*\param[in]		in_u8GainLevel	It specifies the gain level(max:3).
								\n 0 - Gain1 (-10v to +10v),
								\n 1 - Gain2 (-1v t0 +1v),
								\n 2 - Gain3 (-0.1v to +0.1v),
								\n 3 - Gain4 (-0.01v to +0.01v).
*\param[out]	out_pfSlope    	It specifies the pointer to hold the read calibration slope
*\param[out]	out_pfConstant 	It specifies the pointer to hold the read calibration constant
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1105_ERR_INVALID_GAINLEVEL is returned if the gain level selection is out of limit (0 to 3)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if output calibration slope pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if output calibration constant pointer is null
*
*\pre		::DPMM1105_ConfigureADC
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_GetCalibConstants(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GainLevel, PFSINGLE out_pfSlope, PFSINGLE out_pfConstant);

/**
*\brief			This function is used to enable / disable raw data, if raw data option not enabled then caller will get 16 bit ADC FIFO data without any conversion. This function needs to be call before calling DPMM1105_ReadSamples function.
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8RawDataEnDis	It specifies the raw data enable/disable (max:1).
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1105_ERR_INVALID_RAWDATAENDIS is returned if raw data enable/disable values is out of limit(0 to 1)
*
*\pre		::DPMM1105_ConfigureADC
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_RawDataEnDis(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RawDataEnDis);

/**
*\brief			This function is used to write calibration data in file
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function.
*\param[in]	in_ps8FileStringBuf	It specifies the file name with(.bin) extension.
*\param[in]	in_u8CalibPointType		It specifies the calibration type for G1000 to store slope and constant in EEOPROM (max:3).
										0 - two point calibration slope and constant.
										1 - Low point calibration slope and constant.
										2 - Mid point calibration slope and constant.
										3 - High point calibration slope and constant
*\param[in]	in_pSCalibDetails	It specifies the calibration details to store in file.
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if input file name pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if input calibration details pointer is null
*
*\pre		::DPMM1105_ConfigureADC
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_CalibrateDataFileWrite(DP_DRV_HANDLE in_hHandle, PS8BIT in_ps8FileStringBuf, U8BIT in_u8CalibPointType, PSDPMM1105_CALIB_DETAILS in_pSCalibDetails);


/**
*\brief			This function is used to read calibration data from file
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function.
*\param[in]	in_ps8FileStringBuf	It specifies the file name with(.bin) extension.
*\param[in]	in_u8CalibPointType		It specifies the calibration type for G1000 to store slope and constant in EEOPROM (max:3).
										0 - two point calibration slope and constant.
										1 - Low point calibration slope and constant.
										2 - Mid point calibration slope and constant.
										3 - High point calibration slope and constant
*\param[in]	out_pSCalibDetails	It specifies output pointer to hold calibration details(size:in_u8CalibInfoLength).
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if input file name pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if output calibration details pointer is null
*
*\pre		::DPMM1105_ConfigureADC
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_CalibrateDataFileRead(DP_DRV_HANDLE in_hHandle, PS8BIT in_ps8FileStringBuf, U8BIT in_u8CalibPointType, PSDPMM1105_CALIB_DETAILS out_pSCalibDetails);

/**
*\brief 	This function is used to update driver with slope and constant for specified gain value. This will used on ADC sample data.
*
*\param[in]	in_hHandle				It specifies the device handle which is obtained from device open function.
*\param[in]	in_u8GainLevel			It specifies the gain level(max:3).
									\n 0 - Gain1 (-10v to +10v),
									\n 1 - Gain2 (-1v t0 +1v),
									\n 2 - Gain3 (-0.1v to +0.1v),
									\n 3 - Gain4 (-0.01v to +0.01v).
*\param[in]	in_fSlope				It specifies the calibrated slope value
*\param[in]	in_fConstant			It specifies the calibrated constant value
*
*\retval	::DPMM1105_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPMM1105_ERR_INVALID_GAINLEVEL is returned if the gain level selection is out of limit (0 to 3)
*
*\pre		::DPMM1105_ConfigureADC or\n::DPMM1105_CalibrateDataFileRead
*\post		::DPMM1105_GetErrorMessage
*
*\author	Harish Babu G K
*\date		25 February, 2019
*/
S32BIT STDCALL DPMM1105_CalibrationApply(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GainLevel, FSINGLE in_dSlope, FSINGLE in_dConstant);


/*!
* @}
*/

#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif
#endif
