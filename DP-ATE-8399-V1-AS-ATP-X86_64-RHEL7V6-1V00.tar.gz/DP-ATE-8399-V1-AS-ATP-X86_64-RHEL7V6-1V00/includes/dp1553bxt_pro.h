/**
* \file dp1553bxt_pro.h
* \brief This file contains the function prototypes of all the functions or API's are available in this file
*
* \author Tamizharasan K
* \date  06 January, 2020
*
* \version   1.00
*
* \copyright Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
* Phone: 91-44-4741-4000\n
* FAX: 91-44-4741-4444 \n
*
*/

#ifndef _DP1553BXT_PRO_H_
#define _DP1553BXT_PRO_H_

#include "dp_types.h"

#if defined(__cplusplus) || defined(__cplusplus__)
extern 	"C" {
#endif

/***********************************Macros************************/
#define DP1553BXT_BIST_RESET                                    0
#define DP1553BXT_BIST_NOT_RUNNING                              1
#define DP1553BXT_BIST_INPROGRESS                               2
#define DP1553BXT_COMPLETE                                      3

/* Device Operation modes. In combined mode any of following can bed OR'd together */
#define DP1553BXT_OPRN_MODE_TEST				0x0
#define DP1553BXT_OPRN_MODE_BC					0x1
#define DP1553BXT_OPRN_MODE_RT					0x2
#define DP1553BXT_OPRN_MODE_MT					0x4
#define DP1553BXT_OPRN_MODE_BC_RT				0x3
#define DP1553BXT_OPRN_MODE_BC_MT				0x5
#define DP1553BXT_OPRN_MODE_RT_MT				0x6
#define DP1553BXT_OPRN_MODE_BC_RT_MT			0x7

/******* Device Operational Mode Options ***********/
#define DP1553BXT_MODEOPT_SHARED				0x0001	/*!< Multiple application can access same device other wise one application only */
#define DP1553BXT_MODEOPT_DONOT_OVERWRITE		0x0002  /*!< Ignore current mode settings if already mode is set and shared */


/*******************************Reset Options***************************/
#define DP1553BXT_RESET_REGISTER				0x1
#define DP1553BXT_RESET_MEMORY					0x2


/************** BC Initialization Details ************/
/* BC General purpose queue size in Double Words*/
#define DP1553BXT_BC_GPQ_SIZE_256				0x0000
#define DP1553BXT_BC_GPQ_SIZE_64				0x0001
/* High Priority Queue size */
#define DP1553BXT_BC_HPQ_DISABLE				0x0000
#define DP1553BXT_BC_HPQ_SIZE_512				0x0001
#define DP1553BXT_BC_HPQ_SIZE_256				0x0002
#define DP1553BXT_BC_HPQ_SIZE_128				0x0003
#define DP1553BXT_BC_HPQ_SIZE_64				0x0004
#define DP1553BXT_BC_HPQ_SIZE_32				0x0005
/* Low Priority Queue size */
#define DP1553BXT_BC_LPQ_DISABLE				0x0000
#define DP1553BXT_BC_LPQ_SIZE_512				0x0001
#define DP1553BXT_BC_LPQ_SIZE_256				0x0002
#define DP1553BXT_BC_LPQ_SIZE_128				0x0003
#define DP1553BXT_BC_LPQ_SIZE_64				0x0004
#define DP1553BXT_BC_LPQ_SIZE_32				0x0005

/************** BC Configuration Options *****************/
#define DP1553BXT_BC_OPT_ALT_MSG_TIMER			0x0001	/*!< The time to next message will be started from the EOM instead of SOM (act as a message gap) */
#define DP1553BXT_BC_OPT_LATCH_TT_AT_SOM		0x0002	/*!< Latch the time tag value of message at SOM, otherwise EOM. */
#define DP1553BXT_BC_OPT_GAP_CHECK_ENABLE		0x0004	/*!< BC will check the elapsed time between mid-parity of the last transmitted BC word and mid-sync of the RT Status Word.
															If the gap is less than 4�s, the WSA bit in the BC Block Status Word will be set. */
#define DP1553BXT_BC_OPT_BCST_STATUS_CHECK		0x0008	/*!< The BC will check for status in all Broadcast commands. The BC will not timeout until the �No-Response Timeout Value� has expired.
															If an RTStatus Word is received before the timeout, a Word Count Error is logged in the BC Block Status Word (error event). */

/************** Time Tag resolution values **************/
#define DP1553BXT_TIMETAG_RES_64US				0
#define DP1553BXT_TIMETAG_RES_32US				1
#define DP1553BXT_TIMETAG_RES_16US				2
#define DP1553BXT_TIMETAG_RES_8US				3
#define DP1553BXT_TIMETAG_RES_4US				4
#define DP1553BXT_TIMETAG_RES_2US				5
#define DP1553BXT_TIMETAG_RES_1US				6
#define DP1553BXT_TIMETAG_RES_500NS				7
#define DP1553BXT_TIMETAG_RES_100NS				8
#define DP1553BXT_TIMETAG_RES_TEST_CLOCK		9
#define DP1553BXT_TIMETAG_RES_EXT_CLOCK			10

/************ Time tag Roll over select options *********/
#define DP1553BXT_TIMETAG_ROLLOVER_16BITS		0
#define DP1553BXT_TIMETAG_ROLLOVER_17BITS		1
#define DP1553BXT_TIMETAG_ROLLOVER_18BITS		2
#define DP1553BXT_TIMETAG_ROLLOVER_19BITS		3
#define DP1553BXT_TIMETAG_ROLLOVER_20BITS		4
#define DP1553BXT_TIMETAG_ROLLOVER_21BITS		5
#define DP1553BXT_TIMETAG_ROLLOVER_22BITS		6
#define DP1553BXT_TIMETAG_ROLLOVER_48BITS		7

/***************************************************************RAM BIST***************************************************************************/
#define DP1553BXT_SINGLE_PORT_RAM_BIST			0X1
#define DP1553BXT_RAM_BIST						0X2
#define DP1553BXT_ROM_BIST						0X4


/******************** Message Options *******************/
#define DP1553BXT_BC_MSGOPT_DOUBLE_BUFFER		0x0001 /*!< Enable the data double buffer using the data block IDs in normal and alternate message definition */
#define DP1553BXT_BC_MSGOPT_DO_NOT_BUFFER		0x0002 /*!< The message command and data words will not be added in the buffer */

/******************** Message data write option *******************/
#define DP1553BXT_BC_DATAOPT_WRITE_ALT_MSG		0x0001
/**************** Frame Options *****************/
#define DP1553BXT_BC_FRMOPT_WAIT_EXT_TRIG		0x0001

/********** General Purpose Flag State Options **********/
#define DP1553BXT_BC_GPF_STATE_CLEAR			0x0001
#define DP1553BXT_BC_GPF_STATE_SET				0x0002
#define DP1553BXT_BC_GPF_STATE_TOGGLE			0x0003

/******************   BC Control Word  ******************/
/* BC Control Word can be any of the following OR'd together */
#define DP1553BXT_BC_CTRL_1553A_MODE			0x0008
#define DP1553BXT_BC_CTRL_EOM_IRQ				0x0010
#define DP1553BXT_BC_CTRL_BCST_MSK				0x0020
#define DP1553BXT_BC_CTRL_SELFTST				0x0040
#define DP1553BXT_BC_CTRL_CHANNEL_A				0x0080
#define DP1553BXT_BC_CTRL_RETRY_ENA				0x0100
#define DP1553BXT_BC_CTRL_RESRV_MSK				0x0200
#define DP1553BXT_BC_CTRL_TERMFLG_MSK			0x0400
#define DP1553BXT_BC_CTRL_SSFLG_MSK				0x0800
#define DP1553BXT_BC_CTRL_SSBUSY_MSK			0x1000
#define DP1553BXT_BC_CTRL_SRVREQ_MSK			0x2000
#define DP1553BXT_BC_CTRL_ME_MSK				0x4000
#define DP1553BXT_BC_CTRL_TXTT_SYNCMODE			0x8000

/************* BC Message Retry Configurations  *********/
/* Total retries */
#define DP1553BXT_BC_TOTAL_RETRY_ONE			0
#define DP1553BXT_BC_TOTAL_RETRY_TWO			1
/* Retry channel selection */
#define DP1553BXT_BC_RETRYCHN_BOTH_ORIG			0
#define DP1553BXT_BC_RETRYCHN_1_ORIG_2_ALT		1
#define DP1553BXT_BC_RETRYCHN_BOTH_ALT			2
#define DP1553BXT_BC_RETRYCHN_1_ALT_2_ORIG		3
/* Retry error selection */
#define DP1553BXT_BC_RETRYERR_ON_ME_NR			0
#define DP1553BXT_BC_RETRYERR_ON_STATUS_SET		1
#define DP1553BXT_BC_RETRYERR_ON_1553A_ME		2
#define DP1553BXT_BC_RETRYERR_ON_ALL			3

/*************  BC Priority Queue selection *************/
#define DP1553BXT_BC_PRIORITY_QUEUE_HIGH		0
#define DP1553BXT_BC_PRIORITY_QUEUE_LOW			1

/******************** BC Opcodes Types ******************/
#define DP1553BXT_OPCODE_XEQ      				0x0001  /*!< Execute Message {Message id} */
#define DP1553BXT_OPCODE_JMP      				0x0002  /*!< Jump (instruction offset within frame){ opcode index in the frame} */
#define DP1553BXT_OPCODE_CAL      				0x0003  /*!< Call subroutine (frame) {Minor frame id} */
#define DP1553BXT_OPCODE_RTN      				0x0004  /*!< Return from subroutine (frame) {NA} */
#define DP1553BXT_OPCODE_IRQ      				0x0006  /*!< IRQ request (user IRQ bits set) {IRQ 0 to IRQ 3} */
#define DP1553BXT_OPCODE_HLT      				0x0007  /*!< Halt the BC {NA */
#define DP1553BXT_OPCODE_DLY      				0x0008  /*!< Delay in microseconds {Value[15:0]} */
#define DP1553BXT_OPCODE_WFT      				0x0009  /*!< Wait until frame counter = 0 {NA} */
#define DP1553BXT_OPCODE_CFT      				0x000A  /*!< Compare frame timer to value {Value[15:0]} */
#define DP1553BXT_OPCODE_CMT      				0x000B  /*!< Compare message timer to value {Value[15:0]} */
#define DP1553BXT_OPCODE_FLG      				0x000C  /*!< Set, clear, toggle 8 GPF bits {GPFC} */
#define DP1553BXT_OPCODE_LTT      				0x000D  /*!< Load time tag counter {Value[47:0]} */
#define DP1553BXT_OPCODE_LFT      				0x000E  /*!< Load frame time register {Value[15:0]} */
#define DP1553BXT_OPCODE_SFT      				0x000F  /*!< Start frame time counter {NA} */
#define DP1553BXT_OPCODE_PTT      				0x0010  /*!< Push TTL register value to GPQ {NA} */
#define DP1553BXT_OPCODE_PBS      				0x0011  /*!< Push BSW to GPQ {NA} */
#define DP1553BXT_OPCODE_PSI      				0x0012  /*!< Push data to GPQ {Value[31:0]} */
#define DP1553BXT_OPCODE_PSM      				0x0013  /*!< Push memory to GPQ {Mem word ID} */
#define DP1553BXT_OPCODE_WTG      				0x0014  /*!< Wait for external trigger {NA} */
#define DP1553BXT_OPCODE_XQF      				0x0015  /*!< Execute/Flip message {Message ID} */
#define DP1553BXT_OPCODE_GRP      				0x0016  /*!< Group Condition Codes {Value[31:0]} */
#define DP1553BXT_OPCODE_RDM      				0x0017  /*!< Read Memory {Mem word ID} */
#define DP1553BXT_OPCODE_CPM      				0x0018  /*!< Compare Memory {Value[31:0]} */
#define DP1553BXT_OPCODE_INC      				0x0019  /*!< Increment Memory {Mem word ID} */
#define DP1553BXT_OPCODE_DEC      				0x001A  /*!< Decrement Memory {Mem word ID} */
#define DP1553BXT_OPCODE_WRM      				0x001B  /*!< Write Memory {Mem word ID} */
#define DP1553BXT_OPCODE_LIA      				0x001C  /*!< Load Immediate Accumulator A {Value[31:0]} */
#define DP1553BXT_OPCODE_PTU      				0x001D  /*!< Push TTH register value to GPQ {NA} */
#define DP1553BXT_OPCODE_WFV      				0x001E  /*!< Wait For Frame Timer Value {Value[17:0]} */
#define DP1553BXT_OPCODE_AMT      				0x0021  /*!< Asynchronous Message Queue Trigger {NA} */
#define DP1553BXT_OPCODE_CMM      				0x0022  /*!< Compare Accumulator A with Accumulator B, using mask bits given in CMM param1 {Value[31:0]} */
#define DP1553BXT_OPCODE_LWT      				0x0023  /*!< Load Watchdog timer, param1 = 17-bit value in 100 us {Value[16:0]} */
#define DP1553BXT_OPCODE_LIB      				0x0024  /*!< Load Immediate Accumulator B {Value[31:0]} */

/********** Opcode Condition can be any of the following **********/
#define DP1553BXT_CND_LT           				0x0000  /*!< Set or cleared by CFT, CMT, CPB & CPM */
#define DP1553BXT_CND_GT           				0x0010  /*!< Set or cleared by CFT, CMT, CPB & CPM */
#define DP1553BXT_CND_EQ           				0x0001  /*!< Set or cleared by CFT, CMT, CPB,  CPM & CMM */
#define DP1553BXT_CND_NEQ          				0x0011  /*!< Set or cleared by CFT, CMT, CPB,  CPM & CMM */
#define DP1553BXT_CND_GP0_H        				0x0000  /*!< Executes if GP0 is logic 1 */
#define DP1553BXT_CND_GP0_L        				0x0010  /*!< Executes if GP0 is logic 0 */
#define DP1553BXT_CND_GP1_H        				0x0001  /*!< Executes if GP1 is logic 1 */
#define DP1553BXT_CND_GP1_L        				0x0011  /*!< Executes if GP1 is logic 0 */
#define DP1553BXT_CND_GP2_H        				0x0002  /*!< Executes if GP2 is logic 1 */
#define DP1553BXT_CND_GP2_L        				0x0012  /*!< Executes if GP2 is logic 0 */
#define DP1553BXT_CND_GP3_H        				0x0003  /*!< Executes if GP3 is logic 1 */
#define DP1553BXT_CND_GP3_L        				0x0013  /*!< Executes if GP3 is logic 0 */
#define DP1553BXT_CND_GP4_H        				0x0004  /*!< Executes if GP4 is logic 1 */
#define DP1553BXT_CND_GP4_L        				0x0014  /*!< Executes if GP4 is logic 0 */
#define DP1553BXT_CND_GP5_H        				0x0005  /*!< Executes if GP5 is logic 1 */
#define DP1553BXT_CND_GP5_L        				0x0015  /*!< Executes if GP5 is logic 0 */
#define DP1553BXT_CND_GP6_H        				0x0006  /*!< Executes if GP6 is logic 1 */
#define DP1553BXT_CND_GP6_L        				0x0016  /*!< Executes if GP6 is logic 0 */
#define DP1553BXT_CND_GP7_H        				0x0007  /*!< Executes if GP7 is logic 1 */
#define DP1553BXT_CND_GP7_L        				0x0017  /*!< Executes if GP8 is logic 0 */
#define DP1553BXT_CND_NO_RESP      				0x0008  /*!< Indicates no response by RT */
#define DP1553BXT_CND_RESP         				0x0018  /*!< Indicates response by RT */
#define DP1553BXT_CND_FMT_ERR      				0x0009  /*!< Indicates a format err */
#define DP1553BXT_CND_NO_FMT_ERR   				0x0019  /*!< Indicated a no format err */
#define DP1553BXT_CND_GD_XFER      				0x000A  /*!< Indicates good data block transfer */
#define DP1553BXT_CND_BAD_XFER     				0x001A  /*!< Indicates bad data block transfer */
#define DP1553BXT_CND_MSS_SET  					0x000B  /*!< Indicates masked status set */
#define DP1553BXT_CND_MSS_CLR  					0x001B  /*!< Indicates masked status cleared*/
#define DP1553BXT_CND_BAD_MSG      				0x000C  /*!< Indicates a bad message */
#define DP1553BXT_CND_GOOD_MSG     				0x001C  /*!< Indicates a good message */
#define DP1553BXT_CND_0RETRY       				0x001D  /*!< Indicates 0 retries */
#define DP1553BXT_CND_1RETRY       				0x000D  /*!< Indicates 1 retry  */
#define DP1553BXT_CND_2RETRY       				0x000E  /*!< Indicates 2 retries*/
#define DP1553BXT_CND_NO_2RETRY       			0x001E  /*!< Indicates no 2 retries*/
#define DP1553BXT_CND_ALWAYS       				0x000F  /*!< Always run opcode */
#define DP1553BXT_CND_NEVER        				0x001F  /*!< Never run opcode */
#define DP1553BXT_CND_GP9_H        				0x0021  /*!< Executes if GP8 is logic 1 */
#define DP1553BXT_CND_GP9_L        				0x0031  /*!< Executes if GP8 is logic 0 */
#define DP1553BXT_CND_GP10_H        			0x0022  /*!< Executes if GP9 is logic 1 */
#define DP1553BXT_CND_GP10_L        			0x0032  /*!< Executes if GP9 is logic 0 */
#define DP1553BXT_CND_GP11_H       				0x0023  /*!< Executes if GP10 is logic 1 */
#define DP1553BXT_CND_GP11_L       				0x0033  /*!< Executes if GP10 is logic 0 */
#define DP1553BXT_CND_GP12_H       				0x0024  /*!< Executes if GP11 is logic 1 */
#define DP1553BXT_CND_GP12_L       				0x0034  /*!< Executes if GP11 is logic 0 */
#define DP1553BXT_CND_GP13_H       				0x0025  /*!< Executes if GP12 is logic 1 */
#define DP1553BXT_CND_GP13_L       				0x0035  /*!< Executes if GP12 is logic 0 */
#define DP1553BXT_CND_GP14_H       				0x0026  /*!< Executes if GP13 is logic 1 */
#define DP1553BXT_CND_GP14_L       				0x0036  /*!< Executes if GP13 is logic 0 */
#define DP1553BXT_CND_GP15_H       				0x0027  /*!< Executes if GP14 is logic 1 */
#define DP1553BXT_CND_GP15_L       				0x0037  /*!< Executes if GP14 is logic 0 */
#define DP1553BXT_CND_GRPCC       				0x0028  /*!< Executes if GRP tests true (all GRP condition true) */
#define DP1553BXT_CND_NO_GRPCC     				0x0038  /*!< Executes if GRP tests false (any one GRP condition false) */

/**************** Interrupt Event Bit Mask **************/

	/* BC mode interrupt events */
#define DP1553BXT_EVT_BC_EOM					0x00000001 	/*<! BC EOM */
#define DP1553BXT_EVT_BC_STATUS_SET				0x00000002 	/*<! BC status set */
#define DP1553BXT_EVT_BC_FORMAT_ERR				0x00000004 	/*<! BC format error */
#define DP1553BXT_EVT_BC_TRAP					0x00000008 	/*<! BC trap */
#define DP1553BXT_EVT_BC_SELECT_EOM				0x00000010 	/*<! BC selected EOM based on the EOMI in BC control word */
#define DP1553BXT_EVT_BC_OPCODE_PARITY_ERR		0x00000020 	/*<! BC opcode parity error */
#define DP1553BXT_EVT_BC_GPQ_100_ROLLOVER		0x00000040 	/*<! BC general purpose queue 100% roll over */
#define DP1553BXT_EVT_BC_GPQ_50_ROLLOVER		0x00000080 	/*<! BC general purpose queue 50% roll over */
#define DP1553BXT_EVT_BC_MSG_RETIRED			0x00000100 	/*<! BC message retry is occurred */
#define DP1553BXT_EVT_BC_USER_IRQ0				0x00000200 	/*<! BC user IRQ 0 */
#define DP1553BXT_EVT_BC_USER_IRQ1				0x00000400 	/*<! BC user IRQ 1 */
#define DP1553BXT_EVT_BC_USER_IRQ2				0x00000800 	/*<! BC user IRQ 2 */
#define DP1553BXT_EVT_BC_USER_IRQ3				0x00001000 	/*<! BC user IRQ 3 */
#define DP1553BXT_EVT_BC_CALL_STACK_ERR			0x00002000 	/*<! BC call stack error */
#define DP1553BXT_EVT_BC_LP_MSG_TX				0x00004000 	/*<! BC low priority Marker 1 */
#define DP1553BXT_EVT_BC_LP_ROLLOVER			0x00008000 	/*<! BC low priority Marker 2 */
#define DP1553BXT_EVT_BC_HP_MSG_TX				0x00010000 	/*<! BC high priority Marker 1 */
#define DP1553BXT_EVT_BC_HP_ROLLOVER			0x00020000 	/*<! BC high priority Marker 2 */
#define DP1553BXT_EVT_BC_USER_EOF				0x00040000 	/*<! BC End of Frame */
#define DP1553BXT_EVT_BC_ADH_OVERFLOW			0x00080000 	/*<! BC ADH overflow */

	/* RT mode interrupt events */
#define DP1553BXT_EVT_RT_EOM					0x00000001 	/*<!	RT EOM */
#define DP1553BXT_EVT_RT_MODECODE				0x00000002 	/*<! RT mode code */
#define DP1553BXT_EVT_RT_FORMAT_ERR				0x00000004 	/*<! RT format error */
#define DP1553BXT_EVT_RT_SELECT_EOM				0x00000008 	/*<! RT sub-address EOM */
#define DP1553BXT_EVT_RT_DBLK_100_ROLLOVER		0x00000010 	/*<! RT circular data block 100% roll over */
#define DP1553BXT_EVT_RT_STACK_100_ROLLOVER		0x00000020 	/*<! RT message descriptor stack 100% roll over */
#define DP1553BXT_EVT_RT_ADDR_PARITY_ERR		0x00000040 	/*<! RT address parity error */
#define DP1553BXT_EVT_RT_TX_TIMEOUT				0x00000080 	/*<! RT transmitter timeout */
#define DP1553BXT_EVT_RT_DBLK_50_ROLLOVER		0x00000100 	/*<! RT circular data block 50% roll over */
#define DP1553BXT_EVT_RT_STACK_50_ROLLOVER		0x00000200 	/*<! RT message descriptor stack 50% roll over */
#define DP1553BXT_EVT_RT_INTSTS_Q_ROLLOVER		0x00000400 	/*<! RT interrupt status queue roll over */
#define DP1553BXT_EVT_RT_ILLEGAL_CMD			0x00000800 	/*<! RT illegal command word */
#define DP1553BXT_EVT_RT_STACK_OVERFLOW			0x00001000 	/*<! RT message descriptor stack overflow */

	/* MT mode interrupt events */
#define DP1553BXT_EVT_MT_WORD_COUNT				0x00000001 	/*<!  */
#define DP1553BXT_EVT_MT_MSG_COUNT				0x00000002 	/*<!  */
#define DP1553BXT_EVT_MT_TIMERINT_FREERUN		0x00000004 	/*<!  */
#define DP1553BXT_EVT_MT_TIMERINT_EOM			0x00000008 	/*<!  */
#define DP1553BXT_EVT_MT_TRIG_IRQ				0x00000010 	/*<!  */
#define DP1553BXT_EVT_MT_STACK_OVERFLOW			0x00000020 	/*<!  */
#define DP1553BXT_EVT_MT_IRIG_1SEC				0x00000040 	/*<!  */

/* Common events for BC/RT/MT */
#define DP1553BXT_EVT_TT_ROLLOVER				0x01000000 	/*<! Global Interrupt TT roll over */
#define DP1553BXT_EVT_RAM_PARITY				0x02000000 	/*<! Global Interrupt RAM parity */
#define DP1553BXT_EVT_RAM_ST_COMPLETE			0x04000000 	/*<! Global Interrupt RAM self-test complete */

/**************** Interrupt Event Wait Type  **************/
#define DP1553BXT_EVT_OPT_WAIT_ANY				0 	/*<! Wait for any one masked interrupt event(s) occurred */
#define DP1553BXT_EVT_OPT_WAIT_ALL				1 	/*<! Wait for all masked interrupt events occurred */


/*********************** RT Constants *********************/
#define DP1553BXT_RT_STACK_SIZE_64_MSG			0
#define DP1553BXT_RT_STACK_SIZE_128_MSG			1
#define DP1553BXT_RT_STACK_SIZE_256_MSG			2
#define DP1553BXT_RT_STACK_SIZE_512_MSG			3

#define DP1553BXT_RT_GBL_CIRBUF_DISABLE			0
#define DP1553BXT_RT_GBL_CIRBUF_SINGLE_MSG		1
#define DP1553BXT_RT_GBL_CIRBUF_128_WORDS		2
#define DP1553BXT_RT_GBL_CIRBUF_256_WORDS		3
#define DP1553BXT_RT_GBL_CIRBUF_512_WORDS		4
#define DP1553BXT_RT_GBL_CIRBUF_1024_WORDS		5
#define DP1553BXT_RT_GBL_CIRBUF_2048_WORDS		6
#define DP1553BXT_RT_GBL_CIRBUF_4096_WORDS		7
#define DP1553BXT_RT_GBL_CIRBUF_8192_WORDS		8

#define DP1553BXT_RT_OPT_CLR_SRV_REQ			0x01
#define DP1553BXT_RT_OPT_LOAD_TT_MC_SYNC		0x02
#define DP1553BXT_RT_OPT_CLR_TT_MC_SYNC			0x04
#define DP1553BXT_RT_OPT_ENA_ALT_STS			0x08
#define DP1553BXT_RT_OPT_1553A_MC_ENA			0x10
#define DP1553BXT_RT_OPT_ILLEGAL_RX_DIS			0x20
#define DP1553BXT_RT_OPT_BUSY_RX_DIS			0x40
#define DP1553BXT_RT_OPT_ENHANCE_TT_SYNC		0x80

#define DP1553BXT_RT_MSGTYPE_TX					0x01
#define DP1553BXT_RT_MSGTYPE_RX					0x02
#define DP1553BXT_RT_MSGTYPE_BCST				0x04

#define DP1553BXT_RT_BUF_SINGLE					0x00	/* 32 words single message buffer */
#define DP1553BXT_RT_BUF_CIR_128W				0x01	/* 128 words circular buffer */
#define DP1553BXT_RT_BUF_CIR_256W				0x02	/* 256 words circular buffer */
#define DP1553BXT_RT_BUF_CIR_512W				0x03	/* 512 words circular buffer */
#define DP1553BXT_RT_BUF_CIR_1024W				0x04	/* 1024 words circular buffer */
#define DP1553BXT_RT_BUF_CIR_2048W				0x05	/* 2048 words circular buffer */
#define DP1553BXT_RT_BUF_CIR_4096W				0x06	/* 4096 words circular buffer */
#define DP1553BXT_RT_BUF_CIR_8192W				0x07	/* 8192 words circular buffer */
#define DP1553BXT_RT_BUF_DOUBLE					0x08	/* 64 words double message buffer */
#define DP1553BXT_RT_BUF_CIR_GLOBAL				0x09	/* Global circular buffer */

#define DP1553BXT_RT_SA_OPT_EOM_INT				0x01	/* Enable EOM interrupt */
#define DP1553BXT_RT_SA_OPT_CIRBUF_RO_INT		0x02	/* Enable Circular buffer rollover interrupt (50% & 100%) */
#define DP1553BXT_RT_SA_OPT_LEGALIZE			0x04	/* Legalize the subaddress for all word counts*/



/* Modecode with data options */
#define DP1553BXT_RT_MCD_RX_SYNCHRONIZE         0x11
#define DP1553BXT_RT_MCD_RX_SEL_TX_SHUTDWN      0x14
#define DP1553BXT_RT_MCD_RX_OVRSEL_TX_SHUTDWN   0x15
#define DP1553BXT_RT_MCD_TX_TRNS_VECTOR         0x30
#define DP1553BXT_RT_MCD_TX_TRNS_LAST_CMD       0x32
#define DP1553BXT_RT_MCD_TX_TRNS_BIT            0x33
#define DP1553BXT_RT_MCD_BCST_SYNCHRONIZE       0x51
#define DP1553BXT_RT_MCD_BCST_SEL_T_SHUTDWN     0x54
#define DP1553BXT_RT_MCD_BCST_OVRSEL_T_SHUTDWN  0x55

/* Mode code IRQ selection */
#define DP1553BXT_RT_MCIRQ_DYNAMIC_BUS_CTRL			0x1
#define DP1553BXT_RT_MCIRQ_SYNCHRONIZE_NO_DATA		0x2
#define DP1553BXT_RT_MCIRQ_TX_STATUS_WRD			0x4
#define DP1553BXT_RT_MCIRQ_INIT_SELF_TEST			0x8
#define DP1553BXT_RT_MCIRQ_TRNS_SHUTDOWN			0x10
#define DP1553BXT_RT_MCIRQ_OVRD_TRNS_SHUTDOWN		0x20
#define DP1553BXT_RT_MCIRQ_INH_TERM_FLAG			0x40
#define DP1553BXT_RT_MCIRQ_OVRD_INH_TERM_FLG		0x80
#define DP1553BXT_RT_MCIRQ_RESET_REMOTE_TERM		0x100
#define DP1553BXT_RT_MCIRQ_TRNS_VECTOR				0x10000
#define DP1553BXT_RT_MCIRQ_SYNCHRONIZE_DATA			0x20000
#define DP1553BXT_RT_MCIRQ_TRNS_LAST_CMD			0x40000
#define DP1553BXT_RT_MCIRQ_TRNS_BIT_WRD				0x80000
#define DP1553BXT_RT_MCIRQ_SEL_TRNS_SHUTDOWN		0x100000
#define DP1553BXT_RT_MCIRQ_OVRD_SEL_TRNS_SHUTDOWN	0x200000


/************************************************************************RT Status Input Control*********************************************************/
#define DP1553BXT_RT_SIC_FRTF						0x40
#define DP1553BXT_RT_SIC_FSSF						0x80
#define DP1553BXT_RT_SIC_FSR						0x100
#define DP1553BXT_RT_SIC_FBSY						0x200
#define DP1553BXT_RT_SIC_FDBC						0x400



/*************** MT Constants ***************/
/* MT Stack Size- All are in Words */
#define DP1553BXT_MT_STACK_SIZE_MAX_AVAIL		0x0
#define DP1553BXT_MT_STACK_SIZE_500            	0x1
#define DP1553BXT_MT_STACK_SIZE_1K             	0x2
#define DP1553BXT_MT_STACK_SIZE_2K             	0x3
#define DP1553BXT_MT_STACK_SIZE_4K             	0x4
#define DP1553BXT_MT_STACK_SIZE_8K             	0x5
#define DP1553BXT_MT_STACK_SIZE_16K            	0x6
#define DP1553BXT_MT_STACK_SIZE_32K            	0x7
#define DP1553BXT_MT_STACK_SIZE_64K            	0x8
#define DP1553BXT_MT_STACK_SIZE_128K           	0x9
#define DP1553BXT_MT_STACK_SIZE_256K           	0xA
#define DP1553BXT_MT_STACK_SIZE_512K           	0xB
#define DP1553BXT_MT_STACK_SIZE_1024K          	0xC
#define DP1553BXT_MT_STACK_SIZE_2048K          	0xD
#define DP1553BXT_MT_STACK_SIZE_RESERVED1      	0xE
#define DP1553BXT_MT_STACK_SIZE_RESERVED2      	0xF

/* MT Configuration */
#define DP1553BXT_MT_BUS_SW_EOM_DISABLE        	0x00080000
#define DP1553BXT_MT_EOM_TIMETAG_ENABLE        	0x00200000
#define DP1553BXT_MT_1553A_FORMAT_ENABLE       	0x01000000
#define DP1553BXT_MT_BCST_DISABLE              	0x02000000
#define DP1553BXT_MT_MIN_GAP_CHECK_ENABLE      	0x04000000


/* Sub Address Selection */
#define DP1553BXT_MT_SA_ALL_SET 				0xFFFFFFFF
#define DP1553BXT_MT_SA_0       				0x00000001
#define DP1553BXT_MT_SA_1       				0x00000002
#define DP1553BXT_MT_SA_2       				0x00000004
#define DP1553BXT_MT_SA_3       				0x00000008
#define DP1553BXT_MT_SA_4       				0x00000010
#define DP1553BXT_MT_SA_5       				0x00000020
#define DP1553BXT_MT_SA_6       				0x00000040
#define DP1553BXT_MT_SA_7       				0x00000080
#define DP1553BXT_MT_SA_8       				0x00000100
#define DP1553BXT_MT_SA_9       				0x00000200
#define DP1553BXT_MT_SA_10      				0x00000400
#define DP1553BXT_MT_SA_11      				0x00000800
#define DP1553BXT_MT_SA_12      				0x00001000
#define DP1553BXT_MT_SA_13      				0x00002000
#define DP1553BXT_MT_SA_14      				0x00004000
#define DP1553BXT_MT_SA_15      				0x00008000
#define DP1553BXT_MT_SA_16      				0x00010000
#define DP1553BXT_MT_SA_17      				0x00020000
#define DP1553BXT_MT_SA_18      				0x00040000
#define DP1553BXT_MT_SA_19      				0x00080000
#define DP1553BXT_MT_SA_20      				0x00100000
#define DP1553BXT_MT_SA_21      				0x00200000
#define DP1553BXT_MT_SA_22      				0x00400000
#define DP1553BXT_MT_SA_23      				0x00800000
#define DP1553BXT_MT_SA_24      				0x01000000
#define DP1553BXT_MT_SA_25      				0x02000000
#define DP1553BXT_MT_SA_26      				0x04000000
#define DP1553BXT_MT_SA_27      				0x08000000
#define DP1553BXT_MT_SA_28      				0x10000000
#define DP1553BXT_MT_SA_29      				0x20000000
#define DP1553BXT_MT_SA_30      				0x40000000
#define DP1553BXT_MT_SA_31      				0x80000000

#define DP1553BXT_MT_SA_TX      				0x00
#define DP1553BXT_MT_SA_RX      				0x01
#define DP1553BXT_MT_SA_TXRX    				0x02

#define DP1553BXT_MT_INT_MODE       			1
#define DP1553BXT_MT_POLL_MODE      			0

/* Function macro to initialize structures */

#define DP1553BXT_SET_CMD_WORD(out_CmdWord, in_RTAddr, in_SubAddr, in_WC_MC, in_TxRx) {\
	out_CmdWord = ((in_RTAddr & 0x1F) << 11) | ((in_TxRx & 0x1) << 10) | ((in_SubAddr & 0x1F) << 5) | (in_WC_MC & 0x1F);\
}

#define DP1553BXT_GET_CMD_WORD(in_CmdWord, out_RTAddr, out_SubAddr, out_WC_MC, out_TxRx) {\
	out_WC_MC 	= (in_CmdWord & 0x1F); \
	out_SubAddr = ((in_CmdWord >> 5) & 0x1F); \
	out_TxRx 	= ((in_CmdWord >> 10) & 0x1); \
	out_RTAddr 	= ((in_CmdWord >> 11) & 0x1F); \
}

#define DP1553BXT_BC_MSG_DEF_INIT_BCTORT(pBCMsgDef, RTAddr, SubAddr, WordCount, TimeToNextMsg, CtrlWord, DataBlkID) {\
		PDP1553BXT_BC_MSG_DEF pSBCMsgDef = pBCMsgDef;\
		DP1553BXT_SET_CMD_WORD(pSBCMsgDef->u16CmdWord1, RTAddr, SubAddr, WordCount, 0)\
		pSBCMsgDef->u16CmdWord2 = 0;			pSBCMsgDef->u16TimeToNextMsg = TimeToNextMsg;\
		pSBCMsgDef->u16CtrlWord = CtrlWord;	pSBCMsgDef->u16DataBlkID = DataBlkID;\
}

#define DP1553BXT_BC_MSG_DEF_INIT_RTTOBC(pBCMsgDef, RTAddr, SubAddr, WordCount, TimeToNextMsg, CtrlWord, DataBlkID) {\
		PDP1553BXT_BC_MSG_DEF pSBCMsgDef = pBCMsgDef;\
		DP1553BXT_SET_CMD_WORD(pSBCMsgDef->u16CmdWord1, RTAddr, SubAddr, WordCount, 1)\
		pSBCMsgDef->u16CmdWord2 = 0;			pSBCMsgDef->u16TimeToNextMsg = TimeToNextMsg;\
		pSBCMsgDef->u16CtrlWord = CtrlWord;	pSBCMsgDef->u16DataBlkID = DataBlkID;\
}

#define DP1553BXT_BC_MSG_DEF_INIT_RTTORT(pBCMsgDef, RTAddrRx, SubAddrRx, WordCount, RTAddrTx, SubAddrTx, TimeToNextMsg, CtrlWord, DataBlkID) {\
		PDP1553BXT_BC_MSG_DEF pSBCMsgDef = pBCMsgDef;\
		DP1553BXT_SET_CMD_WORD(pSBCMsgDef->u16CmdWord1, RTAddrRx, SubAddrRx, WordCount, 0) \
		DP1553BXT_SET_CMD_WORD(pSBCMsgDef->u16CmdWord2, RTAddrTx, SubAddrTx, WordCount, 1) \
		pSBCMsgDef->u16TimeToNextMsg = TimeToNextMsg;		pSBCMsgDef->u16DataBlkID = DataBlkID; \
		pSBCMsgDef->u16CtrlWord = CtrlWord;\
}

#define DP1553BXT_BC_MSG_DEF_INIT_MODE_TX(pBCMsgDef, RTAddr, ModeCmd, TimeToNextMsg, CtrlWord, DataBlkID) {\
		PDP1553BXT_BC_MSG_DEF pSBCMsgDef = pBCMsgDef; \
		DP1553BXT_SET_CMD_WORD(pSBCMsgDef->u16CmdWord1, RTAddr, 0, ModeCmd, 1) \
		pSBCMsgDef->u16CmdWord2 = 0;			pSBCMsgDef->u16TimeToNextMsg = TimeToNextMsg; \
		pSBCMsgDef->u16CtrlWord = CtrlWord;	pSBCMsgDef->u16DataBlkID = DataBlkID; \
}

#define DP1553BXT_BC_MSG_DEF_INIT_BCTORT_MODE(pBCMsgDef, RTAddr, ModeCmd, TimeToNextMsg, CtrlWord, DataBlkID) {\
		PDP1553BXT_BC_MSG_DEF pSBCMsgDef = pBCMsgDef;\
		DP1553BXT_SET_CMD_WORD(pSBCMsgDef->u16CmdWord1, RTAddr, 0, ModeCmd, 0) \
		pSBCMsgDef->u16CmdWord2 = 0;		pSBCMsgDef->u16TimeToNextMsg = TimeToNextMsg;\
		pSBCMsgDef->u16CtrlWord = CtrlWord;			pSBCMsgDef->u16DataBlkID = DataBlkID;\
}

#define DP1553BXT_BC_MSG_DEF_INIT_BCTORT_BCST(pBCMsgDef, SubAddr, WordCount, TimeToNextMsg, CtrlWord, DataBlkID) {\
		PDP1553BXT_BC_MSG_DEF pSBCMsgDef = pBCMsgDef;\
		DP1553BXT_SET_CMD_WORD(pSBCMsgDef->u16CmdWord1, 31, WordCount, ModeCmd, 0) \
		pSBCMsgDef->u16CmdWord2 = 0;				pSBCMsgDef->u16TimeToNextMsg = TimeToNextMsg;\
		pSBCMsgDef->u16CtrlWord = CtrlWord;		pSBCMsgDef->u16DataBlkID = DataBlkID;\
}

#define DP1553BXT_BC_MSG_DEF_INIT_RTTORT_BCST(pBCMsgDef, SubAddrRx, WordCount, RTAddrTx, SubAddrTx, TimeToNextMsg, CtrlWord, DataBlkID) {\
		PDP1553BXT_BC_MSG_DEF pSBCMsgDef = pBCMsgDef;\
		DP1553BXT_SET_CMD_WORD(pSBCMsgDef->u16CmdWord1, 31, SubAddrRx, WordCount, 0) \
		DP1553BXT_SET_CMD_WORD(pSBCMsgDef->u16CmdWord2, RTAddrTx, SubAddrTx, WordCount, 1) \
		pSBCMsgDef->u16TimeToNextMsg = TimeToNextMsg;		pSBCMsgDef->u16DataBlkID = DataBlkID;\
		pSBCMsgDef->u16CtrlWord = CtrlWord;\
}

#define DP1553BXT_BC_MSG_DEF_INIT_MODE_BCST(pBCMsgDef, ModeCmd, TimeToNextMsg, CtrlWord, DataBlkID) {\
		PDP1553BXT_BC_MSG_DEF pSBCMsgDef = pBCMsgDef;\
		DP1553BXT_SET_CMD_WORD(pSBCMsgDef->u16CmdWord1, 31, 0, ModeCmd, 0) \
		pSBCMsgDef->u16CmdWord2 = 0;			pSBCMsgDef->u16TimeToNextMsg = TimeToNextMsg;\
		pSBCMsgDef->u16CtrlWord = CtrlWord;		pSBCMsgDef->u16DataBlkID = DataBlkID;\
}

#define DP1553BXT_BC_OPCODE_DEF_INIT(pOpcodeDef, OpCodeType, Condition, Parameter1, Parameter2) {\
		PDP1553BXT_BC_OPCODE_DEF pSOpcodeDef = (pOpcodeDef);\
		(pSOpcodeDef)->u16OpCodeType = OpCodeType;\
		(pSOpcodeDef)->u16Condition = Condition;\
		(pSOpcodeDef)->u32Parameter1 = Parameter1;\
		(pSOpcodeDef)->u32Parameter2 = Parameter2;\
}

/***********************************Structures************************/
#pragma pack(push,1)

/**
*\struct    _SDP1553BXT_DEVICE_LOCATION
*\brief  	This structure contains members to hold the device locations details
*
*			The device location details includes the bus number, slot number, function number and channel number.
*
*/
typedef struct _SDP1553BXT_DEVICE_LOCATION
{
    U8BIT ucBusNo;				/*!< Bus number */
    U8BIT ucSlotNo; 			/*!< Slot number */
    U8BIT ucFunctionNo;			/*!< Function number */
    U8BIT ucChannelNo;			/*!< Channel number */
}SDP1553BXT_DEVICE_LOCATION, *PSDP1553BXT_DEVICE_LOCATION;

/**
*\struct    _SDP1553BXT_DRIVER_DETAILS
*\brief  	This structure contains members to hold the driver details
*
*			The driver details includes the driver version.
*
*/
typedef struct _SDP1553BXT_DRIVER_DETAILS
{
    U32BIT u32Version;		   /*!< Driver version */
}SDP1553BXT_DRIVER_DETAILS, *PSDP1553BXT_DRIVER_DETAILS;

/**
*\struct	_SDP1553BXT_DEVICE_DETAILS
*\brief		This structure contains members to hold the device details
*
*  			The device details includes the device id and device version.
*
*/
typedef struct _SDP1553BXT_DEVICE_DETAILS
{
    U16BIT u16DeviceID;			/*!< Device ID	*/
    U16BIT u16BoardVersion;		/*!< Board Version */
    U16BIT u16VendorID;			/*!< Vendor ID	*/
    U16BIT u16ChannelNo;		/*!< Channel No */
}SDP1553BXT_DEVICE_DETAILS, *PSDP1553BXT_DEVICE_DETAILS;

/**
*\struct	_SDP1553BXT_GLUE_LOGIC
*\brief		This structure contains members to hold the FPGA details
*
*  			The device details includes the FPGA type ID and FPGA version.
*
*/
typedef struct _SDP1553BXT_GLUE_LOGIC
{
	U16BIT	u16FPGAVersion;		/*!< FPGA version */
}SDP1553BXT_GLUE_LOGIC, *PSDP1553BXT_GLUE_LOGIC;

/***********************************BC Mode Structure************************/

/**
*\struct	_SDP1553BXT_RAM_BIST_STATUS
*\brief		This structure contains members to hold the RAM BIST status
*
*  			The RAM BIST status includes the Single Port, RAM, ROM results and states.
*
*/
typedef struct _SDP1553BXT_RAM_BIST_STATUS
{
	U8BIT ucSinglePortResult;		/*!< Single Port RAM BIST Result i.e, either (Pass or Fail) */
	U8BIT ucSinglePortState;		/*!< Single Port RAM BIST State i.e, completed or in-progress or not running */
	
	U8BIT ucRAMBistResult;			/*!< RAM BIST Result i.e, either (Pass or Fail) */
	U8BIT ucRAMBISTState;			/*!< RAM BIST State i.e, completed or in-progress or not running */
	
	U8BIT ucROMBISTResult;		    /*!< ROM BIST Result i.e, either (Pass or Fail) */
	U8BIT ucROMBISTState;			/*!< ROM BIST State i.e, completed or in-progress or not running */
}SDP1553BXT_RAM_BIST_STATUS, *PSDP1553BXT_RAM_BIST_STATUS;

/**
*\struct	_SDP1553BXT_BC_INIT
*\brief		This structure contains members to hold the Memory queues and Data blocks
*
*  			The BC initialize includes the GPQ, HPQ, LPQ, Message Blocks, Data Blocks and Host Message Buffer Size.
*
*/
typedef struct _SDP1553BXT_BC_INIT
{
	U16BIT u16GPQSize;           	/*!< General purpose Queue size */
	U16BIT u16HPQSize;           	/*!< High Priority Queue size */
	U16BIT u16LPQSize;           	/*!< Low Priority Queue size */
	U16BIT u16MaxMsgBlocks;		  	/*!< Maximum message blocks can be created for the frame (0 to 1400) */
	U16BIT u16MaxDataBlocks;		/*!< Maximum data blocks can be created for messages (0 to 1400) */
	U16BIT u16MaxMemoryDWords;		/*!< Maximum memory Double Words can be created for memory operation (0 to 1024) using opcodes */
	U16BIT u16HostMsgBufSize;	  	/*!< Host buffer size in number of messages used to store the received message - this buffer will be used in interrupt mode only
										0 - No software buffer used
										256 to 65535  - minimum size is 256 messages */
}SDP1553BXT_BC_INIT, *PSDP1553BXT_BC_INIT;

/**
*\struct	_DP1553BXT_BC_MSG_DEF
*\brief		This structure contains members to hold the Control Word and Command Word.
*
*  			The BC Message define includes the Data Block ID, Control Word, Command Word1, Command Word2, Time to next message.
*
*/
typedef struct _DP1553BXT_BC_MSG_DEF
{
	U16BIT u16DataBlkID;			/*!< Data block id for the message */
	U16BIT u16CtrlWord;				/*!< BC Message Control Word */
	U16BIT u16CmdWord1;				/*!< BC Command Word 1 */
	U16BIT u16CmdWord2;				/*!< BC Command Word 2 (RT-RT Tx Command Word) */
	U16BIT u16TimeToNextMsg;		/*!< Time to next message */

} DP1553BXT_BC_MSG_DEF, *PDP1553BXT_BC_MSG_DEF;

/**
*\struct	_DP1553BXT_BC_OPCODE_DEF
*\brief		This structure contains members to hold the OpCode definition
*
*  			The OpCode definition includes the OpCode type, OpCode Condition, OpCode Parameter1, OpCode Parameter2.
*
*/
typedef struct _DP1553BXT_BC_OPCODE_DEF
{
	U16BIT u16OpCodeType;			/*!< OpCode Type (XEQ, JMP, etc. refer Macro "DP1553BXT_OPCODE_xxx") */
	U16BIT u16Condition;			/*!< OpCode Condition. Refer macro "DP1553BXT_CND_xxx" */
	U32BIT u32Parameter1;			/*!< OpCode Parameter1 */
	U32BIT u32Parameter2;			/*!< OpCode Parameter2 */

} DP1553BXT_BC_OPCODE_DEF, *PDP1553BXT_BC_OPCODE_DEF;

/**
*\struct	_SDP1553BXT_BC_MSG
*\brief		This structure contains members to hold the BC Message details
*
*  			The BC Message includes the BSW, Time Tag, Command Word1, Command Word2, Status Word1, Status Word2, Word Count \n
				Data Words, Control Word, Time to next message, Loop backed word, Message ID, Time Tag Resolution.
*
*/
typedef struct _SDP1553BXT_BC_MSG
{
	U16BIT u16BlockStsWord;		/*!< Block status word */
	U64BIT u64TimeTagVal;		/*!< TimeTag Value */
	U16BIT u16CmdWord1;			/*!< Command Word1 */
	U16BIT u16CmdWord2;			/*!< Command Word2 */
	U16BIT u16RTStsWord1;		/*!< Status Word1 */
	U16BIT u16RTStsWord2;		/*!< Status Word2 */
    U16BIT u16WordCount;		/*!< Word Count */
    U16BIT u16Data[32];			/*!< Data Words */
    U16BIT u16CtrlWord;			/*!< Control Word */
    U16BIT u16TimeToNextMsg;	/*!< Time to next message */
    U16BIT u16LoopbackWord;		/*!< Loop backed word */
    U16BIT u16MsgID;			/*!< Message ID */
    U16BIT u16TimetagRes;		/*!< Time Tag Resolution */
}SDP1553BXT_BC_MSG, *PSDP1553BXT_BC_MSG;

/***********************************RT Mode Structure************************/
/**
*\struct	_SDP1553BXT_RT_INIT
*\brief		This structure contains members to hold the RT Initialization
*
*  			The RT Initialization structure includes the RT Stack size, Global circular buffer size, Time tag at EOM, Mode code reset I/O, \n
				Mode code reset I/O, Broadcast Disable, Host Message Buffer size.
*
*/
typedef struct _SDP1553BXT_RT_INIT
{
	U16BIT	u16RTStackSize;      	/*!< RT Stack size */
	U8BIT	u8GlobalCirBuffSize; 	/*!< Global circular buffer size*/
	U8BIT	u8TimetagAtEOM;      	/*!< Time tag at EOM */
	U8BIT 	u8ModeCodeResetIO;		/*!< Mode code reset I/O */
	U8BIT 	u8BroadcastDisable;		/*!< Broadcast Disable */
	U16BIT 	u16HostMsgBufSize;		/*!< Host buffer size in number of messages used to store the received message (global circular buffer to store all received messages).
									this buffer will be used in interrupt mode only. The value can be double the stack size.
										 0 - No software buffer used
										 256 to 65535  - minimum size is 256 messages */
}SDP1553BXT_RT_INIT, *PSDP1553BXT_RT_INIT;

/**
*\struct	_SDP1553BXT_RT_MSG
*\brief		This structure contains members to hold the RT Message details
*
*  			The RT Message structure includes the Block status word, Time Tag, Time Tag Resolution, Command Word,\n
				Word Count, Data Words.
*
*/
typedef struct _SDP1553BXT_RT_MSG
{
	U16BIT u16BlockStsWord; /*!< Block status word */
	U64BIT u64TimeTag;	/*!< TimeTag Value */
	U16BIT u16TimetagRes;   /*!< Time Tag Resolution */
	U16BIT u16CmdWord;		/*!< Command Word */
	U16BIT u16WordCount;	/*!< Word Count */
	U16BIT u16Data[32];		/*!< Data Words */
}SDP1553BXT_RT_MSG, *PSDP1553BXT_RT_MSG;

/***********************************MT Mode Structure************************/
/**
*\struct	_SDP1553BXT_MT_INIT
*\brief		This structure contains members to hold the MT Initialization
*
*  			The MT Initialization includes the Total interrupt Queue Buffer size, Selective monitor enable, Enable the IRIG-B Message Format,\n
				Total Number of messages for an IRIG packets, Enable the IRIG-B 1 second time packet, Time Stamp type-Relative or Absolute, \n	
				Channel ID for Message Packet, IrigB Time Format.\n
*
*/
typedef struct _SDP1553BXT_MT_INIT
{
	U32BIT u32InteQueBufSize;     /*!< Total interrupt Queue Buffer size */
	U32BIT u8SelectiveMonEnable;  /*!< Selective monitor enable */	
	U8BIT u8IRIGEnable;           /*!< Enable the IRIG-B Message Format*/
	U32BIT u32IRIGMaxMsgCount;    /*!< Total Number of messages for an IRIG packets */
	U8BIT u8IRIGTimePktEnable;    /*!< Enable the IRIG-B 1 second time packet */
	U8BIT u8IRIGTimeType;         /*!< Time Stamp type-Relative or Absolute */
	U16BIT u16IRIGBChennalID;     /*!< Channel ID for Message Packet*/
	U8BIT u8IrigTimeFormat;		  /*!< IrigB Time Format */
}SDP1553BXT_MT_INIT,*PSDP1553BXT_MT_INIT;

/**
*\struct	_SDP1553BXT_MT_MSG
*\brief		This structure contains members to hold the Message details
*
*  			The Message details structure includes the Time tag word, Block status word, Response Time Word, \n
				Length word in bytes, Command word 1, Command word 2, Status Word, Status Word Only for RT to RT Type, \n
				Data Words, Time Tag Resolution.
*
*/
typedef struct _SDP1553BXT_MT_MSG
{
	U64BIT u64TimeTag;			/*!< TimeTag Value */
    U16BIT u16BlockStatusWord;  /*!< Block status word */
    U16BIT u16ResponseTimeWord; /*!< Response Time Word */
    U16BIT u16LengthWord;		/*!< Length word in bytes */
    U16BIT u16CmdWord1;         /*!< Command word 1 */
    U16BIT u16CmdWord2;         /*!< Command word 2 */
    U16BIT u16RTStsWrd1;        /*!< Status Word */
    U16BIT u16RTStsWrd2;        /*!< Status Word Only for RT to RT Type */
    U16BIT u16Data[32];			/*!< Data Words */
    U16BIT u16TimetagRes;		/*!< Time Tag Resolution */
}SDP1553BXT_MT_MSG, *PSDP1553BXT_MT_MSG;

/***********************************IRIGB-GEnerators Structure************************/
/**
*\struct	_SDP1553BXT_IRIGB_TIME
*\brief		This structure contains members to hold the IRIG-B Time
*
*  			The IRIG-B Time structure includes the Second, Minute, Hour, Day, Year, LeapYear.
*
*/
typedef struct _SDP1553BXT_IRIGB_TIME
{
    U8BIT 	u8Second;
    U8BIT 	u8Minute;
    U8BIT 	u8Hour;
	U16BIT 	u16Day;
    U8BIT 	u8Year;
	U8BIT 	u8IsLeapYear;
}SDP1553BXT_IRIGB_TIME, *PSDP1553BXT_IRIGB_TIME;

#pragma pack(pop)

/****************************function  prototypes ******************************/
/*!
*	\addtogroup Common_Functions List of common driver functions
* @{
*/

/**
*\brief 	 This function is used to find the total number of DP-1553B-AceXtreme device(s) present in the system
*
\param[out] out_pu16TotalDevice	It specifies the output pointer to hold the number of DP-1553B-AceXtreme device(s) found
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified total devices output pointer is null
*
*\pre		NA
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_GetTotalDeviceFound(PU16BIT out_pu16TotalDevice);

/** 
*\brief 	 This function is used to get pci details such as bus number, slot number, function number and channel number for the DP-XMC-5019 device(s)
*
*\param[out]  out_pSAllDevLocDetails	It specifies the output pointer to hold the device location details(size: in_u16MaxDevices)
*\param[in]   in_u16MaxDevices			It specifies the total number of DP-1553B-AceXtreme device(s) found
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output device location details structure pointer is null
*
*\pre		::DP1553BXT_GetTotalDeviceFound
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_GetAllDeviceLocations(PSDP1553BXT_DEVICE_LOCATION out_pSAllDevLocDetails, U16BIT in_u16MaxDevices);

/**
*\brief 		This function is used to open the specified DP-1553B-AceXtreme device(s).
*
*\param[in]		in_pSDeviceOpenInfo		It specifies the bus number, slot number, function number and channel number
*\param[out]	out_phDeviceHandle		It specifies the pointer to hold output device handle
*
*\retval		::DP1553BXT_SUCCESS is returned upon success
*\retval		::DP_DRV_ERR_INVALID_POINTER is returned if the device location structure pointer is null
*\retval		::DP1553BXT_ERR_DEVICE_BUSY is returned if the the device is already opened
*
* \pre			::DP1553BXT_GetAllDeviceLocations
* \post    	  	::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_Open(PSDP1553BXT_DEVICE_LOCATION in_pSDeviceOpenInfo, DP_DRV_HANDLE out_phDeviceHandle);

/**
*\brief 	 This function is used to close the opened device. Any opened device has to be closed before the application is exited.
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_DEVICE_NOT_OPEN is returned if the device is not opened
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_Close(DP_DRV_HANDLE in_hHandle);

/** 
*\brief		This function is used to get opened device location details(bus number, slot number, function number and channel number)
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_pSDeviceLocation	It specifies the pointer to hold the device location details
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output device location pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_GetDeviceLocation(DP_DRV_HANDLE in_hHandle, PSDP1553BXT_DEVICE_LOCATION out_pSDeviceLocation);

/**
*\brief 	 This function is used to reset the device to initial state
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u8ResetOption	This parameter provides option to reset device register or device memory or both.
 								\n(Bit 0 - DP1553BXT_RESET_REGISTER - Only Device Registers will be reseted,
 								\n Bit 1 - DP1553BXT_RESET_MEMORY - Only Device Memory will be reseted,
								\n Bit 0|Bit 1 - DP1553BXT_RESET_REGISTER | DP1553BXT_RESET_MEMORY  - Both Device registers and Memory will be reseted).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_Reset(DP_DRV_HANDLE in_hHandle, U8BIT in_u8ResetOption);

/**
*\brief		This function is used to get the error message corresponding to the error code. The error message specify briefly the cause of the error.
*
*\param[in]  in_s32ErrCode	It specifies the error code returned by the functions
*\param[out] out_ps8ErrMsg	It specifies the pointer to hold the error message(size:in_u16BufSize)
*\param[in]  in_u16BufSize	It specifies buffer size to hold the error message
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output error message pointer is null
*
*\pre	 	::DP1553BXT_Open
*\post	 	NA
*
*/
S32BIT STDCALL DP1553BXT_GetErrorMessage(S32BIT in_s32ErrCode, PS8BIT out_ps8ErrMsg, U16BIT in_u16BufSize);

/**
*\brief 	 This function is used to get the driver details(Driver Version)
*
*\param[out] out_pSDriverDetails 	It specifies the structure pointer to read the driver details(Driver Version)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output driver details pointer is null
*
*\pre		NA
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_GetDriverDetails(PSDP1553BXT_DRIVER_DETAILS out_pSDriverDetails);

/**
*\brief		  This function is used to get board ID
*
*\param[in]	  in_hHandle			It specifies the device handle which got from device open function
*\param[out]  out_pSDeviceDetails	It specifies the pointer to read the board ID
*
*\return	::DP1553BXT_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output board id pointer is null
* 
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*\author	Tamizharasan K
*\date		06 January, 2020
*/
S32BIT STDCALL DP1553BXT_GetDeviceDetails(DP_DRV_HANDLE in_hHandle, PSDP1553BXT_DEVICE_DETAILS out_pSDeviceDetails);

/**
*\brief		  This function is used to get glue logic details
*
*\param[in]	  in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out]  out_pSGlueLogicDetails	It specifies the pointer to read the FPGA version
*
*\return	::DP1553BXT_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output FPGA version pointer is null
* 
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_GetGlueLogicDetails(DP_DRV_HANDLE in_hHandle, PSDP1553BXT_GLUE_LOGIC out_pSGlueLogicDetails);

/**
*\brief		 This function is used to write data into the specified FPGA register offset
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[in]  in_u32WriteData	It specifies the the data to be written in specified register offset
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_WriteReg(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, U32BIT in_u32WriteData);

/**
*\brief 	 This function is used to read data from the specified FPGA register offset
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[out] out_pu32ReadData	It specifies the pointer to read data from specified register offset
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified read data output pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_ReadReg(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, PU32BIT out_pu32ReadData);

/**
*\brief 	 This function is used to Write a data to the specified address of the register in the board
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[in]  in_u32WriteData	It specifies the pointer to read data from specified register offset
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_Board_WriteReg(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, U32BIT in_u32WriteData);

/**
*\brief 	 This function is used to read a data from the specified register in the board
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[out] out_pu32ReadData	It specifies the pointer to read data from specified register offset
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified read data output pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_Board_ReadReg(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, PU32BIT out_pu32ReadData);

/**
*\brief 	 This function is used to write a given data word at the specified memory offset of shared RAM
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[in]  in_u32WriteData	It specifies the pointer to read data from specified register offset
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP1553BXT_ERR_INVALID_PARAM is returned if the input parameter is invalid
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_WriteMem(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, U32BIT in_u32WriteData);

/**
*\brief 	 This function is used to read a data word from the specified memory offset of shared RAM
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[out] out_pu32ReadData	It specifies the pointer to read data from specified register offset
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified read data output pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_ReadMem(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, PU32BIT out_pu32ReadData);

/**
*\brief 	 This function is used to read block of data from the specified memory offset of ACE RAM.
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the register offset value from which the data is to be read
*\param[out] out_pu32DataVal	It specifies the value which is to be read from the specified memory address
*\param[in]  in_u32Count		It specifies number of data to be read
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified read data output pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_ReadMemBlock(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, PU32BIT out_pu32DataVal, U32BIT in_u32Count);

/**
*\brief		This function is used to enable or disable(1 - Enable, 0 - Disable) the device share option(opening same device more than one time)
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	 in_u8EnDis		It specifies the enable / disable value(max:1)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_SHARE_VALUE is returned if the enable / disable device share option is out of limit(0 to 1)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_SetDeviceShare(DP_DRV_HANDLE in_hHandle, U8BIT in_u8EnDis);

/*!
* @}
*/

/******************************* Common BC / RT / MT Functions ************************************/
/*!
*	\addtogroup BC_RT_MT_Functions List of device specific driver functions
* @{
*/

/**
*\brief		  This function initialize the operational mode for the device and allocate start address and shared RAM size accordingly.
*
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]   in_u16OprnMode   		It specifies operation mode for device(max:7)
										\n(0 - DP1553BXT_OPRN_MODE_TEST,
										\n 1 - DP1553BXT_OPRN_MODE_BC,
										\n 2 - DP1553BXT_OPRN_MODE_RT,
										\n 3 - DP1553BXT_OPRN_MODE_MT,
										\n 4 - DP1553BXT_OPRN_MODE_BC_RT,
										\n 5 - DP1553BXT_OPRN_MODE_BC_MT,
										\n 6 - DP1553BXT_OPRN_MODE_RT_MT,
										\n 7 - DP1553BXT_OPRN_MODE_BC_RT_MT).
*\param[in]   in_u32Options   		This parameter is reserved for future purpose. Any dummy value need to be passed as input
*
*\return	::DP1553BXT_SUCCESS is returned upon success
*\return	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP1553BXT_ERR_INVALID_OPRNMODE is returned if the operational mode value is out of limit(0 to 7)
*\retval	::DP1553BXT_ERR_INVALID_OPTIONS is returned if the options value is out of limit(1 to 2)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_InitializeMode(DP_DRV_HANDLE in_hHandle, U16BIT in_u16OprnMode, U32BIT in_u32Options);

/**
*\brief 	 This function is used to set the direction (Input / Output) for eight numbers of Digital Input/Output (DIO) channels
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u8IOChannel		It specifies the DIO channel number(max:8)
									\n(0 – specifies all channel,
									\n 1 to 8 – specifies corresponding DIO channel)
*\param[in]  in_u8IODirection	It specifies the direction to be set for DIO channels(max:0xFF)
									\n(0 – set the DIO channel as input,
									\n 1 – set the DIO channel as output)
									\n if in_u8IOChannel is 0 (all channel) the bits 0 to 7 of in_u8IODirection represent the corresponding DIO direction.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_IOCHANNEL is returned if the DIO channel number is out of limit(0 to 8)
*\retval	::DP1553BXT_ERR_INVALID_IODIRECTION is returned if the DIO direction is out of limit(0x0 to 0xFF)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_DIO_SetDirection(DP_DRV_HANDLE in_hHandle, U8BIT in_u8IOChannel, U8BIT in_u8IODirection);

/**
*\brief 	 This function is used to get the direction for eight numbers of Digital Inout/Output (DIO) channels
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]	 in_u8IOChannel			It specifies the DIO channel number(max:8)
										\n(0 – specifies all channel,
										\n 1 to 8 – specifies corresponding DIO channel)
*\param[out]  out_pu8IODirection	It specifies the direction of DIO channels
										\n(0 – indicates the DIO channel as input,
										\n 1 – indicates the DIO channel as output,
										\n if in_u8IOChannel is 0 (all channel) the bits 0 to 7 of in_u8IODirection represent the corresponding DIO direction.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_IOCHANNEL is returned if the DIO channel number is out of limit(0 to 8)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified read DIO channel direction output pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_DIO_GetDirection(DP_DRV_HANDLE in_hHandle, U8BIT in_u8IOChannel, PU8BIT out_pu8IODirection);

/**
*\brief 	 This function is used to set the HIGH / LOW of the all or specified Digital Output (DOP) channel
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u8DOPChannel	It specifies the DOP channel number(max:8)
									\n(0 – specifies all channel,
									\n 1 to 8 – specifies corresponding DOP channel number)
*\param[in]  in_u8OutputState	It specifies the High / Low state of the specified DOP channel(max:0xFF)
									\n(0 - Low,
									\n 1 - High)
								if in_u8DOPChannelis 0 (all channel) the bits 0 to 7 of in_u8OutputState represent the corresponding DOP state.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_DOPCHANNEL is returned if the DIO channel number is out of limit(0 to 8)
*\retval	::DP1553BXT_ERR_INVALID_OUTPUTSTATE is returned if the DIO direction is out of limit(0x0 to 0xFF)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_DIO_WriteOutput(DP_DRV_HANDLE in_hHandle, U8BIT in_u8DOPChannel, U8BIT in_u8OutputState);

/**
*\brief 	 This function is used to read the status of the all or specified Digital Input (DIP) channel
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u8DIPChannel	It specifies the DIP channel number(max:8)\n
									0 – specifies all channel,\n
									1 to 8 – specifies corresponding DIP channel number.
*\param[out]  out_pu8InputState	It specifies the High / Low state of the specified DIP channel\n
									0 - Low,\n
									1 - High,\n
								if in_u8DIPChannel is 0 (all channel) the bits 0 to 7 of out_pu8InputState represent the corresponding DIP state.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_DIPCHANNEL is returned if the DIO channel number is out of limit(min:0 to max:8)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified DIP channel InputState pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_DIO_ReadInput(DP_DRV_HANDLE in_hHandle, U8BIT in_u8DIPChannel, PU8BIT out_pu8InputState);

/**
*\brief 	 This function is used to get the size of the ACE RAM
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu32RAMSize	It specifies the size of the ACE RAM
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified RAM size pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_GetRAMSize(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32RAMSize);

/**
*\brief 	 This function start the RAM self test. The device should not configured in any operation mode during the RAM self-test
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP1553BXT_ERR_DEV_OPRN_INITIALIZED is returned if the specified channel is initialized with operation mode(BC / RT / MT)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RAM_StartSelfTest(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	 This function is used to get the self-test status of the RAM
*
*\param[in]	 in_hHandle					It specifies the device handle which is obtained from device open function
*\param[out] out_pu32RAMSeftTestSts		It specifies the RAM self-test result
											\n(0x0  - Self-Test not performed,
											\n 0x2  - Self-Test running,
											\n 0x5  - Self-Test completed and PASS,
											\n 0x4  - Self-Test completed and FAIL).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified RAM self-test pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RAM_GetSelfTestStatus(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32RAMSeftTestSts);

/**
*\brief 	 This function is used to reset the self-test status of the ACE RAM
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RAM_ResetSelfTestStatus(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	 This function is used to perform the RAM data bus test using the specified offset location and provide the failure data lines of the RAM
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u32Offset		It specifies the offset value to perform the data bus test
*\param[out] out_pu32Result		It specifies the data bus test result of RAM
									\n(0 – Pass, Otherwise if any bit set, corresponding data lines are failed).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified RAM data bus test pointer is null
*\retval	::DP1553BXT_ERR_DEV_OPRN_INITIALIZED is returned if the specified channel is initialized with operation mode(BC / RT / MT)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RAM_DataBusTest(DP_DRV_HANDLE in_hHandle, U32BIT in_u32Offset, PU32BIT out_pu32Result);

/**
*\brief 	 This function is used to perform the RAM address bus test for whole RAM and provide the failure address lines of the RAM
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu32Result		It specifies the address bus test result of RAM
									\n(0 – Pass, Otherwise if any bit set, corresponding address lines are failed).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified address bus test result pointer is null
*\retval	::DP1553BXT_ERR_DEV_OPRN_INITIALIZED is returned if the specified channel is initialized with operation mode(BC / RT / MT)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RAM_AddressBusTest(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32Result);

/**
*\brief 	 This function is used to perform the RAM data integrity test for whole RAM and provide the memory failure counts
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu32FailCount	This parameter specifies the fail count of the data integrity test of RAM
									\n(0 – Pass, otherwise total memory failed count).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified fail count pointer is null
*\retval	::DP1553BXT_ERR_DEV_OPRN_INITIALIZED is returned if the specified channel is initialized with operation mode(BC / RT / MT)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RAM_DataIntegrityTest(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32FailCount);

/**
*\brief 	 This function start the RAM BIST. The device should not configured in any operation mode during the RAM BIST
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u8BistSel		It specifies which BIST to be started
									\n(0x1 - DP1553BXT_SINGLE_PORT_RAM_BIST,
									\n 0x2 - DP1553BXT_RAM_BIST,
									\n 0x4 - DP1553BXT_ROM_BIST).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_DEV_OPRN_INITIALIZED is returned if the specified channel is initialized with operation mode(BC / RT / MT)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RAM_StartBIST(DP_DRV_HANDLE in_hHandle, U8BIT in_u8BistSel);

/**
*\brief 	 This function is used to get the BIST status of the ACE RAM
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_pSRAMBistStatus	It specifies which status of all three type of BIST.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified BIST status structure pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RAM_GetBISTStatus(DP_DRV_HANDLE in_hHandle, PSDP1553BXT_RAM_BIST_STATUS out_pSRAMBistStatus);

/**
*\brief 	 This function start the RAM Adaptive Scan BIST. The device should not configured in any operation mode during the RAM Adaptive Scan BIST
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_DEV_OPRN_INITIALIZED is returned if the specified channel is initialized with operation mode(BC / RT / MT)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RAM_StartAsBIST(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	 This function is used to get the self-test status  of the RAM
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_u8AsBistStatus		It specifies the RAM self-test result
										\n(0x0  - BIST Reset,
										\n 0x1  - BIST not running,
										\n 0x2  - BIST in progress,
										\n 0x7  - BIST completed and FAIL,
										\n 0xB  - BIST completed and PASS).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified bist status pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RAM_GetAsBISTStatus(DP_DRV_HANDLE in_hHandle, PU8BIT out_u8AsBistStatus);

/**
*\brief 	 This function will increment the time tag counter to one if the time tag resolution is "Test Clock Mode".\n
			 This is used to test the time tag counter.
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_TimeTagTestClock(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	 This function is used to set the time tag rollover bits to generate the interrupt, if interrupt is enabled
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]	 in_u16TTRolloverSel	It controls the rollover point that triggers the 'Time Tag Rollover' interrupt(max:7),\n
 									 i.e. which bit position in the Time Tag value triggers the interrupt. Any of following values can be used,
										\n(0 - DP1553BXT_TIMETAG_ROLLOVER_16BITS,
										\n 1 - DP1553BXT_TIMETAG_ROLLOVER_17BITS,
										\n 2 - DP1553BXT_TIMETAG_ROLLOVER_18BITS,
										\n 3 - DP1553BXT_TIMETAG_ROLLOVER_19BITS,
										\n 4 - DP1553BXT_TIMETAG_ROLLOVER_20BITS,
										\n 5 - DP1553BXT_TIMETAG_ROLLOVER_21BITS,
										\n 6 - DP1553BXT_TIMETAG_ROLLOVER_22BITS,
										\n 7 - DP1553BXT_TIMETAG_ROLLOVER_48BITS).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_TIMETAG_TTROLLOVERSEL is returned if the time tag roll-over is out of limit(0 to 7)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_SetTimeTagRollover(DP_DRV_HANDLE in_hHandle, U16BIT in_u16TTRolloverSel);

/**
*\brief 	 This function is used to set the internal 48 bit time tag counter resolution. This will reset the time tag roll-over count also
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u16TimeTagRes	It specifies the time tag resolution value options to be configured(max:10)
									\n(0 - DP1553BXT_TIMETAG_RES_64US,
									\n 1 - DP1553BXT_TIMETAG_RES_32US,
									\n 2 - DP1553BXT_TIMETAG_RES_16US,
									\n 3 - DP1553BXT_TIMETAG_RES_8US,
									\n 4 - DP1553BXT_TIMETAG_RES_4US,
									\n 5 - DP1553BXT_TIMETAG_RES_2US,
									\n 6 - DP1553BXT_TIMETAG_RES_1US,
									\n 7 - DP1553BXT_TIMETAG_RES_500NS,
									\n 8 - DP1553BXT_TIMETAG_RES_100NS,
									\n 9 - DP1553BXT_TIMETAG_RES_TEST_CLOCK,
									\n 10 - DP1553BXT_TIMETAG_RES_EXT_CLOCK).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_TIMETAGRES is returned if the time tag resolution is out of limit(0 to 10)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_SetTimeTagResolution(DP_DRV_HANDLE in_hHandle, U16BIT in_u16TimeTagRes);

/**
*\brief 	 This function is used to get the current time tag value (all 48 bits) and time tag resolution
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_pu64TimeTagVal		It contains current value of 48 bit time tag counter
*\param[out] out_pu16TimeTagRes		It contains current time tag resolution
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified time tag value structure pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified time tag resolution pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_GetTimeTagValue(DP_DRV_HANDLE in_hHandle, PU64BIT out_pu64TimeTagVal, PU16BIT out_pu16TimeTagRes);

/**
*\brief 	 This function is used to set the 48 bit time tag counter value. This will reset the time tag roll-over count also
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]	 in_u64TimeTagVal		It contains new value of 48 bit time tag counter.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_SetTimeTagValue(DP_DRV_HANDLE in_hHandle, U64BIT in_u64TimeTagVal);

/**
*\brief 	 This function is used to reset the time tag register value. This will reset the time tag roll-over count also
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_ResetTimeTag(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	 This function is used to get the time tag roll over count. This count will be increment on the 'Time Tag Rollover' interrupt is generated.\n
			 The Time Tag Rollover can be set using DP1553BXT_SetTimeTagRollover() function.
*
*\param[in]		in_hHandle					It specifies the device handle which is obtained from device open function
*\param[out]	out_pu32TimeTagROCount		It specifies the value of time tag roll over count
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified time tag roll over count pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_GetTimeTagRolloverCount(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32TimeTagROCount);

/**
*\brief 	This function is used to generate common software external trigger of all channels in the module.\n
			This is used to synchronize all BC channels in the module by using software trigger.\n
			This trigger can be generated from external trigger source to synchronize more than one modules.\n
			The BC can wait for the external trigger by using the opcode 'DP1553BXT_OPCODE_WTG".
*
*\param[in]	 in_hHandle	It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_GenerateSWExtTrigger(DP_DRV_HANDLE in_hHandle);


/******************************* BC Functions ************************************/
/*!
*	\addtogroup Bus_Controller_Functions List of bus controller specific driver functions
* @{
*/

/**
*\brief 	 This function initialize the channel as BC, initialize the hardware resources (GPQ, LPQ, HPQ, message blocks,\n
			 data blocks, memory words and host buffer sizes) for BC operation. If the device is already initialized\n
			 it will free all memory and reinitialize it. Based on the information the device RAM will be allocated dynamically.
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_BCInitInfo	It specifies initialization information of BC
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified time tag roll over count pointer is null
*\retval	::DP_DRV_ERR_MEM_ALLOCATION is returned if it is failed to allocate the memory
*\retval	::DP1553BXT_ERR_INVALID_RAM_SIZE is returned if the device ram size is invalid or null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_Initialize(DP_DRV_HANDLE in_hHandle, SDP1553BXT_BC_INIT in_BCInitInfo);

/**
*\brief 	 This function is used to configure the BC operation based on the initialization details and configure options
*
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	in_u16BCOptions		It specifies initialization information of BC.
								The following options can be set individually or together via "OR'ing"
								\n(0x1 - DP1553BXT_BC_OPT_ALT_MSG_TIMER : The time to next message will be started from the SOM instead of EOM (act as total message time)),
								\n(0x2 - DP1553BXT_BC_OPT_LATCH_TT_AT_SOM : Latch the time tag value of message at SOM, otherwise EOM),
								\n(0x4 - DP1553BXT_BC_OPT_GAP_CHECK_ENABLE : BC will check the elapsed time between midparity of the last transmitted BC word and midsync of the RT Status Word. 
								\n 	If the gap is less than 4µs, the WSA bit in the BC Block Status Word will be set),
								\n(0x8 - DP1553BXT_BC_OPT_BCST_STATUS_CHECK : The BC will check for status in all Broadcast commands. 
								\n The BC will not timeout until the No Response timeout Value has expired. 								
								\n 	If an RT Status Word is received before the timeout, a Word Count Error is logged in the BC Block Status Word (error event)).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_Configure(DP_DRV_HANDLE in_hHandle, U16BIT in_u16BCOptions);

/**
*\brief		This function is used to enable/disable the BC watch dog timer. It provides the fail safe mechanism,\n
			If the message sequence control block getting stuck in a loop without reloading the frame timer or branching to incorrect loop. If the specified timeout elapsed,\n 
			It will	generate 'BC Trap" interrupt, if it is masked by using 'DP1553BXT_BC_EnableInterrupt( )' function.\n
			This function should be called before calling 'DP1553BXT_BC_CreateMinorFrame( )' function in order to use the watchdog timer timeout value if it is enabled.\n 
			When using 'DP1553BXT_BC_CreateMinorFrameEx( )' function the watchdog timer (if it is enabled)\n
			has to be reset with the timeout value using opcode 'DP1553BXT_OPCODE_LWT' (the timeout value specified in 'in_pu32Timeout' parameter will not be used).
*
*\param[in]	in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]	in_u16Enable	It specifies enable / disable value of watchdog timer(max:1).
							\n(0 - Watchdog timer functionality is disabled,
							\n 1 - Watchdog timer functionality is enabled)
*\param[in]	in_pu32Timeout	It specifies timeout value for watchdog timer.\n
							This timeout value will be used in function 'DP1553BXT_BC_CreateMinorFrame' function to reset the watchdog timer automatically at the end of each minor frame.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_ENABLE is returned if the specified enable / disable value is out of limit
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_SetWatchdogTimer(DP_DRV_HANDLE in_hHandle, U16BIT in_u16Enable, U32BIT in_pu32Timeout);

/**
*\brief 	This function is used to set the RT response timeout for a message in BC mode. If an RT is slow to respond to messages from a BC,\n 
			in case of very long bus length between the two terminals, may need to increase the RT response timeout value.\n 
			This will cause the BC to wait a little longer for a response before declaring an error and continuing with the next message.
*			
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	in_u16RespTimeout	It specifies RT's response timeout in the resolution of 500ns(max:1023).\n
								Valid range 0 to 1023. If the value is 0 the default timeout 18.5 us will be used.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RESPTIMEOUT is returned if the specified response timeout value is out of limit(0 to 1023)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_SetNoResponseTimeOut(DP_DRV_HANDLE in_hHandle, U16BIT in_u16RespTimeout);

/**
*\brief 	This function is used to configure the global retry option for the messages, if a failure or status set condition occurs.\n 
			This settings will be applied if the 'DP1553BXT_BC_CTRL_RETRY_ENA' option is set in the 'BC Control Word' of particular message.
*			
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function								
*\param[in] in_u16NumOfRetries 	It specifies number of retries to be done for the messages in which the retry option enabled in 'BC Control Word'(max:1)
									\n(0 - DP1553BXT_BC_TOTAL_RETRY_ONE (Single retry for the message),
									\n 1 - DP1553BXT_BC_TOTAL_RETRY_TWO (Two retries for the message)).
*\param[in] in_u16ChannelSelect This parameter selects the in which 1553B channel the retries to be done(max:3)
									\n(0 - DP1553BXT_BC_RETRYCHN_BOTH_ORIG (Both first and second retry on the original bus),
									\n 1 - DP1553BXT_BC_RETRYCHN_1_ORIG_2_ALT (First retry on original bus, second retry on alternate bus),
									\n 2 - DP1553BXT_BC_RETRYCHN_BOTH_ALT (Both first and second retry on the alternate bus),
									\n 3 - DP1553BXT_BC_RETRYCHN_1_ALT_2_ORIG (First retry on alternate bus and second retry on original bus)).
*\param[in] in_u16RetryOnErr 	It specifies on which error the retry to be performed(max:3)\n
									\n(0 - DP1553BXT_BC_RETRYERR_ON_ME_NR (If No Response (NR) or Message Error (ME) is encountered, the message will be retried.),
									\n 1 - DP1553BXT_BC_RETRYERR_ON_STATUS_SET (BC retries will result from any of the following conditions:
											\n a. The 'Status Set' flag (SS) is set in the 'BC Block Status Word',
											\n b. The message fails the validity check,
											\n c. NR/ME Retries are also enabled),
									\n 2 - DP1553BXT_BC_RETRYERR_ON_1553A_ME 
									        \n(a. Messages will be retried if the DP1553BXT_BC_CTRL_1553A_MODE option is set in the 'BC Control Word' and the ME bit in the RT Status Word is ‘1’.
											\n b. NR/ME Retries are also enabled).
									\n 3 - DP1553BXT_BC_RETRYERR_ON_ALL (All above conditions will generate a retry)).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_NUMOFRETRIES is returned if the specified number retries is out of limit(0 or 1)
*\retval	::DP1553BXT_ERR_INVALID_CHANNELSELECT is returned if the specified channel select value is out of limit(0 to 3)
*\retval	::DP1553BXT_ERR_INVALID_RETRYONERR is returned if the specified retry on error value is out of limit(0 to 3)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_SetMessageRetry(DP_DRV_HANDLE in_hHandle, U16BIT in_u16NumOfRetries, U16BIT in_u16ChannelSelect,  U16BIT in_u16RetryOnErr);

/**
*\brief 	This function is used to enables BC external trigger feature and specifies if BC will wait for external trigger signal before it starts to send message.
*			
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	in_u16EnableSts		This parameter is used to start BC only on external trigger(max:1).
									\n(0 - Disable External Trigger Start,
									\n 1 - Enable External Trigger Start).								
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_ENABLESTS is returned if the specified enable/disable value is out of limit(0 to 1)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_EnableExtTriggerStart(DP_DRV_HANDLE in_hHandle, U16BIT in_u16EnableSts);

/**
*\brief 	This function is used to read a Double Word from the specified memory word ID
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u16MemWordID	It specifies the memory word ID(max:1023)
*\param[out] out_pu32Val		It specifies the read value of the memory word ID
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_MEMWORDID is returned if the specified memory word ID value is out of limit(0 to 1023)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_ReadMemoryDWord(DP_DRV_HANDLE in_hHandle, U16BIT in_u16MemWordID, PU32BIT out_pu32Val);

/**
*\brief 	This function is used to write a Double Word into specified memory word ID. These memory word values can be used in opcode also.
*			
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	in_u16MemWordID		It specifies the memory word ID to write(max:1023)	
*\param[in]	in_u32Val			It contains the value to be written in the memory word ID.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_MEMWORDID is returned if the specified memory word ID value is out of limit(0 to 1023)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_WriteMemoryDWord(DP_DRV_HANDLE in_hHandle, U16BIT in_u16MemWordID, U32BIT in_u32Val);

/**
*\brief 	This function creates the data block to use with message. The data block size is 32 data words and assign the application given unique data block ID to newly created data block.\n
			The application can access this data block by using only the data block ID
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u16DataBlkID	It specifies the Unique ID to represent the newly created data block(max:1399)
*\param[out] in_pu16DataBuffer	It specifies the pointer to the data buffer which to be loaded in to the newly created data block
*\param[in]  in_u16DataSize		It specifies the data words size to be copied from buffer to newly created data block(max:32).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_DATABLKID is returned if the specified data block ID is out of limit(0 to 1399)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified Data Buffer pointer is null
*\retval	::DP1553BXT_ERR_INVALID_DATASIZE is returned if the specified data size is out of limit(0 to 32)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_CreateDataBlock(DP_DRV_HANDLE in_hHandle, U16BIT in_u16DataBlkID, PU16BIT in_pu16DataBuffer, U16BIT in_u16DataSize);

/**
*\brief 	This function is used to create the message block (single, double data buffer / alternate message) to use with frames.\n 
			If the message block is created with alternate message this will occupy two messages size in the shared RAM.\n 
			This will assign the given unique message block ID to newly created message block. \n
			The application can access this message block by using only the message block ID.\n
			If the double buffer option is enabled, the message to be executed always by using 'DP1553BXT_OPCODE_XQF' opcode and condition code should be always 'TRUE'.\n 
			If the message is used as alternate message, this to be executed by using opcode 'DP1553BXT_OPCODE_XQF' based on some condition code.\n
*			
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	in_u16MsgBlkID		It specifies Unique ID to represent the newly created message block(max:2048)
*\param[in]	in_pSBCMsgDef		It specifies a pointer to the normal message definition.
*\param[in]	in_pSBCMsgDefAlt	It specifies a pointer to the alternate message definition. If double buffer enabled only\n
*				 				the data block id alone used and remaining informations are same as in 'in_pSBCMsgDef'.
*\param[in]	in_u16MSgOption		It specifies options to the message. The following options can be set individually or together via "OR'ing"(min:0x1 to max:0x2)
*									\n(1 - DP1553BXT_BC_MSGOPT_DOUBLE_BUFFER - Enable the data double buffer using the data block IDs in 'in_pSBCMsgDef' and 'in_pSBCMsgDefAlt'
*									\n 2 - DP1553BXT_BC_MSGOPT_DO_NOT_BUFFER - The message command and data words will not be added in the buffer and this message
*											can be read by using 'DP1553BXT_BC_ReadMessageFromID' function).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_MSGBLKID is returned if the specified message block ID is out of limit(0 to 2048)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified BC message define buffer pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified BC alternate message define buffer pointer is null
*\retval	::DP1553BXT_ERR_INVALID_MSGOPTION is returned if the specified message option value is out of limit(0 to 1)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_CreateMessage(DP_DRV_HANDLE in_hHandle, U16BIT in_u16MsgBlkID, PDP1553BXT_BC_MSG_DEF in_pSBCMsgDef, PDP1553BXT_BC_MSG_DEF in_pSBCMsgDefAlt, U16BIT in_u16MSgOption);

/**
*\brief 	This function is used to create the minor frame using the list of message IDs.\n
			The minor frame is used to create major frame. The application can access this minor frame by using only the application supplied unique minor frame ID.
*			
*\param[in]	in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	in_u16FrameID		It specifies the unique frame ID to represent the newly created minor frame(max:2048)
*\param[in]	in_u16NoOfMsgs		It specifies total number of message IDs available in the message Id array
*\param[in]	in_pu16MsgIDLst		It specifies the list of message IDs to be added in the minor frame in given order
*\param[in]	in_u16FrameTime		It specifies the minor frame time in the resolution of 100 micro seconds that will take to complete.\n 
								If this value is zero it will take total message time as minor frame time and immediately start the next minor frame after completing the last message in current minor frame.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_FRAMEID is returned if the specified frame ID value is out of limit(0 to 2048)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified message ID list buffer pointer is null
*\retval	::DP1553BXT_ERR_FRAME_EXIST
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_CreateMinorFrame(DP_DRV_HANDLE in_hHandle, U16BIT in_u16FrameID, U16BIT in_u16NoOfMsgs, PU16BIT in_pu16MsgIDLst, U16BIT in_u16FrameTime);

/**
*\brief 	This function is used to create the minor frame using the list of opcodes supplied by application. The minor frame is used to create major frame.\n 
			Each minor frame should be return by using 'DP1553BXT_OPCODE_RTN' opcode. The application can access this minor frame by using only the application supplied unique minor frame ID.
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u16FrameID		It specifies the unique frame ID to represent the newly created minor frame(max:1399)
*\param[in]  in_u16NoOfOpcodes	It specifies the total number of opcodes available in the opcode list array.
*\param[in]  in_pOpcodeList		It specifies the list of opcodes to be added in the minor frame in the given order
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_FRAMEID is returned if the specified frame ID is out of limit(0 to 1399)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified BC Opcode list buffer pointer is null
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGBLKID is returned if the specified message block ID is invalid
*\retval	::DP1553BXT_ERR_FRAME_EXIST is returned if the specified frame is already exist
*\retval	::DP1553BXT_ERR_INVALID_MEMWORDID is returned if the specified memory word ID value is out of limit(0 to 1023)
*\retval	::DP1553BXT_ERR_NO_OPCODE_MEMORY is returned if the specified memory is not available for opcodes
*\retval	::DP1553BXT_ERR_MSGBLK_NOT_FOUND is returned if the specified message block not found
*\retval	::DP1553BXT_ERR_INVALID_OPCODE_INDEX is returned if the specified opcode index in the frame is invalid
*\retval	::DP1553BXT_ERR_FRAME_NOT_FOUND is returned if the specified frame is invalid
*\retval	::DP1553BXT_ERR_INVALID_OPCODE_TYPE is returned if the specified opcode type in the frame is invalid
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_CreateMinorFrameEx(DP_DRV_HANDLE in_hHandle, U16BIT in_u16FrameID, U16BIT in_u16NoOfOpcodes, PDP1553BXT_BC_OPCODE_DEF in_pOpcodeList);

/**
*\brief 	This function is used to create the major frame using the list of minor frame IDs. This will assign the given unique major frame ID to newly created major frame.\n 
			The application can access this major frame by using only the unique major frame ID.
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u16FrameID			It specifies the unique frame ID to represent the newly created major frame(max:32)
*\param[in]  in_u16NoOfMinorFrm		It specifies total number of minor frame IDs available in the minor frame ID array
*\param[in]  in_pu16MinorFrmIDList	It specifies the list of minor frame IDs to be added in the major frame in the given order
*\param[in]  in_u32FrameCount		It specifies the frame count value
*\param[in]  in_u16Options			It specifies the opcode options (bit wise)\n
									The DP1553BXT_BC_FRMOPT_WAIT_EXT_TRIG option can be used to wait for external trigger to start the frame.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_FRAMEID is returned if the specified frame ID is out of limit(0 to 32)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified BC minor frame ID list buffer pointer is null
*\retval	::DP1553BXT_ERR_INVALID_MSGBLKID is returned if the specified message block ID is invalid
*\retval	::DP1553BXT_ERR_FRAME_EXIST is returned if the specified frame is already exist
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_CreateMajorFrame(DP_DRV_HANDLE in_hHandle, U16BIT in_u16FrameID, U16BIT in_u16NoOfMinorFrm, PU16BIT in_pu16MinorFrmIDList, U32BIT in_u32FrameCount, U16BIT in_u16Options);

/**
*\brief 	This function is used to create the major frame using the list of opcodes supplied by application.\n 
			The application can access this major frame by using only the application supplied major frame ID.
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u16FrameID			It specifies the unique frame ID to represent the newly created major frame(max:32)
*\param[in]  in_u16NoOfOpcodes		It specifies the total number of opcodes available in the opcode list array
*\param[in]  in_pOpcodeList			It specifies the list of opcodes to be added in the major frame in the given order
*\param[in]  in_u32FrameCount		It specifies the frame count value to repeat the frame
									(0 – the frame will be repeated infinitely up to issuing the stop otherwise the specified number of time the frame will be repeated)
*\param[in]  in_u16FrameRepeatAt	It specifies the index of the opcode in_pOpcodeList when repeating the frame at which index of opcode list to be started.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_FRAMEID is returned if the specified frame ID is out of limit(0 to 32)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified BC Opcode list buffer pointer is null
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGBLKID is returned if the specified message block ID is invalid
*\retval	::DP1553BXT_ERR_FRAME_EXIST is returned if the specified frame is already exist
*\retval	::DP1553BXT_ERR_INVALID_MEMWORDID is returned if the specified memory word ID value is out of limit(0 to 1023)
*\retval	::DP1553BXT_ERR_NO_OPCODE_MEMORY is returned if the specified memory is not available for opcodes
*\retval	::DP1553BXT_ERR_MSGBLK_NOT_FOUND is returned if the specified message block not found
*\retval	::DP1553BXT_ERR_INVALID_OPCODE_INDEX is returned if the specified opcode index in the frame is invalid
*\retval	::DP1553BXT_ERR_FRAME_NOT_FOUND is returned if the specified frame is invalid
*\retval	::DP1553BXT_ERR_INVALID_OPCODE_TYPE is returned if the specified opcode type in the frame is invalid
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_CreateMajorFrameEx(DP_DRV_HANDLE in_hHandle, U16BIT in_u16FrameID, U16BIT in_u16NoOfOpcodes, PDP1553BXT_BC_OPCODE_DEF in_pOpcodeList, U32BIT in_u32FrameCount, U16BIT in_u16FrameRepeatAt);

/**
*\brief 	This function removes all minor and major frames and free the memory allocated for frames(all opcodes will be removed).\n 
			If BC is running this will not allow to delete the frame details
*			
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_DestroyAllFrames(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This function removes all data blocks, message blocks, minor and major frames and free the memory allocated.\n 
			If BC is running this will not allow to delete the frame details
*			
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*\retval	::DP1553BXT_ERR_BC_RUNNING is returned if bus controller is running
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_DestroyAll(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This function enables the BC interrupts and requested (masked) interrupt events for application to receive the events through 'DP1553BXT_BC_WaitForEvents' function.\n 
			By default, 'End of Frame', 'HPQ Message Transmission' and 'LPQ Message Transmission' will be enabled to read normal and asynchronous message transactions.
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u32IntEventMasks	It specifies the interrupt event mask to generate events to application\n
									The following options can be set individually or together via "OR'ing": 
									\n(0x00000001 - DP1553BXT_EVT_BC_EOM, 
									\n 0x00000002 - DP1553BXT_EVT_BC_STATUS_SET,
									\n 0x00000004 - DP1553BXT_EVT_BC_FORMAT_ERR,
									\n 0x00000008 - DP1553BXT_EVT_BC_TRAP,
									\n 0x00000010 - DP1553BXT_EVT_BC_SELECT_EOM,
									\n 0x00000020 - DP1553BXT_EVT_BC_OPCODE_PARITY_ERR,
									\n 0x00000040 - DP1553BXT_EVT_BC_GPQ_100_ROLLOVER,
									\n 0x00000080 - DP1553BXT_EVT_BC_GPQ_50_ROLLOVER,
									\n 0x00000100 - DP1553BXT_EVT_BC_MSG_RETIRED,
									\n 0x00000200 - DP1553BXT_EVT_BC_USER_IRQ0, 
									\n 0x00000400 - DP1553BXT_EVT_BC_USER_IRQ1, 
									\n 0x00000800 - DP1553BXT_EVT_BC_USER_IRQ2, 
									\n 0x00001000 - DP1553BXT_EVT_BC_USER_IRQ3, 
									\n 0x00002000 - DP1553BXT_EVT_BC_CALL_STACK_ERR, 
									\n 0x00004000 - DP1553BXT_EVT_BC_LP_MSG_TX, 
									\n 0x00008000 - DP1553BXT_EVT_BC_LP_ROLLOVER,
									\n 0x00010000 - DP1553BXT_EVT_BC_HP_MSG_TX,
									\n 0x00020000 - DP1553BXT_EVT_BC_HP_ROLLOVER,
									\n 0x00040000 - DP1553BXT_EVT_BC_USER_EOF,
									\n 0x00080000 - DP1553BXT_EVT_BC_ADH_OVERFLOW,
									\n 0x01000000 - DP1553BXT_EVT_TT_ROLLOVER,
									\n 0x02000000 - DP1553BXT_EVT_RAM_PARITY,
									\n 0x04000000 - DP1553BXT_EVT_RAM_ST_COMPLETE).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_EnableInterrupt(DP_DRV_HANDLE in_hHandle, U32BIT in_u32IntEventMasks);

/**
*\brief 	This function disables all BC interrupts and unblock the threads if it is waiting for interrupt events or messages
			using 'DP1553BXT_BC_WaitForEvents()' or 'DP1553BXT_BC_ReadMessage()' functions.
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_DisableInterrupt(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This function is used to provide wait (block / non-block / timeout) for the specified events\n
			mask in which the interrupt events are enabled by using 'DP1553BXT_BC_EnableInterrupt' function.\n 
			This function can be used only if the interrupt(s) are enabled
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32EventMasks	It specifies for which interrupt events the application to be notified
*\param[in]  in_u16Options		It specifies whether the function to be unblocked, if any events occurred or all specified events(max:1).\n 
								Any of the following option can be used,
								\n(0 - DP1553BXT_EVT_OPT_WAIT_ANY,
								\n 1 - DP1553BXT_EVT_OPT_WAIT_ALL)
*\param[in]  in_pu32Timeout		It specifies the address of the timeout value\n
								The following values can be used,\n
								- If the pointer is NULL the function will be blocked infinitely until the any/all of the events occurred.\n
								- If the pointer is not NULL and the memory contains value zero then the function will return immediately regardless of events occurred.\n
								- If the pointer is not NULL and the memory contains non-zero then the function will be blocked upto specified value and timeout will occurred if no events occurred until the specified timeout.\n
*\param[out] out_pu32EventStatus	It contains the current events which all are occurred recently
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_OPTIONS is returned if the specified options value is out of limit(0 to 1)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified timeout pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified event status pointer is null
*\retval	::DP1553BXT_ERR_INT_NOT_ENABLED is returned if the interrupt is not enabled
*\retval	::DP1553BXT_ERR_INVALID_EVTWAIT_OPT is returned if the event wait option is invalid
*\retval	::DP1553BXT_ERR_TIMEOUT is returned if the timeout error is occurred
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_WaitForEvents(DP_DRV_HANDLE in_hHandle, U32BIT in_u32EventMasks, U16BIT in_u16Options, PU32BIT in_pu32Timeout, PU32BIT out_pu32EventStatus);

/**
*\brief 	This function is used to start the BC operation for specified major frame ID
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u16MajorFrmID	It specifies the major frame ID(max:31)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_MAJORFRMID is returned if the major frame ID value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*\retval	::DP1553BXT_ERR_FRAME_NOT_FOUND is returned if the specified frame is not found
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_Start(DP_DRV_HANDLE in_hHandle, U16BIT in_u16MajorFrmID);

/**
*\brief 	This function is used to stops / halts the BC operation after the completion of current message which is being transmitted
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8UnblockWait	It specifies whether the threads are waiting for event interrupts or messages to be unblocked on BC stop.
								\n(0 – no unblocking,
								\n 1 – unblock waiting thread)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_UNBLOCKWAIT is returned if the specified unblock wait value is out of limit(0 to 1)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_Stop(DP_DRV_HANDLE in_hHandle, U8BIT in_u8UnblockWait);

/**
*\brief 	This function is used to get the number of BC messages from software circular buffer only in interrupt mode
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu32MsgsCount	It specifies the Message counts available in software host buffer
*\param[out] out_pu32LostCount	It specifies the lost message count due to software host buffer overflow
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified available message count pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified lost message count pointer is null
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*\retval	::DP1553BXT_ERR_HOSTBUF_NOT_INSTALL is returned if the host buffer is not installed
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_GetBufferInfo(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32MsgsCount, PU32BIT out_pu32LostCount);

/**
*\brief 	This function is used to flush / clear the software circular buffer
*			
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*\retval	::DP1553BXT_ERR_HOSTBUF_NOT_INSTALL is returned if the host buffer is not installed
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_FlushBuffer(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This function is used to read the BC messages from host circular buffer in interrupt mode or directly from the device memory if interrupts are not enabled.
*			
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out]  out_pSBCMsg			It specifies the SDP1553BXT_BC_MSG structure which contains the BC message details
*\param[in]   in_u16MsgsToRead		It specifies the BC message which is to be read
*\param[out]  out_pu16AvailMsgs		It specifies the actual number of BC Messages available the output buffer (out_pSBCMsg)
*\param[in]   in_pu32Timeout		It specifies the address of the timeout value.\n
									The following values can be used,
										- If the pointer is NULL the function will be blocked infinitely until the any/all of the events occurred.\n
										- If the pointer is not NULL and the memory contains value zero then the function will return\n
										immediately regardless of events occurred.\n
										- If the pointer is not NULL and the memory contains non-zero then the function will be blocked upto\n
										specified value and timeout will occurred if no events occurred until the specified timeout.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified BC message structure pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified available message pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified timeout value pointer is null
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*\retval	::DP1553BXT_ERR_HOSTBUF_NOT_INSTALL is returned if the host buffer is not installed
*\retval	::DP1553BXT_ERR_TIMEOUT is returned if the timeout error is occurred
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_ReadMessage(DP_DRV_HANDLE in_hHandle, PSDP1553BXT_BC_MSG out_pSBCMsg, U16BIT in_u16MsgsToRead, PU16BIT out_pu16AvailMsgs, PU32BIT in_pu32Timeout);

/**
*\brief 	This function is used to read the BC message for the specified message ID from shared RAM of device (used when no host buffer or interrupt disabled)
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u16MsgBlkID		It specifies the message block id(max:1399)
*\param[out] out_pSBCMsg		It specifies the structure contains the BC message details
*\param[out] out_pu16MsgAvail	It specifies whether the message available in output buffer
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_MSGBLKID is returned if the specified message block ID value is out of limit(0 to 1399)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified BC message block pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified available message pointer is null
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*\retval	::DP1553BXT_ERR_HOSTBUF_NOT_INSTALL is returned if the host buffer is not installed
*\retval	::DP1553BXT_ERR_TIMEOUT is returned if the timeout error is occurred
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_ReadMessageFromID(DP_DRV_HANDLE in_hHandle, U16BIT in_u16MsgBlkID, PSDP1553BXT_BC_MSG out_pSBCMsg, PU16BIT out_pu16MsgAvail);

/**
*\brief 	This function is used to write a data into a data block from a input buffer given for the message block ID.\n 
			The number of words will be written starting at the specified offset from the beginning of the data block
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u16MsgBlkID		It specifies the message block ID(max:1399)
*\param[in]  in_pu16DataBuffer	It specifies the data buffer
*\param[in]  in_u16DataSize		It specifies the size of the data available in the input buffer(max:32)
*\param[in]  in_u16Offset		It specifies the offset value to write the data(max:32)
*\param[in]  in_u16Option		It specifies the option. DP1553BXT_BC_DATAOPT_WRITE_ALT_MSG – write into alternate message block
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_MSGBLKID is returned if the specified message block ID value is out of limit(0 to 1399)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*\retval	::DP1553BXT_ERR_MSGBLK_NOT_FOUND is returned if the specified message block not found
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_WriteMessageData(DP_DRV_HANDLE in_hHandle, U16BIT in_u16MsgBlkID, PU16BIT in_pu16DataBuffer, U16BIT in_u16DataSize, U16BIT in_u16Offset, U16BIT in_u16Option);

/**
*\brief 	This function is used to get the remaining frame time for the frame currently executing with 100 micro second resolution.
*			
*\param[in]	  in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out]  out_pu16FrmTimeRemain		It specifies the remaining frame time which is 100µs resolution
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified frame time remaining pointer is null 
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_GetFrameTimeRemaining(DP_DRV_HANDLE in_hHandle, PU16BIT out_pu16FrmTimeRemain);

/**
*\brief 	This function is used to clear all the messages loaded in the High Priority Queue (HPQ) or Low Priority Queue (LPQ)
*			
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]  in_u16Queue	It specifies the high priority queue or low priority queue selection(max:1).\n
							Any of the following values can be used,
							\n(0 - DP1553BXT_BC_PRIORITY_QUEUE_HIGH,
							\n 1 - DP1553BXT_BC_PRIORITY_QUEUE_LOW)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_QUEUE is returned if the specified queue selection value is out of limit(0 or 1)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_ResetAsyncMessageQueue(DP_DRV_HANDLE in_hHandle, U16BIT in_u16Queue);

/**
*\brief 	This function is used to send asynchronous messages on the low priority or high priority queue onto the 1553 data bus
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u16Queue			It specifies the high priority queue or low priority queue selection(max:1).\n
									Any of the following values can be used,
									\n(0 - DP1553BXT_BC_PRIORITY_QUEUE_HIGH,
									\n 1 - DP1553BXT_BC_PRIORITY_QUEUE_LOW).
*\param[in]  in_u16MsgCount			It specifies the message count(max:512)
*\param[in]  in_pu16MsgBlkIDList	It specifies the message block list
*\param[out] out_pu16QueueCount 	It specifies the current queue count after inserting the messages in to asynchronous queue
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_QUEUE is returned if the specified queue selection value is out of limit(0 or 1)
*\retval	::DP1553BXT_ERR_INVALID_MSGCOUNT is returned if the specified message count is out of limit(0 to 512)
*\retval	::DP1553BXT_ERR_MSGBLK_NOT_FOUND is returned if the specified message block not found
*\retval	::DP1553BXT_ERR_INVALID_PQUEUE is returned if the specified priority queue is invalid
*\retval	::DP1553BXT_ERR_PQUEUE_NOT_INIT is returned if the specified priority queue is not initialized
*\retval	::DP1553BXT_ERR_PQUEUE_NO_SPACE returned if the specified priority queue space is not available to store the messages
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_SendAsyncMessage(DP_DRV_HANDLE in_hHandle, U16BIT in_u16Queue, U16BIT in_u16MsgCount, PU16BIT in_pu16MsgBlkIDList, PU16BIT out_pu16QueueCount);

/**
*\brief 	This function is used to get the number of asynchronous messages are present in the low priority or high priority queue
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u16Queue			It specifies the high priority queue or low priority queue selection(max:1).\n
									Any of the following values can be used,
									\n(0 - DP1553BXT_BC_PRIORITY_QUEUE_HIGH,
									\n 1 - DP1553BXT_BC_PRIORITY_QUEUE_LOW).
*\param[out] out_pu16QueueCount		It specifies the current queue count after inserting the messages in to asynchronous queue
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP1553BXT_ERR_INVALID_QUEUE is returned if the specified queue selection value is out of limit(0 or 1) 
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_PQUEUE is returned if the specified priority queue is invalid
*\retval	::DP1553BXT_ERR_PQUEUE_NOT_INIT is returned if the specified priority queue is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_GetAsyncMessageCount(DP_DRV_HANDLE in_hHandle, U16BIT in_u16Queue, PU16BIT out_pu16QueueCount);

/**
*\brief 	This function is used to get the total General Priority Queue (GPQ) entries available in the queue
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu16GPQCount	It specifies the the GPQ count
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_GetGPQCount(DP_DRV_HANDLE in_hHandle, PU16BIT out_pu16GPQCount);

/**
*\brief 	This function is used to read a next entry from the General Purpose Queue (GPQ)
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu32GPQEntry	It specifies the next entry from the GPQ
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_ReadGPQ(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32GPQEntry);

/**
*\brief 	This function is used to set / clear / toggle general purpose flag register by the host processor
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u16SetGPF		Each bit Indicates the value of each General Purpose Flag set status(max:0xFFFF) (GPF0 to GPF15)
*\param[in]  in_u16ClearGPF		Each bit Indicates the value of each General Purpose Flag clear status(max:0xFFFF) (GPF0 to GPF15)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_SETGPF is returned if the specified general purpose flag set value is out of limit(0x0 to 0xFFFF)
*\retval	::DP1553BXT_ERR_INVALID_CLEARGPF is returned if the specified general purpose flag clear value is out of limit(0x0 to 0xFFFF)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_SetGPFState(DP_DRV_HANDLE in_hHandle, U16BIT in_u16SetGPF, U16BIT in_u16ClearGPF);

/**
*\brief 	This function is used to get the current BC condition code status
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_pu32CondCodeSts	It specifies the current BC condition code status
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified condition code value pointer is null 
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_BC_GetCondCodeStatus(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32CondCodeSts);

/*!
* @}
*/

/******************************* RT Functions ************************************/
/*!
*	\addtogroup Remote_Terminal_Functions List of Remote Terminal specific driver functions
* @{
*/

/**
*\brief 	This function is used to initialize the channel as RT. If the device is already initialized, it will free all memory and reinitialize it.\n 
			Based on the information, the device RAM will be allocated dynamically.
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_sRTInitInfo		It specifies the initialization information of RT
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RAM_SIZE is returned if the specified RAM size is invalid
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_Initialize(DP_DRV_HANDLE in_hHandle, SDP1553BXT_RT_INIT in_sRTInitInfo);

/**
*\brief 	This function is used to configure the channel as RT
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32ConfigOption	It specifies the configuration option for RT
								\n(0x01 - DP1553BXT_RT_OPT_CLR_SRV_REQ,			
                                \n 0x02 - DP1553BXT_RT_OPT_LOAD_TT_MC_SYNC,		
                                \n 0x04 - DP1553BXT_RT_OPT_CLR_TT_MC_SYNC,			
                                \n 0x08 - DP1553BXT_RT_OPT_ENA_ALT_STS,			
                                \n 0x10 - DP1553BXT_RT_OPT_1553A_MC_ENA,			
                                \n 0x20 - DP1553BXT_RT_OPT_ILLEGAL_RX_DIS,			
                                \n 0x40 - DP1553BXT_RT_OPT_BUSY_RX_DIS,			
                                \n 0x80 - DP1553BXT_RT_OPT_ENHANCE_TT_SYNC).		
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_Configure(DP_DRV_HANDLE in_hHandle, U32BIT in_u32ConfigOption);

/**
*\brief 	This function is used to get the RT address source as internal or external and RT type as Single
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_pu8RtAddrSource	It specifies RT address source
									\n(0 - External RT address source,
									\n 1 - Software control for RT address source).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified RT address source pointer is null  
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_GetRTAddressSource(DP_DRV_HANDLE in_hHandle, PU8BIT out_pu8RtAddrSource);

/**
*\brief 	This function is used to set the user defined RT address to the device, if the RT Address source is internal
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RtAddress		It specifies the RT address value(max:31)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_RT_ADDRESS_SOURCE is returned if the RT address source is invalid
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_SetRTAddress(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RtAddress);

/**
*\brief 	This function is used to get the current RT address latched in the channel
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu8RtAddress	It specifies RT address latched in device
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified RT address pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_GetRTAddress(DP_DRV_HANDLE in_hHandle, PU8BIT out_pu8RtAddress);

/**
*\brief 	This function is used to read the Channel A Transmitter status of specified RT number
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[out] out_pu8ChanATxSts	It specifies Channel A transmitter status of RT
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified transmitter status of RT address pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_GetChanATransmitterStatus(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, PU8BIT out_pu8ChanATxSts);

/**
*\brief 	This function is used to read the Channel B Transmitter status of specified RT number
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[out] out_pu8ChanBTxSts	It specifies Channel B transmitter status of RT
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified transmitter status of RT address pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_GetChanBTransmitterStatus(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, PU8BIT out_pu8ChanBTxSts);

/**
*\brief 	This function is used to get the terminal flag status of the RT
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[out] out_pu8TermFlagSts	It specifies the terminal flag status of the RT
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified terminal flag status pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_GetTerminalFlagStatus(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, PU8BIT out_pu8TermFlagSts);

/**
*\brief 	This function is used to enable the interrupt events for application
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32IntEvtMask	It specifies the value of interrupt event mask
								\n(0x00000001 - DP1553BXT_EVT_RT_EOM,					
                                \n 0x00000002 - DP1553BXT_EVT_RT_MODECODE,
                                \n 0x00000004 - DP1553BXT_EVT_RT_FORMAT_ERR,				
                                \n 0x00000008 - DP1553BXT_EVT_RT_SELECT_EOM,			
                                \n 0x00000010 - DP1553BXT_EVT_RT_DBLK_100_ROLLOVER,		
                                \n 0x00000020 - DP1553BXT_EVT_RT_STACK_100_ROLLOVER,		
                                \n 0x00000040 - DP1553BXT_EVT_RT_ADDR_PARITY_ERR,		
                                \n 0x00000080 - DP1553BXT_EVT_RT_TX_TIMEOUT,				
                                \n 0x00000100 - DP1553BXT_EVT_RT_DBLK_50_ROLLOVER,		
                                \n 0x00000200 - DP1553BXT_EVT_RT_STACK_50_ROLLOVER,		
                                \n 0x00000400 - DP1553BXT_EVT_RT_INTSTS_Q_ROLLOVER,		
                                \n 0x00000800 - DP1553BXT_EVT_RT_ILLEGAL_CMD,			
                                \n 0x00001000 - DP1553BXT_EVT_RT_STACK_OVERFLOW,
								\n 0x01000000 - DP1553BXT_EVT_TT_ROLLOVER,	
                                \n 0x02000000 - DP1553BXT_EVT_RAM_PARITY,	
                                \n 0x04000000 - DP1553BXT_EVT_RAM_ST_COMPLETE).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_EnableInterrupt(DP_DRV_HANDLE in_hHandle, U32BIT in_u32IntEvtMask);

/**
*\brief 	This function is used to disable the interrupt events for application
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_DisableInterrupt(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This function is used to set the mode code events for which RT Mode Code interrupt will be generated
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u8MsgType			It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u32MCIntEvtMask		It specifies the mode code event mask
									\n(0x1 - DP1553BXT_RT_MCIRQ_DYNAMIC_BUS_CTRL,		
                                    \n 0x2 - DP1553BXT_RT_MCIRQ_SYNCHRONIZE_NO_DATA,	
                                    \n 0x4 - DP1553BXT_RT_MCIRQ_TX_STATUS_WRD,		
                                    \n 0x8 - DP1553BXT_RT_MCIRQ_INIT_SELF_TEST,		
                                    \n 0x10 - DP1553BXT_RT_MCIRQ_TRNS_SHUTDOWN,		
                                    \n 0x20 - DP1553BXT_RT_MCIRQ_OVRD_TRNS_SHUTDOWN,	
                                    \n 0x40 - DP1553BXT_RT_MCIRQ_INH_TERM_FLAG,		
                                    \n 0x80 - DP1553BXT_RT_MCIRQ_OVRD_INH_TERM_FLG,	
                                    \n 0x100 - DP1553BXT_RT_MCIRQ_RESET_REMOTE_TERM,	
                                    \n 0x10000 - DP1553BXT_RT_MCIRQ_TRNS_VECTOR,			
                                    \n 0x20000 - DP1553BXT_RT_MCIRQ_SYNCHRONIZE_DATA,		
                                    \n 0x40000 - DP1553BXT_RT_MCIRQ_TRNS_LAST_CMD,		
                                    \n 0x80000 - DP1553BXT_RT_MCIRQ_TRNS_BIT_WRD,			
                                    \n 0x100000 - DP1553BXT_RT_MCIRQ_SEL_TRNS_SHUTDOWN,	
                                    \n 0x200000 - DP1553BXT_RT_MCIRQ_OVRD_SEL_TRNS_SHUTDOWN).
                                    
*                                   
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_SetModeCodeEvent(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MsgType, U32BIT in_u32MCIntEvtMask);

/**
*\brief 	This function is used to clear mode code event interrupt request
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8MsgType		It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u32MCIntEvtMask	It specifies the mode code event mask
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_ClearModeCodeEvent(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MsgType, U32BIT in_u32MCIntEvtMask);

/**
*\brief 	This function is used to legalize messages received by the RT. The legalization is based on whether the message is Broadcast or to the RT's own address.\n
			The legality of the message is based on transmit or receive, the specific sub-address, and the word count (or mode code) of the message.
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u8MsgType			It specifies the which type of message to be set(max:0x04)
										\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
										\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
										\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u8SubAddr			It specifies the sub address(max:31)
*\param[in]  in_u32WordCountMask	It specifies the word count mask.\n
									Each bit of the 32-bit DWORD represents every possible word count or Mode Code to be illegalized
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_SUBADDR is returned if the specified sub address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_Legalize(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MsgType, U8BIT in_u8SubAddr, U32BIT in_u32WordCountMask);

/**
*\brief 	This function is used to illegalize messages received by the RT. The legalization is based on whether the message is Broadcast or to the RT's own address.\n 
			The Illegality of the message is based on transmit or receive, the specific sub-address, and the word count (mode code) of the message
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u8MsgType			It specifies the which type of message to be set(max:0x04)
										\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
										\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
										\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u8SubAddr			It specifies the sub address(max:31)
*\param[in]  in_u32WordCountMask	It specifies the word count mask.\n
									Each bit of the 32-bit DWORD represents every possible word count or Mode Code to be illegalized
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_SUBADDR is returned if the specified sub address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_Illegalize(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MsgType, U8BIT in_u8SubAddr, U32BIT in_u32WordCountMask);

/**
*\brief 	This function is used to configure the sub address
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32SubAddrMask	It specifies Sub-addresses for configuration is to be done.\n
								Each bit is corresponding to Sub-Address.\n
								For example \n(Bit 0 – SA 0, 
											\n Bit 1 – SA 1, ….. ,
											\n Bit 31 - SA 31)
*\param[in]  in_u8MsgType		It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u8DataBufType	It specifies data buffer type with which specified sub-address is to be configured(max:0x09)
									\n(0x00 - DP1553BXT_RT_BUF_SINGLE,
									\n 0x01 - DP1553BXT_RT_BUF_CIR_128W,
									\n 0x02 - DP1553BXT_RT_BUF_CIR_256W,
									\n 0x03	- DP1553BXT_RT_BUF_CIR_512W,
									\n 0x04	- DP1553BXT_RT_BUF_CIR_1024W,
									\n 0x05	- DP1553BXT_RT_BUF_CIR_2048W,
									\n 0x06	- DP1553BXT_RT_BUF_CIR_4096W,
									\n 0x07	- DP1553BXT_RT_BUF_CIR_8192W,
									\n 0x08	- DP1553BXT_RT_BUF_DOUBLE,
									\n 0x09	- DP1553BXT_RT_BUF_CIR_GLOBAL).									
*\param[in]  in_u32Options		It specifies below options for selected sub-addresses
									\n(0x01 - DP1553BXT_RT_SA_OPT_EOM_INT - SA EOM interrupt enabled for selected sub-address,
									\n 0x02 - DP1553BXT_RT_SA_OPT_CIRBUF_RO_INT - Circular roll-over interrupt is enabled for selected sub-address,
									\n 0x04 - DP1553BXT_RT_SA_OPT_LEGALIZE - Legalize selected sub-address for all word counts).
*                                       
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_DATABUFTYPE is returned if the specified data buffer type value is out of limit(0x0 to 0x09)
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_ConfigSubAddress(DP_DRV_HANDLE in_hHandle, U32BIT in_u32SubAddrMask, U8BIT in_u8MsgType, U8BIT in_u8DataBufType, U32BIT in_u32Options);

/**
*\brief 	This function is used to reset the sub address configuration
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32SubAddrMask	It specifies Sub-addresses for configuration is to be done.\n
								Each bit is corresponding to Sub-Address.\n
								For example \n(Bit 0 – SA 0, 
											\n Bit 1 – SA 1, ….. ,
											\n Bit 31 - SA 31)
*\param[in]  in_u8MsgType		It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_ResetSubAddress(DP_DRV_HANDLE in_hHandle, U32BIT in_u32SubAddrMask, U8BIT in_u8MsgType);

/**
*\brief 	This function is used to write the data to a data block from a user provided buffer.\n
			The number of words will be written starting at the user specified offset from the beginning of the data block.
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8SubAddr		It specifies the sub address(max:31)
*\param[in]  in_pu16DataBuffer	It specifies data buffer
*\param[in]  in_u16DataSize		It specifies the size of the data
*\param[in]  in_u16Offset		It specifies the offset value to write the data words to subaddress memory
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_SUBADDR is returned if the specified sub address value is out of limit(0 to 31)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified data buffer pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_WriteSAData(DP_DRV_HANDLE in_hHandle, U8BIT in_u8SubAddr, PU16BIT in_pu16DataBuffer, U16BIT in_u16DataSize, U16BIT in_u16Offset);

/**
*\brief 	This function is used to write the mode code data
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8MsgType		It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u8ModeCode		It specifies the Mode Code whose data to be written(max:31)
*\param[in]  in_u16MCData		It specifies the 16-bit mode data to be written
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_MODECODE is returned if the specified mode code value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_WriteModeCodeData(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MsgType, U8BIT in_u8ModeCode, U16BIT in_u16MCData);

/**
*\brief 	This function is used to read the mode code data
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8MsgType		It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u8ModeCode		It specifies the Mode Code whose data to be written(max:31)
*\param[out] out_pu16MCData		It specifies the 16-bit mode data to be read
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_MODECODE is returned if the specified mode code value is out of limit(0 to 31)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified mode code data pointer is null
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_ReadModeCodeData(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MsgType, U8BIT in_u8ModeCode, PU16BIT out_pu16MCData);

/**
*\brief 	This function is used to enable the BUSY bit in the RT status word for Receive / Transmit commands to any of the 32 possible sub address
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8MsgType		It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u32SubAddrMask	It specifies Sub-addresses for configuration is to be done.\n
								Each bit is corresponding to Sub-Address.\n
								For example \n(Bit 0 – SA 0, 
											\n Bit 1 – SA 1, ….. ,
											\n Bit 31 - SA 31)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_SetBusyBit(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MsgType, U32BIT in_u32SubAddrMask);

/**
*\brief 	This function is used to clear the BUSY bit in the RT status word for Receive / Transmit commands to any of the 32 possible sub address
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8MsgType		It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u32SubAddrMask	It specifies Sub-addresses for configuration is to be done.\n
								Each bit is corresponding to Sub-Address.\n
								For example \n(Bit 0 – SA 0, 
											\n Bit 1 – SA 1, ….. ,
											\n Bit 31 - SA 31)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_ClearBusyBit(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MsgType, U32BIT in_u32SubAddrMask);

/**
*\brief 	This function will set the RT status control bits
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u16StatusBits	It specifies which bits to be set. The corresponding bits will be cleared in RT status word
								\n(0x40 - DP1553BXT_RT_SIC_FRTF ('Terminal Flag' bit in RT status word will be cleared to '0'),
                                \n 0x80 - DP1553BXT_RT_SIC_FSSF (The 'Subsystem Flag' bit in RT status word will be cleared to '0'),
                                \n 0x100 - DP1553BXT_RT_SIC_FSR ('Service Request' bit in RT status word will be cleared to '0'),
                                \n 0x200 - DP1553BXT_RT_SIC_FBSY (The 'Subsystem Busy' bit in RT status word will be cleared to '0',
									\n except if corresponding busy busy bit for this specific sub-address is set to '1'), 
                                \n 0x400 - DP1553BXT_RT_SIC_FDBC ('Dynamic Bus Control Accepted' bit in RT status word will be cleared to '0')). 
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_SetStatusBits(DP_DRV_HANDLE in_hHandle, U16BIT in_u16StatusBits);

/**
*\brief 	This function will Get the RT status / Alternate status bits
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_pu16StatusBits		It specifies which bits to be set. The corresponding bits will be cleared in RT status word
									\n(0x40 - DP1553BXT_RT_SIC_FRTF ('Terminal Flag' bit in RT status word will be cleared to '0'),
									\n 0x80 - DP1553BXT_RT_SIC_FSSF (The 'Subsystem Flag' bit in RT status word will be cleared to '0'),
									\n 0x100 - DP1553BXT_RT_SIC_FSR ('Service Request' bit in RT status word will be cleared to '0'),
									\n 0x200 - DP1553BXT_RT_SIC_FBSY (The 'Subsystem Busy' bit in RT status word will be cleared to '0',
										\n except if corresponding busy busy bit for this specific sub-address is set to '1'), 
									\n 0x400 - DP1553BXT_RT_SIC_FDBC ('Dynamic Bus Control Accepted' bit in RT status word will be cleared to '0')). 
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified status bits pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_GetStatusBits(DP_DRV_HANDLE in_hHandle, PU16BIT out_pu16StatusBits);

/**
*\brief 	This function is used to write RT no response timeout in RT-RT transfer in transmit RT side
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u16NoRespTimeOut	It This parameter specifies the RT no response timeout in RT-RT transfer in Tx RT side in 500ns resolution
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_SetNoRespTimeOut(DP_DRV_HANDLE in_hHandle, U16BIT in_u16NoRespTimeOut);

/**
*\brief 	This function is used to read the last command/status words received / transmitted by RT
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_u16LastCmdWrdRxd	It specifies the last command word received
*\param[out] out_u16LastStsWrdTxd	It specifies the last status word transmitted
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified last command word receive pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified last command word transmit pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_GetLastCommandStatus(DP_DRV_HANDLE in_hHandle, PU16BIT out_u16LastCmdWrdRxd, PU16BIT out_u16LastStsWrdTxd);

/**
*\brief 	This function is used to get the last BIT test result
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu16BITStatus	It specifies the last BIT result
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified BIT status pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_GetLastBITMode(DP_DRV_HANDLE in_hHandle, PU16BIT out_pu16BITStatus);

/**
*\brief 	This function is used to set the RT engine to run state (from ready state). After RT start only the RT will respond to any command
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_Start(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This function is used to stop the RT engine and set to ready state. After stop RT will not response to any command
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_Stop(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This function is used to wait (block / non-block / timeout) for the specified events for that the interrupts are enabled
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32EventMasks	It specifies for which interrupt events the application to be notified
*\param[in]  in_u16Options		It specifies whether the function to be unblocked, if any events occurred or all specified events(max:1).\n 
								Any of the following option can be used,
								\n(0 - DP1553BXT_EVT_OPT_WAIT_ANY,
								\n 1 - DP1553BXT_EVT_OPT_WAIT_ALL)
*\param[in]  in_pu32Timeout		It specifies the address of the timeout value\n
								The following values can be used,\n
								- If the pointer is NULL the function will be blocked infinitely until the any/all of the events occurred.\n
								- If the pointer is not NULL and the memory contains value zero then the function will return immediately regardless of events occurred.\n
								- If the pointer is not NULL and the memory contains non-zero then the function will be blocked upto specified value and timeout will occurred if no events occurred until the specified timeout.\n
*\param[out] out_pu32EventStatus It contains the current events which all are occurred recently
*
*\retval	::DP1553BXT_ERR_INVALID_OPTIONS is returned if the specified options value is out of limit(0 to 1)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified timeout pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified event status pointer is null
*\retval	::DP1553BXT_ERR_INT_NOT_ENABLED is returned if the interrupt is not enabled
*\retval	::DP1553BXT_ERR_INVALID_EVTWAIT_OPT is returned if the event wait option is invalid
*\retval	::DP1553BXT_ERR_TIMEOUT is returned if the timeout error is occurred
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_WaitForEvents(DP_DRV_HANDLE in_hHandle, U32BIT in_u32EventMasks, U16BIT in_u16Options, PU32BIT in_pu32Timeout, PU32BIT out_pu32EventStatus);

/**
*\brief 	This function reads RT messages from software circular buffer or directly from device memory, if interrupts not enabled
*			
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out]  out_pSRTMsg			It specifies the SDP1553BXT_RT_MSG structure which contains the RT message details
*\param[in]   in_u16MsgsToRead		It specifies the RT message which is to be read
*\param[out]  out_pu16AvailMsgs		It specifies the actual number of RT Messages available the output buffer (out_pSRTMsg)
*\param[in]   in_pu32Timeout		It specifies the address of the timeout value.\n
									The following values can be used,
										- If the pointer is NULL the function will be blocked infinitely until the any/all of the events occurred.\n
										- If the pointer is not NULL and the memory contains value zero then the function will return\n
										immediately regardless of events occurred.\n
										- If the pointer is not NULL and the memory contains non-zero then the function will be blocked upto\n
										specified value and timeout will occurred if no events occurred until the specified timeout.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified RT message structure pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified available message pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified timeout value pointer is null
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_HOSTBUF_NOT_INSTALL is returned if the host buffer is not installed
*\retval	::DP1553BXT_ERR_TIMEOUT is returned if the timeout error is occurred
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_ReadMessage(DP_DRV_HANDLE in_hHandle, PSDP1553BXT_RT_MSG out_pSRTMsg, U16BIT in_u16MsgsToRead, PU16BIT out_pu16AvailMsgs, PU32BIT in_pu32Timeout);

/**
*\brief 	This function is used to get the number of RT messages from software circular buffer only in interrupt mode
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu32MsgsCount	It specifies the Message counts available in software host buffer
*\param[out] out_pu32LostCount	It specifies the lost message count due to software host buffer overflow
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified available message count pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified lost message count pointer is null
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_HOSTBUF_NOT_INSTALL is returned if the host buffer is not installed
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_GetBufferInfo(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32MsgsCount, PU32BIT out_pu32LostCount);

/**
*\brief 	This function is used to flush / clear the software circular buffer
*			
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_HOSTBUF_NOT_INSTALL is returned if the host buffer is not installed
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_RT_FlushBuffer(DP_DRV_HANDLE in_hHandle);

/*!
* @}
*/

/******************************* Multi-RT Functions ************************************/
/*!
*	\addtogroup Multi_Remote_Terminal_Functions List of Multi Remote Terminal specific driver functions
* @{
*/

/**
*\brief 	This function is used to initialize the channel as RT.\n
			If the device is already initialized, it will free all memory and reinitialize it.\n
			Based on the information, the device RAM will be allocated dynamically.
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_RTInitInfo		It specifies the initialization information of RT
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RAM_SIZE is returned if the device ram size is invalid or null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_Initialize(DP_DRV_HANDLE in_hHandle, SDP1553BXT_RT_INIT in_RTInitInfo);

/**
*\brief 	This function is used to select multiple RT addresses in Multi-RT mode
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32RtAddrSel	It specifies RT Address in Multi-RT Mode which are to be enabled.\n 
								If associated bit is set corresponding RT address will be enabled.\n 
								For example \n(Bit 0 – RT 0, 
											\n Bit 1 – RT 1, 
											\n. 
											\n Bit 31 – RT31).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_SelectRTAddress(DP_DRV_HANDLE in_hHandle, U32BIT in_u32RtAddrSel);

/**
*\brief 	This function get the user defined RT addresses in case of Multi-RT Mode
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu32RtAddress	It specifies RT Addresses in Multi-RT Mode which are enabled.\n 
								If associated bit is set corresponding RT address is enabled.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified RT address pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_GetSelectedRTAddress(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32RtAddress);

/**
*\brief 	This function is used to configure RT
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[in]  in_u32ConfigOption	It specifies the configuration option for RT
								\n(0x01 - DP1553BXT_RT_OPT_CLR_SRV_REQ,			
                                \n 0x02 - DP1553BXT_RT_OPT_LOAD_TT_MC_SYNC,		
                                \n 0x04 - DP1553BXT_RT_OPT_CLR_TT_MC_SYNC,			
                                \n 0x08 - DP1553BXT_RT_OPT_ENA_ALT_STS,			
                                \n 0x10 - DP1553BXT_RT_OPT_1553A_MC_ENA,			
                                \n 0x20 - DP1553BXT_RT_OPT_ILLEGAL_RX_DIS,			
                                \n 0x40 - DP1553BXT_RT_OPT_BUSY_RX_DIS,			
                                \n 0x80 - DP1553BXT_RT_OPT_ENHANCE_TT_SYNC).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_Configure(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, U32BIT in_u32ConfigOption);

/**
*\brief 	This function is used to read the Channel A Transmitter status of the RT
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[out] out_pu8ChanATxSts	It specifies Channel A transmitter status of RT
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified transmitter status of RT address pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_GetChanATransmitterStatus(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, PU8BIT out_pu8ChanATxSts);

/**
*\brief 	This function is used to read the Channel B Transmitter status of the RT
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[out] out_pu8ChanBTxSts	It specifies Channel B transmitter status of RT
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified transmitter status of RT address pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_GetChanBTransmitterStatus(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, PU8BIT out_pu8ChanBTxSts);

/**
*\brief 	This function is used to get the terminal flag status of the RT
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[out] out_pu8TermFlagSts	It specifies the terminal flag status of the RT
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified terminal flag status pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_GetTerminalFlagStatus(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, PU8BIT out_pu8TermFlagSts);

/**
*\brief 	This function enables RT Interrupts and requested (masked) interrupt events for application to receive the events through 'DP1553BXT_RT_WaitForEvents' function.\n 
			By default 'End of Message' will be enabled.
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32IntEvtMask	It specifies the value of interrupt event mask
								\n(0x00000001 - DP1553BXT_EVT_RT_EOM,					
                                \n 0x00000002 - DP1553BXT_EVT_RT_MODECODE,
                                \n 0x00000004 - DP1553BXT_EVT_RT_FORMAT_ERR,				
                                \n 0x00000008 - DP1553BXT_EVT_RT_SELECT_EOM,			
                                \n 0x00000010 - DP1553BXT_EVT_RT_DBLK_100_ROLLOVER,		
                                \n 0x00000020 - DP1553BXT_EVT_RT_STACK_100_ROLLOVER,		
                                \n 0x00000040 - DP1553BXT_EVT_RT_ADDR_PARITY_ERR,		
                                \n 0x00000080 - DP1553BXT_EVT_RT_TX_TIMEOUT,				
                                \n 0x00000100 - DP1553BXT_EVT_RT_DBLK_50_ROLLOVER,		
                                \n 0x00000200 - DP1553BXT_EVT_RT_STACK_50_ROLLOVER,		
                                \n 0x00000400 - DP1553BXT_EVT_RT_INTSTS_Q_ROLLOVER,		
                                \n 0x00000800 - DP1553BXT_EVT_RT_ILLEGAL_CMD,			
                                \n 0x00001000 - DP1553BXT_EVT_RT_STACK_OVERFLOW,
								\n 0x01000000 - DP1553BXT_EVT_TT_ROLLOVER,	
                                \n 0x02000000 - DP1553BXT_EVT_RAM_PARITY,	
                                \n 0x04000000 - DP1553BXT_EVT_RAM_ST_COMPLETE).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_EnableInterrupt(DP_DRV_HANDLE in_hHandle, U32BIT in_u32IntEvtMask);

/**
*\brief 	This function disables the RT interrupts and unblock the threads if it is waiting for interrupt events or message\n 
			using 'DP1553BXT_RT_WaitForEvents' or 'DP1553BXT_BC_ReadMessage' functions.
*			
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_DisableInterrupt(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This function is used to set the mode code event for interrupt generation
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr			It specifies RT channel(max:31)
*\param[in]  in_u8MsgType			It specifies the which type of message to be set(max:0x04)
										\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
										\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
										\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u32MCIntEvtMask		It specifies the mode code event mask
										\n(0x1 - DP1553BXT_RT_MCIRQ_DYNAMIC_BUS_CTRL,		
										\n 0x2 - DP1553BXT_RT_MCIRQ_SYNCHRONIZE_NO_DATA,	
										\n 0x4 - DP1553BXT_RT_MCIRQ_TX_STATUS_WRD,		
										\n 0x8 - DP1553BXT_RT_MCIRQ_INIT_SELF_TEST,		
										\n 0x10 - DP1553BXT_RT_MCIRQ_TRNS_SHUTDOWN,		
										\n 0x20 - DP1553BXT_RT_MCIRQ_OVRD_TRNS_SHUTDOWN,	
										\n 0x40 - DP1553BXT_RT_MCIRQ_INH_TERM_FLAG,		
										\n 0x80 - DP1553BXT_RT_MCIRQ_OVRD_INH_TERM_FLG,	
										\n 0x100 - DP1553BXT_RT_MCIRQ_RESET_REMOTE_TERM,	
										\n 0x10000 - DP1553BXT_RT_MCIRQ_TRNS_VECTOR,			
										\n 0x20000 - DP1553BXT_RT_MCIRQ_SYNCHRONIZE_DATA,		
										\n 0x40000 - DP1553BXT_RT_MCIRQ_TRNS_LAST_CMD,		
										\n 0x80000 - DP1553BXT_RT_MCIRQ_TRNS_BIT_WRD,			
										\n 0x100000 - DP1553BXT_RT_MCIRQ_SEL_TRNS_SHUTDOWN,	
										\n 0x200000 - DP1553BXT_RT_MCIRQ_OVRD_SEL_TRNS_SHUTDOWN).                                    
*                                   
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_SetModeCodeEvent(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, U8BIT in_u8MsgType, U32BIT in_u32MCIntEvtMask);

/**
*\brief 	This function is used to clear the mode code event
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[in]  in_u8MsgType		It specifies the which type of message mode code events to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u32MCIntEvtMask	It specifies the mode code event mask
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_ClearModeCodeEvent(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, U8BIT in_u8MsgType, U32BIT in_u32MCIntEvtMask);

/**
*\brief 	This function is used to legalize messages received by the RT.\n
			The legalization is based on whether the message is Broadcast or to the RTs own address.\n
			The legality of the message is based on transmit or receive, the specific sub-address, and the word count (mode code) of the message.
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr			It specifies RT channel(max:31)
*\param[in]  in_u8MsgType			It specifies the which type of message to be set(max:0x04)
										\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
										\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
										\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u8SubAddr			It specifies the sub address(max:31)
*\param[in]  in_u32WordCountMask	It specifies the word count mask.\n
									Each bit of the 32-bit DWORD represents every possible word count or Mode Code to be illegalized
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_INVALID_SUBADDR is returned if the specified sub address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_Legalize(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, U8BIT in_u8MsgType, U8BIT in_u8SubAddr, U32BIT in_u32WordCountMask);

/**
*\brief 	This function is used to illegalize messages received by the RT.\n
			The Illegalization is based on whether the message is Broadcast or to the RTs own address.\n
			The Illegality of the message is based on transmit or receive, the specific sub-address, and the word count (mode code) of the message.
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr			It specifies RT channel(max:31)
*\param[in]  in_u8MsgType			It specifies the which type of message to be set(max:0x04)
										\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
										\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
										\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u8SubAddr			It specifies the sub address(max:31)
*\param[in]  in_u32WordCountMask	It specifies the word count mask.\n
									Each bit of the 32-bit DWORD represents every possible word count or Mode Code to be illegalized
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_INVALID_SUBADDR is returned if the specified sub address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_Illegalize(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, U8BIT in_u8MsgType, U8BIT in_u8SubAddr, U32BIT in_u32WordCountMask);

/**
*\brief 	This function is used to configure the sub address
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[in]  in_u32SubAddrMask	It specifies Sub-addresses for configuration is to be done.\n
								Each bit is corresponding to Sub-Address.\n
								For example \n(Bit 0 – SA 0, 
											\n Bit 1 – SA 1, ….. ,
											\n Bit 31 - SA 31)
*\param[in]  in_u8MsgType		It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u8DataBufType	It specifies data buffer type with which specified sub-address is to be configured(max:0x09)
									\n(0x00 - DP1553BXT_RT_BUF_SINGLE,
									\n 0x01 - DP1553BXT_RT_BUF_CIR_128W,
									\n 0x02 - DP1553BXT_RT_BUF_CIR_256W,
									\n 0x03	- DP1553BXT_RT_BUF_CIR_512W,
									\n 0x04	- DP1553BXT_RT_BUF_CIR_1024W,
									\n 0x05	- DP1553BXT_RT_BUF_CIR_2048W,
									\n 0x06	- DP1553BXT_RT_BUF_CIR_4096W,
									\n 0x07	- DP1553BXT_RT_BUF_CIR_8192W,
									\n 0x08	- DP1553BXT_RT_BUF_DOUBLE,
									\n 0x09	- DP1553BXT_RT_BUF_CIR_GLOBAL).									
*\param[in]  in_u32Options		It specifies below options for selected sub-addresses
									\n(0x01 - DP1553BXT_RT_SA_OPT_EOM_INT - SA EOM interrupt enabled for selected sub-address,
									\n 0x02 - DP1553BXT_RT_SA_OPT_CIRBUF_RO_INT - Circular roll-over interrupt is enabled for selected sub-address,
									\n 0x04 - DP1553BXT_RT_SA_OPT_LEGALIZE - Legalize selected sub-address for all word counts).
*                                       
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_INVALID_DATABUFTYPE is returned if the specified data buffer type value is out of limit(0x0 to 0x09)
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_ConfigSubAddress(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, U32BIT in_u32SubAddrMask, U8BIT in_u8MsgType, U8BIT in_u8DataBufType, U32BIT in_u32Options);

/**
*\brief 	This function is used to reset the sub address
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[in]  in_u32SubAddrMask	It specifies Sub-addresses for configuration is to be done.\n
								Each bit is corresponding to Sub-Address.\n
								For example \n(Bit 0 – SA 0, 
											\n Bit 1 – SA 1, ….. ,
											\n Bit 31 - SA 31)
*\param[in]  in_u8MsgType		It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_ResetSubAddress(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, U32BIT in_u32SubAddrMask, U8BIT in_u8MsgType);

/**
*\brief 	This function is used to write the data to a data block from a user provided buffer.\n
			The number of words will be written starting at the user specified offset from the beginning of the data block.
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[in]  in_u8SubAddr		It specifies the sub address(max:31)
*\param[in]  in_pu16DataBuffer	It specifies data buffer
*\param[in]  in_u16DataSize		It specifies the size of the data
*\param[in]  in_u16Offset		It specifies the offset value to write the data words to subaddress memory
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_INVALID_SUBADDR is returned if the specified sub address value is out of limit(0 to 31)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified data buffer pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_WriteSAData(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, U8BIT in_u8SubAddr, PU16BIT in_pu16DataBuffer, U16BIT in_u16DataSize, U16BIT in_u16Offset);

/**
*\brief 	This function is used to write the mode code data
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[in]  in_u8MsgType		It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u8ModeCode		It specifies the Mode Code whose data to be written(max:31)
*\param[in]  in_u16MCData		It specifies the 16-bit mode data to be written
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_INVALID_MODECODE is returned if the specified mode code value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_WriteModeCodeData(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, U8BIT in_u8MsgType, U8BIT in_u8ModeCode, U16BIT in_u16MCData);

/**
*\brief 	This function is used to reads the mode code data
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[in]  in_u8MsgType		It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u8ModeCode		It specifies the Mode Code whose data to be written(max:31)
*\param[out] out_pu16MCData		It specifies the 16-bit mode data to be read
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_INVALID_MODECODE is returned if the specified mode code value is out of limit(0 to 31)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified mode code data pointer is null
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_ReadModeCodeData(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, U8BIT in_u8MsgType, U8BIT in_u8ModeCode, PU16BIT out_pu16MCData);

/**
*\brief 	This function is used to enable the selected sub-addresses to return the BUSY bit in their status word set to a 1
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[in]  in_u8MsgType		It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u32SubAddrMask	It specifies Sub-addresses for configuration is to be done.\n
								Each bit is corresponding to Sub-Address.\n
								For example \n(Bit 0 – SA 0, 
											\n Bit 1 – SA 1, ….. ,
											\n Bit 31 - SA 31)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_SetBusyBit(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, U8BIT in_u8MsgType, U32BIT in_u32SubAddrMask);

/**
*\brief 	This function is used to disable the selected sub-addresses by return the BUSY bit in their status word
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[in]  in_u8MsgType		It specifies the which type of message to be set(max:0x04)
									\n(0x01 - DP1553BXT_RT_MSGTYPE_RX – Receive Message,
									\n 0x02 - DP1553BXT_RT_MSGTYPE_TX – Transmit Message,
									\n 0x04 - DP1553BXT_RT_MSGTYPE_BCST – Broadcast Message).
*\param[in]  in_u32SubAddrMask	It specifies Sub-addresses for configuration is to be done.\n
								Each bit is corresponding to Sub-Address.\n
								For example \n(Bit 0 – SA 0, 
											\n Bit 1 – SA 1, ….. ,
											\n Bit 31 - SA 31)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_INVALID_MSGTYPE is returned if the specified message type value is out of limit(0x0 to 0x04)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_ClearBusyBit(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, U8BIT in_u8MsgType, U32BIT in_u32SubAddrMask);

/**
*\brief 	This function is used to set status bits of RT
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTSlot		It specifies which RT address to be configured in case of Multi-RT mode(max:31)
*\param[in]  in_u16StatusBits	It specifies which bits to be set. The corresponding bits will be cleared in RT status word
								\n(0x40 - DP1553BXT_RT_SIC_FRTF ('Terminal Flag' bit in RT status word will be cleared to '0'),
                                \n 0x80 - DP1553BXT_RT_SIC_FSSF (The 'Subsystem Flag' bit in RT status word will be cleared to '0'),
                                \n 0x100 - DP1553BXT_RT_SIC_FSR ('Service Request' bit in RT status word will be cleared to '0'),
                                \n 0x200 - DP1553BXT_RT_SIC_FBSY (The 'Subsystem Busy' bit in RT status word will be cleared to '0',
									\n except if corresponding busy busy bit for this specific sub-address is set to '1'), 
                                \n 0x400 - DP1553BXT_RT_SIC_FDBC ('Dynamic Bus Control Accepted' bit in RT status word will be cleared to '0')). 
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTSLOT is returned if the specified RT address value is out of limit(0 to 31)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_SetStatusBits(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTSlot, U16BIT in_u16StatusBits);

/**
*\brief 	This function is used to get status bits of RT
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTSlot		It specifies which RT address to be configured in case of Multi-RT mode(max:31)
*\param[out] out_pu16StatusBits	It specifies which bits to be set. The corresponding bits will be cleared in RT status word
									\n(0x40 - DP1553BXT_RT_SIC_FRTF ('Terminal Flag' bit in RT status word will be cleared to '0'),
									\n 0x80 - DP1553BXT_RT_SIC_FSSF (The 'Subsystem Flag' bit in RT status word will be cleared to '0'),
									\n 0x100 - DP1553BXT_RT_SIC_FSR ('Service Request' bit in RT status word will be cleared to '0'),
									\n 0x200 - DP1553BXT_RT_SIC_FBSY (The 'Subsystem Busy' bit in RT status word will be cleared to '0',
										\n except if corresponding busy busy bit for this specific sub-address is set to '1'), 
									\n 0x400 - DP1553BXT_RT_SIC_FDBC ('Dynamic Bus Control Accepted' bit in RT status word will be cleared to '0')). 
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTSLOT is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified status bits pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_GetStatusBits(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTSlot, PU16BIT out_pu16StatusBits);

/**
*\brief 	This function is used to write RT no response timeout in RT-RT transfer in transmit RT side
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr			It specifies RT channel(max:31)
*\param[in]  in_u16NoRespTimeOut	It This parameter specifies the RT no response timeout in RT-RT transfer in Tx RT side in 500ns resolution
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_SetNoRespTimeOut(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, U16BIT in_u16NoRespTimeOut);

/**
*\brief 	This function is used to read the last command/status words received/transmitted by RT
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr			It specifies RT channel(max:31)
*\param[out] out_u16LastCmdWrdRxd	It specifies the last command word received
*\param[out] out_u16LastStsWrdTxd	It specifies the last status word transmitted
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified last command word receive pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified last command word transmit pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_GetLastCommandStatus(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, PU16BIT out_u16LastCmdWrdRxd, PU16BIT out_u16LastStsWrdTxd);

/**
*\brief 	This function is used to get the last BIT test result
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTAddr		It specifies RT channel(max:31)
*\param[out] out_pu16BITStatus	It specifies the last BIT result
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP1553BXT_ERR_INVALID_RTADDRESS is returned if the specified RT address value is out of limit(0 to 31) 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified BIT status pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_GetLastBITMode(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTAddr, PU16BIT out_pu16BITStatus);

/**
*\brief 	This function is used to set the RT engine to run state (from ready state)
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u16MemWordID	It specifies the memory word ID(max:1023)
*\param[out] out_pu32Val		It specifies the read value of the memory word ID
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_MEMWORDID is returned if the specified memory word ID value is out of limit(0 to 1023)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_Start(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This function is used to stop the RT engine and set to ready state. After stop RT will not response to any command
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u16MemWordID	It specifies the memory word ID(max:1023)
*\param[out] out_pu32Val		It specifies the read value of the memory word ID
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_MEMWORDID is returned if the specified memory word ID value is out of limit(0 to 1023)
*\retval	::DP1553BXT_ERR_BC_NOT_INITIALIZED is returned if the BC mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_Stop(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This function will wait (block / non-block / timeout) for the specified events mask which are the interrupt events enabled in the 'DP1553BXT_RT_EnableInterrupt' function.
			This function can be used only if the interrupt(s) are enabled.
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32EventMasks	It specifies for which interrupt events the application to be notified
*\param[in]  in_u16Options		It specifies whether the function to be unblocked, if any events occurred or all specified events(max:1).\n 
								Any of the following option can be used,
								\n(0 - DP1553BXT_EVT_OPT_WAIT_ANY,
								\n 1 - DP1553BXT_EVT_OPT_WAIT_ALL)
*\param[in]  in_pu32Timeout		It specifies the address of the timeout value\n
								The following values can be used,\n
								- If the pointer is NULL the function will be blocked infinitely until the any/all of the events occurred.\n
								- If the pointer is not NULL and the memory contains value zero then the function will return immediately regardless of events occurred.\n
								- If the pointer is not NULL and the memory contains non-zero then the function will be blocked upto specified value and timeout will occurred if no events occurred until the specified timeout.\n
*\param[out] out_pu32EventStatus It contains the current events which all are occurred recently
*
*\retval	::DP1553BXT_ERR_INVALID_OPTIONS is returned if the specified options value is out of limit(0 to 1)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified timeout pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified event status pointer is null
*\retval	::DP1553BXT_ERR_INT_NOT_ENABLED is returned if the interrupt is not enabled
*\retval	::DP1553BXT_ERR_INVALID_EVTWAIT_OPT is returned if the event wait option is invalid
*\retval	::DP1553BXT_ERR_TIMEOUT is returned if the timeout error is occurred
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_WaitForEvents(DP_DRV_HANDLE in_hHandle, U32BIT in_u32EventMasks, U16BIT in_u16Options, PU32BIT in_pu32Timeout, PU32BIT out_pu32EventStatus);

/**
*\brief 	This function is used to read the RT messages from host circular buffer in interrupt mode or directly from the device memory if interrupts are not enabled.
*			
*\param[in]	  in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out]  out_pSRTMsg			It specifies the SDP1553BXT_RT_MSG structure which contains the RT message details
*\param[in]   in_u16MsgsToRead		It specifies the RT message which is to be read
*\param[out]  out_pu16AvailMsgs		It specifies the actual number of RT Messages available the output buffer (out_pSRTMsg)
*\param[in]   in_pu32Timeout		It specifies the address of the timeout value.\n
									The following values can be used,
										- If the pointer is NULL the function will be blocked infinitely until the any/all of the events occurred.\n
										- If the pointer is not NULL and the memory contains value zero then the function will return\n
										immediately regardless of events occurred.\n
										- If the pointer is not NULL and the memory contains non-zero then the function will be blocked upto\n
										specified value and timeout will occurred if no events occurred until the specified timeout.
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified RT message structure pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified available message pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified timeout value pointer is null
*\retval	::DP1553BXT_ERR_RT_NOT_INITIALIZED is returned if the RT mode is not initialized
*\retval	::DP1553BXT_ERR_HOSTBUF_NOT_INSTALL is returned if the host buffer is not installed
*\retval	::DP1553BXT_ERR_TIMEOUT is returned if the timeout error is occurred
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MRT_ReadMessage(DP_DRV_HANDLE in_hHandle, PSDP1553BXT_RT_MSG out_pSRTMsg, U16BIT in_u16MsgsToRead, PU16BIT out_pu16AvailMsgs, PU32BIT in_pu32Timeout);

/*!
* @}
*/


/******************************* MT Functions ************************************/
/*!
*	\addtogroup Bus_Monitor_Functions List of Multi Bus Monitor specific driver functions
* @{
*/

/**
*\brief 	This function initialize the channel as MT, initialize the hardware resources for BC operation.\n
			If the device is already initialized, it will free all memory and reinitialize it.\n 
			Based on the information the device RAM will be allocated dynamically.
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  s_MTInit			It specifies the initialization information of RT
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_MEM_ALLOCATION is returned if it is failed to allocate the memory
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_Initialize(DP_DRV_HANDLE in_hHandle, SDP1553BXT_MT_INIT s_MTInit);

/**
*\brief 	This function is used to configure the bus monitor
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8StackSize		It specifies stack size to be used for MT messages
									\n(0x0 - DP1553BXT_MT_STACK_SIZE_MAX_AVAIL,
									\n 0x1 - DP1553BXT_MT_STACK_SIZE_500,      
									\n 0x2 - DP1553BXT_MT_STACK_SIZE_1K,       
									\n 0x3 - DP1553BXT_MT_STACK_SIZE_2K,       
									\n 0x4 - DP1553BXT_MT_STACK_SIZE_4K,       
									\n 0x5 - DP1553BXT_MT_STACK_SIZE_8K,       
									\n 0x6 - DP1553BXT_MT_STACK_SIZE_16K,      
									\n 0x7 - DP1553BXT_MT_STACK_SIZE_32K,      
									\n 0x8 - DP1553BXT_MT_STACK_SIZE_64K,      
									\n 0x9 - DP1553BXT_MT_STACK_SIZE_128K,     
									\n 0xA - DP1553BXT_MT_STACK_SIZE_256K,     
									\n 0xB - DP1553BXT_MT_STACK_SIZE_512K,     
									\n 0xC - DP1553BXT_MT_STACK_SIZE_1024K,    
									\n 0xD - DP1553BXT_MT_STACK_SIZE_2048K).                                    
*\param[in]  in_u32Config		It specifies the configuration parameter to configure MT
									\n(0x00080000 - DP1553BXT_MT_BUS_SW_EOM_DISABLE, 
									\n 0x00200000 - DP1553BXT_MT_EOM_TIMETAG_ENABLE,  
									\n 0x01000000 - DP1553BXT_MT_1553A_FORMAT_ENABLE, 
									\n 0x02000000 - DP1553BXT_MT_BCST_DISABLE,        
									\n 0x04000000 - DP1553BXT_MT_MIN_GAP_CHECK_ENABLE).													
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_Configure(DP_DRV_HANDLE in_hHandle, U8BIT in_u8StackSize, U32BIT in_u32Config);

/**
*\brief 	This function is used to set No response timeout value for the message
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RespTimeout	It specifies the no response timeout value in the resolution of 500ns(max:255)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RESPTIMEOUT is returned if the specified response timeout is out of limit(0 to 255)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_SetNoResponseTimeOut(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RespTimeout);

/**
*\brief 	This function is used to set particular RT's sub Address (SA) as enable to monitoring
*			
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in]  in_u8RTs		It specifies the RT address to which the monitoring operation to be configured(max:31)
*\param[in]  in_u32SAs		It specifies the sub address of the specified RT. In each entry, logical ‘0’ in a bit location\n 
							indicates that the respective subaddress will not be monitored, while logical ‘1’ indicates that sub-address will be monitored.
*\param[in]  in_u8TxRx		It specifies whether filter is to be specified to Tx or Rx associated with a RT address(max:2).\n 
							Any of the following options to be used.
							\n(0x00 - DP1553BXT_MT_SA_TX,
							\n 0x01 - DP1553BXT_MT_SA_TX,
                            \n 0x02 - DP1553BXT_MT_SA_TX).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_RTS is returned if the specified RT address value is out of limit(0 to 31)
*\retval	::DP1553BXT_ERR_INVALID_TXRX is returned if the specified TX or RX selection is out of limit(0 to 2)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_SetSelectiveMonitorOptions(DP_DRV_HANDLE in_hHandle, U8BIT in_u8RTs, U32BIT in_u32SAs, U8BIT in_u8TxRx);

/**
*\brief 	This function is used to start the 1553B monitoring operation
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_MT_NOT_INITIALIZED is returned if the MT mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_StartMonitor(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This function is used to stop the 1553B monitoring operation
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_MT_NOT_INITIALIZED is returned if the MT mode is not initialized
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_StopMonitor(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This function is used to set block status word compliance as standard or IRIG-B block status word
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8IRIGEnable	It specifies the enable / disable status of the block status word(max:1)
								\n(0 – Disable (default block status),
								\n 1 – Enable IRIG-B Block status).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_IRIGENABLE is returned if the specified IRIGB enable/disable value is out of limit(0 to 1)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_SetIrigBSWCompliance(DP_DRV_HANDLE in_hHandle, U8BIT in_u8IRIGEnable);

/**
*\brief 	This function is used to select the bus channel (bus A / B) to monitor
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u8ChanltoMonitor	It specifies the channel (bus A/B) to set for monitoring operation(max:2).
										\n(0 – Monitor both Bus A and Bus B,
										\n 1 – Monitor Bus A only,
										\n 2 – Monitor Bus B only).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_CHANLTOMONITOR is returned if the channel to monitor value is out of limit(0 to 2)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_SetChannelToMonitor(DP_DRV_HANDLE in_hHandle, U8BIT in_u8ChanltoMonitor);

/**
*\brief 	This function is used to to read the drop message count due to an MT stack overflow condition
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu32DropMsg	It specifies the count value of the dropped messages
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified dropped message structure pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_GetDroppedMessageCount(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32DropMsg);

/**
*\brief 	This function is used to read the pending message from message count on the MT stack memory
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu32MsgCount	It specifies the count value of the pending messages
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified message count pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_GetMessageCount(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32MsgCount);

/**
*\brief 	This function is used to read the number of interrupts actively stored in the MT interrupt queue
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu32QueCount	It specifies the count value of the interrupt count
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified queue count pointer is null
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_GetInterruptQueueCount(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32QueCount);

/**
*\brief 	This function is used to to set threshold message count that will cause the MT Message Count interrupt to be triggered.\n
			This includes all MT messages put on the stack.
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32MsgCont		It specifies the message count threshold value to trigger message count interrupt(max:0x1FFFF)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP1553BXT_ERR_INVALID_MSGCONT is returned if the specified message count value is out of limit(0x0 to 0x1FFFF) 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_SetMessageCountThreshold(DP_DRV_HANDLE in_hHandle, U32BIT in_u32MsgCont);

/**
*\brief 	This function is used to to set the number of WORDs that will cause the MT Word Count interrupt to be triggered.\n
			This includes the MT message header and contents.
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32WrdCont		It specifies the word count value to trigger the word count interrupt(max:0xFFFFF)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_WRDCONT is returned if the specified word count value is out of limit(0x0 to 0xFFFFF)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_SetWordCountThreshold(DP_DRV_HANDLE in_hHandle, U32BIT in_u32WrdCont);

/**
*\brief 	This function is used to set the timer value that will cause the MT timer interrupt to be triggered on roll-over
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32TimerVal		It specifies the timer value to trigger the word count interrupt(max:0xFFFF).\n
 								It has resolution of 100usec
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_TIMERVAL is returned if the specified word count value is out of limit(0x0 to 0xFFFF)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_SetTimerIntrThreshold(DP_DRV_HANDLE in_hHandle, U32BIT in_u32TimerVal);

/**
*\brief 	This function is used to disable the interrupt. After calling this function no interrupt will be generated
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_DisableInterrupt(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This function is used to enable the interrupt. By default Message count and Trigger IRQ interrupt will be enabled.\n
			If Timer, Message and word threshold counts are set as zero message count threshold will be one.
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u32IntEventMasks	It specifies the interrupt event mask to generate events to application.
									\n The following options can be set individually or together via "OR'ing": 
									\n(0x00000001 - DP1553BXT_EVT_MT_WORD_COUNT,
									\n 0x00000002 - DP1553BXT_EVT_MT_MSG_COUNT,
									\n 0x00000004 - DP1553BXT_EVT_MT_TIMERINT_FREERUN,
									\n 0x00000008 - DP1553BXT_EVT_MT_TIMERINT_EOM,
									\n 0x00000010 - DP1553BXT_EVT_MT_TRIG_IRQ,
									\n 0x00000020 - DP1553BXT_EVT_MT_STACK_OVERFLOW,
									\n 0x00000040 - DP1553BXT_EVT_MT_IRIG_1SEC).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_EnableInterrupt(DP_DRV_HANDLE in_hHandle, U32BIT in_u32IntEventMasks);

/**
*\brief 	This function will wait (block / non-block / timeout) for the specified events mask which are the interrupt events enabled in the 'DP1553BXT_MT_EnableInterrupt' function.\n
			This function can be used only if the interrupt(s) are enabled.
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u32EventMasks	It specifies for which interrupt events the application to be notified
*\param[in]  in_u16Options		It specifies whether the function to be unblocked, if any events occurred or all specified events(max:1).\n 
								Any of the following option can be used,
								\n(0 - DP1553BXT_EVT_OPT_WAIT_ANY,
								\n 1 - DP1553BXT_EVT_OPT_WAIT_ALL)
*\param[in]  in_pu32Timeout		It specifies the address of the timeout value\n
								The following values can be used,\n
								- If the pointer is NULL the function will be blocked infinitely until the any/all of the events occurred.\n
								- If the pointer is not NULL and the memory contains value zero then the function will return immediately regardless of events occurred.\n
								- If the pointer is not NULL and the memory contains non-zero then the function will be blocked upto specified value and timeout will occurred if no events occurred until the specified timeout.\n
*\param[out] out_pu32EventStatus It contains the current events which all are occurred recently
*
*\retval	::DP1553BXT_ERR_INVALID_OPTIONS is returned if the specified options value is out of limit(0 to 1)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified timeout pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified event status pointer is null
*\retval	::DP1553BXT_ERR_INT_NOT_ENABLED is returned if the interrupt is not enabled
*\retval	::DP1553BXT_ERR_INVALID_EVTWAIT_OPT is returned if the event wait option is invalid
*\retval	::DP1553BXT_ERR_TIMEOUT is returned if the timeout error is occurred
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_WaitForEvents(DP_DRV_HANDLE in_hHandle, U32BIT in_u32EventMasks, U32BIT in_u16Options, PU32BIT in_pu32Timeout, PU32BIT out_pu32EventStatus);

/**
*\brief 	This function is used to read a Double Word from the specified memory word ID
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_pu32Timeout		It specifies the address of the timeout value.\n
								The following values can be used,\n
								- If the pointer is NULL the function will be blocked infinitely until the any/all of the events occurred.\n
								- If the pointer is not NULL and the memory contains value zero then the function will return\n
									  immediately regardless of events occurred.\n
								- If the pointer is not NULL and the memory contains non-zero then the function will be blocked upto\n
	 								 specified value and timeout will occurred if no events occurred until the specified timeout.\n
*\param[out] out_pu16MsgPacket	It specifies the message buffer in IRIG format
*\param[in]  in_u32PktBufSize	It specifies size of message buffer
*\param[out] out_pu32PacketSize	It specifies the IRIG packet size
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified timeout pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified packet size pointer is null
*\retval	::DP1553BXT_ERR_TIMEOUT is returned if the specified event is failed to wait
*\retval	::DP1553BXT_ERR_MT_NOT_INITIALIZED is returned if the MT mode is not initialized
*\retval	::DP1553BXT_ERR_INPUT_BUF_OVERFLOW is returned if the specified buffer is overflow
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_IRIG_ReadMessage(DP_DRV_HANDLE in_hHandle, PU32BIT in_pu32Timeout, PU16BIT out_pu16MsgPacket, U32BIT in_u32PktBufSize, PU32BIT out_pu32PacketSize);

/**
*\brief 	This function is used to read message from MT stack
*			
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[in]  in_u16NoOfMsg			It specifies the number of message to read
*\param[in]  in_pu32Timeout			It specifies the address of the timeout value.\n
									The following values can be used,\n
									- If the pointer is NULL the function will be blocked infinitely until the any/all of the events occurred.\n
									- If the pointer is not NULL and the memory contains value zero then the function will return\n
										immediately regardless of events occurred.\n
									- If the pointer is not NULL and the memory contains non-zero then the function will be blocked upto\n
										specified value and timeout will occurred if no events occurred until the specified timeout.
*\param[out] out_pMsg				It specifies the message buffer
*\param[out] out_pu16AvalibleMsg	It specifies the available message count in output buffer (out_pMsg)
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified timeout pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified MT message structure pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified available message read pointer is null
*\retval	::DP1553BXT_ERR_INVALID_MT_NO_OF_MSG is returned if the specified no of message is invalid
*\retval	::DP1553BXT_ERR_MT_NOT_INITIALIZED is returned if the MT mode is not initialized
*\retval	::DP1553BXT_ERR_TIMEOUT is returned if the specified event is failed to wait
*\retval	::DP1553BXT_ERR_INVALID_MT_STACK_ADDR is returned if the specified MT stack address is invalid
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_ReadMessage(DP_DRV_HANDLE in_hHandle, U16BIT in_u16NoOfMsg, PU32BIT in_pu32Timeout, PSDP1553BXT_MT_MSG out_pMsg, PU16BIT out_pu16AvalibleMsg);

/**
*\brief 	This function get number of MT messages from software interrupt circular buffer - only in interrupt mode
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[out] out_pu32MsgsCount	It specifies the Message counts available in software host buffer
*\param[out] out_pu32LostCount	It specifies the lost message count due to software host buffer overflow
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified available message count pointer is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified lost message count pointer is null
*\retval	::DP1553BXT_ERR_MT_NOT_INITIALIZED is returned if the MT mode is not initialized
*\retval	::DP1553BXT_ERR_HOSTBUF_NOT_INSTALL is returned if the host buffer is not installed
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_GetBufferInfo(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32MsgsCount, PU32BIT out_pu32LostCount);

/**
*\brief 	This function is used to flush / clear the software circular buffer
*			
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_MT_NOT_INITIALIZED is returned if the MT mode is not initialized
*\retval	::DP1553BXT_ERR_HOSTBUF_NOT_INSTALL is returned if the host buffer is not installed
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_MT_FlushBuffer(DP_DRV_HANDLE in_hHandle);

/*!
* @}
*/


/******************************* IRIGB Functions ************************************/
/*!
*	\addtogroup IRIGB_Functions List of Multi IRIGB specific driver functions
* @{
*/

/**
*\brief 	This function is used to Set Time Source as External or Internal
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_u8TimeSrc		It specifies the timer source
								\n(0 – External Time Source,
								\n 1 – Internal Time Source).
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*\retval	::DP1553BXT_ERR_INVALID_TIMESRC is returned if the specified timer source value is out of limit(0 to 1)
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_IRIGB_SetTimeSource(DP_DRV_HANDLE in_hHandle, U8BIT in_u8TimeSrc);

/**
*\brief 	This function is used to set IRIG-B time
*			
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]  in_IRIGTime		It specifies the structure to IRIG time
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP1553BXT_ERR_INVALID_IRIGTIME is returned if the IRIG-B time is invalid
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_IRIGB_SetTime(DP_DRV_HANDLE in_hHandle, SDP1553BXT_IRIGB_TIME in_IRIGTime);

/**
*\brief 	This Function is used to load IRIG-B Time Value
*			
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_IRIGB_LoadTime(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	This Function is used to reset IRIG Time Generation
*			
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DP1553BXT_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null 
*
*\pre		::DP1553BXT_Open
*\post		::DP1553BXT_GetErrorMessage
*
*/
S32BIT STDCALL DP1553BXT_IRIGB_Reset(DP_DRV_HANDLE in_hHandle);

/*!
* @}
*/


/*!
* @}
*/
#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif

#endif //#ifndef _DP1553BXT_PRO_H_
