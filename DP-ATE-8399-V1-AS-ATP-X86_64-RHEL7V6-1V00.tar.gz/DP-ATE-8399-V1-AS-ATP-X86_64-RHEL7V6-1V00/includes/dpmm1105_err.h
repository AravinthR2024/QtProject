/**
 *	\file dpmm1105_err.h
 *	\brief This file contains the  error code definition
 *
 *	This file contains the  error code definition
 *
 *	\author Mahesh S 
 *	\date 05:41PM on February 26, 2019
 *
 *	\version
 *	- Initial version
 *
 *	Copyright (C) 2019 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
 *	All Rights Reserved.\n
 *	Address:	Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
 *				Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
 *				Chennai-603103 | India\n
 *				Website : http://www.datapatternsindia.com/\n
 *				Phone: 91-44-4741-4000\n
 *				FAX: 91-44-4741-4444 \n
 *
	////////////////////////////REVISION LOG ENTRY//////////////////////////////////
	Date		Version Number	     Reason for Revision	Revised by 
	----		--------------		 -------------------	----------
									 

	 
*/
#ifndef _DPMM1105_ERR_H
#define _DPMM1105_ERR_H

#define DPMM1105_SUCCESS		0


/**
* This list the enumeration of driver error values 
*/ 
enum{
	DPMM1105_ERR_MEM_CREATE = -1999,  		/*!< -1999	Memory creation for Buffer Error*/
	DPMM1105_ERR_MEM_NOT_CREATED,			/*!< -1998		Memory not created error*/	
	DPMM1105_ERR_DATA_NULL,					/*!< -1997		Memory written count zero error*/		
	DPMM1105_ERR_BUFFER_FULL,				/*!< -1996		Memory buffer is full*/		
	DP_DRV_ERR_INVALID_HANDLE = -999,		/*!<-999	Invalid Handle*/
	DP_DRV_ERR_INVALID_POINTER,				/*!<-998	Invalid Pointer*/
	DP_DRV_ERR_INVALID_PARAM,				/*!<-997	Invalid Param*/
	DP_DRV_ERR_MEM_ALLOCATION,				/*!<-996	Mem Allocation*/
	DP_DRV_ERR_NO_ZEROTH_DEVICE,			/*!<-995	No Zeroth Device*/
	DP_DRV_ERR_DEVICE_NOT_OPEN,				/*!<-994	Device Is Not Open*/
	DP_DRV_ERR_INVALID_SHARE_VALUE,			/*!<-993	Invalid Share Value*/
	DP_DRV_ERR_INVALID_DEVICE_REQUEST,		/*!<-992	Invalid Device Request*/
	DP_DRV_ERR_INVALID_MAXDEVICES,			/*!<-991 Invalid Max Devices */
	DPMM1105_ERR_IOCTL,						/*!<-990	Ioctl*/
	DPMM1105_ERR_INVALID_PARAM,				/*!<-989	Invalid Param*/
	DPMM1105_ERR_DEVICE_BUSY,				/*!<-988	Device Busy*/
	DPMM1105_ERR_NO_DEVICE_FOUND,				/*!<-987	No Device Found*/
	DPMM1105_ERR_INVALID_TOTALCARRIERBOARDS,		/*!<-986	Invalid Totalcarrierboards*/
	DPMM1105_ERR_INVALID_FLAG,				/*!<-985	Invalid Flag*/
	DPMM1105_ERR_INVALID_MAXDEVICES,			/*!<-984	Invalid Maxdevices*/
	DPMM1105_ERR_INVALID_HANDLE,				/*!<-983	Invalid Handle*/
	DPMM1105_ERR_INVALID_ERRCODE,				/*!<-982	Invalid Errcode*/
	DPMM1105_ERR_INVALID_BUFSIZE,				/*!<-981	Invalid Bufsize*/
	DPMM1105_ERR_INVALID_OFFSET,				/*!<-980	Invalid Offset*/
	DPMM1105_ERR_INVALID_WRITEDATA,				/*!<-979	Invalid Writedata*/
	DPMM1105_ERR_INVALID_ENDIS,				/*!<-978	Invalid Endis*/
	DPMM1105_ERR_INVALID_BUFFERLENGTH,			/*!<-977	Invalid Bufferlength*/
	DPMM1105_ERR_INVALID_CHANNELNO,				/*!<-976	Invalid Channelno*/
	DPMM1105_ERR_INVALID_ENDISINTERRUPT,			/*!<-975	Invalid Endisinterrupt*/
	DPMM1105_ERR_INVALID_INTPROPAGATE,			/*!<-974	Invalid Intpropagate*/
	DPMM1105_ERR_INVALID_EVENTMASKS,			/*!<-973	Invalid Eventmasks*/
	DPMM1105_ERR_INVALID_OPTIONS,				/*!<-972	Invalid Options*/
	DPMM1105_ERR_INVALID_GAINLEVEL,				/*!<-971	Invalid Gainlevel*/
	DPMM1105_ERR_INVALID_REFVALTYPE,			/*!<-970	Invalid Refvaltype*/
	DPMM1105_ERR_INVALID_REFVAL,				/*!<-969	Invalid Refval*/
	DPMM1105_ERR_INVALID_INPUTSIGNALTYPE,			/*!<-968	Invalid Inputsignaltype*/
	DPMM1105_ERR_INVALID_SOURCETYPE,			/*!<-967	Invalid Sourcetype*/
	DPMM1105_ERR_INVALID_SLOPE,				/*!<-966	Invalid Slope*/
	DPMM1105_ERR_INVALID_CONSTANT,				/*!<-965	Invalid Constant*/
	DPMM1105_ERR_ACQUISITION_IN_PROGRESS,			/*!<-964	Acquisition already in progress */
	DPMM1105_ERR_INVALID_PACER_SOURCE,			/*!<-963	Invalid Pacer Source Type Selection*/
	DPMM1105_ERR_INVALID_PACER_FREQUENCY,			/*!<-962	Invalid pacer frequency selection*/
	DPMM1105_ERR_INVALID_TRIGGER_SELECTION,			/*!<-961	Invalid trigger type selectiont*/
	DPMM1105_ERR_INVALID_CONTINUOUS_TRIGGER_SELECTION,	/*!<-960	Invalid continuous trigger type selection*/
	DPMM1105_ERR_INVALID_EXTERNAL_TRIGGER_SIGNAL_TYPE,	/*!<-959	Invalid external trigger signal type selection*/
	DPMM1105_ERR_INVALID_THRESHOLD_LEVEL,			/*!<-958	Invalid threshold level value*/
	DPMM1105_ERR_INVALID_SOURCE_TYPE,			/*!<-957	Invalid source type selection*/
	DPMM1105_ERR_INVALID_EXT_TRIGGER_PACERSRC_SEL,		/*!<-956	Inavlid external pacer source and external trigger are configured*/
	DPMM1105_ERR_INVALID_FIFO_ENDIS,			/*!<-955	Invalid ADC FIFO enable / disable selection */
	DPMM1105_ERR_INVALID_FIFO_THRESHOLD,			/*!<-954	Invalid FIFO threshold size */
	DPMM1105_ERR_ADC_NOT_CONFIGURED,			/*!<-953	ADC is not configured*/
	DPMM1105_ERROR_FIFO_EMPTY,				/*!<-952	FIFO Empty occured*/
	DPMM1105_ERR_ACQUISITION_NOT_STARTED,			/*!<-951	ADC is acquistion not started*/
	DPMM1105_ERR_INVALID_NO_OF_SAMPLES,			/*!<-950 	Invalid sample range */
	DPMM1105_ERR_EXTERNAL_TRIGGER_SELECTED,			/*!<-949	External Trigger Selection needed */	
	DPMM1105_ERR_TIMEOUT,					/*!<-948	Timeout error */ 
	DPMM1105_ERR_EVENT_WAIT,				/*!<-947	Event wait error */
	DPMM1105_ERR_FIFO_NOT_EANBLED,			/*!<-946	ADC FIFO not enabled */
	DPMM1105_ERR_INVALID_RAWDATAENDIS,	/*!<-945 Invalid calibrate enable / disable */
	DPMM1105_ERR_INT_NOT_ENABLED,			/*!<-944 Interrupt not enabled */
	DPMM1105_ERR_INVALID_APPLY_CALIBRATION_TYPE, /*!<-943 Invalid apply calibration type */
	DPMM1105_ERR_INVALID_CALIBPOINT_TYPE, 		/*!<-942 Invalid calibration type */
	DPMM1105_ERR_CALIB_FILE_OPEN_ERROR,			/*!<-941 file open error*/
	DPMM1105_ERR_CALIB_FILE_EMPTY,			/*!<-940 file is empty*/
	DPMM1105_ERR_CALIB_FILE_CORRUPTED,			/*!<-939 Inavalid file or corrupted file selected*/
	DPMM1105_ERR_EEPROM_CORRUPTED			/*!<-938 EEPROM corrupted */
};

#endif
