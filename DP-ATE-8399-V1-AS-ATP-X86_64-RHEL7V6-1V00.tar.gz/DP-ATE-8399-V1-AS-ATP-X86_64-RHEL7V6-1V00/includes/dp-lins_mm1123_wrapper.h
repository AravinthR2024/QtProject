#ifndef DPMM1123_WRAPPER_H
#define DPMM1123_WRAPPER_H

#define DP_1123_MIN_CHANNEL         1
#define DP_1123_MAX_CHANNEL         3
#define DP_1123_MIN_BOARDS			1
#define DP_1123_MAX_BOARDS          3
#define DPMM1123_INIT               0
#define DPMM1123_ENABLE             1
#define DPMM1123_DISABLE            0
#define DPMM1123_SUCCESS            0
#define DPMM1123_FAILURE            -1

#define DP_CARR_BOARD				0
#define DP_CARR_MAX_BOARDS			2

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <QDebug>

#include "dpmm1123_pro.h"
#include "dpmmcrdrv_pro.h"
#include "dp-lins-cm_signals.h"
#include "dp_types.h"

typedef struct
{
    U8BIT u8BusNo;
    U8BIT u8SlotNo;
    U8BIT u8FunctionNo;
    U8BIT u8MMSlotNo;
    S8BIT s8BoardSts;
    U8BIT u8ExpSlotNo;
}SDPMM1123_DeviceLocation, *PDPMM1123_DeviceLocation;

typedef struct
{
    U8BIT u8BusNo;
    U8BIT u8SlotNo;
    U8BIT u8FunctionNo;
    U8BIT u8MMSlotNo;
}SDPMM1123APP_DeviceLocation,*PSDPMM1123APP_DeviceLocation;

class DPMM1123_Wrapper
{
public:
    U16BIT m_u16NoOfDetBoards;
    PDPMM1123_DeviceLocation m_pSAllDevLocDetails;

private:
    U16BIT m_u16NoOfBoards;
    DP_DRV_HANDLE m_hHandle[DP_1123_MAX_BOARDS];
    DP_DRV_HANDLE m_hCarrierHandle[DP_CARR_MAX_BOARDS];
    U8BIT u8MMSlotNo;
    S32BIT m_s32RetVal;
    U8BIT u8AcqStartedFlag[DP_1123_MAX_BOARDS];
    S8BIT m_szErrorMsg[100];

    S16BIT MUX_1123_ValidateSignalID(U16BIT in_u16SignalId);

public:
    S16BIT Init(U16BIT in_u16NoOfBoards, PSDPMM1123APP_DeviceLocation in_pSDevLocation, PDPMM1123_DeviceLocation out_pSDevLocation);
    S16BIT Close(U16BIT in_u16BoardNo);
    S16BIT Reset(U16BIT in_u16BoardNo);
    S16BIT Config(U16BIT in_u16BoardNo);
    S16BIT StartAcquisition(U16BIT in_u16BoardNo);
    S16BIT StopAcquisition(U16BIT in_u16BoardNo);
    S16BIT ReadResistanceValue(U16BIT in_u16SignalId, PFDOUBLE out_pdResistance);
    S16BIT ReadTemperatureValue(U16BIT in_u16SignalId, PFDOUBLE out_pdTemperature);
    S16BIT ReadThermistorValue(U16BIT in_u16SignalId, PSDPMM1123_THERMISTORVALUES out_pSThermistance);
    void GetLastErrorMsg(PS32BIT out_ps32ErrCode, PS8BIT out_s8ErrMsg);
};

#endif // DPMM1123_WRAPPER_H
