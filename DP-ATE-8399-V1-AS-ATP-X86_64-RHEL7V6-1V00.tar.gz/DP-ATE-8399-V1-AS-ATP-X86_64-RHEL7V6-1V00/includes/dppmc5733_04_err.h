/**
 *	\file dppmc5733_04_err.h
 *	\brief This file contains the  error code definition
 *
 *	This file contains the  error code definition
 *
 *	\author rohith.praveen 
 *	\date 08:09PM on February 28, 2020
 *
 *	\version
 *	- Initial version
 *
 *	Copyright (C) 2020 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
 *	All Rights Reserved.\n
 *	Address:	Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
 *				Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
 *				Chennai-603103 | India\n
 *				Website : http://www.datapatternsindia.com/\n
 *				Phone: 91-44-4741-4000\n
 *				FAX: 91-44-4741-4444 \n
 *
	////////////////////////////REVISION LOG ENTRY//////////////////////////////////
	Date		Version Number	     Reason for Revision	Revised by 
	----		--------------		 -------------------	----------
									 

	 
*/
#ifndef _DPPMC5733_04_ERR_H
#define _DPPMC5733_04_ERR_H

#define DPPMC5733_04_SUCCESS		0


/**
* This list the enumeration of driver error values 
*/ 
enum DPPMC5733_04_ERROR_MACROS{
    DPPMC5733_04_ERR_INVALID_RINGBUFFREAD = -1999,      /*!<-1999	Invalid Ringbuffer read*/
    DPPMC5733_04_ERR_INVALID_RINGBUFFINIT ,             /*!<-1998	Invalid Ringbuffer init*/
    DPPMC5733_04_ERR_INVALID_RINGBUFFDESTORY,           /*!<-1997	Invalid Ring buffer destory*/
    DPPMC5733_04_ERR_INVALID_RINGBUFFWRITE,             /*!<-1996	Invalid Ring buffer write*/
    DPPMC5733_04_ERR_INVALID_RINGBUFFCOUNT,             /*!<-1995   Invalid Ring buffer count*/
    DPPMC5733_04_ERR_INVALID_PARAM = -991,                     /*!< (-991) Invalid Param*/
    DPPMC5733_04_ERR_DEVICE_BUSY,                       /*!< (-990) Device Busy*/
    DPPMC5733_04_ERR_NO_DEVICE_FOUND,                   /*!< (-989) No Device Found*/
    DPPMC5733_04_ERR_INVALID_ENDIS,                     /*!< (-988) Invalid Endis*/
    DPPMC5733_04_ERR_INVALID_SETMODE,                   /*!< (-987) Invalid Setmode*/
    DPPMC5733_04_ERR_INVALID_RAMSEL,                    /*!< (-986) Invalid Ramsel*/
    DPPMC5733_04_ERR_INVALID_STARTINDEX,                /*!< (-985) Invalid Startindex*/
    DPPMC5733_04_ERR_INVALID_TOTCMDTOWRITE,             /*!< (-984) Invalid Totcmdtowrite*/
    DPPMC5733_04_ERR_INVALID_TOTCMDTOREAD,              /*!< (-983) Invalid Totcmdtoread*/
    DPPMC5733_04_ERR_INVALID_ENDINDEX,                  /*!< (-982) Invalid Endindex*/
    DPPMC5733_04_ERR_INVALID_TXRXSEL,                   /*!< (-981) Invalid Txrxsel*/
    DPPMC5733_04_ERR_INVALID_TXRXSTARTSTOP,             /*!< (-980) Invalid Txrxstartstop*/
    DPPMC5733_04_ERR_INVALID_EVENTMASKS,                /*!< (-979) Invalid Eventmasks*/
    DPPMC5733_04_ERR_INVALID_OPTIONS,                   /*!< (-978) Invalid Options*/
    DPPMC5733_04_ERR_INVALID_SETBAUDRATE,               /*!< (-977) Invalid SetBaudRate*/
    DPPMC5733_04_ERR_INVALID_CONFIGINFO,                /*!<-976	Invalid Configinfo*/
    DPPMC5733_04_ERR_INVALID_STARTBIT,                  /*!<-975	Invalid StartBit*/
    DPPMC5733_04_ERR_INVALID_MODEBIT,                   /*!<-974	Invalid ModeBit*/
    DPPMC5733_04_ERR_INVALID_DATABYTE,                  /*!<-973	Invalid DataByte*/
    DPPMC5733_04_ERR_INVALID_MSGTIME,                   /*!<-972	Invalid Msgtime*/
    DPPMC5733_04_ERR_INVALID_FRAMETIME,                 /*!<-971	Invalid Frametime*/
    DPPMC5733_04_ERR_INVALID_TIMEOUT,                   /*!<-970	Invalid TimeOut*/
    DPPMC5733_04_ERR_INVALID_DATATOREAD,                /*!<-969	Invalid Datatoread*/
    DPPMC5733_04_ERR_INVALID_INTEVENTMASKS,             /*!<-968	Invalid Inteventmasks*/
    DPPMC5733_04_ERR_INVALID_EVENTSTATUS,               /*!<-967	Invalid Eventstatus*/
    DPPMC5733_04_ERR_INVALID_RXFIFORESET,               /*!<-966	Invalid TXRXSTART*/
    DPPMC5733_04_ERR_INTR_NOT_ENABLED,                  /*!<-965	Interrrupt not enabled*/
    DPPMC5733_04_ERR_EVENT_WAIT                         /*!<-964	Error in Event Wait*/
};
#endif
