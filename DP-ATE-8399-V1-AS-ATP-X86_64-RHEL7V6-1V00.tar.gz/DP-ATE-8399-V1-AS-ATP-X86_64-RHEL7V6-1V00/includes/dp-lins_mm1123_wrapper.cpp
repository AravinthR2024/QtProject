#include "dp-lins_mm1123_wrapper.h"
#include "dp-lins_mm1105_wrapper.h"

#define _DRV1123_ENABLE_

extern PSDPMM1105_CARRIER_DEVICE_INFO g_pSAllCarrDevLocDetails;

S16BIT DPMM1123_Wrapper::Init(U16BIT in_u16NoOfBoards, PSDPMM1123APP_DeviceLocation in_pSDevLocation, PDPMM1123_DeviceLocation out_pSDevLocation)
{
    U8BIT u8BoardNo = DPMM1123_INIT;
    U8BIT u8Loop = DPMM1123_INIT;
    U16BIT u16NoOfBoards = DPMM1123_INIT;
    PSDPMM1123_DEVICE_LOCATION pSAllDevLocDetails;
    PSDPMMCRDRV_CARRIER_DEVICE_INFO pSAllCarrierDevInfo;
    PSDPMM1123_CARRIER_DEVICE_INFO pSAllCarrDevLocDetails = (PSDPMM1123_CARRIER_DEVICE_INFO)g_pSAllCarrDevLocDetails;
    //    void *g_vpCarrierHandle[2];
    m_u16NoOfDetBoards = 0;

    if(in_pSDevLocation != NULL)
    {
        for(u8Loop = 0; u8Loop < in_u16NoOfBoards; u8Loop++)
        {
            out_pSDevLocation[u8Loop].u8SlotNo = in_pSDevLocation[u8Loop].u8SlotNo;
            out_pSDevLocation[u8Loop].u8BusNo = in_pSDevLocation[u8Loop].u8BusNo;
            out_pSDevLocation[u8Loop].u8FunctionNo = in_pSDevLocation[u8Loop].u8FunctionNo;
            out_pSDevLocation[u8Loop].u8MMSlotNo = in_pSDevLocation[u8Loop].u8MMSlotNo;
            out_pSDevLocation[u8Loop].s8BoardSts = DPMM1123_DISABLE;
        }
    }

#ifdef _DRV1123_ENABLE_
    m_s32RetVal = DPMMCRDRV_GetTotalDeviceFound(&u16NoOfBoards);
    if (m_s32RetVal != DPMM1123_SUCCESS)
    {
        DPMMCRDRV_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DPMM1123_FAILURE;
    }

    if(u16NoOfBoards == 0)
    {
        strncpy(m_szErrorMsg,"No Modules Detected.",sizeof(m_szErrorMsg));
        return DPMM1123_FAILURE;
    }
#if 0
    /* Get All Carrier Device Location */
    pSAllCarrierDevInfo = (PSDPMMCRDRV_CARRIER_DEVICE_INFO)malloc(sizeof(SDPMMCRDRV_CARRIER_DEVICE_INFO) * u16NoOfBoards);
    if(pSAllCarrierDevInfo == NULL)
    {
        sprintf(m_szErrorMsg, "Error in memory creation for carrier device location details");
        return DPMM1123_FAILURE;
    }

    m_s32RetVal = DPMMCRDRV_GetAllDeviceInformation(pSAllCarrierDevInfo, u16NoOfBoards);
    if (m_s32RetVal != DPMM1123_SUCCESS)
    {
        DPMMCRDRV_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        free(pSAllCarrierDevInfo);
        return DPMM1123_FAILURE;
    }

    u16NoOfBoards = 1;
    for(u8BoardNo = 0; u8BoardNo < (u16NoOfBoards); u8BoardNo++)
    {
        m_s32RetVal = DPMMCRDRV_Open(&pSAllCarrierDevInfo[1].m_SDeviceLocation, &g_vpCarrierHandle[u8BoardNo]);
        if (m_s32RetVal != DPMM1123_SUCCESS)
        {
            DPMMCRDRV_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            free(pSAllCarrierDevInfo);
            return DPMM1123_FAILURE;
        }
    }

    pSAllCarrDevLocDetails = (PSDPMM1123_CARRIER_DEVICE_INFO)malloc(sizeof(SDPMM1123_CARRIER_DEVICE_INFO) * u16NoOfBoards);
    if(pSAllCarrDevLocDetails == NULL)
    {
        strcpy(m_szErrorMsg, "Error in memory creation for all device location details\n");
        return DPMM1123_FAILURE;
    }

    memcpy(pSAllCarrDevLocDetails, &pSAllCarrierDevInfo[1], (sizeof(SDPMM1123_CARRIER_DEVICE_INFO) * u16NoOfBoards));
#endif

    for(u8BoardNo = 0; u8BoardNo < (u16NoOfBoards); u8BoardNo++)
    {
        m_s32RetVal = DPMM1123_SetResource(u16NoOfBoards, &pSAllCarrDevLocDetails[u8BoardNo], DP_CARR_BOARD);
        free(pSAllCarrDevLocDetails);
        free(pSAllCarrierDevInfo);
        if (m_s32RetVal != DPMM1123_SUCCESS)
        {
            DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DPMM1123_FAILURE;
        }

        m_s32RetVal = DPMM1123_GetTotalDeviceFound(&m_u16NoOfDetBoards);
        if (m_s32RetVal!= DPMM1123_SUCCESS)
        {
            DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DPMM1123_FAILURE;
        }
        if(m_u16NoOfDetBoards > 0)
        {
            break;
        }
    }

    if(m_u16NoOfDetBoards == 0)
    {
        strncpy(m_szErrorMsg,"No Modules Detected.",sizeof(m_szErrorMsg));
        return DPMM1123_FAILURE;
    }

    /* Get All Device Location */
    pSAllDevLocDetails = (PSDPMM1123_DEVICE_LOCATION)malloc(sizeof(SDPMM1123_DEVICE_LOCATION) * m_u16NoOfDetBoards);
    if(pSAllDevLocDetails == NULL)
    {
        strcpy(m_szErrorMsg,"Error in memory creation for all device location details\n");
        return DPMM1123_FAILURE;
    }

    m_s32RetVal = DPMM1123_GetAllDeviceLocations(pSAllDevLocDetails, m_u16NoOfDetBoards);
    if (m_s32RetVal != DPMM1123_SUCCESS)
    {
        DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        free(pSAllDevLocDetails);
        return DPMM1123_FAILURE;
    }

    m_pSAllDevLocDetails = (PDPMM1123_DeviceLocation)malloc(sizeof(SDPMM1123_DeviceLocation) * m_u16NoOfDetBoards);
    for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfDetBoards); u8BoardNo++)
    {
        m_pSAllDevLocDetails[u8BoardNo].s8BoardSts = DPMM1123_DISABLE;
        m_pSAllDevLocDetails[u8BoardNo].u8SlotNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8SlotNo;
        m_pSAllDevLocDetails[u8BoardNo].u8BusNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8BusNo;
        m_pSAllDevLocDetails[u8BoardNo].u8FunctionNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8FunctionNo;
        m_pSAllDevLocDetails[u8BoardNo].u8MMSlotNo = pSAllDevLocDetails[u8BoardNo].m_u8MMSlotNo;
        if(u8BoardNo < in_u16NoOfBoards)
        {
            m_pSAllDevLocDetails[u8BoardNo].u8ExpSlotNo = in_pSDevLocation[u8BoardNo].u8SlotNo;
        }
        else
        {
            m_pSAllDevLocDetails[u8BoardNo].u8ExpSlotNo = 0;
        }

        for(u8Loop = 0; u8Loop < in_u16NoOfBoards; u8Loop++)
        {
            if((m_pSAllDevLocDetails[u8BoardNo].u8SlotNo == in_pSDevLocation[u8Loop].u8SlotNo) && (m_pSAllDevLocDetails[u8BoardNo].u8BusNo ==  in_pSDevLocation[u8Loop].u8BusNo) && (m_pSAllDevLocDetails[u8BoardNo].u8FunctionNo == in_pSDevLocation[u8Loop].u8FunctionNo) && (m_pSAllDevLocDetails[u8BoardNo].u8MMSlotNo == in_pSDevLocation[u8Loop].u8MMSlotNo))
            {
                m_pSAllDevLocDetails[u8BoardNo].s8BoardSts = DP_BORDS_STATUS_ONE;
                break;
            }
        }
    }

    if(in_pSDevLocation == NULL)
    {
        m_u16NoOfBoards = m_u16NoOfDetBoards;
        for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfDetBoards); u8BoardNo++)
        {
            /* open the found boards */
            m_s32RetVal = DPMM1123_Open((PSDPMM1123_DEVICE_LOCATION)&pSAllDevLocDetails[u8BoardNo], &m_hHandle[u8BoardNo]);
            //            qDebug("1. B%d -> 0x%X", u8BoardNo, m_hHandle[u8BoardNo]);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                free(pSAllDevLocDetails);
                return DPMM1123_FAILURE;
            }

            out_pSDevLocation[u8BoardNo].s8BoardSts = DPMM1123_ENABLE;
            out_pSDevLocation[u8BoardNo].u8SlotNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8SlotNo;
            out_pSDevLocation[u8BoardNo].u8BusNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8BusNo;
            out_pSDevLocation[u8BoardNo].u8FunctionNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8FunctionNo;
            out_pSDevLocation[u8BoardNo].u8MMSlotNo = pSAllDevLocDetails[u8BoardNo].m_u8MMSlotNo;
        }
    }
    else
    {
        m_u16NoOfBoards = 0;
        for(u8Loop = 0; u8Loop < in_u16NoOfBoards; u8Loop++)
        {
            for(u8BoardNo = 0; u8BoardNo < m_u16NoOfDetBoards; u8BoardNo++)
            {
                if((pSAllDevLocDetails[u8BoardNo].u.pci.m_u8SlotNo == in_pSDevLocation[u8Loop].u8SlotNo)\
                        && (pSAllDevLocDetails[u8BoardNo].u.pci.m_u8BusNo ==  in_pSDevLocation[u8Loop].u8BusNo)\
                        && (pSAllDevLocDetails[u8BoardNo].u.pci.m_u8FunctionNo == in_pSDevLocation[u8Loop].u8FunctionNo)\
                        && (pSAllDevLocDetails[u8BoardNo].m_u8MMSlotNo == in_pSDevLocation[u8Loop].u8MMSlotNo))
                {
                    m_u16NoOfBoards++;
                    out_pSDevLocation[u8Loop].s8BoardSts = DPMM1123_ENABLE;
                    break;
                }
            }

            out_pSDevLocation[u8Loop].u8SlotNo = in_pSDevLocation[u8Loop].u8SlotNo;
            out_pSDevLocation[u8Loop].u8BusNo = in_pSDevLocation[u8Loop].u8BusNo;
            out_pSDevLocation[u8Loop].u8FunctionNo = in_pSDevLocation[u8Loop].u8FunctionNo;
            out_pSDevLocation[u8Loop].u8MMSlotNo = in_pSDevLocation[u8Loop].u8MMSlotNo;

            if(u8BoardNo == m_u16NoOfDetBoards)
            {
                out_pSDevLocation[u8Loop].s8BoardSts = DPMM1123_DISABLE;
                continue;
            }

            m_s32RetVal = DPMM1123_Open((PSDPMM1123_DEVICE_LOCATION)&pSAllDevLocDetails[u8BoardNo], &m_hHandle[u8Loop]);
            //            qDebug("2. B%d -> 0x%X", u8BoardNo, m_hHandle[u8BoardNo]);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                free(pSAllDevLocDetails);
                return DPMM1123_FAILURE;
            }
        }
    }
    free(pSAllDevLocDetails);
#endif
    return DPMM1123_SUCCESS;
}

S16BIT DPMM1123_Wrapper::Config(U16BIT in_u16BoardNo)
{
    SDPMM1123_CONFIGURATION ADC_Config;
    U8BIT u8BoardNo = DPMM1123_INIT;

    ADC_Config.m_u8Mode = 0;
    ADC_Config.m_u8BridgeCompletion = 1;
    ADC_Config.m_u16AcquisitionRate = 1;
    ADC_Config.m_u8ExcitationVoltage = 2;
    ADC_Config.m_u8ShuntCalibration = 0;

#ifdef _DRV1123_ENABLE_
    if((in_u16BoardNo > 0) && (in_u16BoardNo <= m_u16NoOfBoards))
    {
        m_s32RetVal = DPMM1123_Reset(m_hHandle[in_u16BoardNo-1]);
        if(m_s32RetVal != DPMM1123_SUCCESS)
        {
            DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DPMM1123_FAILURE;
        }

        m_s32RetVal = DPMM1123_Configure(m_hHandle[in_u16BoardNo-1],0,&ADC_Config);
        if(m_s32RetVal != DPMM1123_SUCCESS)
        {
            DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            qDebug("1:: %s",m_szErrorMsg);
            return DPMM1123_FAILURE;
        }

        m_s32RetVal = DPMM1123_EnableDisableCalibration(m_hHandle[in_u16BoardNo-1],0, 1, 1);
        if(m_s32RetVal != DPMM1123_SUCCESS)
        {
            DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            qDebug("2:: %s",m_szErrorMsg);
            return DPMM1123_FAILURE;
        }

        m_s32RetVal = DPMM1123_SetFIFOMode(m_hHandle[in_u16BoardNo-1], 0, 1);
        if(m_s32RetVal != DPMM1123_SUCCESS)
        {
            DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            qDebug("3:: %s",m_szErrorMsg);
            return DPMM1123_FAILURE;
        }
    }
    else
    {
        /* Load the calibration from EEPROM */
        for(u8BoardNo = 0; u8BoardNo < m_u16NoOfBoards; u8BoardNo++)
        {
            m_s32RetVal = DPMM1123_Reset(m_hHandle[u8BoardNo]);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
            m_s32RetVal = DPMM1123_Configure(m_hHandle[u8BoardNo],0,&ADC_Config);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                qDebug("1:: %s",m_szErrorMsg);
                return DPMM1123_FAILURE;
            }

            m_s32RetVal = DPMM1123_EnableDisableCalibration(m_hHandle[u8BoardNo],0, 1, 1);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                qDebug("2:: %s",m_szErrorMsg);
                return DPMM1123_FAILURE;
            }

            m_s32RetVal = DPMM1123_SetFIFOMode(m_hHandle[u8BoardNo], 0, 1);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                qDebug("3:: %s",m_szErrorMsg);
                return DPMM1123_FAILURE;
            }
        }
    }
#endif
    return DPMM1123_SUCCESS;
}

S16BIT DPMM1123_Wrapper::StartAcquisition(U16BIT in_u16BoardNo)
{
    U8BIT u8BoardNo = DPMM1123_INIT;

#ifdef _DRV1123_ENABLE_
    if(in_u16BoardNo)
    {
        if (in_u16BoardNo >= 1 && in_u16BoardNo <= m_u16NoOfBoards)
        {
            m_s32RetVal = DPMM1123_ResetFIFO(m_hHandle[in_u16BoardNo-1]);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
            m_s32RetVal = DPMM1123_EnableDisableFIFO(m_hHandle[in_u16BoardNo-1], 0, DPMM1123_ENABLE);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
            m_s32RetVal = DPMM1123_StartAcquisition(m_hHandle[in_u16BoardNo-1], 0);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
            u8AcqStartedFlag[in_u16BoardNo-1] = DPMM1123_ENABLE;
        }
        else
        {
            sprintf(m_szErrorMsg, "Invalid Board Number");
            return DPMM1123_FAILURE;
        }
    }
    else
    {
        for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfBoards); u8BoardNo++)
        {
            m_s32RetVal = DPMM1123_ResetFIFO(m_hHandle[u8BoardNo]);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
            m_s32RetVal = DPMM1123_EnableDisableFIFO(m_hHandle[u8BoardNo], 0, DPMM1123_ENABLE);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
            m_s32RetVal = DPMM1123_StartAcquisition(m_hHandle[u8BoardNo], 0);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
            u8AcqStartedFlag[u8BoardNo] = DPMM1123_ENABLE;
        }
    }
#endif
    return DPMM1123_SUCCESS;
}

S16BIT DPMM1123_Wrapper::StopAcquisition(U16BIT in_u16BoardNo)
{
    U8BIT u8BoardNo = DPMM1123_INIT;

#ifdef _DRV1123_ENABLE_
    if(in_u16BoardNo)
    {
        if (in_u16BoardNo >= 1 && in_u16BoardNo <= m_u16NoOfBoards)
        {
            m_s32RetVal = DPMM1123_StopAcquisition(m_hHandle[in_u16BoardNo-1], 0);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
            m_s32RetVal = DPMM1123_EnableDisableFIFO(m_hHandle[in_u16BoardNo-1], 0, DPMM1123_DISABLE);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
            m_s32RetVal = DPMM1123_ResetFIFO(m_hHandle[in_u16BoardNo-1]);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
            u8AcqStartedFlag[in_u16BoardNo-1] = DPMM1123_DISABLE;
        }
        else
        {
            sprintf(m_szErrorMsg, "Invalid Board Number");
            return DPMM1123_FAILURE;
        }
    }
    else
    {
        for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfBoards); u8BoardNo++)
        {
            m_s32RetVal = DPMM1123_StopAcquisition(m_hHandle[u8BoardNo], 0);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
            m_s32RetVal = DPMM1123_EnableDisableFIFO(m_hHandle[u8BoardNo], 0, DPMM1123_DISABLE);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
            m_s32RetVal = DPMM1123_ResetFIFO(m_hHandle[u8BoardNo]);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
            u8AcqStartedFlag[u8BoardNo] = DPMM1123_DISABLE;
        }
    }
#endif
    return DPMM1123_SUCCESS;
}

S16BIT DPMM1123_Wrapper::ReadResistanceValue(U16BIT in_u16SignalId, PFDOUBLE out_pdResistance)
{
    FDOUBLE dResistance = 0.0f;

    if(MUX_1123_ValidateSignalID(in_u16SignalId) != DPMM1123_SUCCESS)
    {
        sprintf(m_szErrorMsg, "Invalid Signal ID");
        return DPMM1123_FAILURE;
    }

    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    U8BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);
    u8BoardNo -= 1;

#ifdef _DRV1123_ENABLE_
    m_s32RetVal=DPMM1123_GetResistance(m_hHandle[u8BoardNo], u8ChannelNo, &dResistance);
    if(m_s32RetVal != DPMM1123_SUCCESS)
    {
        DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DPMM1123_FAILURE;
    }
    else
    {
        *out_pdResistance = dResistance/1000;
        //        printf("\n\tChannel %hu Resistance On Board	:%.3lf KOhm",u8ChannelNo, dResistance/1000);
    }
#endif
    return DPMM1123_SUCCESS;
}

S16BIT DPMM1123_Wrapper::ReadTemperatureValue(U16BIT in_u16SignalId, PFDOUBLE out_pdTemperature)
{
    FDOUBLE dTemperature = 0.0f;

    if(MUX_1123_ValidateSignalID(in_u16SignalId) != DPMM1123_SUCCESS)
    {
        sprintf(m_szErrorMsg, "Invalid Signal ID");
        return DPMM1123_FAILURE;
    }

    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    U8BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);
    u8BoardNo -= 1;

#ifdef _DRV1123_ENABLE_
    m_s32RetVal=DPMM1123_GetTemperature(m_hHandle[u8BoardNo], u8ChannelNo, &dTemperature);
    if(m_s32RetVal != DPMM1123_SUCCESS)
    {
        DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DPMM1123_FAILURE;
    }
    else
    {
        *out_pdTemperature = dTemperature/1000;
        //        printf("\n\tChannel %hu Resistance On Board	:%.3lf KOhm",u8ChannelNo, dTemperature/1000);
    }
#endif
    return DPMM1123_SUCCESS;
}

S16BIT DPMM1123_Wrapper::ReadThermistorValue(U16BIT in_u16SignalId,  PSDPMM1123_THERMISTORVALUES out_pSThermistance)
{
    SDPMM1123_THERMISTORVALUES SThermistance;

    memset(&SThermistance,0,sizeof(SDPMM1123_THERMISTORVALUES));

    if(MUX_1123_ValidateSignalID(in_u16SignalId) != DPMM1123_SUCCESS)
    {
        sprintf(m_szErrorMsg, "Invalid Signal ID");
        return DPMM1123_FAILURE;
    }

    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    U8BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);
    u8BoardNo -= 1;

#ifdef _DRV1123_ENABLE_
    m_s32RetVal=DPMM1123_GetThermistorValues(m_hHandle[u8BoardNo], u8ChannelNo, &SThermistance);
    if(m_s32RetVal != DPMM1123_SUCCESS)
    {
        DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DPMM1123_FAILURE;
    }
    else
    {
        out_pSThermistance->m_dVoltage = SThermistance.m_dVoltage/1000000;
        out_pSThermistance->m_dTemperature = SThermistance.m_dTemperature;
        out_pSThermistance->m_dResistance = SThermistance.m_dResistance/1000;

        //        printf("\n\tVoltage On Board 		:	%.3f MicroVolts",(SThermistance.m_dVoltage * 1000000));
        //        printf("\n\tTemperature On Board	:	%.3f Celcius",SThermistance.m_dTemperature);
        //        printf("\n\tResistance On Board		:	%.3f KOhm",(SThermistance.m_dResistance/1000));
    }
#endif
    return DPMM1123_SUCCESS;
}

S16BIT DPMM1123_Wrapper::Close(U16BIT in_u16BoardNo)
{
    U8BIT u8BoardNo = DPMM1123_INIT;

    StopAcquisition(in_u16BoardNo);

#ifdef _DRV1123_ENABLE_
    if(in_u16BoardNo)
    {
        if (in_u16BoardNo >= 1 && in_u16BoardNo <= m_u16NoOfBoards)
        {
            m_s32RetVal = DPMM1123_Close(m_hHandle[in_u16BoardNo-1]);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
        }
        else
        {
            sprintf(m_szErrorMsg, "Invalid Board Number");
            return DPMM1123_FAILURE;
        }
    }
    else
    {
        for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfBoards); u8BoardNo++)
        {
            m_s32RetVal = DPMM1123_Close(m_hHandle[u8BoardNo]);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
        }
    }
#endif
    return DPMM1123_SUCCESS;
}

S16BIT DPMM1123_Wrapper::Reset(U16BIT in_u16BoardNo)
{
    U8BIT u8BoardNo = DPMM1123_INIT;

#ifdef _DRV1123_ENABLE_
    if(in_u16BoardNo)
    {
        if (in_u16BoardNo >= 1 && in_u16BoardNo <= m_u16NoOfBoards)
        {
            m_s32RetVal = DPMM1123_Reset(m_hHandle[in_u16BoardNo-1]);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
        }
        else
        {
            sprintf(m_szErrorMsg, "Invalid Board Number");
            return DPMM1123_FAILURE;
        }
    }
    else
    {
        for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfBoards); u8BoardNo++)
        {
            m_s32RetVal = DPMM1123_Reset(m_hHandle[u8BoardNo]);
            if(m_s32RetVal != DPMM1123_SUCCESS)
            {
                DPMM1123_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DPMM1123_FAILURE;
            }
        }
    }
#endif
    return DPMM1123_SUCCESS;
}

void DPMM1123_Wrapper::GetLastErrorMsg(PS32BIT out_ps32ErrCode, PS8BIT out_s8ErrMsg)
{
    sprintf(out_s8ErrMsg, "%s" , m_szErrorMsg);
    *out_ps32ErrCode = m_s32RetVal;
}

S16BIT DPMM1123_Wrapper::MUX_1123_ValidateSignalID(U16BIT in_usSignalId)
{
    U8BIT u8BoardID = SID_GET_BOARD_ID(in_usSignalId);
    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_usSignalId);
    U8BIT u8ChannelNo = SID_GET_CHANNEL(in_usSignalId);

    if((u8BoardID != BRD_TYPE_MM1123_THERM) || \
            ((u8BoardNo < DP_1123_MIN_BOARDS) || (u8BoardNo > DP_1123_MAX_BOARDS)) || \
            ((u8ChannelNo < DP_1123_MIN_CHANNEL) || (u8ChannelNo > DP_1123_MAX_CHANNEL)))
    {
        return DPMM1123_FAILURE;
    }

    return DPMM1123_SUCCESS;
}

