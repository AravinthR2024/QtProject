#ifndef MACROS
#define MACROS

#define INDEX_SERIAL_NO         0
#define INDEX_BOARD_NAME        1
#define INDEX_BOARD_NO          2
#define INDEX_BUS_NO            3
#define INDEX_SLOT_NO           4
#define INDEX_FUNC_NO           5
#define INDEX_STATUS            6

#define TAB_AUTO_TEST           0
#define TAB_MANUAL_TEST         1
#define TAB_DETECTION_STATUS    2
#define TAB_EQUIPMENT_DETAILS   3

#define PSU_CONFIG_PSU_ADDR             0
#define PSU_CONFIG_NOMINAL_VOLT         1
#define PSU_CONFIG_UNDER_VOLT           2
#define PSU_CONFIG_OVER_VOLT            3
#define PSU_CONFIG_CURRENT_LIMIT        4
#define PSU_CONFIG_MAX_VOLT             5
#define PSU_CONFIG_TEST_START_RANGE     6
#define PSU_CONFIG_TEST_STOP_RANGE      7
#define PSU_CONFIG_STEPUP_RANGE         8

#define TABLE_IDX_PSU_NAME              0
#define TABLE_IDX_PSU_ADDR              1
#define TABLE_IDX_NOMINAL_VOLT          2
#define TABLE_IDX_UNDER_VOLT            3
#define TABLE_IDX_OVER_VOLT             4
#define TABLE_IDX_MAX_VOLT              5
#define TABLE_IDX_CURRENT_LIMIT         6

#define START_ACQUISITION               1
#define STOP_ACQUISITION                0

#endif // MACROS

