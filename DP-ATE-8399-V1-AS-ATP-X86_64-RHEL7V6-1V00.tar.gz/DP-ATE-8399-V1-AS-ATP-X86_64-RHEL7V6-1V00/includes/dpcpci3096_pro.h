/**
* \file dpcpci3096_pro.h
* \brief This file contains the function prototypes of all the functions or API's are available in this file
*
* \author Mahesh S
* \date	09 August, 2019
*
* \version   1.00
*
* \copyright Copyright (C) 2019 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
* Phone: 91-44-4741-4000\n
* FAX: 91-44-4741-4444 \n
*
*/

#ifndef _DPcPCI3096_PRO_H_
#define _DPcPCI3096_PRO_H_

#include "dp_types.h"

#if defined(__cplusplus)|| defined (__cplusplus)
extern 	"C" {
#endif

/***********************************Structures************************/
#pragma pack(push,1)

/**
*\struct	_SDPCPCI3096_DEVICE_LOCATION
*\brief		This structure contains members to hold the devices location
*
*			The device location structure includes the bus type, bus number, slot number and function number.
*
*/
typedef struct _SDPCPCI3096_DEVICE_LOCATION
{
    U8BIT m_u8BusType;				/*!< Device bus type */
    union
    {
        struct
        {
            U8BIT m_u8BusNo;		/*!<Bus Number */
            U8BIT m_u8SlotNo;		/*!<Slot number */
            U8BIT m_u8FunctionNo;	/*!<Function number*/
        }pci;
    }u;
}SDPCPCI3096_DEVICE_LOCATION, *PSDPCPCI3096_DEVICE_LOCATION;

/**
*\struct	_SDPCPCI3096_DRIVER_DETAILS
*\brief		This structure contains members to hold the driver details
*
*			The driver details structure includes the driver version.
*
*/
typedef struct _SDPCPCI3096_DRIVER_DETAILS
{
	U32BIT m_u32Version;	/*!< Driver version */
}SDPCPCI3096_DRIVER_DETAILS, *PSDPCPCI3096_DRIVER_DETAILS;

/**
*\struct	_SDPCPCI3096_ALL_CHANNELS
*\brief		This structure contains members to hold all channel selection or status value
*
*			The all channel structure includes the group value.
*/
typedef struct _SDPCPCI3096_ALL_CHANNELS
{
	U16BIT m_u16ArrGroupVal[3];		/*!< Group value */
}SDPCPCI3096_ALL_CHANNELS, *PSDPCPCI3096_ALL_CHANNELS;

/**
*\struct	_SDPCPCI3096_EVENT_STS
*\brief		This structure contains members to hold the event information
*
*			The event status  structure includes group number, event status, event data, event type.
**/

typedef struct _SDPCPCI3096_EVENT_STS
{
	U8BIT m_u8GroupNum;		/*!<Group number */
	U8BIT m_u8EventSts;		/*!<Event status of corresponding group*/
    U8BIT m_u8EventType;	/*!<Event type (i.e input interrupt or state change or strobe)*/
	U16BIT m_u16EventData;	/*!<Event data */
	U16BIT m_u16ActualData;	/*!<Actual data */
}SDPCPCI3096_EVENT_STS, *PSDPCPCI3096_EVENT_STS;

#pragma pack(pop)

/****************************function  prototypes ******************************/
/*!
*	\addtogroup Common_Functions List of common driver functions
* @{
*/

/**
*\brief		 This function is used to get the total number of DP-cPCI-3096 device(s) present in the system
*
*\param[out] out_pu16TotalDevices	It specifies the output pointer to hold the number of DP-cPCI-3096 device(s) found
*
*\retval	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output total devices pointer is null
*
*\pre		NA
*\post		::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_GetTotalDeviceFound(PU16BIT out_pu16TotalDevices);

/**
*\brief		  This function is used to get pci details such as bus number, slot number and function number for the DP-cPCI-3096 device(s)
*
*\param[out]  out_pSAllDevLocDetails	It specifies the output pointer to hold the device location details(size: in_u16MaxDevices)
*\param[in]   in_u16MaxDevices			It specifies the total number of DP-cPCI-3096 device(s) found(min:1)
*
*\retval	 ::DPCPCI3096_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_POINTER is returned if the input device location structure pointer is null
*\retval	 ::DP_DRV_ERR_INVALID_MAXDEVICES is returned if the maximum devices value should not be zero and not to be grater than total devices obtained from DPcPCI3096_GetTotalDeviceFound().
*
*\pre		 ::DPcPCI3096_GetTotalDeviceFound
*\post		 ::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_GetAllDeviceLocations(PSDPCPCI3096_DEVICE_LOCATION out_pSAllDevLocDetails, U16BIT in_u16MaxDevices);

/**
*\brief		 This function is used to open the specified DP-cPCI-3096 device.
*
*\param[in]  in_pSDeviceOpenInfo	It specifies the bus number, slot number and function number
*\param[out] out_hDevHandle			It specifies the pointer which holds output device handle
*
*\retval	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the device locataion structure pointer is null
*\retval	::DPCPCI3096_ERR_DEVICE_BUSY is returned if the the device is already opened
*
*\pre		::DPcPCI3096_GetAllDeviceLocations
*\post    	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_Open(PSDPCPCI3096_DEVICE_LOCATION in_pSDeviceOpenInfo, DP_DRV_HANDLE out_hDevHandle);

/**
*\brief 	 This function is used to close the opened device. Any opened device has to be closed before the application is exited.
*
*\param[in]	 in_hHandle	It specifies the device handle which obtained from device open function
*
*\retval	 ::DPCPCI3096_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_POINTER is returned if the device handle is invalid or null
*\retval	 ::DP_DRV_ERR_DEVICE_NOT_OPEN is returned if the device is not opened
*
*\pre		 ::DPcPCI3096_Open
*\post	 	 ::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_Close(DP_DRV_HANDLE in_hHandle);

/**
*\brief		 This function is used to get the driver details(Driver Version)
*
*\param[out] out_pSDriverDetails	It specifies the structure pointer to read the driver details(Driver Version)
*
*\retval	 ::DPCPCI3096_SUCCESS is returned upon success
*\retval	 ::DP_DRV_ERR_INVALID_POINTER is returned if the output driver details structure pointer is null
*
*\pre		 ::DPcPCI3096_Open
*\post		 ::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_GetDriverDetails(PSDPCPCI3096_DRIVER_DETAILS out_pSDriverDetails);

/**
*\brief		  This function is used to get opened device location details(bus number, slot number and function number)
*
*\param[in]	  in_hHandle			It specifies the device handle which obtained from device open function
*\param[out] out_pSDeviceLocation	It specifies the pointer to hold the device location details
*
*\retval	  ::DPCPCI3096_SUCCESS is returned upon success
*\retval	  ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	  ::DP_DRV_ERR_INVALID_POINTER is returned if the output device location structure pointer is null
*
*\pre		  ::DPcPCI3096_Open
*\post		  ::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_GetDeviceLocation(DP_DRV_HANDLE in_hHandle, PSDPCPCI3096_DEVICE_LOCATION out_pSDeviceLocation);

/**
*\brief		This function is used to get the error message corresponding to the error code. The error message specify briefly the cause of the error.
*
*\param[in]   in_s32ErrCode	 It specifies the error code returned by the functions
*\param[out]  out_ps8ErrMsg	 It specifies the error message(size:in_u16BufSize)
*\param[in]   in_u16BufSize  It specifies buffer size to hold the error message(min:100)
*
*\retval	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output string buffer is null
*\retval	::DPCPCI3096_ERR_INVALID_BUFSIZE is returned if the buffer size is lessthan 100.
*
*\pre	 	::DPcPCI3096_Open
*\post		::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_GetErrorMessage(S32BIT in_s32ErrCode, PS8BIT out_ps8ErrMsg, U16BIT in_u16BufSize);

/**
*\brief		This function is used to reset the device to initial state
*
*\param[in]	in_hHandle	It specifies the device handle which obtained from device open function
*
*\retval	::DPCPCI3096_SUCCESS is returned upon success 
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
* 
*\pre		::DPcPCI3096_Open
*\post		::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_Reset(DP_DRV_HANDLE in_hHandle);

/**
*\brief		 This function is used to write data into the specified register offset
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u16Offset		It specifies the offset value of selected device
*\param[in]	 in_u16WriteData	It specifies the the data to be written in specified register offset
*
*\retval	 ::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*
*\pre		 ::DPcPCI3096_Open
*\post		 ::DPcPCI3096_GetErrorMessage
*
*\author	 Mahesh S
*\date		 09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_WriteReg(DP_DRV_HANDLE in_hHandle, U16BIT in_u16Offset, U16BIT in_u16WriteData);

/**
*\brief		 This function is used to read data from the specified register offset
*
*\param[in]	 in_hHandle			It specifies the device handle which obtained from device open function
*\param[in]	 in_u16Offset		It specifies the offset value of selected device
*\param[out] out_pu16ReadData	It specifies the pointer to read data from specified register offset
*
*\retval	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output read data pointer is null
*
*\pre		 ::DPcPCI3096_Open
*\post		 ::DPcPCI3096_GetErrorMessage
*
*\author	 Mahesh S
*\date		 09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_ReadReg(DP_DRV_HANDLE in_hHandle, U16BIT in_u16Offset, PU16BIT out_pu16ReadData);

/**
*\brief		This function is used to enable or disable(1 - Enable, 0 - Disable) the device share option(opening same device more than one time)
*
*\param[in]	 in_hHandle			It specifies the device handle which obtained from device open function
*\param[in]	 in_u8DevShareEnDis	It specifies the enable / disable device share otions(max:1)
*
*\retval	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_DEVSHAREENDIS is returned if the enable / disable device share option is out of limit(0 to 1)
*
*\pre		::DPcPCI3096_Open
*\post		::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_SetDeviceShare(DP_DRV_HANDLE in_hHandle, U8BIT in_u8DevShareEnDis);
/*!
* @}
*/

/*******************************Board Specific Functions *********************************************/
/*!
*	\addtogroup Board_Functions List of device specific driver functions
* @{
*/

/**
*\brief		This function is used to configure the mode of operation and the self test for a particular group. The specified input group can be configured in any one of the following mode.
*<ol>
*			<li><b> Edge Event Mode :</b> Each input channel can be configured as Low True or High True, this is known as Logic Selection. Whenever the channel's input changes, based on the selected logic(low true / high true), the edge event status is set and intimated, and the input data is latched.  For intimation of interrupt status, the interrupt should be enabled. To Enable or disable the interrupt, refer the function DPcPCI3096_EnDisInterrupt() and for logic selection, refer the function DPcPCI3096_ChannelEdgeSelection() or DPcPCI3096_GroupEdgeSelection() or DPcPCI3096_AllChannelEdgeSelection().</li>
*			<li><b> State Change Event Mode :</b> Each input channel's current state is compared with the previous state. Whenever the change occurs in the input, either from high true to low true or low true to high true, the state change event status is set and intimated and also the input data is latched.  For intimation of interrupt status, the interrupt should be enabled. To Enable or disable the interrupt, refer the function DPcPCI3096_EnDisInterrupt().</li>
*			<li><b> Strobe Event Mode :</b> This interrupt status is not based on the change of the input state, but based up on the trigger. When trigger is given, the strobe event status is set and intimated and also the input data is latched.  For intimation of interrupt status, the interrupt should be enabled. To Enable or disable the interrupt, refer the function DPcPCI3096_EnDisInterrupt(). The trigger source is classified as internal trigger and external trigger. The internal trigger, also known as software trigger, can be selected for a particular group or for the whole board i.e., for all groups. The external trigger can be given from any external device. Self test is also configured in this function. Complete built-in self-test allows all channels in the module to be independently tested without any external circuit.</li>
*</ol>
*
*\note		1. The status of a particular type of interrupt will not be set when the particular input channel is masked off. (For mask operations refer function DPcPCI3096_MaskAllChannel() or DPcPCI3096_MaskGroup() or DPcPCI3096_MaskChannel())
*\note		2. During external input configuration i.e., the input to the board is provided through external source (DC voltage), the self test should be disabled
*\note		3. If self-test is enabled, the self-test value can be programmed by the user to carry out the self-test as desired. (For programming self test value refer function DPcPCI3096_SelfTest())
*
*\param[in] in_hHandle			It specifies the device handle which obtained from device open function
*\param[in]	in_u8GrpNum			It specifies the group number(min:1 to max:3)\n
									1 – Group1 specifies 1 to 16 input channels,\n
									2 – Group2 specifies 17 to 32 input channels,\n
									3 – Group3 specifies 33 to 48 input channels.
*\param[in]	in_u8InputMode		It specifies the input mode(min:1 to max:3)\n
									1 - Edge Event Mode,\n
									2 - State Change Event Mode,\n
									3 - Strobe Event mode.
*\param[in]	in_u8StrobeSel		It specifies strobe selection(min:0 to max:2)\n
									0 - Group Strobe,\n
									1 - External Strobe,\n
									2 - Board Strobe.
*\param[in]	in_u8SelfTestEnDis	It specifies selftest enable/disable(max:1)\n
									0 - Self Test Disable,\n
									1 - Self Test Enable.
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_GRPNUM is returned if group number is out of limit(1 to 3)
*\retval	::DPCPCI3096_ERR_INVALID_INPUTMODE is returned if input mode selection is out of limit(1 to 3)
*\retval	::DPCPCI3096_ERR_INVALID_STROBESEL is returned if strobe selection is out of limit(0 to 2)
*\retval	::DPCPCI3096_ERR_INVALID_SELFTESTENDIS is returned if self test selection is out of limit(0 to 1)
*
*\pre    	::DPcPCI3096_Open
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_ConfigMode(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GrpNum, U8BIT in_u8InputMode, U8BIT in_u8StrobeSel, U8BIT in_u8SelfTestEnDis);

/**
*\brief		 This function is used to write self test data for the channels in the specified group
*
*\param[in]	 in_hHandle			It specifies the device handle which obtained from device open function
*\param[in]	 in_u8GrpNum    	It specifies the group number(min:1 to max:3)\n
									1 – Group1 specifies 1 to 16 input channels,\n
									2 – Group2 specifies 17 to 32 input channels,\n
									3 – Group3 specifies 33 to 48 input channels.
*\param[in]	 in_u16SelfTestData	It specifies selftest data\n
									Bit 0 - Channel 1 data,\n
									Bit 1 - Channel 2 data\n
									..,\n
									Bit 15 - Channel 16 data.
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_GRPNUM is returned if group number is out of limit(1 to 3)
*\retval	 ::DPCPCI3096_ERR_INVALID_SELFTESTCONFIG is returned if selftest not enabled for mentioned group number in DPcPCI3096_ConfigMode().
*
*\pre    	::DPcPCI3096_ConfigMode
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_SelfTest(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GrpNum, U16BIT in_u16SelfTestData);

/**
*\brief		This function is used to configure the external strobe for a group.
*
*\param[in]	in_hHandle      It specifies the device handle which obtained from device open function
*\param[in]	in_u8GrpNum		It specifies group number(min:1 to max:3)\n
								1 – Group1 specifies 1 to 16 input channels,\n
								2 – Group2 specifies 17 to 32 input channels,\n
								3 – Group3 specifies 33 to 48 input channels.
*\param[in]	in_u8Polarity	It specifies Polarity selection(min:0 to max:1)\n
								0 – Active Low,\n
								1 – Active High.
*\param[in]	in_u8EdgeSelect	It specifies edge selection(max:1)\n
								0 - Raising Edge Selection,\n
								1 - Falling Edge Selection.
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_GRPNUM is returned if group number is out of limit(1 to 3)
*\retval	::DPCPCI3096_ERR_INVALID_POLARITY is returned if polarity selection is out of limit(0 to 1)
*\retval	::DPCPCI3096_ERR_INVALID_EDGESELECT is retrned if edge selection is out of limit(0 to 1)
*
*\pre    	::DPcPCI3096_ConfigMode
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_ConfigExtStrobe(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GrpNum, U8BIT in_u8Polarity, U8BIT in_u8EdgeSelect);

/**
*\brief      This function is used to set the debounce time for the specified input group. Each input group has a programmable debounce circuit so as to enable a unique debounce time for each group. The input are processed through a debounce circuit to ensure that false transients are not recognized i.e., no inputs are affected until the debounce time selected for the particular group expires. The debounce clock can be programmable from 1 microsec to 16.77216sec.
*
*\param[in]     in_hHandle		It specifies the device handle which obtained from device open function
*\param[in]		in_u8GrpNum     It specifies group number(min:1 to max:3)\n
									1 – Group1 specifies 1 to 16 input channels,\n
									2 – Group2 specifies 17 to 32 input channels,\n
									3 – Group3 specifies 33 to 48 input channels.
*\param[in]	in_u16DebounceTime	It specifies debounce time(min:0x7 to max:0x18)(0x07 - 128 micro sec, 0x08 - 256 micro sec, 0x09 - 512 micro sec, 0x0A - 1.024 milli sec, 0x0B - 2.048 milli sec, 0x0C - 4.096 milli sec, 0x0D - 8.192 milli sec, 0x0E - 16.384 milli sec, 0x0F - 32.768 milli sec, 0x10 - 65.536 milli sec, 0x11 - 131.072 milli sec, 0x12 - 262.144 milli sec, 0x13 - 524.288 milli sec, 0x14 - 1.048576 sec, 0x15 - 2.097152 sec, 0x16 - 4.194304 sec, 0x17 - 8.388608 sec, 0x18 - 16.777216 sec)
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_GRPNUM is returned if group number is out of limit(1 to 3)
*\retval	::DPCPCI3096_ERR_INVALID_DEBOUNCETIME is returned if debounce time is out of limit(0x7 to 0x18)
*
*\pre    	::DPcPCI3096_ConfigMode
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_SetDebounceTime(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GrpNum, U16BIT in_u16DebounceTime);

/**
*\brief      This function is used to mask / unmask a particular channel. If the channel is unmasked, change in the input state is considered, otherwise the change of input state is ignored.
*
*\param[in]	in_hHandle		It specifies the device handle which obtained from device open function
*\param[in]	in_u8ChnNum		It specifies channel number(min:1 to max:48)
*\param[in]	in_u8Mask		It specifies  mask / unmask value (max:1)\n
								0 - Channel disable (mask),\n
								1 - Channel enable (unmask)
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_CHNNUM is returned if channel number is out of limit(1 to 48)
*\retval	::DPCPCI3096_ERR_INVALID_MASK is returned if mask value is out of limit(0 to 1)
*
*\pre    	::DPcPCI3096_ConfigMode
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_MaskChannel(DP_DRV_HANDLE in_hHandle, U8BIT in_u8ChnNum, U8BIT in_u8Mask);

/**
*\brief		This function is used to mask / unmask a particlular group. Each channel in the group can be masked / unmasked. If a channel in the group is unmasked, change in the input state is considered, otherwise the change of input state is ignored.
*
*\param[in]	in_hHandle		It specifies the device handle which obtained from device open function
*\param[in]	in_u8GrpNum     It specifies group number(min:1 to max:3)\n
								1 – Group1 specifies 1 to 16 input channels,\n
								2 – Group2 specifies 17 to 32 input channels,\n
								3 – Group3 specifies 33 to 48 input channels.
*\param[in]	in_u16MaskChannelSel	It specifies mask / unmask channel selection for a specified group, which is only to be affected in input channels(min:0x1 to max:0xFFFF). Each bit specifies the mask / unmask channel selection, as mentioned below,\n
										Bit 0 - Channel 1 (1 - Select, 0 - Unselect),\n
										Bit 1 - Channel 2 (1 - Select, 0 - Unselect),\n
										..,\n
										Bit 15 - Channel 16 (1 - Select, 0 - Unselect).
*\param[in]	in_u16MaskChannelSts	It specifies mask / unmask channel status for a specified group, which is to be written to the input channels. Each bit specifies the mask / unmask data of a particular channel, as mentioned below,\n
										Bit 0 - Channel 1 mask / unmask data (1 - UnMask, 0 - Mask),\n
										Bit 1 - Channel 2 mask / unmask data (1 - UnMask, 0 - Mask),\n
										..\n
										Bit 15 - Channel 16 mask / unmask data (1 - UnMask, 0 - Mask).
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_GRPNUM is returned if group number is out of limit(1 to 3)
*\retval	::DPCPCI3096_ERR_INVALID_MASKCHANNELSEL is returned if the mask / unmask channel selection is out of limit(0x1 to 0xFFFF)
*
*\pre    	::DPcPCI3096_ConfigMode
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_MaskGroup(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GrpNum, U16BIT in_u16MaskChannelSel, U16BIT in_u16MaskChannelSts);

/**
*\brief		This function is used to mask or unmask all channels. This will take an structure pointer as input for masking or unmasking, which actually represent 16 channels per group. One in any bit will represent the specific channel is unmasked. i.e. the interrupt will be raised for the channel. Zero in any bit represents the interrupt will be not raised for the specific channel
*
*\param[in]	in_hHandle              It specifies the device handle which obtained from device open function
*\param[in]	in_pSMaskAllChnSel      It specifies mask / unmask channel selection for all groups, which is only to be affected in input channels(min:0x1 to max:0xFFFF) for corresponding group. Each bit specifies the mask / unmask channel selection for each group, as mentioned below,\n
										Bit 0 - Channel 1 (1 - Select, 0 - Unselect),\n
										Bit 1 - Channel 2 (1 - Select, 0 - Unselect),\n
										..,\n
										Bit 15 - Channel 16 (1 - Select, 0 - Unselect).
*\param[in]	in_pSMaskAllChnSts	It specifies mask / unmask channel status for all groups, which is to be written to the input channels. Each bit specifies the mask / unmask data of a particular channel for each group, as mentioned below,\n
										Bit 0 - Channel 1 mask / unmask data (1 - UnMask, 0 - Mask),\n
										Bit 1 - Channel 2 mask / unmask data (1 - UnMask, 0 - Mask),\n
										..\n
										Bit 15 - Channel 16 mask / unmask data (1 - UnMask, 0 - Mask).\n
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the input mask all channel selection structure pointer is null
* *\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the input mask all channel status structure pointer is null
*\retval	::DPCPCI3096_ERR_INVALID_MASKCHANNELSEL is returned if the mask / unmask channel selection is out of limit(0x1 to 0xFFFF)
*
*\pre		::DPcPCI3096_ConfigMode
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_MaskAllChannel(DP_DRV_HANDLE in_hHandle, PSDPCPCI3096_ALL_CHANNELS in_pSMaskAllChnSel, PSDPCPCI3096_ALL_CHANNELS in_pSMaskAllChnSts);

/**
*\brief      This function is used to configure the logic selection, LOW TRUE / HIGH TRUE, for a particular channel. Based on the logic selection, interrupt status is set for the change in state of a particular input channel. The logic selection is required only for Edge Event Mode. To configure the input interrupt refer function DPcPCI3096_ConfigMode(). For instance, if high true is selected, the interrupt status will be set whenever the channel's input changes from logic 0 to logic 1.
*
*\param[in]	in_hHandle		It specifies the device handle which obtained from device open function
*\param[in]	in_u8ChnNum		It specifies channel number(min:1 to max:48)
*\param[in]	in_u8EdgeSel	It specifies edge selection(max:1)\n
								0 - Raising Edge,\n
								1 - Falling Edge
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_CHNNUM is returned if channel number is out of limit(1 to 48)
*\retval	::DPCPCI3096_ERR_INVALID_EDGESEL is returned if edge selection is out of limit(0 to 1)
*
*\pre		::DPcPCI3096_ConfigMode
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_EdgeChannelSelection(DP_DRV_HANDLE in_hHandle, U8BIT in_u8ChnNum, U8BIT in_u8EdgeSel);

/**
*\brief      This function is used to configure the logic selection, LOW TRUE / HIGH TRUE, for a particular group. Based on the logic selection, the interrupt status is set for the change in state of a particular input channel. The logic selection is required only for Edge Event Mode. To configure the input interrupt refer function DPcPCI3096_ConfigMode(). For instance, if low true is selected, the interrupt status will be set whenever the channel's input changes from logic 1 to logic 0.
*
*\param[in]	in_hHandle          It specifies the device handle which obtained from device open function
*\param[in]	in_u8GrpNum         It specifies group number(min:1 to max:3)\n
									1 – Group1 specifies 1 to 16 input channels,\n
									2 – Group2 specifies 17 to 32 input channels,\n
									3 – Group3 specifies 33 to 48 input channels.
*\param[in]	in_u16EdgeChnSel    It specifies edge channel selection for a specified group, which is only to be affected in input channels(min:0x1 to max:0xFFFF). Each bit specifies the edge channel selection, as mentioned below,
									Bit 0 - Channel 1 (1 - Select, 0 - Unselect),\n
									Bit 1 - Channel 2 (1 - Select, 0 - Unselect),\n
									..,\n
									Bit 15 - Channel 16 (1 - Select, 0 - Unselect).
*\param[in]	in_u16EdgeSts       It specifies edge status for a specified group, which is to be written to the input channels. Each bit specifies the edge status data of a particular channel, as mentioned below,\n
									Bit 0 - Channel 1 mask / unmask data (1 - Falling Edge, 0 - Raising Edge),\n
									Bit 1 - Channel 2 mask / unmask data (1 - Falling Edge, 0 - Raising Edge),\n
									..,\n
									Bit 15 - Channel 16 mask / unmask data (1 - Falling Edge, 0 - Raising Edge).
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_GRPNUM is returned if group number is out of limit(1 to 3)
*\retval	::DPCPCI3096_ERR_INVALID_EDGECHNSEL is returned if edge selection is out of limit(0x1 to 0xFFFF)
*
*\pre    	::DPcPCI3096_Open
*\pre		::DPcPCI3096_ConfigMode
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_EdgeGroupSelection(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GrpNum, U16BIT in_u16EdgeChnSel, U16BIT in_u16EdgeSts);

/**
*\brief      This function is used to configure the logic selection, LOW TRUE / HIGH TRUE, for all groups. Based on the logic selection, the interrupt status is set for the change in state of a particular input channel. The logic selection is required only for edge event mode. To configure the input interrupt refer function DPcPCI3096_ConfigMode(). For instance, if low true is selected, the interrupt status will be set whenever the channel's input changes from logic 1 to logic 0.
*
*\param[in]	in_hHandle              It specifies the device handle which obtained from device open function
*\param[in]	in_pSEdgeChannelSel     It specifies edge channel selection for all groups, which is only to be affected in input channels(min:0x1 to max:0xFFFF). Each bit specifies the edge channel selection for each group, as mentioned below,
                                        Bit 0 - Channel 1 (1 - Select, 0 - Unselect),\n
                                        Bit 1 - Channel 2 (1 - Select, 0 - Unselect),\n
                                        ..,\n
                                        Bit 15 - Channel 16 (1 - Select, 0 - Unselect).
*\param[in]	in_pSEdgeChannelSts     It specifies edge status for all groups, which is to be written to the input channels. Each bit specifies the edge status data of a particular channel for each group, as mentioned below,\n
                                        Bit 0 - Channel 1 mask / unmask data (1 - Falling Edge, 0 - Raising Edge),\n
                                        Bit 1 - Channel 2 mask / unmask data (1 - Falling Edge, 0 - Raising Edge),\n
                                        ..,\n
                                        Bit 15 - Channel 16 mask / unmask data (1 - Falling Edge, 0 - Raising Edge).
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the input edge all channel selection structure  pointer is null
* *\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the input edge all channel selection structure  pointer is null
*
*\pre		::DPcPCI3096_ConfigMode
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_EdgeAllChannelSelection(DP_DRV_HANDLE in_hHandle, PSDPCPCI3096_ALL_CHANNELS in_pSEdgeChannelSel, PSDPCPCI3096_ALL_CHANNELS in_pSEdgeChannelSts);

/**
*\brief		This function is used to provide an internal strobe (trigger) for the specified group. In prior, the type of interrupt mode should be configured as strobe event mode, with the type of strobe as group strobe. For mode configuration refer function DPcPCI3096_ConfigMode(). 
*
*\param[in]	in_hHandle	It specifies the device handle which obtained from device open function
*\param[in]	in_u8GrpNum	It specifies group number(min:1 to max:3)\n
                                    1 – Group1 specifies 1 to 16 input channels,\n
                                    2 – Group2 specifies 17 to 32 input channels,\n
                                    3 – Group3 specifies 33 to 48 input channels.
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_GRPNUM is returned if group number is out of limit(1 to 3)
*\retval	::DPCPCI3096_ERR_INVALID_GRPSTROBE_CONFIG is returned if group strobe mode not configured for mentioned group number in DPcPCI3096_ConfigMode().
*
*\pre    	::DPcPCI3096_ConfigMode
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019	
*/
S32BIT STDCALL DPcPCI3096_GroupStrobe(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GrpNum);

/**
*\brief		This function is used to provide an internal strobe (trigger) for all the groups. In prior, the type of interrupt mode should be configured as strobe event mode, with the type of strobe as board strobe. For mode configuration refer function DPcPCI3096_ConfigMode().
*
*\param[in]	in_hHandle	It specifies the device handle which obtained from device open function
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DPcPCI3096_ConfigMode\n::DPcPCI3096_SelfTest
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019		
*/
S32BIT STDCALL DPcPCI3096_BoardStrobe(DP_DRV_HANDLE in_hHandle);

/**
*\brief		This function is used to write the data into the specified channel primary latch register.
*
*\param[in]	in_hHandle              It specifies the device handle which obtained from device open function
*\param[in]	in_u8ChannelNo          It specifies channel number(min:1 to max:48)
*\param[in]	in_u8ChannelStatus      It specifies the channel status(min:0 to max:1)\n
                                            0 - Reset the channel,\n
                                            1 - Set the channel.
*
*\retval	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_CHANNELNO is returned if channel number is out of limit(1 to 48)
*\retval	::DPCPCI3096_ERR_INVALID_CHANNELSTATUS is returned if read status is out of limit(0 to 1)
*
*\pre    	::DPcPCI3096_Open
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_WriteChannelData(DP_DRV_HANDLE in_hHandle, U8BIT in_u8ChannelNo, U8BIT in_u8ChannelStatus);

/**
*\brief		This function is used to write the data into the specified group primary latch register.
*
*\param[in]	in_hHandle      It specifies the device handle which obtained from device open function
*\param[in]	in_u8GrpNum	It specifies group number(min:1 to max:3)\n
                                    1 – Group1 specifies 1 to 16 input channels,\n
                                    2 – Group2 specifies 17 to 32 input channels,\n
                                    3 – Group3 specifies 33 to 48 input channels.
*\param[in]	in_u16Groupsel	It specifies the channel selection for a specified group, which is only to be affected in the primary latch(min:0x1 to max:0xFFFF). Each bit specifies the channel selection, as mentioned below,\n
                                    Bit 0 - Channel 1 (1 - Select, 0 - Unselect),\n
                                    Bit 1 - Channel 2 (1 - Select, 0 - Unselect),\n
                                    ..,\n
                                    Bit 15 - Channel 16 (1 - Select, 0 - Unselect).
*\param[in]	in_u16GroupSts	It specifies the channel status for a specified group, which is to be written to the primary latch. Each bit specifies the data of a particular channel, as mentioned below,\n
                                    Bit 0 - Channel 1 data,\n
                                    Bit 1 - Channel 2 data,\n
                                    ..,\n
                                    Bit 15 - Channel 16 data.
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_GRPNUM is returned if group number is out of limit(1 to 3)
*\retval	::DPCPCI3096_ERR_INVALID_GROUPSEL is returned if group selection is out of limit(0x1 to 0xFFFF)
*
*\pre    	::DPcPCI3096_Open
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_WriteGroupData(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GrpNum, U16BIT in_u16Groupsel, U16BIT in_u16GroupSts);

/**
*\brief		This function is used to write the data into the all channels primary latch register.
*
*\param[in]	in_hHandle              It specifies the device handle which obtained from device open function
*\param[in]	in_pSAllChannelSel      It specifies all channel selction
*\param[in]	in_pSAllChannelSts	It specifies all channel Status
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the input mask all channel selection structure pointer is null
* *\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the input mask all channel status structure pointer is null
*
*\pre    	::DPcPCI3096_Open
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_WriteAllChannelData(DP_DRV_HANDLE in_hHandle, PSDPCPCI3096_ALL_CHANNELS in_pSAllChannelSel, PSDPCPCI3096_ALL_CHANNELS in_pSAllChannelSts);

/**
*\brief		This function is used to update the data in the secondary latch. The groups will be selected depending on the in_u8TrigSel value. In this data latch we can be latched the single group or all groups.
*
*\param[in]	in_hHandle	It specifies the device handle which obtained from device open function
*\param[in]	in_u8GrpNum	It specifies group number(min:1 to max:3)\n
							1 – Group1 specifies 1 to 16 input channels,\n
							2 – Group2 specifies 17 to 32 input channels,\n
							3 – Group3 specifies 33 to 48 input channels.
*\param[in]	in_u8TrigSel It specifies trigger selection(max:1)\n
							0 – Tigger particular group,\n
							1 – Tigger All groups.
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_GRPNUM is returned if group number is out of limit(1 to 3)
*\retval	::DPCPCI3096_ERR_INVALID_TRIGSEL is returned if trigger selection is out of limit(0 to 1)
*
*\pre		::DPcPCI3096_WriteChannelData or ::DPcPCI3096_WriteGroupData or ::DPcPCI3096_WriteAllChannelData
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_Trigger(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GrpNum, U8BIT in_u8TrigSel);

/**
*\brief		This function is used to read the output of primary / secondary data for particular channel.
*
*\param[in]     in_hHandle	It specifies the device handle which obtained from device open function
*\param[in]		in_u8ChannelNo	It specifies channel number(min:1 to max:48)
*\param[in]		in_u8PriSecSel	It specifies primary or secondary latch selection(max:1)
									0 – Primary latch,\n
                                    1 – Secondary latch.
*\param[out]    out_pu8ChnSts	It specifies channel status of primay /secondary relay 
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_CHANNELNO  is retrned if the channel number is out of limit(1 to 48)
*\retval	::DPCPCI3096_ERR_INVALID_PRISECSEL  is retrned if the selection of primary / secondary is out of limit(0 to 1)
*\retval	::DP_DRV_ERR_INVALID_POINTER if the output channel status pointer is null
*
*\pre		::DPcPCI3096_WriteChannelData or ::DPcPCI3096_WriteGroupData or ::DPcPCI3096_WriteAllChannelData
*\pre		::DPcPCI3096_Trigger for secondary latch data
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_ReadChannelSts(DP_DRV_HANDLE in_hHandle, U8BIT in_u8ChannelNo, U8BIT in_u8PriSecSel, PU8BIT out_pu8ChnSts);

/**
*\brief		This function is used to read the output of primary / secondary data for particular group.
*
*\param[in]	in_hHandle          	It specifies the device handle which obtained from device open function
*\param[in]	in_u8GrpNum         	It specifies group number(min:1 to max:3)\n
                                        1 – Group1 specifies 1 to 16 input channels,\n
                                        2 – Group2 specifies 17 to 32 input channels,\n
                                        3 – Group3 specifies 33 to 48 input channels.
*\param[in]		in_u8PriSecSel		It specifies primary or secondary latch selection(max:1)
										0 – Primary latch,\n
                                        1 – Secondary latch.
*\param[out]    out_pu16GroupSts    It specifies channel status of particular group in primay latch / secondary latch
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_GRPNUM is returned if group number is out of limit(1 to 3)
*\retval	::DPCPCI3096_ERR_INVALID_PRISECSEL  is retrned if the selection of primary / secondary is out of limit(0 to 1)
*\retval	::DP_DRV_ERR_INVALID_POINTER if the output group status pointer is null
*
*\pre		::DPcPCI3096_WriteChannelData or ::DPcPCI3096_WriteGroupData or ::DPcPCI3096_WriteAllChannelData
*\pre		::DPcPCI3096_Trigger for secondary latch data
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019	
*/
S32BIT STDCALL DPcPCI3096_ReadGroupChannelSts(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GrpNum,  U8BIT in_u8PriSecSel, PU16BIT out_pu16GroupSts);

/**
*\brief		 This function is used to read the output of primary / secondary data for all channels.
*
*\param[in]	 in_hHandle				It specifies the device handle which obtained from device open function
*\param[in]	 in_u8PriSecSel			It specifies primary or secondary latch selection(max:1)
										0 – Primary latch,\n
										1 – Secondary latch.
*\param[out] out_pSAllRelaySts	It specifies all channel status of primay / secondary latch
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_PRISECSEL  is retrned if the selection of primary / secondary is out of limit(0 to 1)
*\retval	::DP_DRV_ERR_INVALID_POINTER if the output of all channel structure pointer is null
*
*\pre		::DPcPCI3096_WriteChannelData or ::DPcPCI3096_WriteGroupData or ::DPcPCI3096_WriteAllChannelData
*\pre		::DPcPCI3096_Trigger for secondary latch data
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019	
*/
S32BIT STDCALL DPcPCI3096_ReadAllChannelSts(DP_DRV_HANDLE in_hHandle, U8BIT in_u8PriSecSel, PSDPCPCI3096_ALL_CHANNELS out_pSAllRelaySts);

/**
*\brief		This function is used to read the input data of the specified group in different mode. The different mode available are actual input mode, edge event mode, State Change Event Mode and strobe event mode.
*
*\param[in]	 in_hHandle         	It specifies the device handle which obtained from device open function
*\param[in]	 in_u8GrpNum        	It specifies group number(min:1 to max:3)\n
                                        1 – Group1 specifies 1 to 16 input channels,\n
                                        2 – Group2 specifies 17 to 32 input channels,\n
                                        3 – Group3 specifies 33 to 48 input channels.
*\param[in]  in_u8Mode				It specifies mode selection to read the read back input data(max:3)\n
                                        0 - Actual Mode (It Represents  the input data, which is given as input),\n
                                        1 - Edge Event mode (This data can be read, if the group is configured in edge event mode which represents the input data after masking and logic selection),\n
                                        2 - State Change Event mode(This data can be read, if the group is configured in state change event mode which represents the input data after masking),\n
										3 - Strobe Event mode(This data can be read, if the group is configured in strobe event mode which represents latched data with strobe signal)
*\param[out] out_pu16ReadBackData  It specifies pointer to hold the input data. Each bit specifies the data of a particular channel, as mentioned below,\n
                                        Bit 0 - Channel 1 data,\n
                                        Bit 1 - Channel 2 data,\n
                                        ..,\n
                                        Bit 15 - Channel 16 data.
*
*\retval    ::DPCPCI3096_SUCCESS is returned upon success
*\retval    ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval    ::DPCPCI3096_ERR_INVALID_GRPNUM is returned if group number is out of limit(1 to 3)
*\retval    ::DPCPCI3096_ERR_INVALID_MODE is returned if the mode is out of the limit(0 to 3)
*\retval    ::DP_DRV_ERR_INVALID_POINTER if the output pointer of readback data is null
*
*\pre       Edge Event Mode :\n::DPcPCI3096_ConfigMode\n ::DPcPCI3096_AllChannelEdgeSelection or ::DPcPCI3096_GroupEdgeSelection or ::DPcPCI3096_ChannelEdgeSelection \n::DPcPCI3096_MaskAllChannel or ::DPcPCI3096_MaskGroup or ::DPcPCI3096_MaskChannel \n::DPcPCI3096_SelfTest
*\pre       State Change Event Mode :\n::DPcPCI3096_ConfigMode\n ::DPcPCI3096_MaskAllChannel or ::DPcPCI3096_MaskGroup or ::DPcPCI3096_MaskChannel \n::DPcPCI3096_SelfTest
*\pre       Strobe Event Mode :\n::DPcPCI3096_ConfigMode\n ::DPcPCI3096_ConfigExtStrobe \n::DPcPCI3096_SelfTest \n::DPcPCI3096_GroupStrobe or ::DPcPCI3096_BoardStrobe
*\post      ::DPcPCI3096_GetErrorMessage
*\note      1. DPcPCI3096_SelfTest() is a pre-requisite function if self test is enabled in the function DPcPCI3096_ConfigMode().
*\note      2. DPcPCI3096_ConfigExtStrobe() is a pre-requisite function if strobe selected is external strobe in the function DPcPCI3096_ConfigMode().
*\note      3. DPcPCI3096_GroupStrobe() or DPcPCI3096_BoardStrobe() is a pre-requisite function if strobe selected is either group strobe or board strobe in the function DPcPCI3096_ConfigMode().
*
*\author    Mahesh S
*\date      09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_ReadbackInput(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GrpNum, U8BIT in_u8Mode, PU16BIT out_pu16ReadBackData);

/**
*\brief		  This function is used to read the event status of a particular group. This function primarily used for getting event status in polling mode.
*
*\param[in]	 in_hHandle         It specifies the device handle which obtained from device open function
*\param[in]	 in_u8GrpNum        It specifies group number(min:1 to max:3)\n
                                        1 – Group1 specifies 1 to 16 input channels,\n
                                        2 – Group2 specifies 17 to 32 input channels,\n
                                        3 – Group3 specifies 33 to 48 input channels.
*\param[out]   out_pSEventInfo    It Specifies event status information
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_GRPNUM is returned if group number is out of limit(1 to 3)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output pointer of event status information structure is null
*
*\pre       Edge Event Mode :\n::DPcPCI3096_ConfigMode\n ::DPcPCI3096_AllChannelEdgeSelection or ::DPcPCI3096_GroupEdgeSelection or ::DPcPCI3096_ChannelEdgeSelection \n::DPcPCI3096_MaskAllChannel or ::DPcPCI3096_MaskGroup or ::DPcPCI3096_MaskChannel \n::DPcPCI3096_SelfTest
*\pre       State Change Event Mode :\n::DPcPCI3096_ConfigMode\n ::DPcPCI3096_MaskAllChannel or ::DPcPCI3096_MaskGroup or ::DPcPCI3096_MaskChannel \n::DPcPCI3096_SelfTest
*\pre       Strobe Event Mode :\n::DPcPCI3096_ConfigMode\n ::DPcPCI3096_ConfigExtStrobe \n::DPcPCI3096_SelfTest \n::DPcPCI3096_GroupStrobe or ::DPcPCI3096_BoardStrobe
*\post       ::DPcPCI3096_GetErrorMessage
*\note		1. DPcPCI3096_SelfTest() is a pre-requisite function if self test is enabled in the function DPcPCI3096_ConfigMode().
*\note		2. DPcPCI3096_ConfigExtStrobe() is a pre-requisite function if strobe selected is external strobe in the function DPcPCI3096_ConfigMode().
*\note		3. DPcPCI3096_GroupStrobe() or DPcPCI3096_BoardStrobe() is a pre-requisite function if strobe selected is either group strobe or board strobe in the function DPcPCI3096_ConfigMode().
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_PollGroupEventInfo(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GrpNum, PSDPCPCI3096_EVENT_STS out_pSEventInfo);

/**
*\brief		 This function is used to read the event status information for all groups. This function primarily used for getting event status information in polling mode.
*
*\param[in]		in_hHandle       It specifies the device handle which obtained from device open function
*\param[out]	out_pSEventInfo  It Specifies event status information(size: in_u8MaxCount)
*\param[in]     in_u8MaxCount    It Specifies maximum number group event information to fill in event info structure pointer(max:3)
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output pointer of event status information structure is null
*\retval    ::DPCPCI3096_ERR_INVALID_MAXCOUNT is returned maximum number of group event information vlaue is out of limit(1 to 3)
*
*\pre       Edge Event Mode :\n::DPcPCI3096_ConfigMode\n ::DPcPCI3096_AllChannelEdgeSelection or ::DPcPCI3096_GroupEdgeSelection or ::DPcPCI3096_ChannelEdgeSelection \n::DPcPCI3096_MaskAllChannel or ::DPcPCI3096_MaskGroup or ::DPcPCI3096_MaskChannel \n::DPcPCI3096_SelfTest
*\pre       State Change Event Mode :\n::DPcPCI3096_ConfigMode\n ::DPcPCI3096_MaskAllChannel or ::DPcPCI3096_MaskGroup or ::DPcPCI3096_MaskChannel \n::DPcPCI3096_SelfTest
*\pre       Strobe Event Mode :\n::DPcPCI3096_ConfigMode\n ::DPcPCI3096_ConfigExtStrobe \n::DPcPCI3096_SelfTest \n::DPcPCI3096_GroupStrobe or ::DPcPCI3096_BoardStrobe
*\post       ::DPcPCI3096_GetErrorMessage
*\note		1. DPcPCI3096_SelfTest() is a pre-requisite function if self test is enabled in the function DPcPCI3096_ConfigMode().
*\note		2. DPcPCI3096_ConfigExtStrobe() is a pre-requisite function if strobe selected is external strobe in the function DPcPCI3096_ConfigMode().
*\note		3. DPcPCI3096_GroupStrobe() or DPcPCI3096_BoardStrobe() is a pre-requisite function if strobe selected is either group strobe or board strobe in the function DPcPCI3096_ConfigMode().
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_PollAllGroupEventInfo(DP_DRV_HANDLE in_hHandle, PSDPCPCI3096_EVENT_STS out_pSEventInfo, U8BIT in_u8MaxCount);

/**
*\brief		This function is used to clear the event for a selected group, so that further event can be generated.
*
*\param[in]	in_hHandle	It specifies the device handle which obtained from device open function
*\param[in]	in_u8GrpNum	It specifies group number(min:1 to max:3)\n
							1 – Group1 specifies 1 to 16 input channels,\n
							2 – Group2 specifies 17 to 32 input channels,\n
							3 – Group3 specifies 33 to 48 input channels.
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_GRPNUM is returned if group number is out of limit(1 to 3)
*
*\pre    	::DPcPCI3096_Open
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_ClearEvent(DP_DRV_HANDLE in_hHandle, U8BIT in_u8GrpNum);

/**
*\brief		This function is used to clear the event for all groups, so that further event can be generated.
*
*\param[in]	in_hHandle	It specifies the device handle which obtained from device open function
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre    	::DPcPCI3096_Open
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019			
*/
S32BIT STDCALL DPcPCI3096_ClearAllEvents(DP_DRV_HANDLE in_hHandle);

/**
*\brief		This function is used to enable or disable(1 - Enable, 0 - Disable) interupt for board.
*
*\param[in]	in_hHandle          It specifies the device handle which obtained from device open function
*\param[in]	in_u8IntEnDis       It specifies the enable/disable interupt(max:1) (0-Polling Mode, 1-Interrupt Mode)
*\param[in]	in_u16BuffSize      It specifies the ring buffer size to create ringbuffer(min:1 to max:16)
									1 – sizeof(SDPcPCI3096_EVENT_STS) * 1K,\n
									2 – sizeof(SDPcPCI3096_EVENT_STS) * 2K,\n
									3 – sizeof(SDPcPCI3096_EVENT_STS) * 3K,\n
									..
									16 - sizeof(SDPcPCI3096_EVENT_STS) * 16K.
*\param[in]	in_u8IntPropagate   It specifies the interupt propagation option(max:1)(0- No Propagation, 1-Propagate Interrupt)
*
*\retval 	::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DPCPCI3096_ERR_INVALID_INTENDIS is returned if interrupt enable/disable is out of limit(0 to 1)
*\retval	::DPCPCI3096_ERR_INVALID_INTPROPAGATE is returned if interrupt propagation option is out of limit(0 to 1)
*
*\pre    	::DPcPCI3096_Open
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019	
*/
S32BIT STDCALL DPcPCI3096_EnDisInterrupt(DP_DRV_HANDLE in_hHandle, U8BIT in_u8IntEnDis, U16BIT in_u16BuffSize, U8BIT in_u8IntPropagate);

/**
*\brief		This function is used to read the interrupt data. This function can be used only if the interrupt(s) are enabled.
*
*\param[in]		in_hHandle			It specifies the device handle which got from device open function
*\param[in]     in_u32DataCount		It specifies the data count to get from buffer
*\param[out]	out_pu32AvailCount	It specifies the output pointer to hold the available data count in output buffer(out_pSEventInfo)
*\param[out]    out_pSEventInfo  	It Specifies event status information(size:in_u32DataCount)
*\param[in] 	in_u8Options   		It specifies wait for event have until any one interrupt came or all interrupts came(max:2)
										0 - No wait\n
										1 - Waiting for any configured event occurs\n
										2 - Waiting for occurring all the configured event occurs.
*\param[in]		in_pu32Timeout      It specifies the address of the timeout value
*
*\retval		::DPCPCI3096_SUCCESS is returned upon success
*\retval        ::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*\retval		::DPCPCI3096_ERR_INVALID_OPTIONS is returned if options value is out of limit(0 to 2)
*\retval		::DP_DRV_ERR_INVALID_POINTER is returned if the output pointer of event status information structure is null
*\retval        ::DP_DRV_ERR_INVALID_POINTER is returned if the specified available data count output pointer is null
*
*\pre           ::DPcPCI3096_Open
*\post          ::DPcPCI3096_GetErrorMessage
*
*\author         Mahesh S
*\date           09 August, 2019
*/
S32BIT STDCALL DPcPCI3096_GetGroupEventInfo(DP_DRV_HANDLE in_hHandle, U32BIT in_u32DataCount, PU32BIT out_pu32AvailCount, PSDPCPCI3096_EVENT_STS out_pSEventInfo, U8BIT in_u8Options, PU32BIT in_pu32Timeout);

/**
*\brief         This function is used to get ringbuffer count value. This function can be used only if the interrupt(s) are enabled.
*
*\param[in]		in_hHandle         It specifies the device handle which obtained from device open function
*\param[out]    out_pu32BuffCount  It specifies the output pointer to hold the ring buffer count value
*
*\retval    ::DPCPCI3096_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if output buffer count pointer is null
*
*\pre    	::DPcPCI3096_Open
*\post   	::DPcPCI3096_GetErrorMessage
*
*\author	Mahesh S
*\date		09 August, 2019 
*/
S32BIT STDCALL DPcPCI3096_RingBuff_GetCount(DP_DRV_HANDLE in_hHandle, PU32BIT out_pu32BuffCount);

/*!
* @}
*/
#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif
	
#endif
