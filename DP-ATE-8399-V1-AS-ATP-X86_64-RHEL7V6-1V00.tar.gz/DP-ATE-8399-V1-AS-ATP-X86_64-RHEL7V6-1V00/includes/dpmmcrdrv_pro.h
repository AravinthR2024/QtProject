/**
* \file dpmmcrdrv_pro.h
* \brief This file contains the function prototypes of all the functions or API's are available in this file
*
*
* \author 	Harish Babu GK
* \date		04 June, 2019
*
* \version   1.00
*
* \copyright Copyright (C) 2019 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
* All Rights Reserved.\n
* Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
* Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
* Chennai-603103 | India\n
* Website : http://www.datapatternsindia.com/\n
* Phone: 91-44-4741-4000\n
* FAX: 91-44-4741-4444 \n
*
*/

#ifndef _DPMMCRDRV_PRO_H_
#define _DPMMCRDRV_PRO_H_

#include "dp_types.h"

#if defined(__cplusplus) || defined(__cplusplus__)
extern 	"C" {
#endif

/***********************************Structures************************/
#pragma pack(push, 1)

/**
*\struct	_SDPMMCRDRV_DEVICE_LOCATION
*\brief		This structure contains members to hold the devices location
*
*			The device location structure includes the bus type, bus number, slot number and function number.
*
*/
typedef struct _SDPMMCRDRV_DEVICE_LOCATION
{
    U8BIT m_u8BusType;				/*!< Device bus type */
    union
    {
        struct
        {
            U8BIT m_u8BusNo;		/*!<Bus Number */
            U8BIT m_u8SlotNo;		/*!<Slot number */
            U8BIT m_u8FunctionNo;	/*!<Function number*/
        }pci;
    }u;
	U8BIT m_u8MMSlotNo;
}SDPMMCRDRV_DEVICE_LOCATION, *PSDPMMCRDRV_DEVICE_LOCATION;

/**
*\struct	_SDPMMCRDRV_DRIVER_DETAILS
*\brief		This structure contains members to hold the driver details
*
*			The driver details structure includes the driver version.
*
*/
typedef struct _SDPMMCRDRV_DRIVER_DETAILS
{
	 U32BIT m_u32Version;		/*!< Driver version */
}SDPMMCRDRV_DRIVER_DETAILS, *PSDPMMCRDRV_DRIVER_DETAILS;

/**
*\struct	_SDPMMCRDRV_BAR_INFO
*\brief		This structure contains members of the all bar's information
*
*	The all bar's information includes bar address is IO mapped or Memory mapped, length of the bar and physical address and virtual address of the bar.
*/
typedef struct _SDPMMCRDRV_BAR_INFO
{
	U8BIT 	m_u8IsIoMapped;				/*!< specify that io, id, int0 & int1 are io mapped or mem mapped (1 - Io, 0 - Mem) */
	U32BIT  m_u32BarSize; 				/*!< Bar Size */
	U32BIT	m_vpPhysicalAddressLSB;		/*!< Physical address of LSB */
	U32BIT	m_vpPhysicalAddressMSB;		/*!< Physical address of MSB */
	U32BIT	m_vpVirtualAddressLSB;		/*!< Virtual Address of LSB*/
	U32BIT	m_vpVirtualAddressMSB;		/*!< Virtual Address of MSB */
}SDPMMCRDRV_BAR_INFO, *PSDPMMCRDRV_BAR_INFO ;

/**
*\struct	_SDPMMCRDRV_BAR_INFO
*\brief		This structure contains members to hold carrier device information
*
*	The carrier device information includes IRQ line, device id, bar information and device location.
*/
typedef struct _SDPMMCRDRV_CARRIER_DEVICE_INFO
{
    U8BIT                           m_u8IrqLine;    		/*!< Carrier irq line number */
	U16BIT                          m_u16DeviceId;          /*!< Carrier device id */
    SDPMMCRDRV_BAR_INFO             m_SBusBarInfo[6];       /*!< Bar information */
    SDPMMCRDRV_DEVICE_LOCATION      m_SDeviceLocation;      /*!< Device location */
}SDPMMCRDRV_CARRIER_DEVICE_INFO, *PSDPMMCRDRV_CARRIER_DEVICE_INFO;

#pragma pack(pop)

/****************************function  prototypes ******************************/
/*!
*	\addtogroup Common_Functions List of common driver functions
* @{
*/

/**
*\brief 	 This function is used to find the total number of MM carrier device(s) present in the system
*
*\param[out] out_pu16TotalDevices	It specifies the output pointer to hold the number of MM carrier device(s) found
*
*\retval	::DPMMCRDRV_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified total devices output pointer is null
*
*\pre		NA
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		03 June, 2019
*/
S32BIT STDCALL DPMMCRDRV_GetTotalDeviceFound(PU16BIT out_pu16TotalDevices);

/**
*\brief          This function is used to get pci details such as bus number, slot number, function number for the DP-MM-CRDRV device(s)
 *
*\param[out] out_pSAllDevLocDetails     It specifies the output pointer to hold the device location details(size:in_u16MaxDevices)
*\param[in]  in_u16MaxDevices           It specifies the total number of DP-MM-CRDRV device(s) found
*
*\retval        ::DPMMCRDRV_SUCCESS is returned upon success
*\retval        ::DP_DRV_ERR_INVALID_POINTER is returned if the specified output all device location details pointer is null
*
*\pre           ::DPMMCRDRV_GetTotalDeviceFound
*\post          ::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		03 June, 2019
*/
S32BIT STDCALL DPMMCRDRV_GetAllDeviceLocations(PSDPMMCRDRV_DEVICE_LOCATION out_pSAllDevLocDetails, U16BIT in_u16MaxDevices);

/** 
*\brief 	 This function is used to get MM carrier device details such as irq line number, deveice ID, bar informations and carrier device locations(bus number, slot number, function number and channel number).
*
*\param[out]  out_pSAllDevInfoDetails	It specifies the output pointer to hold the device location details(size: in_u16MaxDevices)
*\param[in]   in_u16MaxDevices			It specifies the total number of MM carrier device(s) found
*
*\retval	::DPMMCRDRV_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output device location details structure pointer is null
*
*\pre		::DPMMCRDRV_GetTotalDeviceFound
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		26 October, 2018
*/
S32BIT STDCALL DPMMCRDRV_GetAllDeviceInformation(PSDPMMCRDRV_CARRIER_DEVICE_INFO out_pSAllDevInfoDetails, U16BIT in_u16MaxDevices);

/**
*\brief		This function is used to open the specified MM carrier device.
*
*\param[in]	 in_pSDeviceOpenInfo		It specifies the bus number, slot number, function number and channel number
*\param[out] out_phDeviceHandle		It specifies the pointer which holds output device handle
*
*\retval	::DPMMCRDRV_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the device locataion structure pointer is null
*\retval	::DPMMCRDRV_ERR_DEVICE_BUSY is returned if the the device is already opened
*
* \pre		::DPMMCRDRV_GetAllDeviceLocations
* \post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		26 October, 2018
*/
S32BIT STDCALL DPMMCRDRV_Open(PSDPMMCRDRV_DEVICE_LOCATION in_pSDeviceOpenInfo, DP_DRV_HANDLE out_phDeviceHandle);

/**
*\brief 	 This function is used to close the opened device. Any opened device has to be closed before the application is exited.
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DPMMCRDRV_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_DEVICE_NOT_OPEN is returned if the device is not opened
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		26 October, 2018
*/
S32BIT STDCALL DPMMCRDRV_Close(DP_DRV_HANDLE in_hHandle);

/**
*\brief 	 This function is used to reset the device to initial state
*
*\param[in]	 in_hHandle		It specifies the device handle which is obtained from device open function
*
*\retval	::DPMMCRDRV_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		26 October, 2018
*/
S32BIT STDCALL DPMMCRDRV_Reset(DP_DRV_HANDLE in_hHandle);

/**
*\brief		This function is used to get the error message corresponding to the error code. The error message specify briefly the cause of the error.
*
*\param[in]  in_s32ErrCode	It specifies the error code returned by the functions
*\param[out] out_ps8ErrMsg	It specifies the pointer to hold the error message(size:in_u16BufSize)
*\param[in]  in_u16BufSize	It specifies buffer size to hold the error message
*
*\retval	::DPMMCRDRV_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output error message pointer is null
*
*\pre		::DPMMCRDRV_Open
*\post		NA
*
*\author 	Harish Babu GK
*\date		26 October, 2018
*/
S32BIT STDCALL DPMMCRDRV_GetErrorMessage(S32BIT in_s32ErrCode, PS8BIT out_ps8ErrMsg, U16BIT in_u16BufSize);

/**
*\brief		This function is used to get the driver details(Driver Version)
*
*\param[out] out_pSDriverDetails 	It specifies the structure pointer to read the driver details(Driver Version)
*
*\retval	::DPMMCRDRV_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output driver details pointer is null
*
*\pre		NA
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		26 October, 2018
*/
S32BIT STDCALL DPMMCRDRV_GetDriverDetails(PSDPMMCRDRV_DRIVER_DETAILS out_pSDriverDetails);

/** 
*\brief		This function is used to get opened device location details(bus number, slot number, function number and channel number)
*
*\param[in]	 in_hHandle				It specifies the device handle which is obtained from device open function
*\param[out] out_pSDeviceLocation	It specifies the pointer to hold the device location details
*
*\retval	::DPMMCRDRV_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the output device location pointer is null
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		26 October, 2018
*/
S32BIT STDCALL DPMMCRDRV_GetDeviceLocation(DP_DRV_HANDLE in_hHandle, PSDPMMCRDRV_DEVICE_LOCATION out_pSDeviceLocation);

/**
*\brief		This function is used to write data into the specified FPGA register offset
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u8BarNo			It specifies the bar number of selected device(max:5)
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[in]  in_u16WriteData	It specifies the the data to be written in specified register offset
*
*\retval	::DPMMCRDRV_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		26 October, 2018
*/
S32BIT STDCALL DPMMCRDRV_WriteReg(DP_DRV_HANDLE in_hHandle, U8BIT in_u8BarNo, U32BIT in_u32Offset, U16BIT in_u16WriteData);

/**
*\brief		This function is used to read data from the specified FPGA register offset
*
*\param[in]	 in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in]	 in_u8BarNo			It specifies the bar number of selected device(max:5)
*\param[in]	 in_u32Offset		It specifies the offset value of selected device
*\param[out] out_pu16ReadData	It specifies the pointer to read data from specified register offset
*
*\retval	::DPMMCRDRV_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if the specified output read data pointer is null
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		03 June, 2019
*/
S32BIT STDCALL DPMMCRDRV_ReadReg(DP_DRV_HANDLE in_hHandle, U8BIT in_u8BarNo, U32BIT in_u32Offset, PU16BIT out_pu16ReadData);

/**
*\brief		This function is used to enable or disable(1 - Enable, 0 - Disable) the device share option(opening same device more than one time)
*
*\param[in]	in_hHandle	It specifies the device handle which is obtained from device open function
*\param[in]	in_u8EnDis	It specifies the enable / disable value(max:1)
*
*\retval	::DPMMCRDRV_SUCCESS is returned upon success
*\retval	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is invalid or null
*\retval	::DP_DRV_ERR_INVALID_SHARE_VALUE is returned if the enable / disable device share option is out of limit(0 to 1)
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		26 October, 2018
*/
S32BIT STDCALL DPMMCRDRV_SetDeviceShare(DP_DRV_HANDLE in_hHandle, U8BIT in_u8EnDis);
/*!
* @}
*/

/*******************************Board Specific Functions *********************************************/
/*!
*	\addtogroup Board_Functions List of device specific driver functions
* @{
*/

/**
*\brief		This function is used to select address mode for the particular M module.
*
*\param[in] in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in] in_u8MMSlotNo	It specifies the MM slot number(min:1 to max:4)
*\param[in] in_u8AddrMode	It specifies the address mode(min:0 to max:3)
							0 - A08 Address Mode,\n
							1 - Reserved,\n
							2 - Reserved,\n
							3 - A24 Address Mode.
*
*\retval 	::DPMMCRDRV_SUCCESS is returned upon success
*\retval 	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*\retval	::DPMMCRDRV_ERR_INVALID_MMSLOTNO is returned if the slot number selection is out of limit(1 to 4)
*\retval	::DPMMCRDRV_ERR_INVALID_ADDRMODE is returned if the address mode selection is out of limit (0 or 3)
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		26 October, 2018
*/
S32BIT STDCALL DPMMCRDRV_SelectAddressMode(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MMSlotNo, U8BIT in_u8AddrMode);

/**
*\brief		This function is used to select data mode for the particular M module.
*
*\param[in] in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in] in_u8MMSlotNo	It specifies the MM slot number(min:1 to max:4)
*\param[in] in_u8DataMode	It specifies the data mode(min:0 to max:3)
							0 - D16 Data Bus Width,\n
							1 - Reserved,\n
							2 - Reserved,\n
							3 - D32 Data Bus Width.
*
*\retval 	::DPMMCRDRV_SUCCESS is returned upon success
*\retval 	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*\retval	::DPMMCRDRV_ERR_INVALID_MMSLOTNO is returned if the slot number selection is out of limit(1 to 4)
*\retval	::DPMMCRDRV_ERR_INVALID_DATAMODE is returned if the data mode selection is out of limit (0 or 3)
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		26 October, 2018
*/
S32BIT STDCALL DPMMCRDRV_SelectDataMode(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MMSlotNo, U8BIT in_u8DataMode);

/**
*\brief		This function is used to read address mode which is configured for the particular M module.
*
*\param[in] in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in] in_u8MMSlotNo	It specifies the MM slot number(min:1 to max:4)
*\param[out] out_pu8RdAddrMode	It specifies the output pointer to read the address mode
								0 - A08 Address Mode,\n
								1 - Reserved,\n
								2 - Reserved,\n
								3 - A24 Address Mode.
*
*\retval 	::DPMMCRDRV_SUCCESS is returned upon success
*\retval 	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*\retval	::DPMMCRDRV_ERR_INVALID_MMSLOTNO is returned if the slot number selection is out of limit(1 to 4)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if output read address mode pointer is null
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		03 June, 2019
*/
S32BIT STDCALL DPMMCRDRV_ReadAddressModeStatus(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MMSlotNo, PU8BIT out_pu8RdAddrMode);

/**
*\brief		This function is used to read data mode which is configured for the particular M module.
*
*\param[in] in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in] in_u8MMSlotNo		It specifies the MM slot number(min:1 to max:4)
*\param[out] out_pu8RdDataMode	It specifies the output pointer to read the data mode
								0 - Reserved,\n
								1 - D16 Data Bus Width,\n
								2 - D32 Data Bus Width,\n
								3 - Reserved.
*
*\retval 	::DPMMCRDRV_SUCCESS is returned upon success
*\retval 	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*\retval	::DPMMCRDRV_ERR_INVALID_MMSLOTNO is returned if the slot number selection is out of limit(1 to 4)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if output read data mode pointer is null
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		03 June, 2019
*/
S32BIT STDCALL DPMMCRDRV_ReadDataModeStatus(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MMSlotNo, PU8BIT out_pu8RdDataMode);

/**
*\brief		This function is used to enable / disable the interrupt status for the particular M module.
*
*\param[in] in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in] in_u8MMSlotNo		It specifies the MM slot number(min:1 to max:4)
*\param[in] in_u8IntStatus		It specifies the enable / disable interrupt status(max:1)
								0 - Disable Interrupt,\n
								1 - Enable Interrupt.
*\param[in]	in_u8IntPropagate	It specifies the interupt propagation option(max:1)
								0 - No Propagation,\n
								1 - Propagate Interrupt.
*
*\retval 	::DPMMCRDRV_SUCCESS is returned upon success
*\retval 	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*\retval	::DPMMCRDRV_ERR_INVALID_MMSLOTNO is returned if the slot number selection is out of limit(1 to 4)
*\retval	::DPMMCRDRV_ERR_INVALID_INTSTATUS is returned if the interrupt status is out of limit(0 to 1)
*\retval	::DPMMCRDRV_ERR_INVALID_INTPROPAGATE is returned if interrupt propagation option is out of limit(0 to 1)
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		03 June, 2019
*/
S32BIT STDCALL DPMMCRDRV_EnableInterrupt(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MMSlotNo, U8BIT in_u8IntStatus, U8BIT in_u8IntPropagate);

/**
*\brief		This function is used to read the interrupt type status for the particular M module.
*
*\param[in] in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in] in_u8MMSlotNo		It specifies the MM slot number(min:1 to max:4)
*\param[out] out_pu8IntTypeSts	It specifies the output pointer to read the interrupt type status
*
*\retval 	::DPMMCRDRV_SUCCESS is returned upon success
*\retval 	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*\retval	::DPMMCRDRV_ERR_INVALID_MMSLOTNO is returned if the slot number selection is out of limit(1 to 4)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if output interrupt type status pointer is null
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		03 June, 2019
*/
S32BIT STDCALL DPMMCRDRV_ReadInterruptType(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MMSlotNo, PU8BIT out_pu8IntTypeSts);

/**
*\brief		This function is used to read the interrupt status for the particular M module.
*
*\param[in] in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in] in_u8MMSlotNo		It specifies the MM slot number(min:1 to max:4)
*\param[out] out_pu8IntStatus	It specifies the output pointer to read the interrupt status
*
*\retval 	::DPMMCRDRV_SUCCESS is returned upon success
*\retval 	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*\retval	::DPMMCRDRV_ERR_INVALID_MMSLOTNO is returned if the slot number selection is out of limit(1 to 4)
*\retval	::DP_DRV_ERR_INVALID_POINTER is returned if output interrupt status pointer is null
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		03 June, 2019
*/
S32BIT STDCALL DPMMCRDRV_ReadInterruptStatus(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MMSlotNo, PU8BIT out_pu8IntStatus);

/**
*\brief		This function is used to clear the interrupt status for the particular M module.
*
*\param[in] in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in] in_u8MMSlotNo	It specifies the MM slot number(min:1 to max:4)
*
*\retval 	::DPMMCRDRV_SUCCESS is returned upon success
*\retval 	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*\retval	::DPMMCRDRV_ERR_INVALID_MMSLOTNO is returned if the slot number selection is out of limit(1 to 4)
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		03 June, 2019
*/
S32BIT STDCALL DPMMCRDRV_ClearInterrupt(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MMSlotNo);

/**
*\brief		This function is used to reset the particular M module.
*
*\param[in] in_hHandle		It specifies the device handle which is obtained from device open function
*\param[in] in_u8MMSlotNo	It specifies the MM slot number(min:1 to max:4)
*
*\retval 	::DPMMCRDRV_SUCCESS is returned upon success
*\retval 	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*\retval	::DPMMCRDRV_ERR_INVALID_MMSLOTNO is returned if the slot number selection is out of limit(1 to 4)
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		03 June, 2019
*/
S32BIT STDCALL DPMMCRDRV_ResetMmodule(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MMSlotNo);

/**
*\brief		This function is used to trigger the particular M module.
*
*\param[in] in_hHandle			It specifies the device handle which is obtained from device open function
*\param[in] in_u8MMSlotNo		It specifies the MM slot number(min:1 to max:4)
*\param[in] in_u8TriggerType	It specifies the trigger type (max:1)
								0 - Trigger A,\n
								1 - Trigger B.
*
*\retval 	::DPMMCRDRV_SUCCESS is returned upon success
*\retval 	::DP_DRV_ERR_INVALID_HANDLE is returned if the device handle is null
*\retval	::DPMMCRDRV_ERR_INVALID_MMSLOTNO is returned if the slot number selection is out of limit(1 to 4)
*\retval	::DPMMCRDRV_ERR_INVALID_TRIGGERTYPE is returned if the trigger type selection is out of limit(0 to 1)
*
*\pre		::DPMMCRDRV_Open
*\post		::DPMMCRDRV_GetErrorMessage
*
*\author 	Harish Babu GK
*\date		03 June, 2019
*/
S32BIT STDCALL DPMMCRDRV_GiveTrigger(DP_DRV_HANDLE in_hHandle, U8BIT in_u8MMSlotNo, U8BIT in_u8TriggerType);

/*!
* @}
*/
#if defined(__cplusplus) || defined(__cplusplus__)
}
#endif

#endif
