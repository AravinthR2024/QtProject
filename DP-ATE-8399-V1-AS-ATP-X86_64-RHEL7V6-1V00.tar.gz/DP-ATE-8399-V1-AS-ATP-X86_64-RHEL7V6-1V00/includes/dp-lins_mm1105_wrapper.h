/**************************************************************************
// File Name:DPMM1105_Wrapper.h 
// Author:
// Created Date:19/02/2020
// Description:Declared for the Wrapper Function.
**************************************************************************/
#ifndef _DP_MM_1105_WRAPPER_H
#define _DP_MM_1105_WRAPPER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>


#include "dpmm1105_pro.h"
#include "dpmmcrdrv_pro.h"
#include "dp-lins-cm_signals.h"
#include "dp_types.h"

#include "dp-simulator.h"
#include <QTcpSocket>

#define DP_SYS_1105_SUCCESS			0
#define DP_SYS_1105_FAILURE			1
#define DEVICE_SHARE_ENABLE			1
#define DP_1105_MAX_ERRORMSG_SIZE		256
#define DP_CRDRV_SUCCESS           		0
#define DP_1105_MIN_BOARDS			1
#define DP_1105_MAX_BOARDS           		8

#define DP_1105_MIN_CHANNEL			1
#define DP_1105_MAX_CHANNEL			16
#define DP_1105_MAX_DIFFERETIAL_CHANNEL		8           
#define DP_1105_TRUE				1
#define DP_1105_FALSE				0
#define DP_MM1105_ONE           		1
#define DP_1105_INITIALIZE_0			0
#define DP_MM_1105_AVERAGE			1

#define DP_MM_1105_GAIN_VAL_28V     0.25f
#define DP_MM_1105_GAIN_VAL_8V      1

#define DP_MM_1105_ON_OP_VOLT          28.0f
#define DP_MM_1105_ON_RES_VOL_MIN      (DP_MM_1105_ON_OP_VOLT - 2.0f)
#define DP_MM_1105_ON_RES_VOL_MAX      (DP_MM_1105_ON_OP_VOLT + 2.0f)
#define DP_MM_1105_OFF_OP_VOLT         0.0f
#define DP_MM_1105_OFF_RES_VOL_MIN     (DP_MM_1105_OFF_OP_VOLT - 2.0f)
#define DP_MM_1105_OFF_RES_VOL_MAX     (DP_MM_1105_OFF_OP_VOLT + 2.0f)

#define DP_MM_1105_OFFSET_VOLT      2.0
#define DP_MM_1105_OFFSET_AMP       0.5

#define DP_1105_MULTI_FACTOR			4
#define DP_1105_MULTI_FACTOR_CHN9_CHN10		2
#define DP_1105_MULTI_FACTOR_CHN1		5.67
#define DP_MM_1105_FIFO_ENABLE           	0
#define DP_MM_1105_RAWDATA_DISABLE           	0
#define DP_BORDS_STATUS_ONE           		1
#define DP_BORDS_STATUS_ZERO           		0

#define DP_1105_BOARD_1           		1
#define DP_CARR_BOARD				0
#define DP_CARR_MAX_BOARDS			1

#define DP_MM_1105_DIFFERENTIAL_MODE		0
#define DP_1105_NO_CALIBRATION		 	0
#define DP_1105_THREE_POINT_CALIBRATION		1
#define DP_1105_USE_CALIBRATION   		1
#define DP_1105_PACERNUMBER                 	1
#define DP_SYS_1105_PACER_FREQUENCY            	1000
#define DP_SYS_1105_SW_TRIGGER              0
#define DP_SYS_1105_TRIGGER_TYPE			1
#define DP_SYS_1105_SOURCE_SELECTION		1
#define DP_SYS_1105_PACER_INTERNAL          0
#define DP_SYS_1105_TRIGGER_CONTINUOUS      2
#define DP_1105_PACER_INTERNAL_2		2
#define DP_1105_PACER_INTERNAL_3		3
#define DP_1105_PACER_INTERNAL_4		4
#define DP_1105_THRESHOLD_VAL			1

#define DP_1105_READ_DELAY			2 // 1 ms

#define DP_1105_DEVICE_NOT_FOUND		-99
#define DP_1105_NO_DEVICE			-56

#define DP_SYS_40K_INSULATION_ERR		3.980f
#define DP_SYS_40K_CONTINUITY_ERR		-1.700f

typedef struct
{
    U8BIT u8BusNo;
    U8BIT u8SlotNo;
    U8BIT u8FunctionNo;
    U8BIT u8MMSlotNo;
    S8BIT s8BoardSts;
    U8BIT u8ExpSlotNo;
}SDPMM1105_DeviceLocation, *PDPMM1105_DeviceLocation;

typedef struct
{
    U8BIT u8BusNo;
    U8BIT u8SlotNo;
    U8BIT u8FunctionNo;
    U8BIT u8MMSlotNo;
}SDPMM1105APP_DeviceLocation,*PSDPMM1105APP_DeviceLocation;

class DPMM1105_Wrapper
{

public:
    QTcpSocket m_SimSocket;
    char m_cSimEnable;
    U16BIT m_u16NoOfDetBoards;
    PDPMM1105_DeviceLocation m_pSAllDevLocDetails;


private:
    U16BIT m_u16NoOfBoards;
    DP_DRV_HANDLE m_hHandle[DP_1105_MAX_BOARDS];
    DP_DRV_HANDLE m_hCarrierHandle[DP_CARR_MAX_BOARDS];
    U8BIT u8MMSlotNo;
    S32BIT m_s32RetVal;
    U8BIT u8StartStopAcqFlag;
    S8BIT m_szErrorMsg[100];

    S16BIT MUX_1105_ValidateSignalID(U16BIT in_u16SignalId);
public:
    S16BIT Init(U16BIT u16NoOfBoards, PSDPMM1105APP_DeviceLocation in_pSDevLocation, PDPMM1105_DeviceLocation out_pSDevLocation);
    S16BIT Config(U16BIT in_u16BoardNo=0);
    S16BIT StartAcquisition(U16BIT in_u16BoardNo=0);
    S16BIT StopAcquisition(U16BIT in_u16BoardNo=0);
    S16BIT ReadRecentSample(U16BIT in_u16SignalId, U8BIT u8NoOfSamples, PFSINGLE out_pfADCData, U8BIT u8MeanOrAvg);/* 1  - Average, 2 - Mean*/
    S16BIT ReadRecentSamples(U16BIT in_u16SignalIdList[], U16BIT in_u16NoOfSignals, U8BIT u8NoOfSamples, FSINGLE out_fADCData[], U8BIT u8MeanOrAvg);/* 1  - Average, 2 - Mean*/
    void GetLastErrorMsg(PS32BIT out_ps32ErrCode, PS8BIT out_s8ErrMsg);
    S16BIT Close(U16BIT in_u16BoardNo=0);
    S16BIT Reset(U16BIT in_u16BoardNo=0);

    S16BIT EnableSimulator(char in_Enable, char *in_pHostName, unsigned int in_iPort);

};

#endif //_DP_COE_VME_1443_WRAPPER_H
