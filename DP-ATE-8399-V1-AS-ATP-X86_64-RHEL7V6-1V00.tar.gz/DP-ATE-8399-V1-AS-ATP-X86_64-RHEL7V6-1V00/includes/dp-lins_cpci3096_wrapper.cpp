/**************************************************************************
// File Name:dpcpci3096_wrapper.c 
// Author:
// Created Date:13/02/2020
// Description: Defined for the Wrapper Function.
**************************************************************************/
#include "dp-lins_cpci3096_wrapper.h"
#include "string.h"
#define _DRV3096_ENABLE

S16BIT DPCPCI3096_Wrapper::EnableSimulator(char in_Enable, char *in_pHostName, unsigned int in_iPort)
{

    m_cSimEnable = 0;
    if(/*m_cSimEnable*/0)
    {
        m_SimSocket.connectToHost(QString::fromUtf8(in_pHostName), in_iPort);
        if(m_SimSocket.waitForConnected(1000))
        {
            return DP_LINS_3096_SUCCESS;
        }
        else
        {
            return DP_LINS_3096_FAILURE;
        }
    }
    else
    {
        m_SimSocket.disconnectFromHost();
        return DP_LINS_3096_SUCCESS;
    }
}

/**************************************************************************
// Name						: Init
// Author					:
// Global Variables affected			: 				 
// Created Date					: 13/02/2020
// Revision Date				:
// Reason for Revising				:
// Description					: This Function is used to Initialize the 3096 CPCI Board
**************************************************************************/
S16BIT DPCPCI3096_Wrapper::Init(U16BIT u16NoOfBoards, PSDPCPCI3096APP_DeviceLocation in_pSDevLocation, PSDPCPCI3096_DeviceLocation out_pSDevLocation)
{
    PSDPCPCI3096_DEVICE_LOCATION	pSAllDevLocDetails;
    SDPCPCI3096_DeviceLocation	SDevLocation;
    U8BIT u8BoardNo  = LINS_3096_INITIALIZE_0;
    U8BIT u8Loop	 = LINS_3096_INITIALIZE_0;
    m_u16NoOfDetBoards = 0;


    if(/*m_cSimEnable*/0)
    {
        return DP_LINS_3096_SUCCESS;
    }
    else
    {
        if(in_pSDevLocation != NULL)
        {
            for(u8Loop = 0; u8Loop < u16NoOfBoards; u8Loop++)
            {
                out_pSDevLocation[u8Loop].u8SlotNo = in_pSDevLocation[u8Loop].u8SlotNo;
                out_pSDevLocation[u8Loop].u8BusNo = in_pSDevLocation[u8Loop].u8BusNo;
                out_pSDevLocation[u8Loop].u8FunctionNo = in_pSDevLocation[u8Loop].u8FunctionNo;
                out_pSDevLocation[u8Loop].s8BoardSts = DP_BORDS_STATUS_ZERO;
            }
        }

#ifdef _DRV3096_ENABLE
        /* find the available boards as per the filter */
        m_s32RetVal = DPcPCI3096_GetTotalDeviceFound(&m_u16NoOfDetBoards);
        if(m_s32RetVal != DP_LINS_3096_SUCCESS)
        {
            DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_3096_FAILURE;
        }

        if(m_u16NoOfDetBoards == 0)
        {
            strncpy(m_szErrorMsg,"No Modules Detected.",sizeof(m_szErrorMsg));
            return DP_LINS_3096_FAILURE;
        }

        pSAllDevLocDetails = (PSDPCPCI3096_DEVICE_LOCATION)malloc(sizeof(SDPCPCI3096_DEVICE_LOCATION)*(m_u16NoOfDetBoards));
        if(pSAllDevLocDetails == NULL)
        {
            strcpy(m_szErrorMsg, "Error in memory creation for carrier device location details");
            return DP_LINS_3096_FAILURE;
        }

        /* Get All device Location Details */
        m_s32RetVal = DPcPCI3096_GetAllDeviceLocations(pSAllDevLocDetails, m_u16NoOfDetBoards);
        if(m_s32RetVal != DP_LINS_3096_SUCCESS)
        {
            DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            free(pSAllDevLocDetails);
            return DP_LINS_3096_FAILURE;
        }

        m_pSAllDevLocDetails = (PSDPCPCI3096_DeviceLocation)malloc(sizeof(SDPCPCI3096_DeviceLocation)*(m_u16NoOfDetBoards));
        for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfDetBoards); u8BoardNo++)
        {
            m_pSAllDevLocDetails[u8BoardNo].s8BoardSts = DP_BORDS_STATUS_ZERO;
            m_pSAllDevLocDetails[u8BoardNo].u8SlotNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8SlotNo;
            m_pSAllDevLocDetails[u8BoardNo].u8BusNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8BusNo;
            m_pSAllDevLocDetails[u8BoardNo].u8FunctionNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8FunctionNo;
            if(u8BoardNo < u16NoOfBoards)
            {
//                qDebug("slot : %d",in_pSDevLocation[u8BoardNo].u8SlotNo);
                m_pSAllDevLocDetails[u8BoardNo].u8ExpSlotNo = in_pSDevLocation[u8BoardNo].u8SlotNo;
            }
            else
            {
                m_pSAllDevLocDetails[u8BoardNo].u8ExpSlotNo = 0;
            }

            for(u8Loop = 0; u8Loop < u16NoOfBoards; u8Loop++)
            {
                if((m_pSAllDevLocDetails[u8BoardNo].u8SlotNo == in_pSDevLocation[u8Loop].u8SlotNo) && (m_pSAllDevLocDetails[u8BoardNo].u8BusNo ==  in_pSDevLocation[u8Loop].u8BusNo) && (m_pSAllDevLocDetails[u8BoardNo].u8FunctionNo == in_pSDevLocation[u8Loop].u8FunctionNo))
                {
                    m_pSAllDevLocDetails[u8BoardNo].s8BoardSts = DP_BORDS_STATUS_ONE;
                    break;
                }
            }
        }

        if(in_pSDevLocation == NULL)
        {
            m_u16NoOfBoards = m_u16NoOfDetBoards;
            for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfDetBoards); u8BoardNo++)
            {
                /* open the found boards */
                m_s32RetVal = DPcPCI3096_Open(&pSAllDevLocDetails[u8BoardNo], &m_hHandle[u8BoardNo]);
                if(m_s32RetVal != DP_LINS_3096_SUCCESS)
                {
                    DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    free(pSAllDevLocDetails);
                    return DP_LINS_3096_FAILURE;
                }
                out_pSDevLocation[u8BoardNo].s8BoardSts = DP_BORDS_STATUS_ONE;
                out_pSDevLocation[u8BoardNo].u8SlotNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8SlotNo;
                out_pSDevLocation[u8BoardNo].u8BusNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8BusNo;
                out_pSDevLocation[u8BoardNo].u8FunctionNo = pSAllDevLocDetails[u8BoardNo].u.pci.m_u8FunctionNo;
            }
        }
        else
        {
            m_u16NoOfBoards = 0;
            for(u8Loop = 0; u8Loop < u16NoOfBoards; u8Loop++)
            {
                for(u8BoardNo = 0; u8BoardNo < m_u16NoOfDetBoards; u8BoardNo++)
                {
                    if((pSAllDevLocDetails[u8BoardNo].u.pci.m_u8SlotNo == in_pSDevLocation[u8Loop].u8SlotNo) && (pSAllDevLocDetails[u8BoardNo].u.pci.m_u8BusNo ==  in_pSDevLocation[u8Loop].u8BusNo) && (pSAllDevLocDetails[u8BoardNo].u.pci.m_u8FunctionNo == in_pSDevLocation[u8Loop].u8FunctionNo))
                    {
                        m_u16NoOfBoards++;
                        out_pSDevLocation[u8Loop].s8BoardSts = DP_BORDS_STATUS_ONE;
                        break;
                    }
                }

                out_pSDevLocation[u8Loop].u8SlotNo = in_pSDevLocation[u8Loop].u8SlotNo;
                out_pSDevLocation[u8Loop].u8BusNo = in_pSDevLocation[u8Loop].u8BusNo;
                out_pSDevLocation[u8Loop].u8FunctionNo = in_pSDevLocation[u8Loop].u8FunctionNo;

                if(u8BoardNo == m_u16NoOfDetBoards)
                {
                    out_pSDevLocation[u8Loop].s8BoardSts = DP_BORDS_STATUS_ZERO;
                    continue;
                }

                m_s32RetVal = DPcPCI3096_Open(&pSAllDevLocDetails[u8BoardNo], &m_hHandle[u8Loop]);
                if(m_s32RetVal != DP_LINS_3096_SUCCESS)
                {
                    DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    return DP_LINS_3096_FAILURE;
                }
            }
        }
        free(pSAllDevLocDetails);

        return DP_LINS_3096_SUCCESS;
#endif
    }
}

/**************************************************************************
// Name						: Config
// Author					: 
// Global Variables affected			: 				 
// Created Date					: 17/02/2020
// Revision Date				:
// Reason for Revising				:
// Description					:This Function is used to config the 3096 CPCI Board
**************************************************************************/
S16BIT DPCPCI3096_Wrapper::Configure()
{
    U8BIT u8BoardNo = LINS_3096_INITIALIZE_0;
    U8BIT u8Loop = LINS_3096_INITIALIZE_0;
    U8BIT u8GroupNo = LINS_3096_INITIALIZE_0;
    U8BIT u8Mode = LINS_3096_DIP_CONFIG_EDGE_EVEMENT_MODE;
    U8BIT u8StrobeSel= LINS_3096_DIP_CONFIG_GROUP_STROBE_SEL;
    U8BIT u8SelfTestEnDis = LINS_3096_DIP_CONFIG_DIS_SELFTEST;

    if(/*m_cSimEnable*/0)
    {
        return DP_LINS_3096_SUCCESS;
    }
    else
    {
#ifdef _DRV3096_ENABLE

        for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfBoards); u8BoardNo++)
        {
            for(u8Loop = 0; u8Loop < DP_DIO_3096_MAX_GROUPS; u8Loop++)
            {
                u8GroupNo = (u8Loop + 1);

                m_s32RetVal = DPcPCI3096_ConfigMode(m_hHandle[u8BoardNo], u8GroupNo, u8Mode,u8StrobeSel, u8SelfTestEnDis);
                if(m_s32RetVal != DP_LINS_3096_SUCCESS)
                {
                    DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                    return DP_LINS_3096_FAILURE;
                }
            }
        }

        return DP_LINS_3096_SUCCESS;
#endif
    }
}
/**************************************************************************
// Name						: ReadInput
// Author					: 
// Global Variables affected			: 				 
// Created Date					: 
// Revision Date				:
// Reason for Revising				:
// Description					:This function is used to read the input of the specified channel
**************************************************************************/
S16BIT DPCPCI3096_Wrapper::ReadInput(U16BIT in_u16SignalId, PU8BIT out_pu8InpData)
{
    U16BIT  u16GroupData = LINS_3096_INITIALIZE_0;
    U8BIT u8GrpNum = LINS_3096_INITIALIZE_0;
    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    U8BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);

    if(CPCI3096_ValidateSignalID(in_u16SignalId) != DP_LINS_3096_SUCCESS)
    {
        strcpy(m_szErrorMsg, "Invalid Signal ID");
        return DP_LINS_3096_FAILURE;
    }

    if(/*m_cSimEnable*/0)
    {
        S_SIG_OPERATION SimOprn = {OPRN_TYPE_GET, SIG_TYPE_DI, in_u16SignalId, 0.0f, -1};
        int iRetVal = m_SimSocket.write((char *)&SimOprn,sizeof(S_SIG_OPERATION));
        m_SimSocket.waitForReadyRead(2000);
        iRetVal = m_SimSocket.read((char *)&SimOprn,sizeof(S_SIG_OPERATION));
        if(iRetVal > 0)
        {
            if(SimOprn.iStatus >=0)
            {
                *out_pu8InpData = (U8BIT)SimOprn.fSigvalue;
                return DP_LINS_3096_SUCCESS;
            }
            else
            {
                strcpy(m_szErrorMsg, "Invalid operation / signal ID");
                return DP_LINS_3096_FAILURE;
            }
        }
        else
        {
            strcpy(m_szErrorMsg, "Ethernet communication error");
            return DP_LINS_3096_FAILURE;
        }

    }
    else
    {
#ifdef _DRV3096_ENABLE

        u8GrpNum = (((u8ChannelNo - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1);
        u8BoardNo-=1;
        m_s32RetVal = DPcPCI3096_ReadbackInput(m_hHandle[u8BoardNo], u8GrpNum, DP_DIO_3096_ACTUAL_INPUT, &u16GroupData);
        if(m_s32RetVal != DP_LINS_3096_SUCCESS)
        {
            DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_3096_FAILURE;
        }
        //		*out_pu8InpData = ((u16GroupData >> (u8ChannelNo-1)) &  LINS_3096_DIP_BIT_POS_1);
        *out_pu8InpData = ((u16GroupData >> ((u8ChannelNo-1)-((u8GrpNum-1)*16))) &  LINS_3096_DIP_BIT_POS_1);
        /* data >> ((chn-1) - ((Grp-1)*16)))
                           * data  ---> data having 16 bits, means it has status of current group 16 channels
                           * chn-1 ---> channel index starts from 0
                           * Grp-1 ---> to get channel number 0 - 15 in that particular group
                            */

        return DP_LINS_3096_SUCCESS;
#endif
    }
}

/**************************************************************************
// Name						: ReadGroupInput
// Author					: 
// Global Variables affected			: 				 
// Created Date					: 
// Revision Date				:
// Reason for Revising				:
// Description					:This function is used to read the input of the specified group
**************************************************************************/
S16BIT DPCPCI3096_Wrapper::ReadGroupInput(U16BIT in_u16SignalId, PU16BIT out_pu16Data)
{
    U16BIT  u16GrpData = LINS_3096_INITIALIZE_0;
    U8BIT u8GrpNum = LINS_3096_INITIALIZE_0;
    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    U16BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);
    //U8BIT in_u8Groupsel = LINS_3096_DIP_CONFIG_GROUP_STROBE_SEL;
    //*out_pusData = 0;
    if(CPCI3096_ValidateSignalID(in_u16SignalId) != DP_LINS_3096_SUCCESS)
    {
        strcpy(m_szErrorMsg, "Invalid Signal ID");
        return DP_LINS_3096_FAILURE;
    }
    u8GrpNum = (((u8ChannelNo - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1);
    //u8ChannelNo = (((u8ChannelNo - 1) % LINS_3096_MAX_GRP_CHANNELS) + 1);
    u8BoardNo-=1;
#ifdef _DRV3096_ENABLE
    m_s32RetVal = DPcPCI3096_ReadbackInput(m_hHandle[u8BoardNo], u8GrpNum, DP_DIO_3096_ACTUAL_INPUT, &u16GrpData);
    if(m_s32RetVal != DP_LINS_3096_SUCCESS)
    {
        DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_3096_FAILURE;
    }
#endif
    //u16GrpData = (u16GrpData >> ((in_u8GrpNum-1) % 16)*16) & 0xFFFF;
    //*out_pu16Data = ((u16GrpData >> (u8ChannelNo-1)) & LINS_3078_DIP_BIT_POS_1);
    *out_pu16Data = u16GrpData;

    return DP_LINS_3096_SUCCESS;
}

/**************************************************************************
// Name					: ReadAllInput
// Author				: 
// Global Variables affected		: 				 
// Created Date				: 
// Revision Date			:
// Reason for Revising			:
// Description				:This function is used to read the input of the all groups
**************************************************************************/
S16BIT DPCPCI3096_Wrapper::ReadAllInput(U16BIT in_u16SignalId, U16BIT out_u16Data[3])
{
    U16BIT u16DIData = LINS_3096_INITIALIZE_0;
    U8BIT u8Loop = LINS_3096_INITIALIZE_0;
    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    U16BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);

#ifdef _DRV3096_ENABLE
    for(u8Loop = 0; u8Loop < DP_DIO_3096_MAX_GROUPS; u8Loop++)
    {
        m_s32RetVal = DPcPCI3096_ReadbackInput(m_hHandle[u8BoardNo], (u8Loop + 1), DP_DIO_3096_ACTUAL_INPUT, &u16DIData);
        if(m_s32RetVal != DP_LINS_3096_SUCCESS)
        {
            DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_3096_FAILURE;
        }
        //*out_pusData[u8Loop] = (u16DIData >> ((((u8Loop)%16) * 16)) & 0xFFFF);
        //out_u16Data[u8Loop] = (u16DIData >> ((((u8Loop)%16) * 16));
        out_u16Data[u8Loop] = u16DIData;
    }
#endif
    return DP_LINS_3096_SUCCESS;
}

/**************************************************************************
// Name						: SetOutput
// Author					: 
// Global Variables affected: 				 
// Created Date				: 
// Revision Date			:
// Reason for Revising		:
// Description				:This Function is used to write data into the specified output channel of 3096 CPCI Board
**************************************************************************/
S16BIT DPCPCI3096_Wrapper::SetOutput(U16BIT in_u16SignalId, U8BIT in_u8Data)
{
    U8BIT  u8ChannelStatus = LINS_3096_INITIALIZE_0;
    U8BIT u8GrpNum = LINS_3096_INITIALIZE_0;
    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    U8BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);

    u8GrpNum = (((u8ChannelNo - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1);
    //	u8ChannelNo = (((u8ChannelNo - 1) % LINS_3096_MAX_GRP_CHANNELS) + 1);
    u8BoardNo-=1;

    if(/*m_cSimEnable*/0)
    {
        S_SIG_OPERATION SimOprn = {OPRN_TYPE_SET, SIG_TYPE_DO, in_u16SignalId, in_u8Data, -1};
        int iRetVal = m_SimSocket.write((char *)&SimOprn,sizeof(S_SIG_OPERATION));
        m_SimSocket.waitForReadyRead(2000);
        iRetVal = m_SimSocket.read((char *)&SimOprn,sizeof(S_SIG_OPERATION));
        if(iRetVal > 0)
        {
            if(SimOprn.iStatus >=0)
            {
                return DP_LINS_3096_SUCCESS;
            }
            else
            {
                strcpy(m_szErrorMsg, "Invalid operation / signal ID");
                return DP_LINS_3096_FAILURE;
            }
        }
        else
        {
            strcpy(m_szErrorMsg, "Ethernet communication error");
            return DP_LINS_3096_FAILURE;
        }

    }
    else
    {
        if(in_u8Data)
        {
            u8ChannelStatus |= (1 << (u8ChannelNo-1));
        }
        else
        {

            u8ChannelStatus &= (~(1 << (u8ChannelNo-1)));
        }
        u8ChannelStatus = in_u8Data;
#ifdef _DRV3096_ENABLE
        m_s32RetVal = DPcPCI3096_WriteChannelData(m_hHandle[u8BoardNo], u8ChannelNo, u8ChannelStatus);
        if(m_s32RetVal != DP_LINS_3096_SUCCESS)
        {
            DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_3096_FAILURE;
        }
        //changed from DP_DIO_3096_ENABLE_OUTPUT to DP_DIO_3096_ACTUAL_INPUT /*changed by Manoj on 8th Feb 2022
        //due to realy status not able to read in bypass test case(change done by refering driver front panel application)*/
        m_s32RetVal = DPcPCI3096_Trigger(m_hHandle[u8BoardNo], u8GrpNum, DP_DIO_3096_ACTUAL_INPUT);
        if(m_s32RetVal != DP_LINS_3096_SUCCESS)
        {
            DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_3096_FAILURE;
        }
#endif
        return DP_LINS_3096_SUCCESS;
    }
}

/**************************************************************************
// Name						: SetGroupOutput
// Author					: 
// Global Variables affected			: 				 
// Created Date					: 
// Revision Date				:
// Reason for Revising				:
// Description					:This Function is used to write data into the specified  group of 3096 CPCI Board
**************************************************************************/
//S16BIT DPCPCI3096_Wrapper::SetGroupOutput(U16BIT in_u16SignalId, U8BIT in_u8Data)
S16BIT DPCPCI3096_Wrapper::SetGroupOutput(U16BIT in_u16SignalId, U16BIT in_u16Data)
{
    U16BIT  u16GrpData = LINS_3096_INITIALIZE_0;
    U8BIT u8GrpNum = LINS_3096_INITIALIZE_0;
    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    U8BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);
    U8BIT u8Groupsel = LINS_3096_DIP_CONFIG_GROUP_STROBE_SEL;

    u8GrpNum = (((u8ChannelNo - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1);
    //	u8ChannelNo = (((u8ChannelNo - 1) % LINS_3096_MAX_GRP_CHANNELS) + 1);
    u8BoardNo-=1;

    memset(&u16GrpData, in_u16Data, sizeof(u16GrpData));
#ifdef _DRV3096_ENABLE
    m_s32RetVal = DPcPCI3096_WriteGroupData(m_hHandle[u8BoardNo], u8GrpNum, u8Groupsel, u16GrpData);
    if(m_s32RetVal != DP_LINS_3096_SUCCESS)
    {
        DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_3096_FAILURE;
    }

    m_s32RetVal = DPcPCI3096_Trigger(m_hHandle[u8BoardNo], u8GrpNum, DP_DIO_3096_ENABLE_OUTPUT);
    if(m_s32RetVal != DP_LINS_3096_SUCCESS)
    {
        DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_3096_FAILURE;
    }
#endif
    return DP_LINS_3096_SUCCESS;
}

/**************************************************************************
// Name						: SetAllOutput
// Author					: 
// Global Variables affected: 				 
// Created Date				: 
// Revision Date			:
// Reason for Revising		:
// Description				:This Function is used to write data into the specified  All channels of 3096 CPCI Board
**************************************************************************/
//S16BIT DPCPCI3096_Wrapper::SetAllOutput(U16BIT in_u16SignalId, U8BIT in_u8Data)
S16BIT DPCPCI3096_Wrapper::SetAllOutput(U16BIT in_u16SignalId, U16BIT in_u16Data[3])
{
    U16BIT u16GrpData = LINS_3096_INITIALIZE_0;
    U8BIT  u8GrpNum = LINS_3096_INITIALIZE_0;
    U8BIT u8Loop = LINS_3096_INITIALIZE_0;
    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    //U8BIT in_u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);
    U16BIT in_u16Groupsel = LINS_3096_DIP_CONFIG_GROUP_STROBE_SEL;

    SDPCPCI3096_ALL_CHANNELS SWriteStsData;
    SDPCPCI3096_ALL_CHANNELS SWriteSelVal;

    //u8GrpNum = (((in_u8ChannelNo - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1);
    //in_u8ChannelNo = (((in_u8ChannelNo - 1) % LINS_3096_MAX_GRP_CHANNELS) + 1);


    if(CPCI3096_ValidateSignalID(in_u16SignalId) != DP_LINS_3096_SUCCESS)
    {
        strcpy(m_szErrorMsg, "Invalid Signal ID");
        return DP_LINS_3096_FAILURE;
    }


    for(u8Loop = 0; u8Loop < DP_DIO_3096_MAX_GROUPS; u8Loop++)
    {
        SWriteSelVal.m_u16ArrGroupVal[u8Loop] = 0xFFFF;
        SWriteStsData.m_u16ArrGroupVal[u8Loop] = in_u16Data[u8Loop];

    }
#ifdef _DRV3096_ENABLE
    m_s32RetVal = DPcPCI3096_WriteAllChannelData(m_hHandle[u8BoardNo], &SWriteSelVal, &SWriteStsData);
    if(m_s32RetVal != DP_LINS_3096_SUCCESS)
    {
        DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_3096_FAILURE;
    }
    m_s32RetVal = DPcPCI3096_BoardStrobe(m_hHandle[u8BoardNo]);
    if(m_s32RetVal != DP_LINS_3096_SUCCESS)
    {
        DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_3096_FAILURE;
    }
#endif
    return DP_LINS_3096_SUCCESS;
}
/**************************************************************************
// Name						: ReadbackOutput
// Author					: 
// Global Variables affected: 				 
// Created Date				: 22/02/2020
// Revision Date			:
// Reason for Revising		:
// Description				:This function is used to read back the specified channel output data
**************************************************************************/
S16BIT DPCPCI3096_Wrapper::ReadbackOutput(U16BIT in_u16SignalId, U8BIT in_u8PriSec, PU8BIT out_pu8Data)
{
    U16BIT u8GroupNo  = LINS_3096_INITIALIZE_0;
    U8BIT u8ChnSts  = LINS_3096_INITIALIZE_0;
    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    U16BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);

    if(CPCI3096_ValidateSignalID(in_u16SignalId) != DP_LINS_3096_SUCCESS)
    {
        strcpy(m_szErrorMsg, "Invalid Signal ID");
        return DP_LINS_3096_FAILURE;
    }

    if(/*m_cSimEnable*/0)
    {
        S_SIG_OPERATION SimOprn = {OPRN_TYPE_GET, SIG_TYPE_DO, in_u16SignalId, 0.0f, -1};
        int iRetVal = m_SimSocket.write((char *)&SimOprn,sizeof(S_SIG_OPERATION));
        m_SimSocket.waitForReadyRead(2000);
        iRetVal = m_SimSocket.read((char *)&SimOprn,sizeof(S_SIG_OPERATION));
        if(iRetVal > 0)
        {
            if(SimOprn.iStatus >=0)
            {
                *out_pu8Data  =SimOprn.fSigvalue;
                return DP_LINS_3096_SUCCESS;
            }
            else
            {
                strcpy(m_szErrorMsg, "Invalid operation / signal ID");
                return DP_LINS_3096_FAILURE;
            }
        }
        else
        {
            strcpy(m_szErrorMsg, "Ethernet communication error");
            return DP_LINS_3096_FAILURE;
        }

    }
    else
    {

        //u8GroupNo = (((u8ChannelNo - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1);
        //	u8ChannelNo = (((u8ChannelNo - 1) % LINS_3096_MAX_GRP_CHANNELS) + 1);
        u8BoardNo-=1;
#ifdef _DRV3096_ENABLE
        m_s32RetVal = DPcPCI3096_ReadChannelSts(m_hHandle[u8BoardNo], u8ChannelNo, in_u8PriSec, &u8ChnSts);
        if(m_s32RetVal != DP_LINS_3096_SUCCESS)
        {
            DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_3096_FAILURE;
        }
#endif
        *out_pu8Data = ((u8ChnSts) >> (u8ChannelNo-1)) & LINS_3096_DIP_BIT_POS_1;

        return DP_LINS_3096_SUCCESS;
    }
}
/**************************************************************************
// Name						: ReadbackGroupOutput
// Author					: 
// Global Variables affected: 				 
// Created Date				: 22/02/2020
// Revision Date			:
// Reason for Revising		:
// Description				:This function is used to read back the specified group output data
**************************************************************************/
S16BIT DPCPCI3096_Wrapper::ReadbackGroupOutput(U16BIT in_u16SignalId, U8BIT in_u8PriSec, PU16BIT out_pu16Data)
{
    U8BIT u8GrpNum  = LINS_3096_INITIALIZE_0;
    U16BIT u16GroupSts = LINS_3096_INITIALIZE_0;
    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    U16BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);
    //*out_pu16Data = 0;

    if(CPCI3096_ValidateSignalID(in_u16SignalId) != DP_LINS_3096_SUCCESS)
    {
        strcpy(m_szErrorMsg, "Invalid Signal ID");
        return DP_LINS_3096_FAILURE;
    }


    u8GrpNum = (((u8ChannelNo - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1);
    //	u8ChannelNo = (((u8ChannelNo - 1) % LINS_3096_MAX_GRP_CHANNELS) + 1);
    u8BoardNo-=1;
#ifdef _DRV3096_ENABLE
    m_s32RetVal = DPcPCI3096_ReadGroupChannelSts(m_hHandle[u8BoardNo], u8GrpNum,  in_u8PriSec, &u16GroupSts);
    if(m_s32RetVal != DP_LINS_3096_SUCCESS)
    {
        DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
        return DP_LINS_3096_FAILURE;
    }
#endif
    //*out_pu16Data = ((*out_pu16GroupSts) >> (u8ChannelNo-1)) & LINS_3096_DIP_BIT_POS_1;
    *out_pu16Data = u16GroupSts;


    return DP_LINS_3096_SUCCESS;
}
/**************************************************************************
// Name						: ReadbackAllOutput
// Author					: 
// Global Variables affected			: 				 
// Created Date					: 22/02/2020
// Revision Date				:
// Reason for Revising				:
// Description					:This function is used to read back the all output channels data
**************************************************************************/

S16BIT DPCPCI3096_Wrapper::ReadbackAllOutput(U16BIT in_u16SignalId, U8BIT in_u8PriSec, U16BIT out_u16Data[3])
{
    SDPCPCI3096_ALL_CHANNELS SAllRelaySts ;
    U8BIT u8GroupNo = LINS_3096_INITIALIZE_0;
    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    //U8BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);
    if(CPCI3096_ValidateSignalID(in_u16SignalId) != DP_LINS_3096_SUCCESS)
    {
        strcpy(m_szErrorMsg, "Invalid Signal ID");
        return DP_LINS_3096_FAILURE;
    }
#ifdef _DRV3096_ENABLE
    for(u8GroupNo = 0; u8GroupNo < DP_DIO_3096_MAX_GROUPS; u8GroupNo++)
    {
        m_s32RetVal = DPcPCI3096_ReadAllChannelSts(m_hHandle[u8BoardNo], in_u8PriSec, &SAllRelaySts);
        if(m_s32RetVal != DP_LINS_3096_SUCCESS)
        {
            DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
            return DP_LINS_3096_FAILURE;
        }
        //*out_pusData[u8Loop] = (usDIData >> ((((u8Loop)%16) * 16)) & 0xFFFF);
        out_u16Data[u8GroupNo] = SAllRelaySts.m_u16ArrGroupVal[u8GroupNo];
    }
#endif
    return DP_LINS_3096_SUCCESS;
}
/**************************************************************************
// Name						: Reset
// Author					: 
// Global Variables affected: 1
// Created Date				: 14/02/2020
// Revision Date			:
// Reason for Revising		:
// Description: This Function is used to reset the 3096 CPCI Board
**************************************************************************/
S16BIT DPCPCI3096_Wrapper::Reset(U16BIT in_u16BoardNo)
{
    U8BIT u8BoardNo = LINS_3096_INITIALIZE_0;
#ifdef _DRV3096_ENABLE
    if(in_u16BoardNo)
    {
        if (in_u16BoardNo >= 1 && in_u16BoardNo <= m_u16NoOfBoards)
        {
            m_s32RetVal = DPcPCI3096_Reset(&m_hHandle[in_u16BoardNo-1]);
            if(m_s32RetVal != DP_LINS_3096_SUCCESS)
            {
                DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_LINS_3096_FAILURE;
            }
        }
        else
        {
            sprintf(m_szErrorMsg, "Invalid Bord Number");
            return DP_LINS_3096_FAILURE;
        }
    }
    else{
        for(u8BoardNo = 0; u8BoardNo < (m_u16NoOfBoards); u8BoardNo++)
        {
            m_s32RetVal = DPcPCI3096_Reset(m_hHandle[u8BoardNo]);
            if(m_s32RetVal != DP_LINS_3096_SUCCESS)
            {
                DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_LINS_3096_FAILURE;
            }
        }
    }
#endif
    return DP_LINS_3096_SUCCESS;
}

/**************************************************************************
// Name						: Close
// Author					:
// Global Variables affected: 1				 
// Created Date				: 22/11/2010
// Revision Date			:
// Reason for Revising		:
// Description:This Function is used to Close the 3096 CPCI Board
**************************************************************************/
S16BIT DPCPCI3096_Wrapper::Close(U16BIT in_u16BoardNo)
{
    U8BIT u8BoardNo = LINS_3096_INITIALIZE_0;
#ifdef _DRV3096_ENABLE
    if(in_u16BoardNo)
    {
        if (in_u16BoardNo >= 1 && in_u16BoardNo <= m_u16NoOfBoards)
        {
            m_s32RetVal = DPcPCI3096_Close(&m_hHandle[in_u16BoardNo-1]);
            if(m_s32RetVal != DP_LINS_3096_SUCCESS)
            {
                DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_LINS_3096_FAILURE;
            }
        }
        else
        {
            sprintf(m_szErrorMsg, "Invalid Bord Number");
            return DP_LINS_3096_FAILURE;
        }
    }
    else{
        for(u8BoardNo = LINS_3096_INITIALIZE_0; u8BoardNo < m_u16NoOfBoards; u8BoardNo++)
        {
            m_s32RetVal = DPcPCI3096_Close(m_hHandle[u8BoardNo]);
            if(m_s32RetVal != DP_LINS_3096_SUCCESS)
            {
                DPcPCI3096_GetErrorMessage(m_s32RetVal, m_szErrorMsg, sizeof(m_szErrorMsg));
                return DP_LINS_3096_FAILURE;
            }
        }
    }
#endif
    return DP_LINS_3096_SUCCESS;
}
/**************************************************************************
// Name						: GetLastErrorMsg
// Author					: 
// Global Variables affected			: 				 
// Created Date					: 25/02/2020
// Revision Date				:
// Reason for Revising				:
// Description					:This Function is used to get last error message
**************************************************************************/
void DPCPCI3096_Wrapper::GetLastErrorMsg(PS32BIT out_ps32ErrCode, PS8BIT out_s8ErrMsg)
{
    if(out_s8ErrMsg != NULL)
    {
        sprintf(out_s8ErrMsg, "%s" , m_szErrorMsg);
    }
    if(out_ps32ErrCode != NULL)
    {
        *out_ps32ErrCode = m_s32RetVal;
    }
}

S16BIT DPCPCI3096_Wrapper::CPCI3096_ValidateSignalID(U16BIT in_u16SignalId)
{
    U8BIT u8BoardID = SID_GET_BOARD_ID(in_u16SignalId);
    U8BIT u8BoardNo = SID_GET_BOARD_NUM(in_u16SignalId);
    U8BIT u8ChannelNo = SID_GET_CHANNEL(in_u16SignalId);

    if(((u8BoardID != BRD_TYPE_CPCI3096_DI) && (u8BoardID != BRD_TYPE_CPCI3096_DI)) || \
            ((u8BoardNo < DP_DIO_3096_MIN_BOARDS) || (u8BoardNo > DP_DIO_3096_MAX_BOARDS)) || \
            ((u8ChannelNo < DP_DIO_3096_MIN_CHANNEL) || (u8ChannelNo > DP_DIO_3096_MAX_CHANNEL)))
    {
        strcpy(m_szErrorMsg, "Invalid Signal ID");
        return DP_LINS_3096_FAILURE;
    }
    return DP_LINS_3096_SUCCESS;
}
