#include "dp-lins-atp_testthread.h"
#include "dp-lins-atp_mainwindow.h"

unsigned short g_usDOChannel[3][4]= {{DO_PS1_C1_PWR,DO_PS1_C2_PWR,DO_PS1_DEMAG_PWR,DO_TC_PWR},\
                                     {DO_PS2_C1_PWR,DO_PS2_C2_PWR,DO_PS2_C3_PWR,DO_TC_PWR},\
                                     {DO_PS3_C1_PWR,DO_PS3_C2_PWR,DO_PS3_C3_PWR,DO_TC_PWR}};
unsigned short g_usDIChannel[3][4]= {{DI_PS1_C1_PWR_STS,DI_PS1_C2_PWR_STS,DI_PS1_DEMAG_PWR_STS,DI_TC_PWR_STS},\
                                     {DI_PS2_C1_PWR_STS,DI_PS2_C2_PWR_STS,DI_PS2_C3_PWR_STS,DI_TC_PWR_STS},\
                                     {DI_PS3_C1_PWR_STS,DI_PS3_C2_PWR_STS,DI_PS3_C3_PWR_STS,DI_TC_PWR_STS}};

unsigned short g_usAI_PSU [4]= {AI_PSO_PS1_V,AI_PSO_PS2_V,AI_PSO_PS3_V,AI_PSO_TC_V};

/*** Changed by Aravinth R **/

unsigned short g_usAI_PSUChVolt[4][3]= {{AI_PKG_PS1_C1_V,AI_PKG_PS1_C2_V,AI_PKG_PS1_SP1_V},\
                                        {AI_PKG_PS2_C1_V,AI_PKG_PS2_C2_V,AI_PKG_PS2_SP2_V},\
                                        {AI_PKG_PS3_C1_V,AI_PKG_PS3_C2_V,AI_PKG_PS3_DEMAG_V},
                                        {AI_PKG_TC1_V,AI_PKG_TC2_V,AI_PKG_TC3_V}};

unsigned short g_usAI_PSUChCurr[3][3]= {{AI_PKG_PS1_C1_C,AI_PKG_PS1_C2_C,AI_PKG_PS1_SP1_C},\
                                        {AI_PKG_PS2_C1_C,AI_PKG_PS2_C2_C,AI_PKG_PS2_SP2_C},\
                                        {AI_PKG_PS3_C1_C,AI_PKG_PS3_C2_C,AI_PKG_PS3_DEMAG_C}};

/****************************/

unsigned short g_usTC_DOCh[32]={DO_TC_S1_BAT1_SEL, DO_TC_S1_BAT2_SEL, DO_TC_S4_BAT1_SEL, DO_TC_S4_BAT2_SEL,\
                                DO_TC_LCE1_BAT1_SEL, DO_TC_LCE1_BAT2_SEL, DO_TC_S3_BAT2_SEL, DO_TC_S3_BAT3_SEL,\
                                DO_TC_S6_BAT2_SEL, DO_TC_S6_BAT3_SEL, DO_TC_LCE2_BAT2_SEL, DO_TC_LCE2_BAT3_SEL,\
                                DO_TC_S5_BAT3_SEL, DO_TC_S5_BAT1_SEL, DO_TC_S2_BAT3_SEL, DO_TC_S2_BAT1_SEL,\
                                DO_TC_LCE3_BAT3_SEL, DO_TC_LCE3_BAT1_SEL, DO_TC_LCE1_ON, DO_TC_LCE1_OFF,\
                                DO_TC_LCE2_ON, DO_TC_LCE2_OFF, DO_TC_LCE3_ON, DO_TC_LCE3_OFF, DO_TC_LCE1_RESET,\
                                DO_TC_LCE2_RESET, DO_TC_LCE3_RESET, DO_TC_DEMAG_ON, DO_TC_DEMAG_OFF,\
                                DO_TC_SPARE1,DO_TC_SPARE2,DO_TC_SPARE3};

unsigned short g_usTC_DICh[18]={DI_TC_S1_BAT1_SEL_STS,DI_TC_S1_BAT2_SEL_STS,DI_TC_S4_BAT1_SEL_STS,\
                                DI_TC_S4_BAT2_SEL_STS,DI_TC_LCE1_BAT1_SEL_STS,DI_TC_LCE1_BAT2_SEL_STS,\
                                DI_TC_S3_BAT2_SEL_STS,DI_TC_S3_BAT3_SEL_STS,DI_TC_S6_BAT2_SEL_STS,\
                                DI_TC_S6_BAT3_SEL_STS,DI_TC_LCE2_BAT2_SEL_STS,DI_TC_LCE2_BAT3_SEL_STS,\
                                DI_TC_S5_BAT3_SEL_STS,DI_TC_S5_BAT1_SEL_STS,DI_TC_S2_BAT3_SEL_STS,\
                                DI_TC_S2_BAT1_SEL_STS,DI_TC_LCE3_BAT3_SEL_STS,DI_TC_LCE3_BAT1_SEL_STS};

unsigned short g_usThremisterChn[3][4]={{TH_BRD1_CH1, TH_BRD1_CH2, TH_BRD1_CH3, TH_BRD2_CH1},
                                        {TH_BRD2_CH2, TH_BRD2_CH3, TH_BRD3_CH1, TH_BRD3_CH2},
                                        {TH_BRD3_CH3, TH_BRD4_CH1, TH_BRD4_CH2, TH_BRD4_CH3}};

unsigned short g_usTC_SpareDOCh[16] ={DO_TC_SPARE4, DO_TC_SPARE5, DO_TC_SPARE6, DO_TC_SPARE7, DO_TC_SPARE8, \
                                      DO_TC_SPARE9, DO_TC_SPARE10, DO_TC_SPARE11, DO_TC_SPARE12, DO_TC_SPARE13, \
                                      DO_TC_SPARE14, DO_TC_SPARE15, DO_TC_SPARE16, DO_TC_SPARE17, DO_TC_SPARE18, DO_TC_SPARE19};

unsigned short g_usTC_SpareDICh[30] = {DI_TC_LCE1_ON_STS, DI_TC_LCE1_OFF_STS, DI_TC_LCE2_ON_STS, \
                                       DI_TC_LCE2_OFF_STS, DI_TC_LCE3_ON_STS, DI_TC_LCE3_OFF_STS, \
                                       DI_TC_LCE1_RESET_STS, DI_TC_LCE2_RESET_STS, DI_TC_LCE3_RESET_STS, \
                                       DI_TC_DEMAG_ON_STS, DI_TC_DEMAG_OFF_STS, DI_TC_SPARE1, \
                                       DI_TC_SPARE2, DI_TC_SPARE3, DI_TC_SPARE4, DI_TC_SPARE5, DI_TC_SPARE6, \
                                       DI_TC_SPARE7, DI_TC_SPARE8, DI_TC_SPARE9, DI_TC_SPARE10, DI_TC_SPARE11, \
                                       DI_TC_SPARE12, DI_TC_SPARE13, DI_TC_SPARE14, DI_TC_SPARE15, DI_TC_SPARE16, \
                                       DI_TC_SPARE17, DI_TC_SPARE18, DI_TC_SPARE19};

unsigned short g_usPSU_PinOut_DICh[22]={DI_TC_S1_BAT1_SEL_STS,DI_TC_S1_BAT2_SEL_STS,DI_TC_S4_BAT1_SEL_STS,\
                                        DI_TC_S4_BAT2_SEL_STS,DI_TC_LCE1_BAT1_SEL_STS,DI_TC_LCE1_BAT2_SEL_STS,\
                                        DI_TC_S3_BAT2_SEL_STS,DI_TC_S3_BAT3_SEL_STS,DI_TC_S6_BAT2_SEL_STS,\
                                        DI_TC_S6_BAT3_SEL_STS,DI_TC_LCE3_BAT3_SEL_STS,DI_TC_LCE3_BAT1_SEL_STS,\
                                        DI_TC_SPARE4,DI_TC_SPARE5,DI_TC_SPARE6,DI_TC_SPARE7};

unsigned short g_usTC_StsReadback_DICh[22]={DI_TC_LCE1_ON_STS, DI_TC_LCE1_OFF_STS, DI_TC_LCE2_ON_STS, DI_TC_LCE2_OFF_STS, \
                                            DI_TC_LCE3_ON_STS, DI_TC_LCE3_OFF_STS, DI_TC_LCE1_RESET_STS, \
                                            DI_TC_LCE2_RESET_STS, DI_TC_LCE3_RESET_STS, DI_TC_DEMAG_ON_STS, \
                                            DI_TC_DEMAG_OFF_STS, DI_TC_SPARE1, DI_TC_SPARE2, DI_TC_SPARE3};


void CTestThread::DP_LINS_PowerControlTest(int in_iPSUIdx, int in_iChIdx, int* out_piStatus)
{
    QString qsErrorDesc = "", qsPSUError = "";
    unsigned char ucDIOSts[3] = {0};
    float fLoadVolt[3] = {0.0f};
    float fLoadCurr[3] = {0.0f};
    float f232Volt = 0.0f;
    float f232Curr = 0.0f;
    float fADCVolt = 0.0f;

    float fPSUVolt = 0.0f;
    float fPSUCurr = 0.0f;
    float fPSU_UV = 0.0f;
    float fPSU_OV = 0.0f;

    bool bResult = true, bPrevState = false, bTestSts = true, bRelRes = true, bLEDsts = true;

    float fCompLoadCurr = 0.0f;

    int iTestResult = 0x01;
    int iRetval = 0;
    int iChainIdx = 0;

    *out_piStatus = LINS_TEST_FAIL;

    memset(&m_SReportData.UTestData, 0, sizeof(m_SReportData.UTestData));

    bPrevState = bResult;
    for(iChainIdx = 0; iChainIdx < 3; iChainIdx++)
    {
        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;
            iRetval = m_p3096Wrapper->SetOutput(g_usDOChannel[in_iPSUIdx][iChainIdx],DIO_DISABLE);
            if (iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : Unable to set Relay Status", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if(m_bPauseOnFailure)
                {
                    m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usDOChannel[in_iPSUIdx][iChainIdx]), (((SID_GET_CHANNEL(g_usDOChannel[in_iPSUIdx][iChainIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usDOChannel[in_iPSUIdx][iChainIdx])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : Set Relay Status Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);
    }

    /*************************************************************************************************/
    /* Power Interface Validation @ 28V and 42V */
    for(iChainIdx = 0; iChainIdx < 3; iChainIdx++)
    {
        /*Verify all the Relay Channel are OFF*/
        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;

            iRetval = m_p3096Wrapper->ReadInput(g_usDIChannel[in_iPSUIdx][iChainIdx],&ucDIOSts[iChainIdx]);
            if (iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : Unable to Read Relay Status", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usDIChannel[in_iPSUIdx][iChainIdx]), (((SID_GET_CHANNEL(g_usDIChannel[in_iPSUIdx][iChainIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usDIChannel[in_iPSUIdx][iChainIdx])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : Read Relay Status Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if(m_bRetryOnFailure)
                        bResult = bPrevState;
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            if(ucDIOSts[iChainIdx] != 1)
            {
                iTestResult = LINS_TEST_FAIL;
            }
        } while(m_bRetryOnFailure);
    }

    for(int iIttrCnt = 0; iIttrCnt < 2; iIttrCnt++)
    {
        // Configuring the PSU Configuration values
        fPSUVolt = (iIttrCnt == 0)? m_SPSUConfig[in_iPSUIdx].m_fNominalVolt : m_SPSUConfig[in_iPSUIdx].m_fMaxVolt;
        fPSUCurr = m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit;
        fPSU_UV = m_SPSUConfig[in_iPSUIdx].m_fUnderVolt;
        fPSU_OV = m_SPSUConfig[in_iPSUIdx].m_fOverVolt;

        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;

            iRetval = m_obj_CPSUWrapper->DP_PSU_VoltCurrConfig(DP_PSU_DAISY_CHAIN_MODE, fPSUVolt, fPSUCurr, in_iPSUIdx+1);
            if (iRetval)
            {

                qsErrorDesc.sprintf("PSU%d : PSU Configuration failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                    qsErrorDesc.sprintf("%s - Configured Value for Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSUVolt, fPSUCurr, iRetval, qsPSUError.toLatin1().data());
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : Configuration Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);

        msleep(DP_PSU_RESTTIME);

        if(iIttrCnt == 0)
        {
            //Configure Over Voltage and Under Voltage
            do
            {
                iTestResult = 0x01;
                m_bRetryOnFailure = false;

                iRetval = m_obj_CPSUWrapper->DP_PSU_OV_UV_Config(fPSU_OV, fPSU_UV, in_iPSUIdx+1);
                if (iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Over Voltage - Under Voltage Configuration failed", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                        qsErrorDesc.sprintf("%s - Configured Over Voltage: %.2f, Under Voltage: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSU_OV, fPSU_UV, iRetval, qsPSUError.toLatin1().data());
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : Configuration Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
            } while(m_bRetryOnFailure);

            msleep(DP_PSU_RESTTIME);

            //Enable PSU out
            do
            {
                iTestResult = 0x01;
                m_bRetryOnFailure = false;

                iRetval = m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_DAISY_CHAIN_MODE, DP_PSU_OUTPUT_ON, (in_iPSUIdx+1));

                if (iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU PSU Output failed", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                        qsErrorDesc.sprintf("%s - Configured Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), m_SPSUConfig[in_iPSUIdx].m_fMaxVolt, m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit, iRetval, qsPSUError.toLatin1().data());
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : Configuration Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
            } while(m_bRetryOnFailure);

            msleep(DP_PSU_RESTTIME);
        }

        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;

            iRetval = m_obj_CPSUWrapper->DP_PSU_Measure_Ouput(&f232Volt, &f232Curr, in_iPSUIdx+1);
            if (iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : PSU Measure Output failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                    qsErrorDesc += qsPSUError;
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : Configuration Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);

        msleep(DP_PSU_RESTTIME);

        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;

            iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSU[in_iPSUIdx], 1, &fADCVolt, DP_MM_1105_AVERAGE);
            if (iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC Read Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bRetryOnFailure)
                    {
                        continue;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }

            if((fADCVolt > (f232Volt + TEST_COSPSU_TOL_VOLT)) || (fADCVolt < (f232Volt - TEST_COSPSU_TOL_VOLT)))
            {
                m_bRetryOnFailure = false;
                qsErrorDesc.sprintf ("PSU%d : Board %d Channel %d - Expected : %.2fV  Read : %.2fV", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), f232Volt, fADCVolt);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : Voltage Read sampling skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                }
            }

        } while(m_bRetryOnFailure);
        msleep(DP_PSU_RESTTIME);

        /* Voltage and Current Output Validation*/
        for(iChainIdx = 0; iChainIdx < 3; iChainIdx++)
        {
            /*Read PSU Chain Voltage*/
            do
            {
                m_bRetryOnFailure = false;
                iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSUChVolt[in_iPSUIdx][iChainIdx], 1, &fLoadVolt[iChainIdx], 1);
                if (iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                        qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), iRetval, m_errString);
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC Read skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bRetryOnFailure)
                        {
                            continue;
                        }
                    }
                }

                if (fLoadVolt[iChainIdx] > 1.0)
                {
                    m_bRetryOnFailure = false;
                    qsErrorDesc.sprintf ("PSU%d : Board %d Channel %d - Expected : 0V  Read : %.2fV", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), fLoadVolt[iChainIdx]);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);

                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC Read Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
            } while(m_bRetryOnFailure);
            msleep(DP_PSU_RESTTIME);

            /*Read PSU Chain Current*/
            do
            {
                m_bRetryOnFailure = false;
                iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSUChCurr[in_iPSUIdx][iChainIdx], 1, &fLoadCurr[iChainIdx], 1);
                if (iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                        qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSUChCurr[in_iPSUIdx][iChainIdx]), SID_GET_CHANNEL(g_usAI_PSUChCurr[in_iPSUIdx][iChainIdx]), iRetval, m_errString);
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : PSU Current ADC Read skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bRetryOnFailure)
                        {
                            continue;
                        }
                    }
                }

                if (fLoadCurr[iChainIdx] > 0.5)
                {
                    m_bRetryOnFailure = false;
                    qsErrorDesc.sprintf ("PSU%d : Board %d Channel %d - Expected : 0A  Read : %.2fA", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSUChCurr[in_iPSUIdx][iChainIdx]), SID_GET_CHANNEL(g_usAI_PSUChCurr[in_iPSUIdx][iChainIdx]), fLoadCurr[iChainIdx]);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);

                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC Read Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
            } while(m_bRetryOnFailure);
            msleep(DP_PSU_RESTTIME);
        }

        m_SReportData.UTestData.SPsuData.m_fConfigVolt     = fPSUVolt;
        m_SReportData.UTestData.SPsuData.m_fPSU232Volt     = f232Volt;
        m_SReportData.UTestData.SPsuData.m_fPSUADCVolt     = fADCVolt;
        m_SReportData.UTestData.SPsuData.m_ucExpRelaySts   = LINSCM_ENABLE;
        m_SReportData.UTestData.SPsuData.m_ucRelayStatus   = ucDIOSts[in_iChIdx];
        m_SReportData.m_iLoadStatus                       = m_bPSU_LoadSelect[in_iPSUIdx];
        m_SReportData.UTestData.SPsuData.m_fLoadVolt1      = fLoadVolt[0];
        m_SReportData.UTestData.SPsuData.m_fLoadVolt2      = fLoadVolt[1];
        m_SReportData.UTestData.SPsuData.m_fLoadVolt3      = fLoadVolt[2];
        m_SReportData.UTestData.SPsuData.m_ucCurrLimitNA   = m_bPSU_LoadSelect[in_iPSUIdx] ? 0:1;
        m_SReportData.UTestData.SPsuData.m_fExpMinCurr    = DP_PSU_CURRENT_ON_ADC(f232Volt) - 0.1;
        m_SReportData.UTestData.SPsuData.m_fExpMaxCurr    = DP_PSU_CURRENT_ON_ADC(f232Volt) + 0.1;
        m_SReportData.UTestData.SPsuData.m_fPSU232Curr     = f232Curr;
        m_SReportData.UTestData.SPsuData.m_fLoadCurr1      = fLoadCurr[0];
        m_SReportData.UTestData.SPsuData.m_fLoadCurr2      = fLoadCurr[1];
        m_SReportData.UTestData.SPsuData.m_fLoadCurr3      = fLoadCurr[2];
        m_SReportData.m_iTestResult                       = iTestResult;
        reportUpdateTable(m_SReportData);
        logTestData(m_SReportData);

        if(iTestResult == 0)
        {
            qDebug()<<"PSU Power Interface Test:: PSU-OP = " << fADCVolt <<"V";
            *out_piStatus = iTestResult;
            return;
        }
    }

    /*************************************************************************************************/
    /* Power Output Validation @28V */
    fPSUVolt = m_SPSUConfig[in_iPSUIdx].m_fNominalVolt;
    fPSUCurr = m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit;

    do
    {
        iTestResult = 0x01;
        m_bRetryOnFailure = false;

        iRetval = m_obj_CPSUWrapper->DP_PSU_VoltCurrConfig(DP_PSU_DAISY_CHAIN_MODE, fPSUVolt, fPSUCurr, in_iPSUIdx+1);
        if (iRetval)
        {

            qsErrorDesc.sprintf("PSU%d : PSU Voltage-Current Configuration failed", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Value for Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSUVolt, fPSUCurr, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : Configuration Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
        msleep(DP_PSU_RESTTIME);
    }while(m_bRetryOnFailure);

    /*Set Relay Output*/
    do
    {
        iTestResult = 0x01;
        m_bRetryOnFailure = false;
        iRetval = m_p3096Wrapper->SetOutput(g_usDOChannel[in_iPSUIdx][in_iChIdx],DIO_ENABLE);
        if (iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : Unable to set Relay Status", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usDOChannel[in_iPSUIdx][iChainIdx]), (((SID_GET_CHANNEL(g_usDOChannel[in_iPSUIdx][iChainIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usDOChannel[in_iPSUIdx][iChainIdx])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : Set Relay Status Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while (m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    /* Relay Output Validation*/
    for(iChainIdx = 0; iChainIdx < 3; iChainIdx++)
    {
        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;
            iRetval = m_p3096Wrapper->ReadInput(g_usDIChannel[in_iPSUIdx][iChainIdx],&ucDIOSts[iChainIdx]);
            if(iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : Unable to Read Relay Status", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usDIChannel[in_iPSUIdx][iChainIdx]), (((SID_GET_CHANNEL(g_usDIChannel[in_iPSUIdx][iChainIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usDIChannel[in_iPSUIdx][iChainIdx])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : Read Relay Status Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bRetryOnFailure)
                    {
                        continue;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }

            if((iChainIdx == in_iChIdx) && (ucDIOSts[iChainIdx] != 0))
            {
                qDebug("%d, %d, %d",iChainIdx, in_iChIdx, ucDIOSts[iChainIdx]);
            }

            if(((iChainIdx == in_iChIdx) && (ucDIOSts[iChainIdx] != 0))|| \
                    ((iChainIdx != in_iChIdx) && (ucDIOSts[iChainIdx] != 1)))
            {
                iTestResult = 0x01;
                qsErrorDesc.sprintf("PSU%d : Exp = %d , Obj = %d", (in_iPSUIdx + 1), !ucDIOSts[iChainIdx], ucDIOSts[iChainIdx]);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : Board %d Group %d Channel %d - Exp = %d, Obj = %d", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usDIChannel[in_iPSUIdx][iChainIdx]), (((SID_GET_CHANNEL(g_usDIChannel[in_iPSUIdx][iChainIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usDIChannel[in_iPSUIdx][iChainIdx])) % LINS_3096_MAX_GRP_CHANNELS), !ucDIOSts[iChainIdx], ucDIOSts[iChainIdx]);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : Read Relay Status Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);
    }

    /*************************************************************************************************/
    /* Power Output Validation from 22V to 36V */
    for(float fSetVolt = m_SPSUConfig[in_iPSUIdx].m_fTestStartRange; fSetVolt < m_SPSUConfig[in_iPSUIdx].m_fTestStopRange; fSetVolt += m_SPSUConfig[in_iPSUIdx].m_fStepupRange)
    {
        fPSUVolt = fSetVolt;
        fPSUCurr = m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit;

        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;
            iRetval = m_obj_CPSUWrapper->DP_PSU_VoltCurrConfig(DP_PSU_DAISY_CHAIN_MODE, fPSUVolt, fPSUCurr, in_iPSUIdx+1);
            if (iRetval)
            {

                qsErrorDesc.sprintf("PSU%d : Voltage Current Configuration Failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                    qsErrorDesc.sprintf("%s - Configured Value for Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSUVolt, fPSUCurr, iRetval, qsPSUError.toLatin1().data());
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : Voltage Current Configuration Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);
        msleep(DP_PSU_RESTTIME);

        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;

            iRetval = m_obj_CPSUWrapper->DP_PSU_Measure_Ouput(&f232Volt, &f232Curr, in_iPSUIdx+1);
            if (iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : Unable to Measure PSU Output", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                    qsErrorDesc += qsPSUError;
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : PSU Measure output Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);
        msleep(DP_PSU_RESTTIME);

        /*Read PSU Volatge*/
        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;
            iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSU[in_iPSUIdx], 1, &fADCVolt, 1);
            if (iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC Read Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bRetryOnFailure)
                    {
                        continue;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            if((fADCVolt > (f232Volt + TEST_COSPSU_TOL_VOLT)) || (fADCVolt < (f232Volt - TEST_COSPSU_TOL_VOLT)))
            {
                iTestResult = 0x01;
                m_bRetryOnFailure = false;
                qsErrorDesc.sprintf ("PSU%d : Board %d Channel %d - Expected : %.2fV  Read : %.2fV", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), f232Volt, fADCVolt);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf( "PSU%d : PSU Voltage ADC Read Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                }
            }
        } while(m_bRetryOnFailure);

        /* Voltage and Current Output Validation*/
        for(iChainIdx = 0; iChainIdx < 3; iChainIdx++)
        {
            /*Read PSU Chain Voltage*/
            do
            {
                iTestResult = 0x01;
                m_bRetryOnFailure = false;
                iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSUChVolt[in_iPSUIdx][iChainIdx], 1, &fLoadVolt[iChainIdx], 1);
                if (iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                        qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), iRetval, m_errString);
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC Read Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bRetryOnFailure)
                        {
                            continue;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }

                if(((iChainIdx == in_iChIdx) && ((fLoadVolt[iChainIdx] > (fADCVolt+TEST_COSPSU_TOL_VOLT)) || (fLoadVolt[iChainIdx] < (fADCVolt-TEST_COSPSU_TOL_VOLT)))) ||\
                        ((iChainIdx != in_iChIdx) && (fLoadVolt[iChainIdx] > 1.0)))
                {
                    iTestResult = 0x01;
                    m_bRetryOnFailure = false;
                    qsErrorDesc.sprintf ("PSU%d : Board %d Channel %d - Expected : %.2fV  Read : %.2fV", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), fADCVolt, fLoadVolt[iChainIdx]);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ( "Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf( "PSU%d : PSU Voltage ADC Read Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                    }
                }
            } while(m_bRetryOnFailure);

            /*Read PSU Chain Current*/
            do
            {
                iTestResult = 0x01;
                m_bRetryOnFailure = false;
                iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSUChCurr[in_iPSUIdx][iChainIdx], 1, &fLoadCurr[iChainIdx], 1);
                if (iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                        qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), iRetval, m_errString);
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ( "Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : PSU Current ADC Read Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bRetryOnFailure)
                        {
                            continue;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }

                if(m_bPSU_LoadSelect[in_iPSUIdx])
                {
                    fCompLoadCurr = DP_PSU_CURRENT_ON_ADC(f232Volt);
                }
                else
                {
                    fCompLoadCurr = 0.0f;
                }

                if(((iChainIdx == in_iChIdx) && ((fLoadCurr[iChainIdx] > (fCompLoadCurr+0.1)) || (fLoadCurr[iChainIdx] < (fCompLoadCurr-0.1)))) ||\
                        ((iChainIdx != in_iChIdx) && (fLoadCurr[iChainIdx] > 0.1)))
                {
                    iTestResult = 0x01;
                    m_bRetryOnFailure = false;
                    qsErrorDesc.sprintf ("PSU%d : Board %d Channel %d - Expected : %.2fA  Read : %.2fA", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), fCompLoadCurr, fLoadCurr[iChainIdx]);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : PSU Current ADC Read Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
            } while(m_bRetryOnFailure);
        }

        m_SReportData.UTestData.SPsuData.m_fConfigVolt     = fPSUVolt;
        m_SReportData.UTestData.SPsuData.m_fPSU232Volt     = f232Volt;
        m_SReportData.UTestData.SPsuData.m_fPSUADCVolt     = fADCVolt;
        m_SReportData.UTestData.SPsuData.m_ucExpRelaySts   = LINSCM_DISABLE;
        m_SReportData.UTestData.SPsuData.m_ucRelayStatus   = ucDIOSts[in_iChIdx];
        m_SReportData.m_iLoadStatus                       = m_bPSU_LoadSelect[in_iPSUIdx];
        m_SReportData.UTestData.SPsuData.m_fLoadVolt1      = fLoadVolt[0];
        m_SReportData.UTestData.SPsuData.m_fLoadVolt2      = fLoadVolt[1];
        m_SReportData.UTestData.SPsuData.m_fLoadVolt3      = fLoadVolt[2];
        m_SReportData.UTestData.SPsuData.m_ucCurrLimitNA   = m_bPSU_LoadSelect[in_iPSUIdx] ? 0:1;
        m_SReportData.UTestData.SPsuData.m_fExpMinCurr    = DP_PSU_CURRENT_ON_ADC(f232Volt) - 0.1;
        m_SReportData.UTestData.SPsuData.m_fExpMaxCurr    = DP_PSU_CURRENT_ON_ADC(f232Volt) + 0.1;
        m_SReportData.UTestData.SPsuData.m_fPSU232Curr     = f232Curr;
        m_SReportData.UTestData.SPsuData.m_fLoadCurr1      = fLoadCurr[0];
        m_SReportData.UTestData.SPsuData.m_fLoadCurr2      = fLoadCurr[1];
        m_SReportData.UTestData.SPsuData.m_fLoadCurr3      = fLoadCurr[2];
        m_SReportData.m_iTestResult                       = iTestResult;
        reportUpdateTable(m_SReportData);
        logTestData(m_SReportData);

        if(iTestResult == 0)
        {
            qDebug()<<"PSU Power Variation Test:: " << fPSUVolt <<"V";
            *out_piStatus = iTestResult;
            return;
        }
    }

    /*************************************************************************************************/
    /*Set Relay Output Disable*/
    do
    {
        iTestResult = 0x01;
        iRetval = m_p3096Wrapper->SetOutput(g_usDOChannel[in_iPSUIdx][in_iChIdx],DIO_DISABLE);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU-%d : Unable to set Relay status", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usDOChannel[in_iPSUIdx][in_iChIdx]), (((SID_GET_CHANNEL(g_usDOChannel[in_iPSUIdx][in_iChIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usDOChannel[in_iPSUIdx][in_iChIdx])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Set Relay Status Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    for(iChainIdx = 0; iChainIdx < 3; iChainIdx++)
    {
        /*Verify all the Relay Channel are OFF*/
        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;

            iRetval = m_p3096Wrapper->ReadInput(g_usDIChannel[in_iPSUIdx][iChainIdx],&ucDIOSts[iChainIdx]);
            if (iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : Unable to Read Relay Status", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usDIChannel[in_iPSUIdx][iChainIdx]), (((SID_GET_CHANNEL(g_usDIChannel[in_iPSUIdx][iChainIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usDIChannel[in_iPSUIdx][iChainIdx])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : Read Relay Status Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if(m_bRetryOnFailure)
                        bResult = bPrevState;
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            if(ucDIOSts[iChainIdx] != 1)
            {
                iTestResult = LINS_TEST_FAIL;
            }
        } while(m_bRetryOnFailure);
    }

    do
    {
        iTestResult = 0x01;
        m_bRetryOnFailure = false;

        iRetval = m_obj_CPSUWrapper->DP_PSU_Measure_Ouput(&f232Volt, &f232Curr, in_iPSUIdx+1);
        if (iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU Measure Output failed", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc += qsPSUError;
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : Configuration Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);

    /* Voltage Output Validation*/
    for(iChainIdx = 0; iChainIdx < 3; iChainIdx++)
    {
        /*Read PSU Chain Voltage*/
        do
        {
            iTestResult = 0x01;
            iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSUChVolt[in_iPSUIdx][iChainIdx], 1, &fLoadVolt[iChainIdx], 1);
            if(iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC read Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            if(fLoadVolt[iChainIdx] > 1.0)
            {
                iTestResult = 0x01;
                m_bRetryOnFailure = false;
                qsErrorDesc.sprintf ("PSU%d : Board %d Channel %d - Expected : 0V  Read : %.2fV", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), fLoadVolt[iChainIdx]);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC read Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);

        /*Read PSU Chain Current*/
        do
        {
            m_bRetryOnFailure = false;
            iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSUChCurr[in_iPSUIdx][iChainIdx], 1, &fLoadCurr[iChainIdx], 1);
            if (iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSUChCurr[in_iPSUIdx][iChainIdx]), SID_GET_CHANNEL(g_usAI_PSUChCurr[in_iPSUIdx][iChainIdx]), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : PSU Current ADC Read skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bRetryOnFailure)
                    {
                        continue;
                    }
                }
            }

            if (fLoadCurr[iChainIdx] > 0.5)
            {
                m_bRetryOnFailure = false;
                qsErrorDesc.sprintf ("PSU%d : Board %d Channel %d - Expected : 0A  Read : %.2fA", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSUChCurr[in_iPSUIdx][iChainIdx]), SID_GET_CHANNEL(g_usAI_PSUChCurr[in_iPSUIdx][iChainIdx]), fLoadCurr[iChainIdx]);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);

                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC Read Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);
    }
    msleep(DP_PSU_RESTTIME);

    m_SReportData.UTestData.SPsuData.m_fConfigVolt     = fPSUVolt;
    m_SReportData.UTestData.SPsuData.m_fPSU232Volt     = f232Volt;
    m_SReportData.UTestData.SPsuData.m_fPSUADCVolt     = fADCVolt;
    m_SReportData.UTestData.SPsuData.m_ucExpRelaySts   = LINSCM_ENABLE;
    m_SReportData.UTestData.SPsuData.m_ucRelayStatus   = ucDIOSts[in_iChIdx];
    m_SReportData.m_iLoadStatus                       = m_bPSU_LoadSelect[in_iPSUIdx];
    m_SReportData.UTestData.SPsuData.m_fLoadVolt1      = fLoadVolt[0];
    m_SReportData.UTestData.SPsuData.m_fLoadVolt2      = fLoadVolt[1];
    m_SReportData.UTestData.SPsuData.m_fLoadVolt3      = fLoadVolt[2];
    m_SReportData.UTestData.SPsuData.m_ucCurrLimitNA   = m_bPSU_LoadSelect[in_iPSUIdx] ? 0:1;
    m_SReportData.UTestData.SPsuData.m_fExpMinCurr    = DP_PSU_CURRENT_ON_ADC(f232Volt) - 0.1;
    m_SReportData.UTestData.SPsuData.m_fExpMaxCurr    = DP_PSU_CURRENT_ON_ADC(f232Volt) + 0.1;
    m_SReportData.UTestData.SPsuData.m_fPSU232Curr     = f232Curr;
    m_SReportData.UTestData.SPsuData.m_fLoadCurr1      = fLoadCurr[0];
    m_SReportData.UTestData.SPsuData.m_fLoadCurr2      = fLoadCurr[1];
    m_SReportData.UTestData.SPsuData.m_fLoadCurr3      = fLoadCurr[2];
    m_SReportData.m_iTestResult                       = iTestResult;
    reportUpdateTable(m_SReportData);
    logTestData(m_SReportData);

    do
    {
        iTestResult = 0x01;
        m_bRetryOnFailure = false;

        iRetval = m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_DAISY_CHAIN_MODE, DP_PSU_OUTPUT_OFF, (in_iPSUIdx+1));

        if (iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU PSU Output failed", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), m_SPSUConfig[in_iPSUIdx].m_fMaxVolt, m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : Configuration Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);

    /* Update Test Result */
    *out_piStatus = iTestResult;
    return;
}

void CTestThread::DP_LINS_PowerControlReset(int in_iPSUIdx, int in_iChIdx, int in_iOpt)
{
    QString qsErrorDesc = "";
    int iRetval = 0;
    float fPSUVolt = 0.0f;
    float fPSUCurr = 0.0f;

    if(in_iOpt & 0x1)
    {
        if(in_iPSUIdx != 3)
        {
            iRetval = m_p3096Wrapper->SetOutput(g_usDOChannel[in_iPSUIdx][in_iChIdx], DIO_DISABLE);
        }
        else
        {
            iRetval = m_p3096Wrapper->SetOutput(DO_TC_PWR, DIO_DISABLE);
        }
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU-%d : Unable to set Relay status", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
        }
    }

    if(in_iOpt & 0x2)
    {
        /* Power Output Validation @28V */
        fPSUVolt = m_SPSUConfig[in_iPSUIdx].m_fNominalVolt;
        fPSUCurr = m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit;

        iRetval = m_obj_CPSUWrapper->DP_PSU_VoltCurrConfig(DP_PSU_DAISY_CHAIN_MODE, fPSUVolt, fPSUCurr, in_iPSUIdx+1);
        if (iRetval)
        {

            qsErrorDesc.sprintf("PSU%d : PSU Voltage-Current Configuration failed", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
        }

        iRetval = m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_DAISY_CHAIN_MODE, DP_PSU_OUTPUT_OFF, (in_iPSUIdx+1));
        if (iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU Output Disable failed", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
        }
    }
}

void CTestThread::DP_LINS_TeleCmdPSUTest(int in_iPSUIdx, int in_iConnNo, int* out_piStatus)
{
    QString qsErrorDesc = "", qsPSUError = "";
    unsigned char ucDIOSts = 0;

    int iTestResult = 0x01;
    int iRetval = 0;
    int iChainIdx = 0;

    unsigned short usDITCPwrSts = DI_TC_PWR_STS;
    unsigned short usDOTCPwrSts = DO_TC_PWR;

    float fLoadVolt[3] = {0.0f};
    float f232Volt = 0.0f;
    float f232Curr = 0.0f;
    float fADCVolt = 0.0f;

    float fPSUVolt = 0.0f;
    float fPSUCurr = 0.0f;
    float fPSU_UV = 0.0f;
    float fPSU_OV = 0.0f;

    *out_piStatus = LINS_TEST_FAIL;

    /* Ensure Telecommad Relay is OFF */
    do
    {
        m_bRetryOnFailure = false;
        iRetval = m_p3096Wrapper->ReadInput(usDITCPwrSts,&ucDIOSts);
        if (iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : Unable to Read Relay Status", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDITCPwrSts), (((SID_GET_CHANNEL(usDITCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDITCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf( "PSU%d : Read Relay Status Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
        if(ucDIOSts != DIO_ENABLE)
        {
            iTestResult = LINS_TEST_FAIL;
        }
    } while(m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);


    for(int iIttrCnt = 0; iIttrCnt < 2; iIttrCnt++)
    {
        fPSUVolt = (iIttrCnt == 0)? m_SPSUConfig[in_iPSUIdx].m_fNominalVolt : m_SPSUConfig[in_iPSUIdx].m_fMaxVolt;
        fPSUCurr = m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit;
        fPSU_UV = m_SPSUConfig[in_iPSUIdx].m_fUnderVolt;
        fPSU_OV = m_SPSUConfig[in_iPSUIdx].m_fOverVolt;

        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;

            iRetval = m_obj_CPSUWrapper->DP_PSU_VoltCurrConfig(DP_PSU_DAISY_CHAIN_MODE, fPSUVolt, fPSUCurr, in_iPSUIdx+1);
            if (iRetval)
            {

                qsErrorDesc.sprintf("PSU%d : PSU Voltage Current Configuration Failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                    qsErrorDesc.sprintf("%s - Configured Value for Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSUVolt, fPSUCurr, iRetval, qsPSUError.toLatin1().data());
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf( "PSU%d : PSU Voltage Current Configuration Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);
        msleep(DP_PSU_RESTTIME);

        if(iIttrCnt == 0)
        {
            // Configure Over Voltage and Under Voltage
            do
            {
                iTestResult = 0x01;
                m_bRetryOnFailure = false;

                iRetval = m_obj_CPSUWrapper->DP_PSU_OV_UV_Config(fPSU_OV, fPSU_UV, in_iPSUIdx+1);
                if (iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Over Voltage & Under Voltage Configuration Failed", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                        qsErrorDesc.sprintf("%s - Configured Over Voltage: %.2f, Under Voltage: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSU_OV, fPSU_UV, iRetval, qsPSUError.toLatin1().data());
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf( "PSU%d : PSU OV & UV Configuration Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
            } while(m_bRetryOnFailure);
            msleep(DP_PSU_RESTTIME);

            //Enable PSU out
            do
            {
                iTestResult = 0x01;
                m_bRetryOnFailure = false;

                iRetval = m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_DAISY_CHAIN_MODE, DP_PSU_OUTPUT_ON, in_iPSUIdx+1);
                if (iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Output Enabling Failed", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                        qsErrorDesc.sprintf("%s - Configured Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), m_SPSUConfig[in_iPSUIdx].m_fMaxVolt, m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit, iRetval, qsPSUError.toLatin1().data());
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf( "PSU%d : PSU Enable Output Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
            } while(m_bRetryOnFailure);
            msleep(DP_PSU_RESTTIME);
        }

        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;

            iRetval = m_obj_CPSUWrapper->DP_PSU_Measure_Ouput(&f232Volt, &f232Curr, in_iPSUIdx+1);
            if (iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : PSU Measure output Failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                    qsErrorDesc += qsPSUError;
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf( "PSU%d : PSU Measure output Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);
        msleep(DP_PSU_RESTTIME);

        do
        {
            iTestResult = 0x01;
            iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSU[in_iPSUIdx], 1, &fADCVolt, 1);
            if (iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf( "PSU%d : PSU Voltage ADC Read Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bRetryOnFailure)
                    {
                        continue;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }

            if((fADCVolt > (f232Volt + TEST_COSPSU_TOL_VOLT)) || (fADCVolt < (f232Volt - TEST_COSPSU_TOL_VOLT)))
            {
                iTestResult = 0x01;
                m_bRetryOnFailure = false;
                qsErrorDesc.sprintf ("PSU%d : Board %d Channel %d - Expected : %.2fV  Read : %.2fV", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), f232Volt, fADCVolt);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf( "PSU%d : PSU Voltage ADC Read Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                }
            }
        }  while(m_bRetryOnFailure);

        /* Voltage Output Validation*/
        for(iChainIdx = 0; iChainIdx < 3; iChainIdx++)
        {
            /*Read PSU Chain Voltage*/
            do
            {
                iTestResult = 0x01;
                iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSUChVolt[in_iPSUIdx][iChainIdx], 1, &fLoadVolt[iChainIdx], 1);
                if (iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                        qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), iRetval, m_errString);
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf( "PSU%d : PSU Voltage ADC Read Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bRetryOnFailure)
                        {
                            continue;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }

                if (fLoadVolt[iChainIdx] > 1.0)
                {
                    iTestResult = 0x01;
                    m_bRetryOnFailure = false;
                    qsErrorDesc.sprintf ("PSU%d : Board %d Channel %d - Expected : 0V  Read : %.2fV", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), fLoadVolt[iChainIdx]);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);

                    qsErrorDesc.sprintf("PSU%d : Voltage Error (Obs = %.3f) ", (in_iPSUIdx + 1), fLoadVolt[iChainIdx]);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf( "PSU%d : PSU Voltage ADC Read Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                    }
                }
            } while(m_bRetryOnFailure);
        }

        m_SReportData.UTestData.SPsuData.m_fConfigVolt     = fPSUVolt;
        m_SReportData.UTestData.SPsuData.m_fPSU232Volt     = f232Volt;
        m_SReportData.UTestData.SPsuData.m_fPSUADCVolt     = fADCVolt;
        m_SReportData.UTestData.SPsuData.m_ucExpRelaySts   = LINSCM_ENABLE;
        m_SReportData.UTestData.SPsuData.m_ucRelayStatus   = ucDIOSts;
        m_SReportData.m_iLoadStatus                       = m_bPSU_LoadSelect[in_iConnNo];
        m_SReportData.UTestData.SPsuData.m_fLoadVolt1      = fLoadVolt[0];
        m_SReportData.UTestData.SPsuData.m_fLoadVolt2      = fLoadVolt[1];
        m_SReportData.UTestData.SPsuData.m_fLoadVolt3      = fLoadVolt[2];
        m_SReportData.UTestData.SPsuData.m_ucCurrLimitNA   = m_bPSU_LoadSelect[in_iConnNo] ? 0:1;
        m_SReportData.UTestData.SPsuData.m_fExpMinCurr    = DP_PSU_CURRENT_ON_ADC(f232Volt) - 0.1;
        m_SReportData.UTestData.SPsuData.m_fExpMaxCurr    = DP_PSU_CURRENT_ON_ADC(f232Volt) + 0.1;
        m_SReportData.UTestData.SPsuData.m_fPSU232Curr     = f232Curr;
        m_SReportData.m_iTestResult                       = iTestResult;
        reportUpdateTable(m_SReportData);
        logTestData(m_SReportData);

        if(iTestResult == 0)
        {
            qDebug()<<"PSU Power Interface Test:: PSU-OP = " << fADCVolt <<"V";
            *out_piStatus = iTestResult;
            return;
        }
    }

    /*************************************************************************************************/
    /* Power Output Validation @28V */
    fPSUVolt = m_SPSUConfig[in_iPSUIdx].m_fNominalVolt;
    fPSUCurr = m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit;

    do
    {
        iTestResult = 0x01;
        m_bRetryOnFailure = false;

        iRetval = m_obj_CPSUWrapper->DP_PSU_VoltCurrConfig(DP_PSU_DAISY_CHAIN_MODE, fPSUVolt, fPSUCurr, in_iPSUIdx+1);
        if(iRetval)
        {

            qsErrorDesc.sprintf("PSU%d : PSU Voltage Current Configuration Failed", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Value for Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSUVolt, fPSUCurr, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf( "PSU%d : PSU Voltage Current Configuration Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    /*Set Relay Output*/
    do
    {
        iTestResult = 0x01;
        iRetval = m_p3096Wrapper->SetOutput(usDOTCPwrSts,DIO_ENABLE);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : Unable to set Relay Status", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDOTCPwrSts), (((SID_GET_CHANNEL(usDOTCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDOTCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf( "PSU%d : Set Relay Status Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);
    msleep(DP_DIO_RESTTIME);

    /* Relay Output Validation*/
    do
    {
        iTestResult = 0x01;
        iRetval = m_p3096Wrapper->ReadInput(usDITCPwrSts,&ucDIOSts);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : Unable to Read Relay Status", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDITCPwrSts), (((SID_GET_CHANNEL(usDITCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDITCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf( "PSU%d : Read Relay Status Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }

        if(ucDIOSts != 0)
        {
            iTestResult = 0x01;
            qsErrorDesc.sprintf("PSU%d : Exp = %d , Obs = %d",(in_iPSUIdx + 1), !ucDIOSts,ucDIOSts);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf( "PSU%d : Read Relay Status Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);

    /*************************************************************************************************/
    /* Power Output Validation from 22V to 36V */
    for(float fSetVolt = m_SPSUConfig[in_iPSUIdx].m_fTestStartRange; fSetVolt < m_SPSUConfig[in_iPSUIdx].m_fTestStopRange; fSetVolt += m_SPSUConfig[in_iPSUIdx].m_fStepupRange)
    {
        fPSUVolt = fSetVolt;
        fPSUCurr = m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit;

        do
        {
            iTestResult = 0x01;
            iRetval = m_obj_CPSUWrapper->DP_PSU_VoltCurrConfig(DP_PSU_DAISY_CHAIN_MODE, fPSUVolt, fPSUCurr, in_iPSUIdx+1);
            if(iRetval)
            {

                qsErrorDesc.sprintf("PSU%d : PSU Voltage-Current Configuration failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                    qsErrorDesc.sprintf("%s - Configured Value for Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSUVolt, fPSUCurr, iRetval, qsPSUError.toLatin1().data());
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf( "PSU%d : PSU Voltage-Current Configuration Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);
        msleep(DP_PSU_RESTTIME);

        do
        {
            iTestResult = 0x01;
            iRetval = m_obj_CPSUWrapper->DP_PSU_Measure_Ouput(&f232Volt, &f232Curr, in_iPSUIdx+1);
            if(iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : PSU Measure Output Failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                    qsErrorDesc += qsPSUError;
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf( "PSU%d : PSU Measure Output Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);
        msleep(DP_PSU_RESTTIME);

        /*Read PSU Volatge*/
        do
        {
            iTestResult = 0x01;
            iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSU[in_iPSUIdx], 1, &fADCVolt, 1);
            if(iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC read Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bRetryOnFailure)
                    {
                        continue;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }

            if((fADCVolt > (f232Volt + TEST_COSPSU_TOL_VOLT)) || (fADCVolt < (f232Volt - TEST_COSPSU_TOL_VOLT)))
            {
                iTestResult = 0x01;
                m_bRetryOnFailure = false;
                qsErrorDesc.sprintf ("PSU%d : Board %d Channel %d - Expected : %.2fV  Read : %.2fV", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), f232Volt, fADCVolt);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC read Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);

        /* Voltage Output Validation*/
        for(iChainIdx = 0; iChainIdx < 3; iChainIdx++)
        {
            /*Read PSU Chain Voltage*/
            do
            {
                iTestResult = 0x01;
                iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSUChVolt[in_iPSUIdx][iChainIdx], 1, &fLoadVolt[iChainIdx], 1);
                if(iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                        qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), iRetval, m_errString);
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC read Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bRetryOnFailure)
                        {
                            continue;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
            } while(m_bRetryOnFailure);
        }

        /*Read PSU Chain Voltage*/
        do
        {
            if((fLoadVolt[in_iConnNo] > (fADCVolt+TEST_COSPSU_TOL_VOLT)) || (fLoadVolt[in_iConnNo] < (fADCVolt-TEST_COSPSU_TOL_VOLT)))
            {
                m_bRetryOnFailure = false;
                qsErrorDesc.sprintf ("PSU%d : Board %d Channel %d - Expected : %.2fV  Read : %.2fV", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), fADCVolt, fLoadVolt[iChainIdx]);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC read Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);

        m_SReportData.UTestData.SPsuData.m_fConfigVolt     = fPSUVolt;
        m_SReportData.UTestData.SPsuData.m_fPSU232Volt     = f232Volt;
        m_SReportData.UTestData.SPsuData.m_fPSUADCVolt     = fADCVolt;
        m_SReportData.UTestData.SPsuData.m_ucExpRelaySts   = LINSCM_DISABLE;
        m_SReportData.UTestData.SPsuData.m_ucRelayStatus   = ucDIOSts;
        m_SReportData.m_iLoadStatus                       = m_bPSU_LoadSelect[in_iConnNo];
        m_SReportData.UTestData.SPsuData.m_fLoadVolt1      = fLoadVolt[0];
        m_SReportData.UTestData.SPsuData.m_fLoadVolt2      = fLoadVolt[1];
        m_SReportData.UTestData.SPsuData.m_fLoadVolt3      = fLoadVolt[2];
        m_SReportData.UTestData.SPsuData.m_ucCurrLimitNA   = m_bPSU_LoadSelect[in_iConnNo] ? 0:1;
        m_SReportData.UTestData.SPsuData.m_fExpMinCurr    = DP_PSU_CURRENT_ON_ADC(f232Volt) - 0.1;
        m_SReportData.UTestData.SPsuData.m_fExpMaxCurr    = DP_PSU_CURRENT_ON_ADC(f232Volt) + 0.1;
        m_SReportData.UTestData.SPsuData.m_fPSU232Curr     = f232Curr;
        m_SReportData.m_iTestResult                       = iTestResult;
        reportUpdateTable(m_SReportData);
        logTestData(m_SReportData);

        if(iTestResult == 0)
        {
            qDebug()<<"PSU Power Variation Test:: " << fPSUVolt <<"V";
            *out_piStatus = iTestResult;
            return;
        }
    }

    /*************************************************************************************************/

    /*Set Relay Output Disable*/
    do
    {
        iTestResult = 0x01;
        iRetval = m_p3096Wrapper->SetOutput(usDOTCPwrSts,DIO_DISABLE);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU-%d : Unable to set Relay status", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDOTCPwrSts), (((SID_GET_CHANNEL(usDOTCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDOTCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Set Relay Status Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);
    msleep(DP_DIO_RESTTIME);

    /* Relay Output Validation*/
    do
    {
        iTestResult = 0x01;
        iRetval = m_p3096Wrapper->ReadInput(usDITCPwrSts,&ucDIOSts);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU-%d : Unable to read Relay status", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDITCPwrSts), (((SID_GET_CHANNEL(usDITCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDITCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Read Relay status Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bRetryOnFailure)
                {
                    continue;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }

        if(ucDIOSts != DIO_ENABLE)
        {
            iTestResult = 0x01;
            qsErrorDesc.sprintf("PSU%d : Exp = %d , Obs = %d",(in_iPSUIdx + 1), !ucDIOSts,ucDIOSts);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Read Relay status Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);

    do
    {
        iTestResult = 0x01;
        m_bRetryOnFailure = false;

        iRetval = m_obj_CPSUWrapper->DP_PSU_Measure_Ouput(&f232Volt, &f232Curr, in_iPSUIdx+1);
        if (iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU Measure output Failed", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc += qsPSUError;
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf( "PSU%d : PSU Measure output Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    /* Voltage Output Validation*/
    for(iChainIdx = 0; iChainIdx < 3; iChainIdx++)
    {
        /*Read PSU Chain Voltage*/
        do
        {
            iTestResult = 0x01;
            iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSUChVolt[in_iPSUIdx][iChainIdx], 1, &fLoadVolt[iChainIdx], 1);
            if(iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC read Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            if(fLoadVolt[iChainIdx] > 1.0)
            {
                iTestResult = 0x01;
                m_bRetryOnFailure = false;
                qsErrorDesc.sprintf ("PSU%d : Board %d Channel %d - Expected : 0V  Read : %.2fV", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), fLoadVolt[iChainIdx]);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC read Skipped", (in_iPSUIdx + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while(m_bRetryOnFailure);
    }

    m_SReportData.UTestData.SPsuData.m_fConfigVolt     = fPSUVolt;
    m_SReportData.UTestData.SPsuData.m_fPSU232Volt     = f232Volt;
    m_SReportData.UTestData.SPsuData.m_fPSUADCVolt     = fADCVolt;
    m_SReportData.UTestData.SPsuData.m_ucExpRelaySts   = LINSCM_ENABLE;
    m_SReportData.UTestData.SPsuData.m_ucRelayStatus   = ucDIOSts;
    m_SReportData.m_iLoadStatus                        = m_bPSU_LoadSelect[in_iConnNo];
    m_SReportData.UTestData.SPsuData.m_fLoadVolt1      = fLoadVolt[0];
    m_SReportData.UTestData.SPsuData.m_fLoadVolt2      = fLoadVolt[1];
    m_SReportData.UTestData.SPsuData.m_fLoadVolt3      = fLoadVolt[2];
    m_SReportData.UTestData.SPsuData.m_ucCurrLimitNA   = m_bPSU_LoadSelect[in_iConnNo] ? 0:1;
    m_SReportData.UTestData.SPsuData.m_fExpMinCurr    = DP_PSU_CURRENT_ON_ADC(f232Volt) - 0.1;
    m_SReportData.UTestData.SPsuData.m_fExpMaxCurr    = DP_PSU_CURRENT_ON_ADC(f232Volt) + 0.1;
    m_SReportData.UTestData.SPsuData.m_fPSU232Curr     = f232Curr;
    m_SReportData.m_iTestResult                        = iTestResult;
    reportUpdateTable(m_SReportData);
    logTestData(m_SReportData);

    //Enable PSU out
    do
    {
        iTestResult = 0x01;
        m_bRetryOnFailure = false;

        iRetval = m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_DAISY_CHAIN_MODE, DP_PSU_OUTPUT_OFF, in_iPSUIdx+1);
        if (iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU Output Enabling Failed", (in_iPSUIdx + 1));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), m_SPSUConfig[in_iPSUIdx].m_fMaxVolt, m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf( "PSU%d : PSU Enable Output Skipped", (in_iPSUIdx + 1));
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    if(iTestResult == 0)
    {
        qDebug()<<"PSU Power Output Test:: " << fPSUVolt <<"V";
        *out_piStatus = iTestResult;
        return;
    }

    /* Update Test Result */
    *out_piStatus = iTestResult;
    return;
}

void CTestThread::DP_LINS_TeleCmdTest(int in_iPSUIdx, int in_iConnNo, int* out_piStatus)
{
    QString qsErrorDesc = "", qsPSUError = "", qsDispInfo = "";
    unsigned char ucDIOSts = 0;
    unsigned char ucDIOEnDis = 0;

    unsigned char ucRlyONSts = 0;
    unsigned char ucRlyOFFSts = 0;

    int iTestResult = 0x01;
    int iOverAllResult = 0x01;
    int iRetval = 0;
    int iChainIdx = 0;
    int iChIdx = 0;

    unsigned short usDITCPwrSts = DI_TC_PWR_STS;
    unsigned short usDOTCPwrSts = DO_TC_PWR;

    float fLoadVolt[3] = {0.0f};
    float f232Volt = 0.0f;
    float f232Curr = 0.0f;
    float fADCVolt = 0.0f;

    float fPSUVolt = 0.0f;
    float fPSUCurr = 0.0f;
    float fPSU_UV = 0.0f;
    float fPSU_OV = 0.0f;


    *out_piStatus = LINS_TEST_PASS;

    fPSUVolt = m_SPSUConfig[in_iPSUIdx].m_fNominalVolt;
    fPSUCurr = m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit;
    fPSU_UV = m_SPSUConfig[in_iPSUIdx].m_fUnderVolt;
    fPSU_OV = m_SPSUConfig[in_iPSUIdx].m_fOverVolt;

    qsDispInfo.sprintf("Connect the D-Type Connector <b>PL1</b> of JIG1 to <b>SK12</b> of the Test-Rig and\n "
                       "Connect the D-Type Connector <b>SK1</b> of JIG2 to <b>PL123</b> of the Test-Rig");
    emit Sig_MsgBox(qsDispInfo,MSGTYPE_INFO);

    do
    {
        m_bRetryOnFailure = false;
        iTestResult = 0x01;
        iRetval = m_obj_CPSUWrapper->DP_PSU_VoltCurrConfig(DP_PSU_DAISY_CHAIN_MODE, fPSUVolt, fPSUCurr, in_iPSUIdx+1);
        if(iRetval)
        {

            qsErrorDesc.sprintf("PSU%d : PSU Voltage-Current Configuration failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Value for Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSUVolt, fPSUCurr, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Voltage-Current Configuration Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    }while(m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    //Configure Over Voltage and Under Voltage
    do
    {
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_OV_UV_Config(fPSU_OV, fPSU_UV, in_iPSUIdx+1);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU Over Voltage & Under Voltage Configuration Failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Over Voltage: %.2f, Under Voltage: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSU_OV, fPSU_UV, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Overflow & Underflow Configuration Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    //Enable PSU out
    do
    {
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_DAISY_CHAIN_MODE, DP_PSU_OUTPUT_ON, in_iPSUIdx+1);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), m_SPSUConfig[in_iPSUIdx].m_fMaxVolt, m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while (m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    do
    {
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_Measure_Ouput(&f232Volt, &f232Curr, in_iPSUIdx+1);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU Measure Output failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc += qsPSUError;
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Measure Output Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while (m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    /*Set Relay Output*/
    do
    {
        iTestResult = LINS_TEST_PASS;
        m_bRetryOnFailure = false;
        iRetval = m_p3096Wrapper->SetOutput(usDOTCPwrSts,DIO_ENABLE);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU-%d : Unable to set Relay status", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDOTCPwrSts), (((SID_GET_CHANNEL(usDOTCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDOTCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Set Relay status Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);
    msleep(DP_DIO_RESTTIME);

    /* Relay Output Validation*/
    do
    {
        iTestResult = LINS_TEST_PASS;
        m_bRetryOnFailure = false;
        iRetval = m_p3096Wrapper->ReadInput(usDITCPwrSts,&ucDIOSts);
        if(iRetval)
        {
            qsErrorDesc.sprintf("TeleCmd-DICh%2d : Unable to read Relay status", (SID_GET_CHANNEL(usDITCPwrSts)));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDITCPwrSts), (((SID_GET_CHANNEL(usDITCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDITCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Unable to read Relay status", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bRetryOnFailure)
                {
                    continue;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }

        if(ucDIOSts != 0)
        {
            iTestResult = LINS_TEST_FAIL;
            qsErrorDesc.sprintf("DI Read-back Error : Exp = %d , Obs = %d", !ucDIOSts,ucDIOSts);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Unable to read Relay status", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);

    /* Voltage and Current Output Validation*/
    for(iChainIdx = 0; iChainIdx < 3; iChainIdx++)
    {
        /*Read PSU Chain Voltage*/
        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;
            iRetval =  m_p1105Wrapper->ReadRecentSample(g_usAI_PSUChVolt[in_iPSUIdx][iChainIdx], 1, &fLoadVolt[iChainIdx], 1);
            if(iRetval)
            {
                qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed", (in_iPSUIdx + 1));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p1105Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : PSU output ADC read failed in Board %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usAI_PSU[in_iPSUIdx]), SID_GET_CHANNEL(g_usAI_PSU[in_iPSUIdx]), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iConnNo+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : PSU Voltage ADC read Skipped", in_iPSUIdx+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bRetryOnFailure)
                    {
                        continue;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while (m_bRetryOnFailure);
    }

    for(int iChCnt = 0; iChCnt < 18; iChCnt++)
    {
        if(((iChCnt >= 9)&&(iChCnt < 16))&&(in_iConnNo != 0))
        {
            iChIdx = iChCnt + (in_iConnNo * 8) - in_iConnNo;
        }
        else if(iChCnt >= 16)
        {
            iChIdx = (iChCnt == 16)? 30 : 31;
        }
        else
        {
            iChIdx = iChCnt;
        }

        ucDIOEnDis = DIO_ENABLE;
        iOverAllResult = LINS_TEST_PASS;
        for(int iLoop = 0; iLoop < 2; iLoop++)
        {
            do
            {
                do
                {
                    iTestResult = LINS_TEST_PASS;
                    m_bRetryOnFailure = false;
                    iRetval = m_p3096Wrapper->SetOutput(g_usTC_DOCh[iChIdx],ucDIOEnDis);
                    if(iRetval)
                    {
                        qsErrorDesc.sprintf("TeleCmd-DOCh%2d : Unable to set Relay status", (SID_GET_CHANNEL(g_usTC_DOCh[iChIdx])));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                        if (m_bPauseOnFailure)
                        {
                            m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                            qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usTC_DOCh[iChIdx]), (((SID_GET_CHANNEL(g_usTC_DOCh[iChIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usTC_DOCh[iChIdx])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                            emit Sig_PauseOnFailureMsg (qsErrorDesc);
                            if (m_bTestStop)
                            {
                                qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iConnNo+1);
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                            if (m_bSkipTestOnFailure)
                            {
                                qsErrorDesc.sprintf("TeleCmd-DOCh%2d : Set Relay status Skipped", (SID_GET_CHANNEL(g_usTC_DOCh[iChIdx])));
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                        }
                        else
                        {
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                } while(m_bRetryOnFailure);
                msleep(DP_DIO_RESTTIME);

                do
                {
                    iTestResult = LINS_TEST_PASS;
                    m_bRetryOnFailure = false;
                    iRetval = m_p3096Wrapper->ReadInput(g_usTC_DICh[iChCnt],&ucDIOSts);
                    if(iRetval)
                    {
                        qsErrorDesc.sprintf("TeleCmd-DICh%2d : Unable to read Relay status", (SID_GET_CHANNEL(g_usTC_DICh[iChCnt])));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                        if (m_bPauseOnFailure)
                        {
                            m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                            qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usTC_DICh[iChCnt]), (((SID_GET_CHANNEL(g_usTC_DICh[iChCnt]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usTC_DICh[iChCnt])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                            emit Sig_PauseOnFailureMsg (qsErrorDesc);
                            if (m_bTestStop)
                            {
                                qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iConnNo+1);
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                            if (m_bSkipTestOnFailure)
                            {
                                qsErrorDesc.sprintf("TeleCmd-DICh%2d : Read Relay status Skipped", (SID_GET_CHANNEL(g_usDIChannel[in_iPSUIdx][iChainIdx])));
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                        }
                        else
                        {
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                } while (m_bRetryOnFailure);

                if(ucDIOEnDis == ucDIOSts)
                {
                    m_bRetryOnFailure = false;
                    iTestResult = LINS_TEST_FAIL;
                    qsErrorDesc.sprintf("DI Read-Back Error - Exp = %d, Obj = %d", !ucDIOEnDis, ucDIOSts);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : Board %d Group %d Channel %d - Exp = %d, Obj = %d", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usTC_DICh[iChCnt]), (((SID_GET_CHANNEL(g_usTC_DICh[iChCnt]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usTC_DICh[iChCnt])) % LINS_3096_MAX_GRP_CHANNELS), !ucDIOEnDis, ucDIOSts);
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : Read Relay Status Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                    }
                }
            } while (m_bRetryOnFailure);

            if(ucDIOEnDis == DIO_ENABLE)
            {
                ucRlyONSts = !ucDIOSts;
            }
            else
            {
                ucRlyOFFSts = !ucDIOSts;
            }

            ucDIOEnDis = DIO_DISABLE;

            iOverAllResult &= iTestResult;
        }


        iTestResult = iOverAllResult;

        m_SReportData.UTestData.STeleCmdData.m_ucDOChnNo   = iChIdx+1;
        m_SReportData.UTestData.STeleCmdData.m_ucDIChnNo   = iChCnt+1;
        m_SReportData.UTestData.STeleCmdData.m_ucExpONSts  = DIO_ENABLE;
        m_SReportData.UTestData.STeleCmdData.m_ucObsONSts  = ucRlyONSts;
        m_SReportData.UTestData.STeleCmdData.m_ucExpOFFSts = DIO_DISABLE;
        m_SReportData.UTestData.STeleCmdData.m_ucObsOFFSts = ucRlyOFFSts;
        m_SReportData.m_iTestResult                       = iTestResult;
        reportUpdateTable(m_SReportData);
        logTestData(m_SReportData);

        *out_piStatus &= iTestResult;
    }

    /*Set Relay Output*/
    do
    {
        do
        {
            iTestResult = LINS_TEST_PASS;
            m_bRetryOnFailure = false;
            iRetval = m_p3096Wrapper->SetOutput(usDOTCPwrSts,DIO_DISABLE);
            if(iRetval)
            {
                qsErrorDesc.sprintf("PSU-%d : Unable to set Relay status", in_iPSUIdx+1);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDOTCPwrSts), (((SID_GET_CHANNEL(usDOTCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDOTCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iConnNo+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU-%d : Set Relay status Skipped", in_iPSUIdx+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while (m_bRetryOnFailure);

        /* Relay Output Validation*/
        do
        {
            iTestResult = LINS_TEST_PASS;
            m_bRetryOnFailure = false;
            iRetval = m_p3096Wrapper->ReadInput(usDITCPwrSts,&ucDIOSts);
            if(iRetval)
            {
                qsErrorDesc.sprintf("TeleCmd-DICh%2d : Unable to read Relay status", (SID_GET_CHANNEL(usDITCPwrSts)));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDITCPwrSts), (((SID_GET_CHANNEL(usDITCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDITCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iConnNo+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU-%d : Read Relay status Skipped", in_iPSUIdx+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while (m_bRetryOnFailure);

        if(ucDIOSts != DIO_DISABLE)
        {
            iTestResult = LINS_TEST_FAIL;
            m_bRetryOnFailure = false;
            qsErrorDesc.sprintf("DI Read-Back Error : Exp = %d , Obs = %d", !ucDIOSts,ucDIOSts);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iConnNo+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Read Relay status Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while (m_bRetryOnFailure);

    *out_piStatus &= iTestResult;

    //Enable PSU out
    do
    {
        iTestResult = LINS_TEST_PASS;
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_DAISY_CHAIN_MODE, DP_PSU_OUTPUT_OFF, in_iPSUIdx+1);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), m_SPSUConfig[in_iPSUIdx].m_fMaxVolt, m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while (m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    *out_piStatus &= iTestResult;
}

void CTestThread::DP_LINS_TeleCmdStsReadbackTest(int in_iPSUIdx, int in_iBankNo, int* out_piStatus)
{
    QString qsErrorDesc = "", qsPSUError = "", qsDispInfo = "";
    unsigned char ucDIOSts = 0;
    unsigned char ucDIOEnDis = 0;
    unsigned char ucDOChnCnt = 0;

    unsigned char ucRlyONSts = 0;
    unsigned char ucRlyOFFSts = 0;

    int iTestResult = 0x01;
    int iOverAllResult = 0x01;
    int iRetval = 0;
    int iChainIdx = 0;
    int iChIdx = 0;

    int iDOChIdx = 0;
    int iDIChIdx = 0;

    unsigned short usDITCPwrSts = DI_TC_PWR_STS;
    unsigned short usDOTCPwrSts = DO_TC_PWR;

    float fLoadVolt[3] = {0.0f};
    float f232Volt = 0.0f;
    float f232Curr = 0.0f;
    float fADCVolt = 0.0f;

    float fPSUVolt = 0.0f;
    float fPSUCurr = 0.0f;
    float fPSU_UV = 0.0f;
    float fPSU_OV = 0.0f;

    *out_piStatus = LINS_TEST_PASS;

    fPSUVolt = m_SPSUConfig[in_iPSUIdx].m_fNominalVolt;
    fPSUCurr = m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit;
    fPSU_UV = m_SPSUConfig[in_iPSUIdx].m_fUnderVolt;
    fPSU_OV = m_SPSUConfig[in_iPSUIdx].m_fOverVolt;

    do
    {
        iTestResult = 0x01;
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_VoltCurrConfig(DP_PSU_DAISY_CHAIN_MODE, fPSUVolt, fPSUCurr, in_iPSUIdx+1);
        if(iRetval)
        {

            qsErrorDesc.sprintf("PSU%d : PSU Voltage-Current Configuration failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Value for Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSUVolt, fPSUCurr, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Voltage-Current Configuration Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    }while(m_bRetryOnFailure && m_bPauseOnFailure);
    msleep(DP_PSU_RESTTIME);

    //Configure Over Voltage and Under Voltage
    do
    {
        iTestResult = LINS_TEST_PASS;
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_OV_UV_Config(fPSU_OV, fPSU_UV, in_iPSUIdx+1);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU Over Voltage & Under Voltage Configuration Failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Over Voltage: %.2f, Under Voltage: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSU_OV, fPSU_UV, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Overflow & Underflow Configuration Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    //Enable PSU out
    do
    {
        iTestResult = LINS_TEST_PASS;
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_DAISY_CHAIN_MODE, DP_PSU_OUTPUT_ON, in_iPSUIdx+1);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), m_SPSUConfig[in_iPSUIdx].m_fMaxVolt, m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while (m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    do
    {
        iTestResult = LINS_TEST_PASS;
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_Measure_Ouput(&f232Volt, &f232Curr, in_iPSUIdx+1);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU Measure Output failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc += qsPSUError;
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Measure Output Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while (m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    /*Set Relay Output*/
    do
    {
        iTestResult = LINS_TEST_PASS;
        m_bRetryOnFailure = false;
        iRetval = m_p3096Wrapper->SetOutput(usDOTCPwrSts,DIO_ENABLE);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU-%d : Unable to set Relay status", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDOTCPwrSts), (((SID_GET_CHANNEL(usDOTCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDOTCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Set Relay status Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);
    msleep(DP_DIO_RESTTIME);

    /* Relay Output Validation*/
    do
    {
        iTestResult = LINS_TEST_PASS;
        m_bRetryOnFailure = false;
        iRetval = m_p3096Wrapper->ReadInput(usDITCPwrSts,&ucDIOSts);
        if(iRetval)
        {
            qsErrorDesc.sprintf("TeleCmd-DICh%2d : Unable to read Relay status", (SID_GET_CHANNEL(usDITCPwrSts)));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDITCPwrSts), (((SID_GET_CHANNEL(usDITCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDITCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Unable to read Relay status", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bRetryOnFailure)
                {
                    continue;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }

        if(ucDIOSts != 0)
        {
            iTestResult = LINS_TEST_FAIL;
            m_bRetryOnFailure = false;
            qsErrorDesc.sprintf("PSU%d : Exp = %d , Obs = %d", in_iPSUIdx+1, !ucDIOSts,ucDIOSts);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Unable to read Relay status", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);

    for(int iChCnt = 0; iChCnt < 6; iChCnt++)
    {
        iDOChIdx = iChCnt;
        if(iChCnt < 4)
        {
            iDIChIdx = iChCnt+ (in_iBankNo * 4);
        }
        else
        {
            iDIChIdx = (iChCnt == 4) ? 12 : 13;
        }

        //        qDebug("DO: %d, DI:%d ",SID_GET_CHANNEL(g_usTC_SpareDOCh[iDOChIdx]), SID_GET_CHANNEL(g_usTC_StsReadback_DICh[iDIChIdx]));

        iOverAllResult = LINS_TEST_PASS;
        ucDIOEnDis = DIO_ENABLE;
        for(int iLoop = 0; iLoop < 2; iLoop++)
        {
            do
            {
                do
                {
                    iTestResult = 0x01;
                    m_bRetryOnFailure = false;
                    iRetval = m_p3096Wrapper->SetOutput(g_usTC_SpareDOCh[iDOChIdx],ucDIOEnDis);
                    if(iRetval)
                    {
                        qsErrorDesc.sprintf("TeleCmd-DOCh%2d : Unable to set Relay status", (SID_GET_CHANNEL(g_usTC_SpareDOCh[iDOChIdx])));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                        if (m_bPauseOnFailure)
                        {
                            m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                            qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usTC_DOCh[iDIChIdx]), (((SID_GET_CHANNEL(g_usTC_DOCh[iDIChIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usTC_DOCh[iDIChIdx])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                            emit Sig_PauseOnFailureMsg (qsErrorDesc);
                            if (m_bTestStop)
                            {
                                qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iPSUIdx+1);
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                            if (m_bSkipTestOnFailure)
                            {
                                qsErrorDesc.sprintf("TeleCmd-DOCh%2d : Set Relay status Skipped", (SID_GET_CHANNEL(g_usTC_SpareDOCh[iDOChIdx])));
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                        }
                        else
                        {
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                } while(m_bRetryOnFailure);
                msleep(DP_DIO_RESTTIME);

                do
                {
                    iTestResult = 0x01;
                    m_bRetryOnFailure = false;
                    iRetval = m_p3096Wrapper->ReadInput(g_usTC_StsReadback_DICh[iDIChIdx],&ucDIOSts);
                    if(iRetval)
                    {
                        qsErrorDesc.sprintf("TeleCmd-DICh%2d : Unable to read Relay status", (SID_GET_CHANNEL(g_usTC_StsReadback_DICh[iDIChIdx])));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                        if (m_bPauseOnFailure)
                        {
                            m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                            qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usTC_StsReadback_DICh[iDIChIdx]), (((SID_GET_CHANNEL(g_usTC_StsReadback_DICh[iDIChIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usTC_StsReadback_DICh[iDIChIdx])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                            emit Sig_PauseOnFailureMsg (qsErrorDesc);
                            if (m_bTestStop)
                            {
                                qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iPSUIdx+1);
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                            if (m_bSkipTestOnFailure)
                            {
                                qsErrorDesc.sprintf("TeleCmd-DICh%2d : Read Relay status Skipped", (SID_GET_CHANNEL(g_usTC_StsReadback_DICh[iDIChIdx])));
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                        }
                        else
                        {
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                } while (m_bRetryOnFailure);

                if(ucDIOEnDis == ucDIOSts)
                {
                    iTestResult = LINS_TEST_FAIL;
                    m_bRetryOnFailure = false;
                    qsErrorDesc.sprintf("DI Read-Back Error : Exp = %d , Obj = %d", !ucDIOEnDis, ucDIOSts);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : Board %d Group %d Channel %d - Exp = %d, Obj = %d", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usTC_StsReadback_DICh[iDIChIdx]), (((SID_GET_CHANNEL(g_usTC_StsReadback_DICh[iDIChIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usTC_StsReadback_DICh[iDIChIdx])) % LINS_3096_MAX_GRP_CHANNELS), !ucDIOEnDis, ucDIOSts);
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iPSUIdx+1);
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("TeleCmd-DICh%2d : Read Relay status Skipped", (SID_GET_CHANNEL(g_usTC_StsReadback_DICh[iDIChIdx])));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                    }
                }
            } while (m_bRetryOnFailure);

            if(ucDIOEnDis == DIO_ENABLE)
            {
                ucRlyONSts = !ucDIOSts;
            }
            else
            {
                ucRlyOFFSts = !ucDIOSts;
            }

            ucDIOEnDis = DIO_DISABLE;

            iOverAllResult &= iTestResult;
        }

        iTestResult = iOverAllResult;

        m_SReportData.UTestData.STeleCmdData.m_ucDOChnNo   = SID_GET_CHANNEL(g_usTC_SpareDOCh[iDOChIdx]);
        m_SReportData.UTestData.STeleCmdData.m_ucDIChnNo   = SID_GET_CHANNEL(g_usTC_StsReadback_DICh[iDIChIdx]);
        m_SReportData.UTestData.STeleCmdData.m_ucExpONSts  = DIO_ENABLE;
        m_SReportData.UTestData.STeleCmdData.m_ucObsONSts  = ucRlyONSts;
        m_SReportData.UTestData.STeleCmdData.m_ucExpOFFSts = DIO_DISABLE;
        m_SReportData.UTestData.STeleCmdData.m_ucObsOFFSts = ucRlyOFFSts;
        m_SReportData.m_iTestResult                       = iTestResult;
        reportUpdateTable(m_SReportData);
        logTestData(m_SReportData);

        *out_piStatus &= iTestResult;
    }

    /*Set Relay Output*/
    do
    {
        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;
            iRetval = m_p3096Wrapper->SetOutput(usDOTCPwrSts,DIO_DISABLE);
            if(iRetval)
            {
                qsErrorDesc.sprintf("PSU-%d : Unable to set Relay status", in_iPSUIdx+1);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDOTCPwrSts), (((SID_GET_CHANNEL(usDOTCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDOTCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iPSUIdx+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU-%d : Set Relay status Skipped", in_iPSUIdx+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while (m_bRetryOnFailure);

        /* Relay Output Validation*/
        do
        {
            iTestResult = 0x01;
            m_bRetryOnFailure = false;
            iRetval = m_p3096Wrapper->ReadInput(usDITCPwrSts,&ucDIOSts);
            if(iRetval)
            {
                qsErrorDesc.sprintf("TeleCmd-DICh%2d : Unable to read Relay status", (SID_GET_CHANNEL(usDITCPwrSts)));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDITCPwrSts), (((SID_GET_CHANNEL(usDITCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDITCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iPSUIdx+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU-%d : Read Relay status Skipped", in_iPSUIdx+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while (m_bRetryOnFailure);

        if(ucDIOSts != DIO_DISABLE)
        {
            m_bRetryOnFailure = false;
            iTestResult = LINS_TEST_FAIL;
            qsErrorDesc.sprintf("DI Read-Back Error : Exp = %d , Obs = %d", !ucDIOSts,ucDIOSts);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Read Relay status Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while (m_bRetryOnFailure);

    *out_piStatus &= iTestResult;

    //Enable PSU out
    do
    {
        iTestResult = LINS_TEST_PASS;
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_DAISY_CHAIN_MODE, DP_PSU_OUTPUT_OFF, in_iPSUIdx+1);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), m_SPSUConfig[in_iPSUIdx].m_fMaxVolt, m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while (m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    *out_piStatus &= iTestResult;
}

void CTestThread::DP_LINS_SpareDIOTest(int in_iPSUIdx, int in_iBankNo, int* out_piStatus)
{
    QString qsErrorDesc = "", qsPSUError = "", qsDispInfo = "";
    unsigned char ucDIOSts = 0;
    unsigned char ucDIOEnDis = 0;
    unsigned char ucDOChnCnt = 0;

    unsigned char ucRlyONSts = 0;
    unsigned char ucRlyOFFSts = 0;

    int iTestResult = 0x01;
    int iOverAllResult = 0x01;
    int iRetval = 0;
    int iChainIdx = 0;
    int iChIdx = 0;

    int iDOChIdx = 0;
    int iDIChIdx = 0;

    unsigned short usDITCPwrSts = DI_TC_PWR_STS;
    unsigned short usDOTCPwrSts = DO_TC_PWR;

    float fLoadVolt[3] = {0.0f};
    float f232Volt = 0.0f;
    float f232Curr = 0.0f;
    float fADCVolt = 0.0f;

    float fPSUVolt = 0.0f;
    float fPSUCurr = 0.0f;
    float fPSU_UV = 0.0f;
    float fPSU_OV = 0.0f;

    *out_piStatus = LINS_TEST_PASS;

    fPSUVolt = m_SPSUConfig[in_iPSUIdx].m_fNominalVolt;
    fPSUCurr = m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit;
    fPSU_UV = m_SPSUConfig[in_iPSUIdx].m_fUnderVolt;
    fPSU_OV = m_SPSUConfig[in_iPSUIdx].m_fOverVolt;

    if(in_iBankNo == 4)
    {
        ucDOChnCnt = 14;
    }
    else
    {
        ucDOChnCnt = 16;
    }

    qsDispInfo.sprintf("Connect the D-Type Connector <b>PL2</b> of JIG2 to <b>SK12</b> of the Test-Rig\n\n "
                       "Connect the D-Type Connector <b>SK2</b> of JIG2 to <b>PL123</b> of the Test-Rig");
    emit Sig_MsgBox(qsDispInfo,MSGTYPE_INFO);

    do
    {
        iTestResult = 0x01;
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_VoltCurrConfig(DP_PSU_DAISY_CHAIN_MODE, fPSUVolt, fPSUCurr, in_iPSUIdx+1);
        if(iRetval)
        {

            qsErrorDesc.sprintf("PSU%d : PSU Voltage-Current Configuration failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Value for Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSUVolt, fPSUCurr, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Voltage-Current Configuration Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    }while(m_bRetryOnFailure && m_bPauseOnFailure);
    msleep(DP_PSU_RESTTIME);

    //Configure Over Voltage and Under Voltage
    do
    {
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_OV_UV_Config(fPSU_OV, fPSU_UV, in_iPSUIdx+1);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU Over Voltage & Under Voltage Configuration Failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Over Voltage: %.2f, Under Voltage: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), fPSU_OV, fPSU_UV, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Overflow & Underflow Configuration Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    //Enable PSU out
    do
    {
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_DAISY_CHAIN_MODE, DP_PSU_OUTPUT_ON, in_iPSUIdx+1);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), m_SPSUConfig[in_iPSUIdx].m_fMaxVolt, m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while (m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    do
    {
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_Measure_Ouput(&f232Volt, &f232Curr, in_iPSUIdx+1);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU Measure Output failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc += qsPSUError;
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Measure Output Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while (m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    /*Set Relay Output*/
    do
    {
        m_bRetryOnFailure = false;
        iRetval = m_p3096Wrapper->SetOutput(usDOTCPwrSts,DIO_ENABLE);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU-%d : Unable to set Relay status", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDOTCPwrSts), (((SID_GET_CHANNEL(usDOTCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDOTCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Set Relay status Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while(m_bRetryOnFailure);
    msleep(DP_DIO_RESTTIME);

    /* Relay Output Validation*/
    do
    {
        m_bRetryOnFailure = false;
        iRetval = m_p3096Wrapper->ReadInput(usDITCPwrSts,&ucDIOSts);
        if(iRetval)
        {
            qsErrorDesc.sprintf("TeleCmd-DICh%2d : Unable to read Relay status", (SID_GET_CHANNEL(usDITCPwrSts)));
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDITCPwrSts), (((SID_GET_CHANNEL(usDITCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDITCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Unable to read Relay status", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bRetryOnFailure)
                {
                    continue;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }

        if(ucDIOSts != 0)
        {
            m_bRetryOnFailure = false;
            iTestResult = LINS_TEST_FAIL;
            qsErrorDesc.sprintf("DI Read-Back Error : Exp = %d , Obs = %d", !ucDIOSts,ucDIOSts);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Unable to read Relay status", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
            }
        }
    } while(m_bRetryOnFailure);

    for(int iChCnt = 0; iChCnt < ucDOChnCnt; iChCnt++)
    {
        if(in_iBankNo == 4)
        {
            iDOChIdx = iChCnt + 2;
            iDIChIdx = iChCnt;
        }
        else
        {
            iDOChIdx = iChCnt;
            iDIChIdx = iChCnt+14;
        }

        //        qDebug("DO: %d, DI:%d ",SID_GET_CHANNEL(g_usTC_SpareDOCh[iDOChIdx]), SID_GET_CHANNEL(g_usTC_SpareDICh[iDIChIdx]));

        iOverAllResult = LINS_TEST_PASS;
        ucDIOEnDis = DIO_ENABLE;
        for(int iLoop = 0; iLoop < 2; iLoop++)
        {
            do
            {
                do
                {
                    m_bRetryOnFailure = false;
                    iRetval = m_p3096Wrapper->SetOutput(g_usTC_SpareDOCh[iDOChIdx],ucDIOEnDis);
                    if(iRetval)
                    {
                        qsErrorDesc.sprintf("TeleCmd-DOCh%2d : Unable to set Relay status", (SID_GET_CHANNEL(g_usTC_SpareDOCh[iDOChIdx])));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                        if (m_bPauseOnFailure)
                        {
                            m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                            qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usTC_DOCh[iDIChIdx]), (((SID_GET_CHANNEL(g_usTC_DOCh[iDIChIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usTC_DOCh[iDIChIdx])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                            emit Sig_PauseOnFailureMsg (qsErrorDesc);
                            if (m_bTestStop)
                            {
                                qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iPSUIdx+1);
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                            if (m_bSkipTestOnFailure)
                            {
                                qsErrorDesc.sprintf("TeleCmd-DOCh%2d : Set Relay status Skipped", (SID_GET_CHANNEL(g_usTC_SpareDOCh[iDOChIdx])));
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                        }
                        else
                        {
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                } while(m_bRetryOnFailure);
                msleep(DP_DIO_RESTTIME);

                do
                {
                    m_bRetryOnFailure = false;
                    iRetval = m_p3096Wrapper->ReadInput(g_usTC_SpareDICh[iDIChIdx],&ucDIOSts);
                    if(iRetval)
                    {
                        qsErrorDesc.sprintf("TeleCmd-DICh%2d : Unable to read Relay status", (SID_GET_CHANNEL(g_usTC_SpareDICh[iDIChIdx])));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                        if (m_bPauseOnFailure)
                        {
                            m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                            qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usTC_SpareDICh[iDIChIdx]), (((SID_GET_CHANNEL(g_usTC_SpareDICh[iDIChIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usTC_SpareDICh[iDIChIdx])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                            emit Sig_PauseOnFailureMsg (qsErrorDesc);
                            if (m_bTestStop)
                            {
                                qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iPSUIdx+1);
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                            if (m_bSkipTestOnFailure)
                            {
                                qsErrorDesc.sprintf("TeleCmd-DICh%2d : Read Relay status Skipped", (SID_GET_CHANNEL(g_usTC_SpareDICh[iDIChIdx])));
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                        }
                        else
                        {
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                } while (m_bRetryOnFailure);

                if(ucDIOEnDis == ucDIOSts)
                {
                    m_bRetryOnFailure = false;
                    iTestResult = LINS_TEST_FAIL;
                    qsErrorDesc.sprintf("DI Read-Back Error : Exp = %d , Obj = %d", !ucDIOEnDis, ucDIOSts);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU%d : Board %d Group %d Channel %d - Exp = %d, Obj = %d", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usTC_SpareDICh[iDIChIdx]), (((SID_GET_CHANNEL(g_usTC_SpareDICh[iDIChIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usTC_SpareDICh[iDIChIdx])) % LINS_3096_MAX_GRP_CHANNELS), !ucDIOEnDis, ucDIOSts);
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : Read Relay Status Skipped", (in_iPSUIdx + 1));
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                    }
                }
            } while (m_bRetryOnFailure);

            if(ucDIOEnDis == DIO_ENABLE)
            {
                ucRlyONSts = !ucDIOSts;
            }
            else
            {
                ucRlyOFFSts = !ucDIOSts;
            }

            ucDIOEnDis = DIO_DISABLE;

            iOverAllResult &= iTestResult;
        }

        iTestResult = iOverAllResult;

        m_SReportData.UTestData.STeleCmdData.m_ucDOChnNo   = SID_GET_CHANNEL(g_usTC_SpareDOCh[iDOChIdx]);
        m_SReportData.UTestData.STeleCmdData.m_ucDIChnNo   = SID_GET_CHANNEL(g_usTC_SpareDICh[iDIChIdx]);
        m_SReportData.UTestData.STeleCmdData.m_ucExpONSts  = DIO_ENABLE;
        m_SReportData.UTestData.STeleCmdData.m_ucObsONSts  = ucRlyONSts;
        m_SReportData.UTestData.STeleCmdData.m_ucExpOFFSts = DIO_DISABLE;
        m_SReportData.UTestData.STeleCmdData.m_ucObsOFFSts = ucRlyOFFSts;
        m_SReportData.m_iTestResult                       = iTestResult;
        reportUpdateTable(m_SReportData);
        logTestData(m_SReportData);

        *out_piStatus &= iTestResult;
    }

    /*Set Relay Output*/
    do
    {
        do
        {
            m_bRetryOnFailure = false;
            iRetval = m_p3096Wrapper->SetOutput(usDOTCPwrSts,DIO_DISABLE);
            if(iRetval)
            {
                qsErrorDesc.sprintf("PSU-%d : Unable to set Relay status", in_iPSUIdx+1);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDOTCPwrSts), (((SID_GET_CHANNEL(usDOTCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDOTCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iPSUIdx+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU-%d : Set Relay status Skipped", in_iPSUIdx+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while (m_bRetryOnFailure);

        /* Relay Output Validation*/
        do
        {
            m_bRetryOnFailure = false;
            iRetval = m_p3096Wrapper->ReadInput(usDITCPwrSts,&ucDIOSts);
            if(iRetval)
            {
                qsErrorDesc.sprintf("PSU-%d : Unable to read Relay status", in_iPSUIdx+1);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                if (m_bPauseOnFailure)
                {
                    m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                    qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d - Error Value: %d (%s)", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(usDITCPwrSts), (((SID_GET_CHANNEL(usDITCPwrSts) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(usDITCPwrSts)) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iPSUIdx+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("PSU-%d : Read Relay status Skipped", in_iPSUIdx+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
                else
                {
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
        } while (m_bRetryOnFailure);

        if(ucDIOSts != DIO_DISABLE)
        {
            m_bRetryOnFailure = false;
            qsErrorDesc.sprintf("PSU%d : Exp = %d , Obs = %d", in_iPSUIdx+1, !ucDIOSts,ucDIOSts);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU-%d : Read Relay status Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
            }
        }
    } while (m_bRetryOnFailure);

    *out_piStatus &= iTestResult;

    //Enable PSU out
    do
    {
        iTestResult = LINS_TEST_PASS;
        m_bRetryOnFailure = false;
        iRetval = m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_DAISY_CHAIN_MODE, DP_PSU_OUTPUT_OFF, in_iPSUIdx+1);
        if(iRetval)
        {
            qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON failed", in_iPSUIdx+1);
            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
            if (m_bPauseOnFailure)
            {
                m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                qsErrorDesc.sprintf("%s - Configured Output Voltage: %.2f, Output Current: %.2f - Error Value: %d (%s)", qsErrorDesc.toLatin1().data(), m_SPSUConfig[in_iPSUIdx].m_fMaxVolt, m_SPSUConfig[in_iPSUIdx].m_fCurrentLimit, iRetval, qsPSUError.toLatin1().data());
                emit Sig_PauseOnFailureMsg (qsErrorDesc);
                if (m_bTestStop)
                {
                    qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
                if (m_bSkipTestOnFailure)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON Skipped", in_iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                    iTestResult = LINS_TEST_FAIL;
                    return;
                }
            }
            else
            {
                iTestResult = LINS_TEST_FAIL;
                return;
            }
        }
    } while (m_bRetryOnFailure);
    msleep(DP_PSU_RESTTIME);

    *out_piStatus &= iTestResult;
}

void CTestThread::DP_LINS_ThermistorTest(unsigned short in_u16SignalId, int in_iConnNo, unsigned char in_Switch, int* out_piStatus)
{
    QString qsErrorDesc = "";
    QString qsLogString = "";
    QString qsDispInfo;
    int iRetry = 0;
    int iTestResult = 0x01;
    int iRetval = 0;
    int iTestIttr = 0;
    char carrErrmsg[250] = {0};
    SDPMM1123_THERMISTORVALUES SThermistance;


    int iChnNo = SID_GET_CHANNEL(in_u16SignalId);
    int iBrdNo = SID_GET_BOARD_NUM(in_u16SignalId);

    //    float m_fExpTemp[4] = {-24.5f, 1.1f, 25.0f, 92.8f};
    //    float m_fExpRes[4] = {100.0f, 28.0f, 10.0f, 1.0f};

    m_p1123Wrapper->StartAcquisition(0);
    *out_piStatus = LINS_TEST_PASS;

    for(iTestIttr=0; iTestIttr < 4; iTestIttr++)
    {
        qsDispInfo.sprintf("Set Rotatory-Switch(SWT%d) in Test RIG to Position-%d",in_Switch, iTestIttr+1);
        emit Sig_MsgBox(qsDispInfo,MSGTYPE_INFO);
        msleep(1000);

        do
        {
            iTestResult = LINS_TEST_PASS;
            m_bRetryOnFailure = false;

            iRetval =  m_p1123Wrapper->ReadThermistorValue(in_u16SignalId,  &SThermistance);
            if(iRetval && (iRetval != -972))
            {
                //                                qDebug("Ret: %d Res: %f, Temp: %f", iRetval, SThermistance.m_dResistance,SThermistance.m_dTemperature);
                qsErrorDesc.sprintf("Thermistor (Board %d Ch %d) : Resistance read failed", SID_GET_BOARD_NUM(in_u16SignalId), SID_GET_CHANNEL(in_u16SignalId));
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                iTestResult = LINS_TEST_FAIL;

                if (m_bPauseOnFailure)
                {
                    m_bRetryOnFailure = false;
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if(m_bRetryOnFailure)
                    {
                        memset(&SThermistance, 0, sizeof(SDPMM1123_THERMISTORVALUES));
                        continue;
                    }
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf("Thermistor test for Connector J%d Stopped", (in_iConnNo + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("Thermistor (Board %d Ch %d) : Resistance read Skipped", iBrdNo, iChnNo);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        return;
                    }
                }
            }

            if((SThermistance.m_dTemperature < (m_fExpTemp[iTestIttr]-m_fTolTemp))|| \
                    (SThermistance.m_dTemperature > (m_fExpTemp[iTestIttr]+m_fTolTemp)))
            {
                qsErrorDesc.sprintf("Thermistor (Board %d Ch %d): TemperatureError (Obs = %.3f) ", SID_GET_BOARD_NUM(in_u16SignalId), SID_GET_CHANNEL(in_u16SignalId), SThermistance.m_dTemperature);
                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                iTestResult = LINS_TEST_FAIL;

                if (m_bPauseOnFailure)
                {
                    m_bRetryOnFailure = false;
                    emit Sig_PauseOnFailureMsg (qsErrorDesc);
                    if(m_bRetryOnFailure)
                    {
                        memset(&SThermistance, 0, sizeof(SDPMM1123_THERMISTORVALUES));
                        continue;
                    }
                    if (m_bTestStop)
                    {
                        qsErrorDesc.sprintf("Thermistor test for Connector J%d Stopped", (in_iConnNo + 1));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        return;
                    }
                    if (m_bSkipTestOnFailure)
                    {
                        qsErrorDesc.sprintf("Thermistor (Board %d Ch %d) : Temperature read Skipped", SID_GET_BOARD_NUM(in_u16SignalId), SID_GET_CHANNEL(in_u16SignalId));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                        return;
                    }
                }
            }
        } while (m_bRetryOnFailure);

        m_SReportData.UTestData.SThermodata.m_ucBrdNo = SID_GET_BOARD_NUM(in_u16SignalId);
        m_SReportData.UTestData.SThermodata.m_ucChnNo = SID_GET_CHANNEL(in_u16SignalId);
        m_SReportData.UTestData.SThermodata.m_ucSWNum = in_Switch;
        m_SReportData.UTestData.SThermodata.m_ucSWPos = iTestIttr+1;
        m_SReportData.UTestData.SThermodata.m_dExpRes = m_fExpRes[iTestIttr];
        m_SReportData.UTestData.SThermodata.m_dTolRes = m_fTolRes;
        m_SReportData.UTestData.SThermodata.m_dObsRes = SThermistance.m_dResistance;
        m_SReportData.UTestData.SThermodata.m_dExpTemp = m_fExpTemp[iTestIttr];
        m_SReportData.UTestData.SThermodata.m_dTolTemp = m_fTolTemp;
        m_SReportData.UTestData.SThermodata.m_dObsTemp = SThermistance.m_dTemperature;
        m_SReportData.m_iTestResult = iTestResult;
        reportUpdateTable(m_SReportData);
        logTestData(m_SReportData);

        *out_piStatus &= iTestResult;
    }

    m_p1123Wrapper->StopAcquisition(0);

}

void CTestThread::DP_LINS_PSU_PinOutTest(int in_iPSUIdx, int in_iConnNo, int* out_piStatus)
{
    QString qsErrorDesc = "", qsPSUError = "";
    unsigned char ucDIOSts = 0;
    unsigned char ucDIOEnDis = 0;

    int iDIChnCnt[4] = {6, 4, 2, 4};
    int iChCnt = 0 ;
    int iDIIdx = 0;
    int iTestResult = 0x01;
    int iOverAllResult = 0x01;
    int iRetval = 0;
    int iChainIdx = 0;
    int iChIdx = 0;

    float fLoadVolt[3] = {0.0f};
    float f232Volt = 0.0f;
    float f232Curr = 0.0f;
    float fADCVolt = 0.0f;

    float fPSUVolt = 0.0f;
    float fPSUCurr = 0.0f;
    float fPSU_UV = 0.0f;
    float fPSU_OV = 0.0f;

    QString qsPSChainRef;
    QString qsRLYRef;
    int iRlyObsSts;
    QString qsDIChRef;
    int iDIObsSts;
    int iPSUIdx = 0;

    *out_piStatus = LINS_TEST_FAIL;

    for(iChIdx = 0; iChIdx < 4; iChIdx++)
    {
        if((iChIdx == 0) || (iChIdx == 3))
        {
            if(iChIdx == 0)
            {
                iPSUIdx = in_iPSUIdx;
            }
            else
            {
                iPSUIdx = iChIdx;
                readPowerRating(iPSUIdx);
            }

            fPSUVolt = m_SPSUConfig[iPSUIdx].m_fNominalVolt;
            fPSUCurr = m_SPSUConfig[iPSUIdx].m_fCurrentLimit;
            fPSU_UV = m_SPSUConfig[iPSUIdx].m_fUnderVolt;
            fPSU_OV = m_SPSUConfig[iPSUIdx].m_fOverVolt;

            do
            {
                iTestResult = 0x01;
                m_bRetryOnFailure = false;
                iRetval = m_obj_CPSUWrapper->DP_PSU_VoltCurrConfig(DP_PSU_DAISY_CHAIN_MODE, fPSUVolt, fPSUCurr, iPSUIdx+1);
                if(iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Voltage-Current Configuration failed", iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                        qsErrorDesc.sprintf("%s\nConfigured Value for Output Voltage: %.2f, Output Current: %.2f\nError Value: %d\n%s", qsErrorDesc.toLatin1().data(), fPSUVolt, fPSUCurr, iRetval, qsPSUError.toLatin1().data());
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : PSU Voltage-Current Configuration Skipped", iPSUIdx+1);
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
            }while(m_bRetryOnFailure && m_bPauseOnFailure);
            msleep(DP_PSU_RESTTIME);

            //Configure Over Voltage and Under Voltage
            do
            {
                m_bRetryOnFailure = false;
                iRetval = m_obj_CPSUWrapper->DP_PSU_OV_UV_Config(fPSU_OV, fPSU_UV, iPSUIdx+1);
                if(iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Over Voltage & Under Voltage Configuration Failed", iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                        qsErrorDesc.sprintf("%s\nConfigured Over Voltage: %.2f, Under Voltage: %.2f\nError Value: %d\n%s", qsErrorDesc.toLatin1().data(), fPSU_OV, fPSU_UV, iRetval, qsPSUError.toLatin1().data());
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : PSU Overflow & Underflow Configuration Skipped", iPSUIdx+1);
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
            } while(m_bRetryOnFailure);
            msleep(DP_PSU_RESTTIME);

            //Enable PSU out
            do
            {
                m_bRetryOnFailure = false;
                iRetval = m_obj_CPSUWrapper->DP_PSU_Output(DP_PSU_DAISY_CHAIN_MODE, DP_PSU_OUTPUT_ON, iPSUIdx+1);
                if(iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON failed", iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                        qsErrorDesc.sprintf("%s\nConfigured Output Voltage: %.2f, Output Current: %.2f\nError Value: %d\n%s", qsErrorDesc.toLatin1().data(), m_SPSUConfig[iPSUIdx].m_fMaxVolt, m_SPSUConfig[iPSUIdx].m_fCurrentLimit, iRetval, qsPSUError.toLatin1().data());
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : PSU PSU Output ON Skipped", iPSUIdx+1);
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
            } while (m_bRetryOnFailure);
            msleep(DP_PSU_RESTTIME);

            do
            {
                m_bRetryOnFailure = false;
                iRetval = m_obj_CPSUWrapper->DP_PSU_Measure_Ouput(&f232Volt, &f232Curr, iPSUIdx+1);
                if(iRetval)
                {
                    qsErrorDesc.sprintf("PSU%d : PSU Measure Output failed", iPSUIdx+1);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        m_obj_CPSUWrapper->DP_PSU_GetErrorMessage(iRetval, &qsPSUError);
                        qsErrorDesc += qsPSUError;
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : PSU Measure Output Skipped", iPSUIdx+1);
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                        return;
                    }
                }
            } while (m_bRetryOnFailure);
            msleep(DP_PSU_RESTTIME);
        }

        if(iChIdx == 0)
        {
            iDIIdx = 0;
        }
        else
        {
            iDIIdx += iDIChnCnt[iChIdx -1];
        }

        ucDIOEnDis = DIO_ENABLE;
        for(iChCnt = 0; iChCnt < 2; iChCnt++)
        {
            if(iChIdx < 2)
            {
                qsRLYRef.sprintf("T1B%d",in_iPSUIdx+1);
                qsPSChainRef.sprintf("PS%d-OUT%d", iPSUIdx+1, iChIdx+1);
                qsRLYRef.append((iChIdx == 0)?"-RL4: ":"-RL3: ");
            }
            else if(iChIdx == 2)
            {
                qsRLYRef.sprintf("T1B%d",in_iPSUIdx+1);
                qsPSChainRef.sprintf("PS%d-Spare1", iPSUIdx+1);
                qsRLYRef.append("-RL2: ");
            }
            else
            {
                qsRLYRef.sprintf("T3B%d",in_iPSUIdx+1);
                qsPSChainRef.sprintf("PS4-TELE CMD");
                qsRLYRef.append("-RL2: ");
            }

            qsRLYRef.append((ucDIOEnDis == DIO_ENABLE)? "ON": "OFF");
            do
            {
                /*Set Relay Output*/
                do
                {
                    m_bRetryOnFailure = false;
                    iRetval = m_p3096Wrapper->SetOutput(g_usDOChannel[in_iPSUIdx][iChIdx],ucDIOEnDis);
                    if(iRetval)
                    {
                        qsErrorDesc.sprintf("PSU-%d : Unable to set Relay status", iPSUIdx+1);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                        if (m_bPauseOnFailure)
                        {
                            m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                            qsErrorDesc.sprintf("PSU%d : Unable to set Relay status in Board %d Group %d Channel %d\nError Value: %d\n%s", (iPSUIdx + 1), SID_GET_BOARD_NUM(g_usDOChannel[iPSUIdx][iChIdx]), (((SID_GET_CHANNEL(g_usDOChannel[iPSUIdx][iChIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usDOChannel[iPSUIdx][iChIdx])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                            emit Sig_PauseOnFailureMsg (qsErrorDesc);
                            if (m_bTestStop)
                            {
                                qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                            if (m_bSkipTestOnFailure)
                            {
                                qsErrorDesc.sprintf("PSU-%d : Set Relay status Skipped", iPSUIdx+1);
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                        }
                        else
                        {
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                } while(m_bRetryOnFailure);
                msleep(DP_DIO_RESTTIME);


                /* Relay Output Validation*/
                do
                {
                    m_bRetryOnFailure = false;
                    iRetval = m_p3096Wrapper->ReadInput(g_usDIChannel[in_iPSUIdx][iChIdx],&ucDIOSts);
                    if(iRetval)
                    {
                        qsErrorDesc.sprintf("DICh%2d : Unable to read Relay status", (SID_GET_CHANNEL(g_usDIChannel[in_iPSUIdx][iChIdx])));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                        if (m_bPauseOnFailure)
                        {
                            m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                            qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d\nError Value: %d\n%s", (iPSUIdx + 1), SID_GET_BOARD_NUM(g_usDIChannel[iPSUIdx][iChIdx]), (((SID_GET_CHANNEL(g_usDIChannel[iPSUIdx][iChIdx]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usDIChannel[iPSUIdx][iChIdx])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                            emit Sig_PauseOnFailureMsg (qsErrorDesc);
                            if (m_bTestStop)
                            {
                                qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                            if (m_bSkipTestOnFailure)
                            {
                                qsErrorDesc.sprintf("PSU-%d : Unable to read Relay status", iPSUIdx+1);
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                            if (m_bRetryOnFailure)
                            {
                                continue;
                            }
                        }
                        else
                        {
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                } while(m_bRetryOnFailure);

                iRlyObsSts = !ucDIOSts;

                //                qDebug("DO: %d, DI:%d  :: %d",SID_GET_CHANNEL(g_usDOChannel[in_iPSUIdx][iChIdx]), \
                //                       SID_GET_CHANNEL(g_usDIChannel[in_iPSUIdx][iChIdx]), ucDIOSts);

                if(ucDIOEnDis == ucDIOSts)
                {
                    m_bRetryOnFailure = false;
                    qsErrorDesc.sprintf("DI Read-Back Error : Exp = %d , Obs = %d", !ucDIOSts,ucDIOSts);
                    emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                    if (m_bPauseOnFailure)
                    {
                        emit Sig_PauseOnFailureMsg (qsErrorDesc);
                        if (m_bTestStop)
                        {
                            qsErrorDesc.sprintf ( "Telecommand PSU test for Connector J%d Stopped", in_iConnNo+1);
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                        if (m_bSkipTestOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU-%d : Unable to read Relay status", iPSUIdx+1);
                            emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }
                    else
                    {
                        iTestResult = LINS_TEST_FAIL;
                    }
                }
            } while(m_bRetryOnFailure);

            for(int iLoop = iDIIdx; iLoop < (iDIIdx + iDIChnCnt[iChIdx]); iLoop++)
            {
                iTestResult = LINS_TEST_PASS;
                qsDIChRef.sprintf("3096-B2-DI CH%d: %s", SID_GET_CHANNEL(g_usPSU_PinOut_DICh[iLoop]), (ucDIOEnDis == DIO_ENABLE)? "HIGH": "LOW");

                do
                {
                    m_bRetryOnFailure = false;
                    iRetval = m_p3096Wrapper->ReadInput(g_usPSU_PinOut_DICh[iLoop],&ucDIOSts);
                    if(iRetval)
                    {
                        qsErrorDesc.sprintf("TeleCmd-DICh%2d : Unable to read Relay status", (SID_GET_CHANNEL(g_usPSU_PinOut_DICh[iLoop])));
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                        if (m_bPauseOnFailure)
                        {
                            m_p3096Wrapper->GetLastErrorMsg(&iRetval, m_errString);
                            qsErrorDesc.sprintf("PSU%d : Unable to read Relay status in Board %d Group %d Channel %d\nError Value: %d\n%s", (iPSUIdx + 1), SID_GET_BOARD_NUM(g_usPSU_PinOut_DICh[iLoop]), (((SID_GET_CHANNEL(g_usPSU_PinOut_DICh[iLoop]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usPSU_PinOut_DICh[iLoop])) % LINS_3096_MAX_GRP_CHANNELS), iRetval, m_errString);
                            emit Sig_PauseOnFailureMsg (qsErrorDesc);
                            if (m_bTestStop)
                            {
                                qsErrorDesc.sprintf ( "Telecommand test for Connector J%d Stopped", in_iConnNo+1);
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                            if (m_bSkipTestOnFailure)
                            {
                                qsErrorDesc.sprintf("TeleCmd-DICh%2d : Read Relay status Skipped", (SID_GET_CHANNEL(g_usPSU_PinOut_DICh[iLoop])));
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                        }
                        else
                        {
                            iTestResult = LINS_TEST_FAIL;
                            return;
                        }
                    }

                    //                    qDebug("3096-B2-DI CH%d: %s", SID_GET_CHANNEL(g_usPSU_PinOut_DICh[iLoop]), (ucDIOSts == DIO_ENABLE)? "HIGH": "LOW");
                    iDIObsSts = ucDIOSts;

                    if(ucDIOEnDis != ucDIOSts)
                    {
                        iTestResult = 0x01;
                        m_bRetryOnFailure = false;
                        qsErrorDesc.sprintf("PSU%d : Exp = %d , Obj = %d", (in_iPSUIdx + 1), ucDIOEnDis, ucDIOSts);
                        emit Sig_PrintLog (qsErrorDesc, MSGTYPE_ERROR);
                        if (m_bPauseOnFailure)
                        {
                            qsErrorDesc.sprintf("PSU%d : Board %d Group %d Channel %d - Exp = %d, Obj = %d", (in_iPSUIdx + 1), SID_GET_BOARD_NUM(g_usPSU_PinOut_DICh[iLoop]), (((SID_GET_CHANNEL(g_usPSU_PinOut_DICh[iLoop]) - 1) / LINS_3096_MAX_GRP_CHANNELS) + 1), ((SID_GET_CHANNEL(g_usPSU_PinOut_DICh[iLoop])) % LINS_3096_MAX_GRP_CHANNELS), !ucDIOEnDis, ucDIOSts);
                            emit Sig_PauseOnFailureMsg (qsErrorDesc);
                            if (m_bTestStop)
                            {
                                qsErrorDesc.sprintf ("Interface test for Connector J%d Stopped", (in_iPSUIdx + 1));
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                            if (m_bSkipTestOnFailure)
                            {
                                qsErrorDesc.sprintf("PSU%d : Read Relay Status Skipped", (in_iPSUIdx + 1));
                                emit Sig_PrintLog (qsErrorDesc, MSGTYPE_INFO);
                                iTestResult = LINS_TEST_FAIL;
                                return;
                            }
                        }
                        else
                        {
                            iTestResult = LINS_TEST_FAIL;
                        }
                    }
                } while (m_bRetryOnFailure);

                iOverAllResult &= iTestResult;

                strcpy(m_SReportData.UTestData.SPSUOutData.qsPSChainRef, qsPSChainRef.toStdString().c_str());
                strcpy(m_SReportData.UTestData.SPSUOutData.qsRLYRef, qsRLYRef.toStdString().c_str());
                m_SReportData.UTestData.SPSUOutData.iRlyObsSts = iRlyObsSts;
                strcpy(m_SReportData.UTestData.SPSUOutData.qsDIChRef, qsDIChRef.toStdString().c_str());
                m_SReportData.UTestData.SPSUOutData.iDIObsSts = iDIObsSts;
                m_SReportData.m_iTestResult = iTestResult;
                reportUpdateTable(m_SReportData);
                logTestData(m_SReportData);
            }

            ucDIOEnDis = !ucDIOEnDis;
            msleep(500);
        }
        msleep(500);
    }

    *out_piStatus = iOverAllResult;
}
