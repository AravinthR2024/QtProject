#include "dp-lins-atp_testthread.h"
#include "dp-lins-atp_mainwindow.h"

void CTestThread::initReport()
{
    QString filename = "";
    m_qs1553BLogDir = "";
    QDir dir(DP_LINS_REPORT_DIR);
    if(!dir.exists())
    {
        dir.mkpath(DP_LINS_REPORT_DIR);
    }

    if(m_b1553BTestEnable)
    {
        m_qs1553BLogDir.append(DP_LINS_REPORT_1553B_LOG_DIR+"/");
        m_qs1553BLogDir.append(QDateTime::currentDateTime().toString("yyyy-MM-dd_HH-mm-ss"));
        m_qs1553BLogDir.append("_A8399-300_"+QString(m_SReportInfo.carrSerNo)+"_dp-lins-atp_report");
        dir.mkpath(m_qs1553BLogDir);
    }

    filename.append(DP_LINS_REPORT_DIR+"/");
    filename.append(QDateTime::currentDateTime().toString("yyyy-MM-dd_HH-mm-ss"));
    filename.append("_A8399-300_"+QString(m_SReportInfo.carrSerNo)+"_dp-lins-atp_report");
    filename.append(".html");

    m_qfReport.setFileName(filename);
    m_qfReport.open(QIODevice::WriteOnly);

    m_qfReport.write(DP_LINS_HTML_HEADER);
    m_qfReport.write(DP_LOGO);
    m_qfReport.write(DP_LINS_DOC_HEADER);

    reportAddInfo(m_SReportInfo);
}

void CTestThread::closeReport()
{
    m_qfReport.write("</ body>\n</ html>");
    m_qfReport.close();
}

void CTestThread::reportAddInfo(SREPORTINFO in_reportInfo)
{
    QString Str;

    Str.append("<br>\n<table style = \"border: none; width: 35%;\">\n");

    Str.append(REPORT_TABLEROW_START);
    Str.append("<th style = \"border: none; text-align:left;\">ATE Part No.</th><th style = \"border: none; text-align:center;\">:</th><td style = \"border: none; text-align:left;\">"+QString(in_reportInfo.carrPartNumber)+"</td>\n");
    Str.append(REPORT_TABLEROW_END);
    Str.append(REPORT_TABLEROW_START);
    Str.append("<th style = \"border: none; text-align:left;\">ATE Serial No.</th><th style = \"border: none; text-align:center;\">:</th><td style = \"border: none; text-align:left;\">"+QString(in_reportInfo.carrSerNo)+"</td>\n");
    Str.append(REPORT_TABLEROW_END);
    Str.append(REPORT_TABLEROW_START);
    Str.append("<th style = \"border: none; text-align:left;\">ATE Test Location</th><th style = \"border: none; text-align:center;\">:</th><td style = \"border: none; text-align:left;\">"+QString(in_reportInfo.carrTestLocation)+"</td>\n");
    Str.append(REPORT_TABLEROW_END);
    Str.append(REPORT_TABLEROW_START);
    Str.append("<th style = \"border: none; text-align:left;\">Application Version</th><th style = \"border: none; text-align:center;\">:</th><td style = \"border: none; text-align:left;\">"+QString(in_reportInfo.carrVersion)+"</td>\n");
    Str.append(REPORT_TABLEROW_END);
    Str.append(REPORT_TABLEROW_START);
    Str.append("<th style = \"border: none; text-align:left;\">Application Checksum</th><th style = \"border: none; text-align:center;\">:</th><td style = \"border: none; text-align:left;\">"+QString(in_reportInfo.carrChecksum)+"</td>\n");
    Str.append(REPORT_TABLEROW_END);
    Str.append(REPORT_TABLEROW_START);
    Str.append("<th style = \"border: none; text-align:left;\">Tested By</th><th style = \"border: none; text-align:center;\">:</th><td style = \"border: none; text-align:left;\">"+QString(in_reportInfo.carrUserName)+"</td>");
    Str.append(REPORT_TABLEROW_END);

    Str.append(REPORT_TABLE_END);

    m_qfReport.write(Str.toStdString().c_str());

}

void CTestThread::reportAddSection(int TestCaseId, int iIdx)
{
    QString Str;
    QString qstrTestName;

    switch(TestCaseId)
    {
    case DP_J1_PSU1_OUT1_Test: qstrTestName = QString::number(iIdx)+ ". J1 : PS1-OUT1 Output"; break;
    case DP_J1_PSU1_OUT2_Test: qstrTestName = QString::number(iIdx)+ ". J1 : PS1-OUT2 Output"; break;
    case DP_J1_PSU1_DEMG_Test: qstrTestName = QString::number(iIdx)+ ". J1 : PS1-DEMAG Output"; break;
    case DP_J1_PSU_TELE_CMD_Test: qstrTestName = QString::number(iIdx)+ ". J1 : PS4-TELECMD Output"; break;
    case DP_J1_TELECOMMAND_Test:
    {
        switch(m_SReportData.m_iSubTestId)
        {
        case 0 : qstrTestName = QString::number(iIdx)+ ". J1 : Telecommand Loopback Test"; break;
        case 1 : qstrTestName = QString::number(iIdx)+ "." + QString::number(m_SReportData.m_iSubTestId)+ \
                    " J1 : Status Input Loopback Test"; break;
        }
    } break;
    case DP_J1_THERMISTORCH1: qstrTestName = QString::number(iIdx)+ ". J1 : Thermistor Interface Test"; break;
    case DP_J1_THERMISTORCH2: qstrTestName = QString::number(iIdx)+ ". J1 : Thermistor Interface Test"; break;
    case DP_J1_THERMISTORCH3: qstrTestName = QString::number(iIdx)+ ". J1 : Thermistor Interface Test"; break;
    case DP_J1_THERMISTORCH4: qstrTestName = QString::number(iIdx)+ ". J1 : Thermistor Interface Test"; break;

    case DP_J2_PSU2_OUT1_Test: qstrTestName = QString::number(iIdx)+ ". J2 : PS2-OUT1 Output"; break;
    case DP_J2_PSU2_OUT2_Test: qstrTestName = QString::number(iIdx)+ ". J2 : PS2-OUT2 Output"; break;
    case DP_J2_PSU2_DEMG_Test: qstrTestName = QString::number(iIdx)+ ". J2 : PS2-Spare1 Output"; break;
    case DP_J2_PSU_TELE_CMD_Test: qstrTestName = QString::number(iIdx)+ ". J2 : PS4-TELECMD Output"; break;
    case DP_J2_TELECOMMAND_Test:
    {
        switch(m_SReportData.m_iSubTestId)
        {
        case 0 : qstrTestName = QString::number(iIdx)+ ". J2 : Telecommand Loopback Test"; break;
        case 1 : qstrTestName = QString::number(iIdx)+ "." + QString::number(m_SReportData.m_iSubTestId)+ \
                    " J2 : Status Input Loopback Test"; break;
        }
    } break;
    case DP_J2_THERMISTORCH1: qstrTestName = QString::number(iIdx)+ ". J2 : Thermistor Interface Test"; break;
    case DP_J2_THERMISTORCH2: qstrTestName = QString::number(iIdx)+ ". J2 : Thermistor Interface Test"; break;
    case DP_J2_THERMISTORCH3: qstrTestName = QString::number(iIdx)+ ". J2 : Thermistor Interface Test"; break;
    case DP_J2_THERMISTORCH4: qstrTestName = QString::number(iIdx)+ ". J2 : Thermistor Interface Test"; break;

    case DP_J3_PSU3_OUT1_Test: qstrTestName = QString::number(iIdx)+ ". J3 : PS3-OUT1 Output"; break;
    case DP_J3_PSU3_OUT2_Test: qstrTestName = QString::number(iIdx)+ ". J3 : PS3-OUT2 Output"; break;
    case DP_J3_PSU3_DEMG_Test: qstrTestName = QString::number(iIdx)+ ". J3 : PS3-Spare1 Output"; break;
    case DP_J3_PSU_TELE_CMD_Test: qstrTestName = QString::number(iIdx)+ ". J3 : PS4-TELECMD Output"; break;
    case DP_J3_TELECOMMAND_Test:
    {
        switch(m_SReportData.m_iSubTestId)
        {
        case 0 : qstrTestName = QString::number(iIdx)+ ". J3 : Telecommand Loopback Test"; break;
        case 1 : qstrTestName = QString::number(iIdx)+ "." + QString::number(m_SReportData.m_iSubTestId)+ \
                    " J3 : Status Input Loopback Test"; break;
        }
    } break;
    case DP_J3_THERMISTORCH1: qstrTestName = QString::number(iIdx)+ ". J3 : Thermistor Interface Test"; break;
    case DP_J3_THERMISTORCH2: qstrTestName = QString::number(iIdx)+ ". J3 : Thermistor Interface Test"; break;
    case DP_J3_THERMISTORCH3: qstrTestName = QString::number(iIdx)+ ". J3 : Thermistor Interface Test"; break;
    case DP_J3_THERMISTORCH4: qstrTestName = QString::number(iIdx)+ ". J3 : Thermistor Interface Test"; break;

    case DP_J4_SPAREDIO_TEST: qstrTestName = QString::number(iIdx)+ ". J4 : Spare DIO Loopback Test"; break;

    case DP_J1_PSU1_PINOUT_TEST: qstrTestName = QString::number(iIdx)+ ". J1 : Power Supply Pin Validation Test"; break;
    case DP_J2_PSU2_PINOUT_TEST: qstrTestName = QString::number(iIdx)+ ". J2 : Power Supply Pin Validation Test"; break;
    case DP_J3_PSU3_PINOUT_TEST: qstrTestName = QString::number(iIdx)+ ". J3 : Power Supply Pin Validation Test"; break;
    }

    Str.append(REPORT_TAG_H2(qstrTestName + ":(Time: "+ QDateTime::currentDateTime().toString("dd-MMM-yyyy HH:mm") + ")"));
    m_qfReport.write(Str.toStdString().c_str());
}

void CTestThread::reportInsertTable(int in_Load, int TestCaseId)
{
    QString Str;

    Str.sprintf(REPORT_TABLE_START);

    m_qfReport.write(Str.toStdString().c_str());
    reportAddTableHeader(in_Load, TestCaseId);
}

void CTestThread::reportAddTableHeader(int in_Load, int in_TestCaseId)
{
    QString qsHeader;
    QString qsSubHeader;

    if((in_TestCaseId >= DP_J1_PSU1_PINOUT_TEST) && (in_TestCaseId <= DP_J3_PSU3_PINOUT_TEST))
    {
        in_TestCaseId = DP_J1_PSU1_PINOUT_TEST;
    }

    if(in_TestCaseId == DP_J4_SPAREDIO_TEST)
    {
        in_TestCaseId = DP_J1_TELECOMMAND_Test;
    }

    if((in_TestCaseId >= DP_J3_TELECOMMAND_Test) && (in_TestCaseId <= DP_J3_THERMISTORCH4))
    {
        in_TestCaseId -= 18;
    }

    if((in_TestCaseId >= DP_J2_TELECOMMAND_Test) && (in_TestCaseId <= DP_J2_THERMISTORCH4))
    {
        in_TestCaseId -= 9;
    }

    if((in_TestCaseId >= DP_J1_THERMISTORCH1)&&(in_TestCaseId <= DP_J1_THERMISTORCH4))
    {
        in_TestCaseId = DP_J1_THERMISTORCH1;
    }

    in_TestCaseId = in_TestCaseId + 1;

    QFile config;

    if(in_Load)
    {
        config.setFileName(":/html/html/withloadtables.cfg");
    }
    else
    {
        config.setFileName(":/html/html/noloadtables.cfg");
    }

    if(config.open(QIODevice::ReadOnly))
    {
        while(!config.atEnd())
        {
            QByteArray line = config.readLine();
            if(line.contains("**"))
            {
                QStringList Items = QString(line).split(',');

                if(in_TestCaseId ==  QString(Items.at(0)).mid(2).toInt())
                {
                    int rowcnt = QString(Items.at(2)).toInt();
                    qsHeader.append(REPORT_TABLEROW_START);

                    for(int iHeadIttr = 0; iHeadIttr < rowcnt; iHeadIttr++)
                    {
                        QStringList headers = QString(config.readLine()).split(',');
                        if(headers.count() == 4)
                        {
                            qsHeader.append("<th rowspan = \""+headers.at(1)+"\" colspan = \""+headers.at(2)+"\" style=\"background-color:#ededed\">"+headers.at(0)+"</th>\n");
                            int SubHeadcnt = QString(headers.at(2)).toInt();

                            if(SubHeadcnt > 1)
                            {
                                iHeadIttr += SubHeadcnt;
                                if(qsSubHeader.isEmpty())
                                {
                                    qsSubHeader.sprintf(REPORT_TABLEROW_START);
                                }

                                for(int iSubheadIttr = 0; iSubheadIttr < SubHeadcnt; iSubheadIttr++)
                                {
                                    QStringList subHeaders = QString(config.readLine()).split(',');
                                    if(subHeaders.count() == 4)
                                    {
                                        qsSubHeader.append("<th rowspan = \""+subHeaders.at(1)+"\" colspan = \""+subHeaders.at(2)+"\" style=\"background-color:#ededed\">"+subHeaders.at(0)+"</th>\n");
                                    }
                                }
                            }
                        }
                    }
                    qsHeader.append(REPORT_TABLEROW_END);

                    qsSubHeader.append(REPORT_TABLEROW_END);
                    qsHeader.append(qsSubHeader);
                }
            }
        }
        config.close();
    }

    m_qfReport.write(qsHeader.toStdString().c_str());
}

void CTestThread::reportUpdateTable(SReportStruct in_SReportData)
{
    QString Str;
    QString qsTemp;
    int iRLYIdx = 0;
    int iPSUIdx = 1;

    if(in_SReportData.m_iTestCaseId >= DP_J1_PSU1_PINOUT_TEST)
    {
        in_SReportData.m_iTestCaseId = DP_J1_PSU1_PINOUT_TEST;
    }

    if(in_SReportData.m_iTestCaseId == DP_J4_SPAREDIO_TEST)
    {
        in_SReportData.m_iTestCaseId = DP_J1_TELECOMMAND_Test;
    }

    if((in_SReportData.m_iTestCaseId >= DP_J3_PSU3_OUT1_Test) && (in_SReportData.m_iTestCaseId <= DP_J3_THERMISTORCH4))
    {
        iPSUIdx = 3;
        in_SReportData.m_iTestCaseId -= 18;
    }

    if((in_SReportData.m_iTestCaseId >= DP_J2_PSU2_OUT1_Test) && (in_SReportData.m_iTestCaseId <= DP_J2_THERMISTORCH4))
    {
        iPSUIdx = 2;
        in_SReportData.m_iTestCaseId -= 9;
    }

    if(in_SReportData.m_iTestCaseId == DP_J1_PSU1_OUT1_Test)
    {
        iRLYIdx = 4;
    }
    else if(in_SReportData.m_iTestCaseId == DP_J1_PSU1_OUT2_Test)
    {
        iRLYIdx = 3;
    }
    else
    {
        iRLYIdx = 2;
    }

    Str.append(REPORT_TABLEROW_START);
    switch(in_SReportData.m_iTestCaseId)
    {
    case DP_J1_PSU1_OUT1_Test:
    case DP_J1_PSU1_OUT2_Test:
    case DP_J1_PSU1_DEMG_Test: {
        Str.append(REPORT_TABLE_TXT_FIXED(QString::number(in_SReportData.UTestData.SPsuData.m_fConfigVolt,'f',2)));
        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fPSU232Volt));
        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fPSUADCVolt));
        qsTemp.sprintf("T1B%d-RL%d : ",iPSUIdx,iRLYIdx);
        qsTemp.append((in_SReportData.UTestData.SPsuData.m_ucExpRelaySts == LINSCM_ENABLE)?"OFF":"ON");
        Str.append(REPORT_TABLE_TXT_FIXED(qsTemp));
        qsTemp = (in_SReportData.UTestData.SPsuData.m_ucRelayStatus == LINSCM_ENABLE)?"OFF":"ON";
        Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
        qsTemp = (in_SReportData.m_iLoadStatus == LINSCM_ENABLE)?"With Load":"No Load";
        Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fLoadVolt1));
        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fLoadVolt2));
        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fLoadVolt3));

        if((in_SReportData.UTestData.SPsuData.m_ucCurrLimitNA) || \
                (in_SReportData.UTestData.SPsuData.m_ucRelayStatus == LINSCM_ENABLE))
        {
            Str.append(REPORT_TABLE_TXT_FIXED("NA"));
        }
        else
        {
            Str.append(REPORT_TABLE_TXT_FIXED(QString::number(in_SReportData.UTestData.SPsuData.m_fExpMinCurr,'f',2) + " - " + \
                                              QString::number(in_SReportData.UTestData.SPsuData.m_fExpMaxCurr,'f',2)));
        }

        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fPSU232Curr));
        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fLoadCurr1));
        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fLoadCurr2));
        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fLoadCurr3));
        Str.append(in_SReportData.m_iTestResult?REPORT_RESULT_PASS:REPORT_RESULT_FAIL);
    } break;

    case DP_J1_PSU_TELE_CMD_Test: {
        Str.append(REPORT_TABLE_TXT_FIXED(QString::number(in_SReportData.UTestData.SPsuData.m_fConfigVolt,'f',2)));
        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fPSU232Volt));
        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fPSUADCVolt));
        qsTemp.sprintf("T3B%d-RL2 : ",iPSUIdx);
        qsTemp.append((in_SReportData.UTestData.SPsuData.m_ucExpRelaySts == LINSCM_ENABLE)?"OFF":"ON");
        Str.append(REPORT_TABLE_TXT_FIXED(qsTemp));
        qsTemp = (in_SReportData.UTestData.SPsuData.m_ucRelayStatus == LINSCM_ENABLE)?"OFF":"ON";
        Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
        qsTemp = (in_SReportData.m_iLoadStatus == LINSCM_ENABLE)?"With Load":"No Load";
        Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fLoadVolt1));
        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fLoadVolt2));
        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fLoadVolt3));

        if((in_SReportData.UTestData.SPsuData.m_ucCurrLimitNA) || \
                (in_SReportData.UTestData.SPsuData.m_ucRelayStatus == LINSCM_ENABLE))
        {
            Str.append(REPORT_TABLE_TXT_FIXED("NA"));
        }
        else
        {
            Str.append(REPORT_TABLE_TXT_FIXED(QString::number(in_SReportData.UTestData.SPsuData.m_fExpMinCurr,'f',2) + " - " + \
                                              QString::number(in_SReportData.UTestData.SPsuData.m_fExpMaxCurr,'f',2)));
        }

        Str.append(REPORT_TABLE_VAL_FLOAT(in_SReportData.UTestData.SPsuData.m_fPSU232Curr));
        Str.append(in_SReportData.m_iTestResult?REPORT_RESULT_PASS:REPORT_RESULT_FAIL);
    } break;

    case DP_J1_TELECOMMAND_Test: {
        if(in_SReportData.m_iSubTestId == 0)
        {
            qsTemp.sprintf("3096-B2-DO-CH%02d",in_SReportData.UTestData.STeleCmdData.m_ucDOChnNo);
            Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
            qsTemp.sprintf("3096-B2-DI-CH%02d",in_SReportData.UTestData.STeleCmdData.m_ucDIChnNo);
            Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucExpOFFSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(REPORT_TABLE_TXT_FIXED(qsTemp));
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucObsOFFSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucExpONSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(REPORT_TABLE_TXT_FIXED(qsTemp));
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucObsONSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
            Str.append(in_SReportData.m_iTestResult?REPORT_RESULT_PASS:REPORT_RESULT_FAIL);
        }
        else
        {
            qsTemp.sprintf("3096-B2-DI-CH%02d",in_SReportData.UTestData.STeleCmdData.m_ucDIChnNo);
            Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
            qsTemp.sprintf("3096-B2-DO-CH%02d",in_SReportData.UTestData.STeleCmdData.m_ucDOChnNo);
            Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucExpOFFSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(REPORT_TABLE_TXT_FIXED(qsTemp));
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucObsOFFSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucExpONSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(REPORT_TABLE_TXT_FIXED(qsTemp));
            qsTemp = (!in_SReportData.UTestData.STeleCmdData.m_ucObsONSts == DIO_ENABLE)?"HIGH":"LOW";
            Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
            Str.append(in_SReportData.m_iTestResult?REPORT_RESULT_PASS:REPORT_RESULT_FAIL);
        }
    } break;

    case DP_J1_THERMISTORCH1:
    case DP_J1_THERMISTORCH2:
    case DP_J1_THERMISTORCH3:
    case DP_J1_THERMISTORCH4: {
        qsTemp.sprintf("1123-B%d-CH%d",in_SReportData.UTestData.SThermodata.m_ucBrdNo, \
                       in_SReportData.UTestData.SThermodata.m_ucChnNo);
        Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
        qsTemp.sprintf("SWT%d-Position%2d",in_SReportData.UTestData.SThermodata.m_ucSWNum, \
                       in_SReportData.UTestData.SThermodata.m_ucSWPos);
        Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
        qsTemp.sprintf("%.2f",in_SReportData.UTestData.SThermodata.m_dObsRes);
        Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
        qsTemp.sprintf("%.2f +/-%.1f",in_SReportData.UTestData.SThermodata.m_dExpTemp, \
                       in_SReportData.UTestData.SThermodata.m_dTolTemp);
        Str.append(REPORT_TABLE_TXT_FIXED(qsTemp));
        qsTemp.sprintf("%.2f",in_SReportData.UTestData.SThermodata.m_dObsTemp);
        Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
        Str.append(in_SReportData.m_iTestResult?REPORT_RESULT_PASS:REPORT_RESULT_FAIL);
    } break;

    case DP_J1_PSU1_PINOUT_TEST:{
        Str.append(REPORT_TABLE_TXT_FIXED(in_SReportData.UTestData.SPSUOutData.qsPSChainRef));
        Str.append(REPORT_TABLE_TXT_FIXED(in_SReportData.UTestData.SPSUOutData.qsRLYRef));
        qsTemp = (in_SReportData.UTestData.SPSUOutData.iRlyObsSts != LINSCM_ENABLE)?"OFF":"ON";
        Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
        Str.append(REPORT_TABLE_TXT_FIXED(in_SReportData.UTestData.SPSUOutData.qsDIChRef));
        qsTemp = (in_SReportData.UTestData.SPSUOutData.iDIObsSts == DIO_ENABLE)?"HIGH":"LOW";
        Str.append(REPORT_TABLE_VAL_TEXT(qsTemp));
        Str.append(in_SReportData.m_iTestResult?REPORT_RESULT_PASS:REPORT_RESULT_FAIL);
    }break;
    }
    Str.append(REPORT_TABLEROW_END);

    m_qfReport.write(Str.toStdString().c_str());
}

void CTestThread::reportFinishTable()
{
    QString Str;

    Str.sprintf(REPORT_TABLE_END);

    m_qfReport.write(Str.toStdString().c_str());
}
