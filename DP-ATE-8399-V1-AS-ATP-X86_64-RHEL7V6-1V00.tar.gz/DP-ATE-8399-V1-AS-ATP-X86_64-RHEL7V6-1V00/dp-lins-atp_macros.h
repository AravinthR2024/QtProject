#ifndef DPLINSATP_MACROS_H
#define DPLINSATP_MACROS_H


enum TESTCASE_HIGHLIGHT{
    DP_TEST_INPROGRESS = 1,
    DP_TEST_COMPLETED,
    DP_TEST_PASS,
    DP_TEST_FAIL,
    DP_TEST_RESET,
};

enum{
    DP_1553B_BASE_ERROR = -3000,
    DP_1553B_ERR_BC_ERROR_FLAG_SET,
    DP_1553B_ERR_BC_FORMAT_ERROR,
    DP_1553B_ERR_BC_NO_RESP_TIME_OUT,
    DP_1553B_ERR_RT_ERROR_FLAG_SET,
    DP_1553B_ERR_RT_FORMAT_ERROR,
    DP_1553B_ERR_RT_NO_RESP_TIME_OUT,
    DP_1553B_ERR_MT_ERROR_FLAG_SET,
    DP_1553B_ERR_MT_FORMAT_ERROR,
    DP_1553B_ERR_MT_NO_RESP_TIME_OUT,
    DP_1553B_ERROR_DATA,
    DP_PWR_SUPPLY_END_VOLT_ERROR,
    DP_PACKAGE_END_VOLT_ERROR,
    DP_RELAY_STATE_ERROR,
    DP_DISCRETE_ERROR,
};

enum DP_TEST_CASE{
    DP_J1_PSU1_OUT1_Test = 0,
    DP_J1_PSU1_OUT2_Test,
    DP_J1_PSU1_DEMG_Test,
    DP_J1_PSU_TELE_CMD_Test,
    DP_J1_TELECOMMAND_Test,
    DP_J1_THERMISTORCH1,
    DP_J1_THERMISTORCH2,
    DP_J1_THERMISTORCH3,
    DP_J1_THERMISTORCH4,

    DP_J2_PSU2_OUT1_Test,
    DP_J2_PSU2_OUT2_Test,
    DP_J2_PSU2_DEMG_Test,
    DP_J2_PSU_TELE_CMD_Test,
    DP_J2_TELECOMMAND_Test,
    DP_J2_THERMISTORCH1,
    DP_J2_THERMISTORCH2,
    DP_J2_THERMISTORCH3,
    DP_J2_THERMISTORCH4,

    DP_J3_PSU3_OUT1_Test,
    DP_J3_PSU3_OUT2_Test,
    DP_J3_PSU3_DEMG_Test,
    DP_J3_PSU_TELE_CMD_Test,
    DP_J3_TELECOMMAND_Test,
    DP_J3_THERMISTORCH1,
    DP_J3_THERMISTORCH2,
    DP_J3_THERMISTORCH3,
    DP_J3_THERMISTORCH4,

    DP_J4_SPAREDIO_TEST,

    DP_J1_PSU1_PINOUT_TEST,
    DP_J2_PSU2_PINOUT_TEST,
    DP_J3_PSU3_PINOUT_TEST,

    DP_1553B_Internal_selfTest,
    DP_1553B_Terminal_Test,
    DP_1553B_Combined_Mode_Test,
    DP_1553B_Sync_Test,
    DP_1553B_Async_Test,

    DP_RS232_CH1_Loopback_Test,
    DP_RS232_CH2_Loopback_Test,
    DP_RS232_CH1_CH2_Loopback_Test,

    DP_COS_Power_Test,
    DP_WDT_Alarm_Test,
    DP_Bypass_Test,
    DP_Emergency_Switch_Test,
    DP_LINS_TESTCASE_MAX ,//43
};

#define DP_REPORT_TC_STS_READBACK   98

#define DP_REPORT_NAME             "dp-lins-atp"
#define DP_SYNC_REPORT_NAME        "dp-lins-atp_sync"

#define DP_FILE_ATP_CONFIG          qApp->applicationDirPath()+"/config/LINS_CM_ATPConfiguration.ini"
#define DP_FILE_ATP_AUTH          qApp->applicationDirPath()+"/config/authfile"

#define DP_PSU_CURRENT_ON_ADC(Conf_Volt)        (Conf_Volt/m_fLLSloadImpedance)

#define LOG_SPACES_THERM "     "
#define LOG_SPACES_INTER "        "
#define LOG_SPACES_BEGIN "    "

#define DIO_ENABLE  1
#define DIO_DISABLE 0

#define LINSCM_ENABLE  1
#define LINSCM_DISABLE 0

#define LINS_TEST_FAIL  0
#define LINS_TEST_PASS  1

#define MSGTYPE_INFO    0
#define MSGTYPE_SUCCESS 1
#define MSGTYPE_ERROR   2
#define MSGTYPE_TEXT    3
#define MSGTYPE_QUEST   4

#define DP_DIO_RESTTIME     100
#define DP_ADC_RESTTIME     100
#define DP_PSU_RESTTIME     1000

#define DP_DIO_MAX_CHN   48

#define DP_1553B_ZERO                                           0
#define DP_1553B_ONE                                            1
#define DP_1553B_TWO                                            2
#define DP_1553B_THREE                                          3
#define DP_1553B_FOUR                                           4
#define DP_1553B_FIVE                                           5
#define DP1553BXT_BIST_RESET                                    0
#define DP1553BXT_BIST_NOT_RUNNING                              1
#define DP1553BXT_BIST_INPROGRESS                               2
#define DP1553BXT_COMPLETE                                      3
#define DP_MIN_SA_VAL                                          16
#define DP_MAX_SA_VAL                                          31
#define DP_BC_TIME_TAG_RES                                     0

#define DP1553BXT_EXT_TRIG                                      1

#define DP_1553B_START                                          1
#define DP_1553B_STOP                                           0
#define DP_1553B_UNBLOCK_WAIT_TRUE                              1
#define DP_1553B_UNBLOCK_WAIT_FALSE                             0

#define DP_1553B_BC_MODE_TRUE                                   1
#define DP_1553B_BC_MODE_FALSE                                  0
#define DP_1553B_RT_MODE_TRUE                                   1
#define DP_1553B_RT_MODE_FALSE                                  0
#define DP_1553B_MT_MODE_TRUE                                   1
#define DP_1553B_MT_MODE_FALSE                                  0

#define DP_1553B_RT_COMM_RX_TYPE                                0
#define DP_1553B_RT_COMM_TX_TYPE                                1

#define DP_TIME_TAG_RES_SELECTION                              0

#define DP_MAX_VOLT_SUPPLY_TEST                                 4
#define DP_MAX_MAX_PSU                                          1

#define DP_1553B_MAX_DATA_BLOCKS                                20
#define DP_1553B_MAX_MSG_BLOCKS                                 20
#define DP_1553B_HOST_MSG_BUF_SIZE                              1024
#define DP_1553B_MAX_CHANNEL_SEL                                3
#define DP_1553B_RT_CONFIG_OPTION                               0x63
#define DP_1553B_RT_RESPONSE_TIME                               50
#define DP_1553B_FRAME_TIME                                     2000
#define DP_1553B_FRAME_COUNT                                    20
#define DP_1553B_WAIT_FOR_MESSAGE                               5000000
#define DP_1553B_SA_MASK                                        0xFFFFFFFFF
#define DP1553BXT_RT_MSGTYPE_RX                                 0x02

#define DP_1553B_BC_RT                                          0
#define DP_1553B_RT_BC                                          8
#define DP_1553B_RT_RT                                          1

#define DP_1553B_BUS_A                                          1
#define DP_1553B_BUS_B                                          0

#define DP_1553B_SA_ONE                                         1

#define DP1553BXT_SYNC_MNR_FRAME_ID                              490
#define DP1553BXT_SYNC_MJR_FRAME_ID                              29

#define DP_1553B_HIGH_PRIORITY_MSG_CNT                          1
#define DP_1553B_HIGH_PRIORITY_SEL                              1
#define DP_1553B_LOW_PRIORITY_SEL                               2
#define DP_ENABLE_EXT_TRIGGER                                   1
#define DP_DISABLE_EXT_TRIGGER                                  0

#define DP_DISCRETE_MAX_CHANNEL_NO                              8

#define TOTAL_PSU                       4
#define TOTAL_RS232_COM                 2

/* Manual Test*/

#define DP_COS_TEST_RL_EXP_STS      0
#define DP_COS_TEST_RL_OBS_STS      1
#define DP_COS_TEST_LED_EXP_STS     2
#define DP_COS_TEST_LED_OBS_STS     3
#define DP_COS_TEST_ME_COS_IN_V     4
#define DP_COS_TEST_ME_COS_OUT_V    5
#define DP_COS_TEST_RES             6


#define DP_BPECOS_BP_STS        0
#define DP_BPECOS_BP_LED_STS    1
#define DP_BPECOS_ECOS_LED_STS  2
#define DP_BPECOS_COS_V         3
#define DP_BPECOS_ME_COS_V      4
#define DP_BPECOS_RLY_STS       5
#define DP_BPECOS_RES           6


#define DP_TOL_PSU_CONF_VOLT        0.5
#define DP_TOL_PSU_LOAD_VOLT        1.0

#define DP_TOL_PSU_LLS_CONF_CURR    0.1
#define DP_TOL_PSU_LLS_LOAD_CURR    0.1

#define DP_TOL_PSU_RST_CONF_CURR    0.5
#define DP_TOL_PSU_RST_LOAD_CURR    0.5

#define DP_TOL_PSU_DPU_CONF_CURR    0.2
#define DP_TOL_COS_ADC_OUT_VOLT     2.0

#define TEST_COSPSU_ON_VOLT         28.0f
#define TEST_COSPSU_OFF_VOLT        0.0f
#define TEST_COSPSU_TOL_VOLT        2.0f
#define TEST_COSPSU_TOL_CURR        0.5f
#define TEST_THER_TOL_TEMP          2.0f
#define TEST_THER_TOL_RES           1.0f

#define TEST_COSPSU_ON_MIN          TEST_COSPSU_ON_VOLT - TEST_COSPSU_TOL_VOLT
#define TEST_COSPSU_ON_MAX          TEST_COSPSU_ON_VOLT + TEST_COSPSU_TOL_VOLT
#define TEST_COSPSU_OFF_MIN         TEST_COSPSU_OFF_VOLT - TEST_COSPSU_TOL_VOLT
#define TEST_COSPSU_OFF_MAX         TEST_COSPSU_OFF_VOLT + TEST_COSPSU_TOL_VOLT

#define TEST_WDT_PULSEWIDTH     700 /* milli Sec*/


/* Test Report */
#define DP_LINS_LOGFILE_DIR         qApp->applicationDirPath() + "/Reports/" +QDateTime::currentDateTime().toString("yyyy-MM-dd")
#define DP_LINS_REPORT_DIR          qApp->applicationDirPath() + "/Reports/" +QDateTime::currentDateTime().toString("yyyy-MM-dd")+"/ATP_TEST"
#define DP_LINS_MANUAL_REPORT_DIR   qApp->applicationDirPath() + "/Reports/" +QDateTime::currentDateTime().toString("yyyy-MM-dd")+"/PRE_ATP_TEST"

#define DP_LINS_REPORT_1553B_LOG_DIR      qApp->applicationDirPath() + "/Reports/" +QDateTime::currentDateTime().toString("yyyy-MM-dd")+ "/Logs"
#define DP_LINS_REPORT_1553B_ASYNC_DIR      "/AsynchronousTestLog"
#define DP_LINS_REPORT_1553B_SYNC_DIR       "/SyncStartTestLog"
#define DP_LINS_REPORT_1553B_COMBINED_DIR   "/CombinedModeTestLog"
#define DP_LINS_REPORT_1553B_TERMINAL_DIR   "/TerminalModeTestLog"

#define DP_LOGO                 "<img src= \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJoAAAAxCAMAAAAV+kAIAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAAwBQTFRFAAAAgAAAAIAAgIAAAACAgACAAICAwMDAwNzApsrwAAAAWRQRioqKk5OTnZ2dsikjtjYwurq6u0M+v7+/wFFMxMTExV5aymtnznl1zs7O04aD2JSR3aGe4eHh4q6s5ry668nI6+vr8NbV9eTj9fX1+vHx////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vwoKCkgICA/wAAAP8A//8AAAD//wD/AP//////7elzQQAAAylJREFUWEftWF2PozAM7Ps9JOKqFDUIokTx//+JN7YD/UjKdrurip6I1C6YSRiPx2HLgTY7Dm1mHJZL88HNSTv6BGRlYs1jp7ZahBV5GjXdckEP7xyP/f5hqu0duuwmDyrXCr/Tav9Ph+5eW/eab40/CPJHvqqTdvQG/+2JFYvxQGajw+3UXqjMR6mmduyPc57O81EfyuCTTkI6egY7RSv0NEO7+aAXlPcOMzFOrgPMn3WBzuPMAnDm6NWoVSNKfgr4dgqLdGIGo0fMD4FDI/XLEoiO+DDGBPnjgh8FaoP3RMGHHldywqFxjI6UrDGAaD7chxNNPqSvqfHtj5kU2WExnYLb6IHNuMk8QMvYJBhLNGkYDMr1QiCUGbjgzFGWxJ4uCTI1x5ftVS3kQtWhnJyuLjPPRPmOWo9VF/GZGkThPAAlyPElNbDCLQDO7AOm5uf0l4zXqJmkEkSIpeVbVAtDLsVAVPSIQj8BoQZaV+0kMJoyZWSi1GjUpK7GQ9WKEi6Bo5Z2ptZRN5ZQoQYZB9jxAm1QS+x/toezkaIkAorRCjWUmPJwR66mNttCKmXCmeskJp+pDRMvJSGhhpHYJvECbVDLaFfWiof2jDdIKVppA/bIlYFV+sprM7XI0CMNfiiTQI2b1ubJ+0sjzHBkX0GlsmLuBQV9S1+BmuFjoWY6mOSq71epQXoUaUxIFm0vG5FS85x/XBphuSmg4x20Sc2BDy/H1LANUZz7Pl0MvK6ap9xBIdmoNE+lZjMviX2ibClBjMObTAXVqfeqndE0vAcINRyLb7hV/ZOqwWDoy14zgmywqFLzJDs/LKauVUtybSroDbXoHD8zmCr4wnVKDT3BbSBcuV+vRstrYlV5GKRJoCCFdYSazbrLgbrukIUaHHgP5fOLaupz9A+m4dnQGVEfamdQO+UcYlqejcqvpuYM8isPqZssfnJy5DXLk7a1jm3c8qP+8/iJOL86d9uqbfhnS+O3++Vl5P5W8qE8jQv7q7/y0qcpmr7mrseWVQPb/eV80aBduQ8r6P5W8pV3uXsbvKDaX6jGH/mqTtrRG/y3Jz7doe2N+L3RfwKm4XY9Nn4DAAAAAElFTkSuQmCC\" alt=\"DataPatterns Logo\" style=\"float:left\">"

#define DP_LINS_HTML_HEADER    "<html>\n<head>\n<style>\ntitle {text-align: center;}\nbody {font-family: \"Arial\";}\n\
                                h1 {text-align: center;}\ntd {text-align: center;}\ntable{border: 1px solid black; margin-left: auto; margin-right: auto; border-collapse:collapse; width:80%}\n\
                                th {border: 1px solid black;padding: 3px;font-size: 18px;}\ntd {border: 1px solid black;padding: 3px;text-align:center;font-size:12pt;}\n\
                                div {margin-left: auto; margin-right: auto;}\n</style>\n\
                                <title>LINS-CM CHECKOUT ATP TEST REPORT</title>\n</head>\n<body>\n<div>"

#define DP_LINS_DOC_HEADER      "<div align=\"right\"><b>&#9733;Restricted &#169;Data Patterns (India) Limited</b></div><br><br><h1>LINS-CM CHECKOUT ATP TEST REPORT</h1>"

#define REPORT_TAG_H2(str)             "<h2>"+QString(str)+"</h2>\n"
#define REPORT_TABLE_START             "<br>\n<table>\n"
#define REPORT_TABLE_END               "</table>\n<br>\n"
#define REPORT_TABLEROW_START          "<tr>\n"
#define REPORT_TABLEROW_END            "</tr>\n"
#define REPORT_TABLE_VAL_FLOAT(fVal)   "<td>"+QString::number(fVal,'f',2)+"</td>\n"
#define REPORT_TABLE_VAL_TEXT(str)     "<td>"+QString(str)+"</td>\n"
#define REPORT_TABLE_TXT_FIXED(str)    "<td style=\"background-color:#ededed\">"+QString(str)+"</td>\n"
#define REPORT_RESULT_PASS             "<td><span style=\"font-weight:bold; color:GREEN;\">PASS</span></td>\n"
#define REPORT_RESULT_FAIL             "<td><span style=\"font-weight:bold; color:RED;\">FAIL</span></td>\n"
#define REPORT_TEXT_PASS(str)          "<td><span style=\"font-weight:bold; color:GREEN;\">"+QString(str)+"</span></td>\n"
#define REPORT_TEXT_FAIL(str)          "<td><span style=\"font-weight:bold; color:RED;\">"+QString(str)+"</span></td>\n"

#define LOG_NEW_START "\n===============================================================================================\n\n"

#define LOG_HEADER_PSU "PSU(RS232)Volt(V) PSU(ADC)Volt(V) RelaySts LoadStatus LoadVolt(V)     CurrLimit(A)    PSU Curr(A)  LoadCurr(A)   Result"
#define LOG_HEADER_TELECMD_PSU "PSU(RS232)Volt(V) PSU(ADC)Volt(V) RelaySts LoadStatus LoadVolt(V)   CurrLimit(A)    PSU Curr(A)  Result"
#define LOG_HEADER_TELECMD "Telecommand Channel        Readback Channel DO-Sts-ON-EXP  Observed DO-Sts-OFF-EXP  Observed    Result"
#define LOG_HEADER_TELECMD_READBACK "Status Input Channel       DO Channel       DO-Sts-ON-EXP  Observed DO-Sts-OFF-EXP  Observed    Result"
#define LOG_HEADER_THERMISTOR "Thermistor Channel  Switch Position     Measured Resistance    Expected Temperature   Observed       Result"
#define LOG_HEADER_PINOUT "PSU_Name            Relay-STS-EXP     Observed     DO-Sts-OFF-EXP            Observed     Result"

#endif // DPLINSATP_MACROS_H

