#include "dp-lins-systemdetails.h"
#include "ui_dp-lins-systemdetails.h"
#include <QMessageBox>
#include <QFile>
#include <QDir>
#include <QTextStream>
#include <QDebug>
#include <stdio.h>

CSystemDetails::CSystemDetails(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CSystemDetails)
{
    ui->setupUi(this);
    m_leSlNo = ui->le_SerialNo;
    m_leLoca = ui->le_Location;
    m_leTestBy = ui->le_TestedBy;

    m_ucContinue = 1;

    QStringList strList;
    QString strTemp;

    QFile file(qApp->applicationDirPath()+"/config/SystemDetails.txt");
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::information(this, "File not available", "<font size=\"3\"><b>Faild to open file.\nFile may be corrupted.</b></font>");
        ui->le_SerialNo->setText("");
        ui->le_Location->setText("");
        ui->le_TestedBy->setText("");
    }
    else
    {
        QTextStream in(&file);
        strTemp = in.readAll();
        file.close();
        strList = strTemp.split(",");

        ui->le_SerialNo->setText(strList.at(0));
        ui->le_Location->setText(strList.at(1));
        ui->le_TestedBy->setText(strList.at(2));
    }
}

CSystemDetails::~CSystemDetails()
{
    delete ui;
}

void CSystemDetails::on_pbUpdate_clicked()
{
    ui->le_SerialNo->setEnabled(true);
    ui->le_Location->setEnabled(true);
    ui->le_TestedBy->setEnabled(true);

    ui->le_SerialNo->setFocus();
}

void CSystemDetails::on_pbContinue_clicked()
{
    bool bEmptyFlag = false;
    unsigned char ucCase = 0;
    QString strField = "";

    if(ui->le_SerialNo->text().isEmpty())
    {
        bEmptyFlag = true;
        ucCase |= (1 << 0);
    }
    if(ui->le_Location->text().isEmpty())
    {
        bEmptyFlag = true;
        ucCase |= (1 << 1);
    }
    if(ui->le_TestedBy->text().isEmpty())
    {
        bEmptyFlag = true;
        ucCase |= (1 << 2);
    }

    if(bEmptyFlag)
    {
        switch(ucCase)
        {
            case 1: strField = "\"ATE Serial Number\" field is";
                    ui->le_SerialNo->setFocus();
                break;
            case 2: strField = "\"ATE Test Location\" field is";
                    ui->le_Location->setFocus();
                break;
            case 4: strField = "\"Tested by\" field is";
                    ui->le_TestedBy->setFocus();
                break;
            default: strField = "One or more fields are";
                break;
        }

        QMessageBox::information(this, "Empty Field", strField+" empty...!");
        return;
    }
    else
    {
        QString strTemp = "";

        QFile file(qApp->applicationDirPath()+"/config/SystemDetails.txt");
        if (!file.open(QIODevice::WriteOnly))
        {
            QMessageBox::information(this, "File not created", "<font size=\"3\"><b>Faild to Create file.</b></font>");
            return;
        }
        else
        {
            strTemp = ui->le_SerialNo->text()+","+ui->le_Location->text()+","+ui->le_TestedBy->text();
            QTextStream out(&file);
            out << strTemp;
            file.close();
        }
    }
    m_ucContinue = 0;

    this->close();
}

void CSystemDetails::ShowDialog()
{
    m_ucContinue = 1;

    ui->le_SerialNo->setEnabled(false);
    ui->le_Location->setEnabled(false);
    ui->le_TestedBy->setEnabled(false);

    show();
    setModal(true);
    exec();
}
