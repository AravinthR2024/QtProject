#ifndef DPLINSATP_STRUCTURES
#define DPLINSATP_STRUCTURES

#include <QString>
#include "dp-lins-atp_macros.h"
#include "includes/dp1553bxt_pro.h"

/***** PSU Config Details (added by Aravinth R) *****/


typedef struct _SDP_PSU_CONFIG
{
    QString m_strPSUName;
    float m_fNominalVolt;
    float m_fUnderVolt;
    float m_fOverVolt;
    float m_fCurrentLimit;
    float m_fMaxVolt;
    float m_fTestStartRange;
    float m_fTestStopRange;
    float m_fStepupRange;
}SDP_PSU_CONFIG;


/****************************************************/

typedef struct _SDP_PSU_TEST_INPUT
{
    QString qsTestName;
    QString qsReportName;
    unsigned char ucPSU_Id;
    unsigned short usRelay2sts;
    unsigned short usRelay3sts;
    unsigned short usRelay4sts;
    unsigned short usRelay2_Ctrl;
    unsigned short usRelay3_Ctrl;
    unsigned short usRelay4_Ctrl;
    unsigned short usPSU_Voltage;
    unsigned short usV2_ChNo;
    unsigned short usA2_ChNo;
    unsigned short usV3_ChNo;
    unsigned short usA3_ChNo;
    unsigned short usV4_ChNo;
    unsigned short usA4_ChNo;
    float fOpVolt;
    float fOverVolt;
    float fUnderVolt;
    float fCurrentLimit;
    float fMaxVolt;

}SDP_PSU_Test;

typedef struct _SDP_JIG1_PSU_INPUT
{
    QString qsTestName;
    QString qsReportName;
    unsigned char ucPSU_Id;
    unsigned short usRelay1sts;
    unsigned short usRelay1_Ctrl;
    unsigned short usPSU_Voltage;
    unsigned short usV1_ChNo;
    unsigned short usA1_ChNo;
    float fOpVolt;
    float fOverVolt;
    float fUnderVolt;
    float fCurrentLimit;
    float fMaxVolt;
}SDP_Demag_PSU;

typedef struct _SDP_RST_PSU_INPUT
{
    QString qsTestName;
    QString qsReportName;
    unsigned char ucPSU_Id;
    unsigned short usRelay1sts;
    unsigned short usRelay1_Ctrl;
    unsigned short usPSU_Voltage;
    unsigned short usV1_ChNo;
    unsigned short usV2_ChNo;
    float fOpVolt;
    float fOverVolt;
    float fUnderVolt;
    float fCurrentLimit;
    float fMaxVolt;
}SDP_RESET_PSU;

typedef struct _SDP_RST_PULSE_INPUT
{
    QString qsTestName;
    QString qsReportName;
    unsigned short usRelay[4];
    unsigned short usAND_StsSigId[4];
    unsigned short usNAND_StsSigId[4];
}SDP_RESET_PULSE;

typedef struct _SDP_DPU_PSU_INPUT
{
    QString qsTestName;
    QString qsReportName;
    unsigned char ucPSU1_Id;
    unsigned char ucPSU2_Id;
    float fOpVolt;
    float fOverVolt;
    float fUnderVolt;
    float fCurrentLimit;
}SDP_DPU_PSU;

typedef struct _SDP_ASYNC_TEST
{
    SDP1553BXT_BC_MSG SDP_BC_Msg;
    int iMsgID;
    unsigned short usFirstMsgTT;
    unsigned short usBCChNo;
    unsigned short usRTChNo;
    unsigned short usMT1ChNo;
    unsigned short usMT2ChNo;
    int iResult;

}SDP_ASYNC_TRANS_Test;

typedef struct _SDP_INTERNAL_TEST
{
    unsigned char ucSinglePortRslt;
    unsigned char ucRAM_BIST_Rslt;
    unsigned char ucROM_BIST_Rslt;
    unsigned char ucRAM_AddrBus_Rslt;
    unsigned char ucRAM_DataBus_Rslt;
    unsigned char ucIntergrityTest;

}SDP_INTERNAL_SELF_Test;

typedef struct _SDP_SYNC_TEST
{
    unsigned long long usFirstMsgTT[4];
    unsigned long long usLastMsgTT[4];
    unsigned short u16TimetagRes[4];
    unsigned short u16WordCount[4];
    unsigned short usFirstFailCount;
    unsigned short usLastFailCount;
    QString qsSyncResult;
}SDP_SYNC_Test;

typedef struct _SDP_All_MSG
{
    SDP1553BXT_BC_MSG DP_1553B_BC_Strct;
    SDP1553BXT_RT_MSG DP_1553B_RT_Strct;
    SDP1553BXT_MT_MSG DP_1553B_MT1_Strct;
    SDP1553BXT_MT_MSG DP_1553B_MT2_Strct;
    SDP_ASYNC_TRANS_Test SDP_Async_Test_Rslt;
    SDP_INTERNAL_SELF_Test SDP_InternalSelf_Test[4];
    SDP_SYNC_Test sDP_Sync_Reslt;
    int iBCError;
    int iRTError;
    int iRTDATAError;
    int iMT1Error;
    int iMT2Error;
    int iTestNo;
    int iTerminalTestStart;
    int iCombinedTestStart;
    int iAsyncTestStart;
    int iPSUAndIOError;
    int iDiscreteSNOTestNo;
    unsigned short usTimeToNextMsg;
    unsigned short usMsgCnt;
    unsigned short usMaxDiff;
    unsigned char ucBusSel;
    unsigned char ucCommTypeTxRx;
    QString qsRs485TxData;
    QString qsRs485RxData[4];
    QString qsRs485Rslt[4];
    QString qsRS232TxData;
    QString qsRS232RxData;
    QString qsRS232RxData2;
    QString qsRS232Rslt;
    QString qsResetPulseTestRslt[8];

}SDP_All_Msg;

typedef struct _SDP_AUTOMODE_INPUT
{
    //COM1 Config Details
    unsigned char ucCOM1_StopBit;
    unsigned short usCOM1_Baudrate;
    unsigned char ucCOM1_DataBit;
    unsigned char ucCOM1_Parity;
    unsigned char ucCOM1_DataType;
    unsigned char ucCOM1_PatternData;

    //COM2 Config Details
    unsigned char ucCOM2_StopBit;
    unsigned short usCOM2_Baudrate;
    unsigned char ucCOM2_DataBit;
    unsigned char ucCOM2_Parity;
    unsigned char ucCOM2_DataType;
    unsigned char ucCOM2_PatternData;

    //1553B Config Details
    char carr1553B_BusSelect[4];
    char c1553B_Ch2_Bus;
    char c1553B_Ch3_Bus;
    char c1553B_Ch4_Bus;
    unsigned char uc1553B_DataType;
    unsigned char uc1553B_PatternData;

}SDP_AUTOMODE_INPUT;

typedef struct _stestdetails{

    unsigned char ucRootTestCaseNo;
    char carrRootTestName[63];

    unsigned char ucTestCaseNo;
    unsigned char ucTestSelected;
    unsigned char ucTestResult;
    char carrTestName[61];

}STEST_DETAILS, *PSTEST_DETAILS;


typedef struct DP1553BXT_VINFO
{
    unsigned short usNoofBoards;
    unsigned short usOpenBoard;
}S_1553B_BoardStatus;

typedef struct AsynHPMsg
{
    unsigned char ucHPTxallbit;
    unsigned short usHPdataarr[512];
    unsigned short usTotalMsg;
    unsigned short usIndex;
}SAsynHPMsg,*PSAsynHPMsg;

typedef struct AsynLPMsg
{
    unsigned char ucLPTxallbit;
    unsigned short usLPdataarr[512];
    unsigned short usTotalMsg;
    unsigned short usIndex;
}SAsynLPMsg,*PSAsynLPMsg;

typedef struct _spsutestreport
{
    unsigned char m_ucExpRelaySts;
    unsigned char m_ucRelayStatus;
    unsigned char m_ucCurrLimitNA;
    float m_fConfigVolt;
    float m_fPSU232Volt;
    float m_fPSUADCVolt;
    float m_fRlyOPVolt;
    float m_fLoadVolt1;
    float m_fLoadVolt2;
    float m_fLoadVolt3;
    float m_fExpMinCurr;
    float m_fExpMaxCurr;
    float m_fPSU232Curr;
    float m_fPSUADCCurr;
    float m_fLoadCurr1;
    float m_fLoadCurr2;
    float m_fLoadCurr3;
}SPSUTestReport;

typedef struct _stelecmdtestreport
{
    unsigned char m_ucDOChnNo;
    unsigned char m_ucDIChnNo;
    unsigned char m_ucExpONSts;
    unsigned char m_ucObsONSts;
    unsigned char m_ucExpOFFSts;
    unsigned char m_ucObsOFFSts;
}STCTestReport;

typedef struct _sthermotestreport
{
    double m_dObsRes;
    double m_dObsTemp;
    double m_dExpRes;
    double m_dExpTemp;
    double m_dTolRes;
    double m_dTolTemp;
    unsigned char m_ucBrdNo;
    unsigned char m_ucChnNo;
    unsigned char m_ucSWNum;
    unsigned char m_ucSWPos;
}SThermoTestReport;

typedef struct _spsuouttestreport{
    char qsPSChainRef[26];
    char qsRLYRef[26];
    int  iRlyObsSts;
    char qsDIChRef[26];
    int  iDIObsSts;
}SPSUOutTestReport;

typedef struct _sreportinfo{
    char carrSerNo[12];
    char carrUserName[24];
    char carrTestLocation[24];
    char carrPartNumber[28];
    char carrVersion[12];
    char carrChecksum[24];
}SREPORTINFO;

typedef struct _sreportstruct{

    union{
        SPSUTestReport SPsuData;
        STCTestReport STeleCmdData;
        SThermoTestReport SThermodata;
        SPSUOutTestReport SPSUOutData;
    }UTestData;
    int m_iLoadStatus;
    int m_iTestResult;
    int m_iTestCaseId;
    int m_iSubTestId;
}SReportStruct;

typedef struct _sglobal{
    unsigned long ulAppChecksum;
    STEST_DETAILS STestCaseDetails[DP_LINS_TESTCASE_MAX];
}SGLOBAL;

#endif // DPLINSATP_STRUCTURES

