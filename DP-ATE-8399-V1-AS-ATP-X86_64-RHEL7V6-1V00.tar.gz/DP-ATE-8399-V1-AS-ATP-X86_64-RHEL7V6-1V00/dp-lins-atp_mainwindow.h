#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTreeWidgetItem>
#include <QTableWidgetItem>
#include <QStyledItemDelegate>
#include <QPainter>
#include <QMessageBox>
#include <QDebug>
#include <QEvent>
#include <QDateTime>
#include <QDir>
#include <QSettings>
#include <QFileInfo>
#include <QString>
#include <QTextBrowser>
#include <QtPrintSupport/QPrinter>
#include <QCloseEvent>
#include <QComboBox>
#include <QLineEdit>
#include <QSize>
#include <QToolButton>
#include <QSerialPortInfo>
#include <QDesktopServices>
#include <QUrl>
#include <QTimer>
#include <QScrollBar>
#include <QApplication>

#include "dp-lins-atp_includes.h"
#include "dp-lins-atp_about.h"
#include "dp-lins-atp_testthread.h"
#include "dp-lins-systemdetails.h"

#include "./User_Authentication/allusermanagement.h"
#include "./User_Authentication/changepassword.h"
#include "./includes/macros.h"


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    QFile m_qfActionLog;
    QString m_qsLogFileName;

    QTimer m_SurTimer;
    QTimer m_WDTimer;
    QTimer m_STemTimer;

    int m_iTestCaseIndex;
    int m_iOverAllResult;
    int m_iTopLevelResult;
    CTestThread *m_qProcTestThread;
    CDP_PSU_Wrapper *obj_CDP_PSU_Wrapper;
    cDP1553BWrapper m_objC1553BWrapper;

    CAbout m_objAbout;
    CSystemDetails *m_objSystDet;

    void *m_vpADCHandle[4];
    unsigned short m_usCards;
    void *m_vpCarrierHandle;
    unsigned char m_ucGainScanList[16];
    unsigned char m_ucRawDataEnDis;

    unsigned char m_uc1553BExpSlotNo;
    unsigned char m_uc1553BExpBusNo;

    SDPCPCI3096APP_DeviceLocation m_S3096ExpDevLocation[LINS_MAX_CPCI3096_BRDS];
    SDPMM1105APP_DeviceLocation m_S1105ExpDevLocation[LINS_MAX_MM1105_BRDS];
    SDPMM1123APP_DeviceLocation m_S1123ExpDevLocation[LINS_MAX_MM1123_BRDS];
    PSDPMM1105_DEVICE_LOCATION m_pSAllDevLocDetails;
    SDPMM1105_ADC_CONFIGURATION m_sADCConfigure;
    SDPMMCRDRV_DEVICE_LOCATION m_sCarrDeviceOpenInfo;
    PDPMM1105_DeviceLocation m_out1105BrdDetails;
    PDPMM1123_DeviceLocation m_out1123BrdDetails;
    PSDP1553_DEVICE_LOC  m_pS1553B_DevLoc[4];

    DPCPCI3096_Wrapper     m_obj3096Board;
    DPMM1105_Wrapper       m_obj1105Board;
    DPMM1123_Wrapper       m_obj1123Board;

    QTableWidgetItem *qtblItem_Header;
    QTableWidgetItem *qtblItem_Data;

    PSDPCPCI3096_DeviceLocation m_out3096BrdDetails;

    int m_iPSUAddr;
    int m_iPSUMode;
    QByteArray m_qbaPSUSerialport;
    long m_lPSUBaudrate;
    int m_iPSUDatabits;
    int m_iPSUParity;
    int m_iPSULoc_Global;

    int m_iADCPacerSource;
    int m_iADCSourceType;
    int m_iADCTrgType;
    int m_iADCContTrg;
    int m_iADCExtTrg;
    int m_iADCTimePeriod;
    float m_fADCPacerFreq;
    QBrush qcSubTest;
    QBrush qcRootTest;

    QString getErrorMessage(int in_iErrNo);
private slots:
    void closeEvent (QCloseEvent *event);

    void on_pb_Proceed_clicked();

    void on_pb_StartStopTest_clicked();

    void on_actionAutoTest_triggered();

    void on_pb_ManualTstBtn_clicked();

    void on_actionManualTest_triggered();

    void on_actionDetection_Status_triggered();

    void on_actionAbout_triggered();

    void on_actionChange_Password_triggered();
    
    void on_actionChannel_Mapping_triggered();

    void on_cb_PauseOnFailure_stateChanged(int in_iState);

    void on_actionEquipment_Configuration_Details_triggered();

private:
    Ui::MainWindow *ui;
    bool m_bIsTestTypeAuto;
    bool m_bIsTestActive;
    bool m_bPropertiesVisible;
    QTreeWidgetItem *qtrwParentItem;
    int m_iRowIndex;
    QList<int> Sizes;
    
    CAllUserManagement *m_objUserManagement;
    CChangePassword *m_objChangePassword;

public slots:

    void WatchDogTimerReset();

    void SurveillanceTimerReset();

    void SurveillanceError();

    void resetTreeWidget();

    void resetTreeWidgetColor(QTreeWidgetItem *item);

    void getTestSelection(QTreeWidgetItem *item, unsigned char *TestSelList, int *Cnt);

    void highlightTest(QTreeWidgetItem *item, int in_iTestIdx, int in_iHiType, int *in_iStatus);

    void onPSU_ADC_Test();

    void Board_Init();

    void Update_Board_Details();

    void DP_TestCase_Checked(QTreeWidgetItem *item, int column);

    int DP_1553B_BoardInit();

    int DP3096_BoardInit();

    int DP_1105_BoardInit();

    int DP_MM1123_BoardInit();

    void DisplayError(int in_iErrNo);

    void UpdateResult(int iTestId, bool bResult);

    void HighLightTestCase(int iTestCaseNo);

    void ReHighLightTestCase(int iTestCaseNo);

    void GetUserInput(int iTestCase, QString in_Message);

    void OnTestThreadFinish();

    void ConfigFileCreation();

    bool ReadConfigFile();

    void PrintActionLog(QString qDisplayData, int iMsgType);

    void DisplayMsg(QString qDisplayData, int iMsgType);

    void DisplayPauseOnFailMsg(int in_iErrorNo);

    void PauseOnFailurMessage(QString in_strError);
};


#endif // MAINWINDOW_H
