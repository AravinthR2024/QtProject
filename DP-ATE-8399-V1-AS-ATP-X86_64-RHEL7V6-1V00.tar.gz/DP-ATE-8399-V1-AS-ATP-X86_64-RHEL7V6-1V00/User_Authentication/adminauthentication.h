#ifndef ADMINAUTHENTICATION_H
#define ADMINAUTHENTICATION_H

#include <QDialog>
//#include "cusermanagement.h"
#include <QCryptographicHash>
#include "usermanagement.h"
#include <QDir>
#include <QMessageBox>
#include "allusermanagement.h"

namespace Ui {
class CAdminAuthentication;
}

class CAdminAuthentication : public QDialog
{
    Q_OBJECT

public:
    explicit CAdminAuthentication(QWidget *parent = 0);
    ~CAdminAuthentication();
    bool m_bIsAdmin;
    QString m_strUsrName;

private:
    Ui::CAdminAuthentication *ui;

private slots:

    void closeEvent(QCloseEvent *in_CloseEvent);
    void on_pbCancel_clicked();
    void on_pbLogin_clicked();
};

#endif // ADMINAUTHENTICATION_H
