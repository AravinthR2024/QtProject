#ifndef CUSERMANAGEMENT_H
#define CUSERMANAGEMENT_H

#include <QString>
#include <QCryptographicHash>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QByteArray>

#include "DP_UML_Error.h"
#include "DP_UML_FunMacro.h"
#include "DP_UML_Macro.h"

typedef struct
{
    char m_szUserName[32];          /*!< user name */
    char m_szUserPrevilege[16];     /*!< user previlege */
    char m_szUserPassword[64];      /*!< user password */
} S_USER_DETAILS;


class CUserManagement
{
public:
    char DP_UML_GetNoOfUsers(int *in_iNoOfUsers);

    char DP_UML_ValidateUser(char *in_szUserName, char *in_szPassword, char in_cPrevilage);

    char DP_UML_AddNewUser(char *in_szUserName, char *in_szNewPassword, char *in_szConfirmPassword, char *in_szPrevilage);

    char DP_UML_ChangePassword(char *in_szUserName, char *in_szOldPassword, char *in_szNewPassword, char *in_szConfirmPassword);

    char DP_UML_ChangePasswordAdmin(char *in_szUserName, char *in_szNewPassword, char *in_szConfirmPassword);

    char DP_UML_DeleteUser(char *in_szUserName);

    int DP_UML_IsUserNameExists(char *in_szUserName);

    char DP_UML_GetUserPrivilage(char *in_szUserName);

    char DP_UML_GetAllUserDetails(S_USER_DETAILS in_SArrUsers[]);

    char DP_UML_Init_UMLLib(char in_ucMaxUsers, char in_ucMaxUsernamelen, char in_ucMaxPasslen, char in_ucMinUsernamelen, char in_ucMinPasslen, const char *in_szAuthFilename);

    void Encrypt(char *in_szArray, int in_iArraySize, char *out_szArray);

    void Decrypt(char *in_szArray, int in_iArraySize, char *out_szArray);

    int EncryptData(S_USER_DETAILS  *in_SUserDetailsTemp,S_USER_DETAILS *out_SUserDetailsEncoded);

    int DecryptData(S_USER_DETAILS  *in_SUserDetailsTemp ,S_USER_DETAILS *out_SUserDetailsDecoded);

    void UpdateAuthfile();

    int IsSpclCharExist(char *in_szData);

    int IsDigitExist(char *in_szData);

    int check_file_checksum(const char *in_szFileName);

    int update_file_checksum(const char *in_szFileName, int in_iNoOfUsers);
};

#endif // CUSERMANAGEMENT_H
