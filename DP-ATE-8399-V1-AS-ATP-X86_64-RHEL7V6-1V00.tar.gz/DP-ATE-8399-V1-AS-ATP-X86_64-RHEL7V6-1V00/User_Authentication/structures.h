#ifndef STRUCTURES
#define STRUCTURES

#include <QString>

typedef struct _S_USER_DATA
{
    QString m_sUserName;                        /*!< user name */
    QString m_sUserprevilage;                 /*!< user previlege */

}S_USER_DATA;

typedef struct _S_GLOBAL_HANDLES
{
    S_USER_DATA m_UserDetails;
}S_GLOBAL_HANDLES;

#endif // STRUCTURES
