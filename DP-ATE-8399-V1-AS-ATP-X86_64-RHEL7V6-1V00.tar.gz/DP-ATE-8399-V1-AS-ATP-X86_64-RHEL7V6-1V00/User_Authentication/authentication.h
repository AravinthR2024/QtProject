#ifndef AUTHENTICATION_H
#define AUTHENTICATION_H

#include <QDialog>
#include "QMessageBox"
#include <QCryptographicHash>
#include <QSharedMemory>
#include "structures.h"
#include "usermanagement.h"
#include "dp-lins-atp_macros.h"

namespace Ui {
class CAuthentication;
}

class CAuthentication : public QDialog
{
    Q_OBJECT

private:
    FILE *Afp;

public:
    explicit CAuthentication(QWidget *parent = 0);
    bool m_bAuth_Sts;
    bool lock();
    QString  m_strUsrname, m_strPwd,str;
    QMessageBox msgBox;
//    QString strUserName;

    ~CAuthentication();

private slots:

    void Msg_display(int in_iError);

    void LoginButtonEnaDis();

    void on_pbClose_clicked();

    void on_PB_Login_clicked();

    void on_LE_Pwd_textEdited();

    void on_le_Username_textChanged(const QString &in_str);

private:
    Ui::CAuthentication *ui;
    QSharedMemory *_singular;
};

#endif // AUTHENTICATION_H
