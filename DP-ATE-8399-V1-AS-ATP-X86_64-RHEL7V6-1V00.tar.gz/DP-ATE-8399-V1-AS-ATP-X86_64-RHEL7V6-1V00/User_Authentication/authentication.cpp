#include "authentication.h"
#include "ui_authentication.h"

QString g_strUsername;      /*! Global variable to store username */
char g_arrAuthfileName[500];
extern short g_sReturn;
S_GLOBAL_HANDLES g_Handles;

CAuthentication::CAuthentication(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CAuthentication)
{
    ui->setupUi(this);
    this->setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);
//    QDir dir;
//    QString strAuthFilePathName;
//    strAuthFilePathName.sprintf ("%s/%s", dir.absolutePath ().toStdString ().c_str (), "authfile");
//    strcpy(g_arrAuthfileName, strAuthFilePathName.toLatin1 ().data ());    //to provide filename for storing user details.

    QString strAuthFile = DP_FILE_ATP_AUTH;
    strcpy(g_arrAuthfileName, strAuthFile.toLatin1().data());
    CUserManagement manage;
    int iRetVal = manage.DP_UML_Init_UMLLib(255, 32, 32, 6, 6, g_arrAuthfileName);
    if (iRetVal == DP_UML_FILE_CORRUPTED)
    {
        QMessageBox :: information(this, "Error", "Authentication file corrupted", QMessageBox::Ok);
        exit(0);
    }
    //update_file_checksum();
    _singular = new QSharedMemory("USER_MANAGEMENT_CHECK", this);
    m_bAuth_Sts = false;
    ui->LE_Pwd->setFocus();
}

bool CAuthentication::lock()
{
    if(_singular->attach(QSharedMemory::ReadOnly)){
        _singular->detach();
        return false;
    }

    if(_singular->create(1))
        return true;

    return false;
}

CAuthentication::~CAuthentication()
{
    if(_singular->isAttached())
        _singular->detach();

    delete ui;
}

void CAuthentication::on_pbClose_clicked()
{
    this->close ();
}

void CAuthentication::Msg_display(int in_iError)
{
    switch(in_iError)
    {
    case DP_UML_NOT_VALID_USERNAME:
        QMessageBox :: information(this, "Error", "Invalid Username");
        break;
    case DP_UML_NOT_VALID_PASSWORD:
        QMessageBox :: information(this, "Error", "Invalid Password");
        break;
    case DP_UML_NOT_VALID_OLDPASSWORD:
        QMessageBox :: information(this, "Error", "Invalid Old Password");
        break;
    case DP_UML_NOT_VALID_CONFPASSWORD:
        QMessageBox :: information(this, "Error", "Invalid Confirm Password");
        break;
    case DP_UML_USER_ALREADY_EXIST:
        QMessageBox :: information(this, "Error", "User already exists");
        break;
    case DP_UML_USERNAME_LEN_MINERR:
        QMessageBox :: information(this, "Error", "Username must be of minimum 6 characters");
        break;
    case DP_UML_USERNAME_LEN_MAXERR:
        QMessageBox :: information(this, "Error", "Username must be less than 32 characters");
        break;
    case DP_UML_PASS_LEN_MINERR:
        QMessageBox :: information(this, "Error", "Password must be of minimum 6 characters");
        break;
    case DP_UML_PASS_LEN_MAXERR:
        QMessageBox :: information(this, "Error", "Password must be less than 32 characters");
        break;
    case DP_UML_USER_MAX_ERR:
        QMessageBox :: information(this, "Error", "Maximum number of users reached");
        break;
    case DP_UML_PASS_SPLCHAR_ERR:
        QMessageBox :: information(this, "Error", "Password must contain atleast one special character");
        break;
    case DP_UML_PASS_DIGIT_ERR:
        QMessageBox :: information(this, "Error", "Password must contain atleast one numeric character");
        break;
    case DP_UML_SPLCHAR_NAME_ERR:
        QMessageBox :: information(this, "Error", "Username must not contain any special characters other than '.'");
        break;
    case DP_UML_USERNAME_LEN_EMPTY:
        QMessageBox :: information(this, "Error", "Username field is empty");
        break;
    case DP_UML_PASS_LEN_EMPTY:
        QMessageBox :: information(this, "Error", "Password field is empty");
        break;
    case DP_UML_NEWPASS_LEN_EMPTY:
        QMessageBox :: information(this, "Error", "NewPassword field is empty");
        break;
    case DP_UML_CONFPASS_LEN_EMPTY:
        QMessageBox :: information(this, "Error", "ConfirmPassword field is empty");
        break;
    case DP_UML_FILE_CORRUPTED:
        QMessageBox :: information(this, "Error", "Authentication file corrupted", QMessageBox::Ok);
        break;
    case DP_UML_FILE_NOT_FOUND:
        QMessageBox :: information(this, "Error", "Authentication file not found", QMessageBox::Ok);
        break;
    case DP_UML_FILE_IS_EMPTY:
        QMessageBox :: information(this, "Error", "Authentication file is empty", QMessageBox::Ok);
        break;
    default:
        break;
    }
}

void CAuthentication::LoginButtonEnaDis()
{
    if(ui->le_Username->text().isEmpty() || ui->LE_Pwd->text().isEmpty())
    {
        ui->PB_Login->setDisabled(true);
    }
    else
    {
        ui->PB_Login->setEnabled(true);
    }
}


void CAuthentication::on_PB_Login_clicked()
{
    int iRetVal = 0;
    char cPrevilege = 0;
    CUserManagement manage;

//    strUserName = ui->le_Username->text();
    g_strUsername = ui->le_Username->text();
    g_Handles.m_UserDetails.m_sUserName = g_strUsername;

    QFile file(g_arrAuthfileName);
    if (file.size() != 0)
    {
        int iRetval = manage.check_file_checksum(g_arrAuthfileName);
        if (iRetval == DP_UML_FILE_CORRUPTED || iRetval == DP_UML_FILE_NOT_FOUND || iRetVal == DP_UML_FILE_IS_EMPTY)
        {
            if (iRetval == DP_UML_FILE_CORRUPTED)
            {
                QMessageBox :: information(this, "Error", "Authentication file corrupted", QMessageBox::Ok);
                exit(0);
            }
            else
            {
                QMessageBox :: information(this, "Error", "Authentication file not found", QMessageBox::Ok);
                exit(0);
            }
        }
    }

    iRetVal = manage.DP_UML_ValidateUser(ui->le_Username->text().toLatin1().data(), ui->LE_Pwd->text().toLatin1().data(), 0);

    if(iRetVal)
    {
        ui->LE_Pwd->clear();
        Msg_display(iRetVal);
    }
    else
    {
        cPrevilege = manage.DP_UML_GetUserPrivilage(ui->le_Username->text().toLatin1().data());

        if(cPrevilege == ADMIN_USER || cPrevilege == SUPER_USER)
        {
                g_Handles.m_UserDetails.m_sUserprevilage = SUPER_USER_STR;
        }
        else
        {
                g_Handles.m_UserDetails.m_sUserprevilage = NORMAL_USER_STR;
        }
        g_sReturn = 1;
        g_strUsername = ui->le_Username->text();
        m_bAuth_Sts = true;
        this->close();
    }
}

void CAuthentication::on_LE_Pwd_textEdited()
{
    LoginButtonEnaDis ();
}

void CAuthentication::on_le_Username_textChanged(const QString &in_str)
{
    if(in_str == " ")
    {
        ui->le_Username->setText("");
        return;
    }
    LoginButtonEnaDis();
}
