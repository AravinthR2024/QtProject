#ifndef ALLUSERMANAGEMENT_H
#define ALLUSERMANAGEMENT_H

#include <QDialog>
#include "adminauthentication.h"
#include <QDebug>
#include <QMessageBox>
#include<QCryptographicHash>
#include <QFile>
#include <QLineEdit>
#include "usermanagement.h"
#include "structures.h"
#include "authentication.h"

#define TAB_CHANGE_PASSWORD     0
#define TAB_ADD_USER            1
#define TAB_ADMIN_CONTROL       2

namespace Ui {
class CAllUserManagement;
}

class CAllUserManagement : public QDialog
{
    Q_OBJECT

public:
    explicit CAllUserManagement(QWidget *parent = 0);
    ~CAllUserManagement();

    class CAdminAuthentication *m_objAdminAuthWindow;
    class CAuthentication *m_objAuthWindow;

    QLineEdit *le_objUserName;
    char  m_strMsg[256];
    void updateuser();
    void displayMessage(int in_iError);

    void changePasswordTrigger();

public slots:

    void closeEvent(QCloseEvent *in_CloseEvent);

private slots:
    void on_pbAddUser_clicked();

    void on_pbClose_clicked();

    void on_pbAddUserOk_clicked();

    void on_pbAddUserCancel_clicked();

    void on_pbChangePassword_clicked();

    void on_pbChangePasswordOk_clicked();

    void on_pbChangePasswordCancel_clicked();

    void on_pbDeleteUser_clicked();

    void on_twAllUsers_cellClicked(int in_iRow);

    void on_leNewUserName_textChanged(const QString &in_strText);

    void on_twAllUsers_itemSelectionChanged();

private:
    Ui::CAllUserManagement *ui;
};

#endif // ALLUSERMANAGEMENT_H
