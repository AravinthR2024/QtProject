#include "usermanagement.h"


S_USER_DETAILS g_arrSUserDetails[255];
unsigned char key[DATA_SIZE_32], g_ucMaxUser, g_ucMaxUsernamelen, g_ucMaxPassLen, g_ucMinUsernamelen, g_ucMinPassLen;
unsigned int g_uiRecCount = DP_UML_INIT_VALUE;
char g_szAuthFileName[500];

char CUserManagement::DP_UML_GetNoOfUsers(int *in_iNoOfUsers)
{
    *in_iNoOfUsers = g_uiRecCount;

    return DP_UML_SUCCESS;
}

char CUserManagement::DP_UML_ValidateUser(char *in_szUserName, char *in_szPassword, char in_cPrevilage)
{
    Q_UNUSED(in_cPrevilage);

    int iLoop = DP_UML_INIT_VALUE;
    int iNoOfUsers = DP_UML_INIT_VALUE;

    DP_UML_GetNoOfUsers (&iNoOfUsers);

    /** Check username is empty */
    DP_UML_VALIDATE_USERNAME_EMPTY(strlen(in_szUserName));

    /** Check password is empty */
    DP_UML_VALIDATE_PASSWORD_EMPTY(strlen (in_szPassword));

    /** Check if the user is Administrator */
    if(strcasecmp(ADMIN_USERNAME, in_szUserName) == DP_UML_SUCCESS)
    {
        /** Validating Administrator password */
        if (strcmp(ADMIN_PASSWORD, in_szPassword) == DP_UML_SUCCESS)
        {
            return DP_UML_SUCCESS;
        }
    }

    /** Check if no user available */
    if (iNoOfUsers == DP_UML_INIT_VALUE)
    {
        return DP_UML_NOT_VALID_USERNAME;
    }

    /** Check username with special character */
    DP_UML_VALIDATE_SPCL_CHAR_USERNAME(in_szUserName);

    /** Check Max length username */
    DP_UML_VALIDATE_MAX_USERNAME_LEN(strlen (in_szUserName), g_ucMaxUsernamelen);

    /** Check Min length username */
    DP_UML_VALIDATE_MIN_USERNAME_LEN(strlen (in_szUserName), g_ucMinUsernamelen);

    /** Check Max and Min length of password other than administrator password */
    if (strcmp (ADMIN_PASSWORD, in_szPassword) != DP_UML_SUCCESS)
    {
        DP_UML_VALIDATE_MAX_PASSWORD_LEN(strlen (in_szPassword), g_ucMaxPassLen);

        DP_UML_VALIDATE_MIN_PASSWORD_LEN(strlen (in_szPassword), g_ucMinPassLen);
    }

    char szUserPasswordHash[DATA_SIZE_64];
    memset (szUserPasswordHash, 0, sizeof(char)*DATA_SIZE_64);
    qstrcpy (szUserPasswordHash, QCryptographicHash::hash (in_szPassword, QCryptographicHash::Sha256).toHex ());

    while (iLoop < g_uiRecCount) {
        /** Compare username with existing data */
        if (strcasecmp (g_arrSUserDetails[iLoop].m_szUserName, in_szUserName) == DP_UML_SUCCESS)
        {
            /** Compare password with existing data */
            if (strcmp (g_arrSUserDetails[iLoop].m_szUserPassword, szUserPasswordHash) == DP_UML_SUCCESS) {
                return DP_UML_SUCCESS;
            }
            else
            {
                return DP_UML_NOT_VALID_PASSWORD;
            }
        }
        iLoop++;
    }

    return DP_UML_NOT_VALID_USERNAME;
}

char CUserManagement::DP_UML_AddNewUser(char *in_szUserName, char *in_szNewPassword, char *in_szConfirmPassword, char *in_szPrevilage)
{
    /** Compare username with admin data */
    if (strcasecmp (ADMIN_USERNAME, in_szUserName) == DP_UML_SUCCESS)
    {
        /** Setting previlage as Administrator */
        strcpy (in_szPrevilage, ADMIN_USER_STR);
    }

    /** Check Max No of Users */
    DP_UML_VALIDATE_MAX_USER(g_uiRecCount, g_ucMaxUser);

    /** Check username is empty */
    DP_UML_VALIDATE_USERNAME_EMPTY(strlen(in_szUserName));

    /** Check Max length of username */
    DP_UML_VALIDATE_MAX_USERNAME_LEN(strlen (in_szUserName), g_ucMaxUsernamelen);

    /** Check Min length of username */
    DP_UML_VALIDATE_MIN_USERNAME_LEN(strlen (in_szUserName), g_ucMinUsernamelen);

    /** Check any special character in username */
    DP_UML_VALIDATE_SPCL_CHAR_USERNAME(in_szUserName);

    /** Check new password is empty or not */
    DP_UML_VALIDATE_NEWPASSWORD_EMPTY(in_szNewPassword);

    /** Check confirm password is empty or not */
    DP_UML_VALIDATE_CONFPASSWORD_EMPTY(in_szConfirmPassword);

    /** Check Max length of new password */
    DP_UML_VALIDATE_MAX_PASSWORD_LEN(strlen (in_szNewPassword), g_ucMaxPassLen);

    /** Check Min length of new password */
    if (strcasecmp (ADMIN_PASSWORD, in_szNewPassword) != DP_UML_SUCCESS)
    {
        DP_UML_VALIDATE_MIN_PASSWORD_LEN(strlen (in_szNewPassword), g_ucMinPassLen);
    }

    /** Check Max length of confirm password */
    DP_UML_VALIDATE_MAX_PASSWORD_LEN(strlen (in_szConfirmPassword), g_ucMaxPassLen);

    /** Check Min length of confirm password */
    if (strcasecmp (ADMIN_PASSWORD, in_szConfirmPassword) != DP_UML_SUCCESS)
    {
        DP_UML_VALIDATE_MIN_PASSWORD_LEN(strlen (in_szConfirmPassword), g_ucMinPassLen);
    }

    /** Check special characters available in new password */
    if (strcasecmp (ADMIN_PASSWORD, in_szNewPassword) != DP_UML_SUCCESS)
    {
        DP_UML_VALIDATE_SPCL_CHAR(in_szNewPassword);
    }

    /** Check any digit available in new password */
    if(strcasecmp (ADMIN_PASSWORD, in_szNewPassword) != DP_UML_SUCCESS)
    {
        DP_UML_VALIDATE_DIGIT(in_szNewPassword);
    }

    /** Check if username already exists */
    DP_UML_VALIDATE_USER_EXISTS(in_szUserName);

    /** Compare New password and Confirm password */
    DP_UML_VALIDATE_NEW_AND_CONF_PASSWORD(in_szNewPassword, in_szConfirmPassword);

    /* If all the validations passed */
    /** Copy the username in array */
    strcpy (g_arrSUserDetails[g_uiRecCount].m_szUserName, in_szUserName);

    /** Copy the password in array */
    char szPasswordHash[DATA_SIZE_64] = {"\0"};

    // Hash the password using SHA-256
    qstrcpy (szPasswordHash, QCryptographicHash::hash (in_szNewPassword, QCryptographicHash::Sha256).toHex ());
    strcpy (g_arrSUserDetails[g_uiRecCount].m_szUserPassword, szPasswordHash);

    /** Set user previlage */
    strcpy (g_arrSUserDetails[g_uiRecCount].m_szUserPrevilege, in_szPrevilage);

    /** Increment total number of users by 1 */
    g_uiRecCount++;

    /** Update the data into the authentication file */
    UpdateAuthfile ();

    return DP_UML_SUCCESS;
}

char CUserManagement::DP_UML_ChangePassword(char *in_szUserName, char *in_szOldPassword, char *in_szNewPassword, char *in_szConfirmPassword)
{
    unsigned int uiRecordIndex = DP_UML_INIT_VALUE;

//    /** If changing Admin password, Change password macro */
//    if (strcasecmp (in_szUserName, ADMIN_USERNAME) == DP_UML_SUCCESS)
//    {
//        if (strcmp (in_szOldPassword, ADMIN_PASSWORD) == DP_UML_SUCCESS)
//        {
//#undef ADMIN_PASSWORD
//#define ADMIN_PASSWORD in_szNewPassword
//        }
//    }

    /** Check username is empty or not */
    DP_UML_VALIDATE_USERNAME_EMPTY(strlen(in_szUserName));

    /** Check username has special characters */
    DP_UML_VALIDATE_SPCL_CHAR_USERNAME(in_szUserName);

    /** Check old password is empty or not */
    DP_UML_VALIDATE_PASSWORD_EMPTY(strlen(in_szOldPassword));

    /** Check new password is empty or not */
    DP_UML_VALIDATE_PASSWORD_EMPTY(strlen(in_szNewPassword));

    /** Check confirm password is empty or not */
    DP_UML_VALIDATE_PASSWORD_EMPTY(strlen(in_szConfirmPassword));

    /** Check max length of username */
    DP_UML_VALIDATE_MAX_USERNAME_LEN(strlen(in_szUserName), g_ucMaxUsernamelen);

    /** Check min length of username */
    DP_UML_VALIDATE_MIN_USERNAME_LEN(strlen(in_szUserName), g_ucMinUsernamelen);

    /** Check max length of old password */
    DP_UML_VALIDATE_MAX_PASSWORD_LEN(strlen(in_szOldPassword), g_ucMaxPassLen);

    /** Check min length of old password */
    if (strcasecmp(in_szUserName, ADMIN_USERNAME) != DP_UML_SUCCESS)
    {
        DP_UML_VALIDATE_MIN_PASSWORD_LEN(strlen(in_szOldPassword), g_ucMinPassLen);
    }

    /** Check max length of new password */
    DP_UML_VALIDATE_MAX_PASSWORD_LEN(strlen(in_szNewPassword), g_ucMaxPassLen);

    /** Check min length of new password */
    if (strcasecmp(in_szUserName, ADMIN_USERNAME) != DP_UML_SUCCESS)
    {
        DP_UML_VALIDATE_MIN_PASSWORD_LEN(strlen(in_szNewPassword), g_ucMinPassLen);
    }

    /** Check max length of confirm password */
    DP_UML_VALIDATE_MAX_PASSWORD_LEN(strlen(in_szConfirmPassword), g_ucMaxPassLen);

    /** Check min length of confirm password */
    if (strcasecmp(in_szUserName, ADMIN_USERNAME) != DP_UML_SUCCESS)
    {
        DP_UML_VALIDATE_MIN_PASSWORD_LEN(strlen(in_szConfirmPassword), g_ucMinPassLen);
    }

    /** Check special characters available in new password or not */
    if (strcasecmp(in_szUserName, ADMIN_USERNAME) != DP_UML_SUCCESS)
    {
        DP_UML_VALIDATE_SPCL_CHAR(in_szNewPassword);
    }

    /** Check digit available in new password or not */
    if (strcasecmp(in_szUserName, ADMIN_USERNAME) != DP_UML_SUCCESS)
    {
        DP_UML_VALIDATE_DIGIT(in_szNewPassword);
    }

    /** Compare new password and confirm password are equal */
    DP_UML_VALIDATE_NEW_AND_CONF_PASSWORD(in_szNewPassword, in_szConfirmPassword);

    /** Locate the index of record of the user */
    uiRecordIndex = DP_UML_IsUserNameExists (in_szUserName);

    if (uiRecordIndex != DP_UML_FAILURE)     // If user exists
    {
        char szOldPassHash[64] = {"\0"};
        char szNewPassHash[64] = {"\0"};
        // Encrypting Old Password
        qstrcpy (szOldPassHash, QCryptographicHash::hash (in_szOldPassword, QCryptographicHash::Sha256).toHex ());

        /** Comparing Old Password with existing password */
        if (strcmp(g_arrSUserDetails[uiRecordIndex].m_szUserPassword, szOldPassHash) == DP_UML_SUCCESS)
        {
            qstrcpy (szNewPassHash, QCryptographicHash::hash (in_szNewPassword, QCryptographicHash::Sha256).toHex ());
            strcpy (g_arrSUserDetails[uiRecordIndex].m_szUserPassword, szNewPassHash);  // Updating new password
        }
        else    // If old password does not match
        {
            return DP_UML_NOT_VALID_OLDPASSWORD;
        }
    }
    else    // If user does not exists
    {
        return DP_UML_NOT_VALID_USERNAME;
    }

    /** Update into authentication file */
    UpdateAuthfile ();

    return DP_UML_SUCCESS;
}

char CUserManagement::DP_UML_ChangePasswordAdmin(char *in_szUserName, char *in_szNewPassword, char *in_szConfirmPassword)
{
    unsigned int uiRecordIndex = DP_UML_INIT_VALUE;

    /** Check username is empty or not */
    DP_UML_VALIDATE_USERNAME_EMPTY(strlen(in_szUserName));

    /** Check username has special characters */
    DP_UML_VALIDATE_SPCL_CHAR_USERNAME(in_szUserName);

    /** Check new password is empty or not */
    DP_UML_VALIDATE_PASSWORD_EMPTY(strlen(in_szNewPassword));

    /** Check confirm password is empty or not */
    DP_UML_VALIDATE_PASSWORD_EMPTY(strlen(in_szConfirmPassword));

    /** Check max length of username */
    DP_UML_VALIDATE_MAX_USERNAME_LEN(strlen(in_szUserName), g_ucMaxUsernamelen);

    /** Check min length of username */
    DP_UML_VALIDATE_MIN_USERNAME_LEN(strlen(in_szUserName), g_ucMinUsernamelen);

    /** Check max length of new password */
    DP_UML_VALIDATE_MAX_PASSWORD_LEN(strlen(in_szNewPassword), g_ucMaxPassLen);

    /** Check min length of new password */
    DP_UML_VALIDATE_MIN_PASSWORD_LEN(strlen(in_szNewPassword), g_ucMinPassLen);

    /** Check max length of confirm password */
    DP_UML_VALIDATE_MAX_PASSWORD_LEN(strlen(in_szConfirmPassword), g_ucMaxPassLen);

    /** Check min length of confirm password */
    DP_UML_VALIDATE_MIN_PASSWORD_LEN(strlen(in_szConfirmPassword), g_ucMinPassLen);

    /** Check special characters available in new password or not */
    DP_UML_VALIDATE_SPCL_CHAR(in_szNewPassword);

    /** Check digit available in new password or not */
    DP_UML_VALIDATE_DIGIT(in_szNewPassword);

    /** Compare new password and confirm password are equal */
    DP_UML_VALIDATE_NEW_AND_CONF_PASSWORD(in_szNewPassword, in_szConfirmPassword);

    /** Locate the index of record of the user */
    uiRecordIndex = DP_UML_IsUserNameExists (in_szUserName);

    if (uiRecordIndex != DP_UML_FAILURE)     // If user exists
    {
        char szNewPassHash[64] = {"\0"};
        qstrcpy (szNewPassHash, QCryptographicHash::hash (in_szNewPassword, QCryptographicHash::Sha256).toHex ());

        /** Update the new password */
        strcpy (g_arrSUserDetails[uiRecordIndex].m_szUserPassword, szNewPassHash);
    }
    else        // If user does not exists
    {
        return DP_UML_NOT_VALID_USERNAME;
    }

    /** Update data into authentication file */
    UpdateAuthfile ();

    return DP_UML_SUCCESS;
}

char CUserManagement::DP_UML_DeleteUser(char *in_szUserName)
{
    unsigned int uiRecordIndex = DP_UML_INIT_VALUE;

    /** Check if username is empty or not */
    DP_UML_VALIDATE_USERNAME_EMPTY(strlen (in_szUserName));

    /** Check Max length of username */
    DP_UML_VALIDATE_MAX_USERNAME_LEN(strlen (in_szUserName), g_ucMaxUsernamelen);

    /** Check Min length of username */
    DP_UML_VALIDATE_MIN_USERNAME_LEN(strlen(in_szUserName), g_ucMinUsernamelen);

    /** Check username contains special characters */
    DP_UML_VALIDATE_SPCL_CHAR_USERNAME(in_szUserName);

    /** Location the index of the user in record */
    uiRecordIndex = DP_UML_IsUserNameExists (in_szUserName);

    if (uiRecordIndex != DP_UML_FAILURE)     // If user exists
    {
        /** Delete the user details */
        memmove (&g_arrSUserDetails[uiRecordIndex], &g_arrSUserDetails[uiRecordIndex + 1],\
                (g_uiRecCount - uiRecordIndex - 1) * sizeof(S_USER_DETAILS));

        /** Decrementing number of users by 1 */
        g_uiRecCount--;
    }
    else        // If user does not exists
    {
        return DP_UML_NOT_VALID_USERNAME;
    }

    /** Update the authentication file */
    UpdateAuthfile ();

    return DP_UML_SUCCESS;
}

int CUserManagement::DP_UML_IsUserNameExists(char *in_szUserName)
{
    int iLoop = DP_UML_INIT_VALUE;

    for (; iLoop < g_uiRecCount; iLoop++)
    {
        if (strcasecmp(g_arrSUserDetails[iLoop].m_szUserName, in_szUserName) == DP_UML_SUCCESS)
        {
            return iLoop;     /// Returning the position of the user
        }
    }

    /** If user not found, Return -1 */
    return DP_UML_FAILURE;
}

char CUserManagement::DP_UML_GetUserPrivilage(char *in_szUserName)
{
    int iLoop;

    for (iLoop = DP_UML_INIT_VALUE; iLoop < g_uiRecCount; iLoop++)
    {
        if (strcasecmp(g_arrSUserDetails[iLoop].m_szUserName, in_szUserName) == DP_UML_SUCCESS)
        {
            if (strcmp(g_arrSUserDetails[iLoop].m_szUserPrevilege, ADMIN_USER_STR) == DP_UML_SUCCESS)
            {
                return ADMIN_USER;
            }
            else if (strcmp(g_arrSUserDetails[iLoop].m_szUserPrevilege, SUPER_USER_STR) == DP_UML_SUCCESS)
            {
                return SUPER_USER;
            }
            else if (strcmp(g_arrSUserDetails[iLoop].m_szUserPrevilege, NORMAL_USER_STR) == DP_UML_SUCCESS)
            {
                return NORMAL_USER;
            }
            else
            {
                return DP_UML_NOT_VALID_PRIVILAGE;
            }
        }
    }

    /** If no user found */
    return DP_UML_FAILURE;
}

char CUserManagement::DP_UML_GetAllUserDetails(S_USER_DETAILS in_SArrUsers[])
{
    memcpy (in_SArrUsers, g_arrSUserDetails, sizeof(g_arrSUserDetails));

    return DP_UML_SUCCESS;
}

char CUserManagement::DP_UML_Init_UMLLib(char in_ucMaxUsers, char in_ucMaxUsernamelen, char in_ucMaxPasslen, char in_ucMinUsernamelen, char in_ucMinPasslen, const char *in_szAuthFilename)
{
    FILE *fpAuthFile;
    S_USER_DETAILS arrSUserDetails[255];

    /** Initialize max number of users */
    g_ucMaxUser = in_ucMaxUsers;

    /** Initialize max length of username */
    g_ucMaxUsernamelen = in_ucMaxUsernamelen;

    /** Initialize min length of username */
    g_ucMinUsernamelen = in_ucMinUsernamelen;

    /** Initialize max length of password */
    g_ucMaxPassLen = in_ucMaxPasslen;

    /** Initialize min length of password */
    g_ucMinPassLen = in_ucMinPasslen;

    /** Setting the authentication file name */
    strcpy(g_szAuthFileName, in_szAuthFilename);

    fpAuthFile = NULL;

    // Opening authentication file
    fpAuthFile = fopen(g_szAuthFileName, "rb");

    /** Check availability of file */
    if (fpAuthFile == NULL)
    {
        return DP_UML_FILE_CORRUPTED;
    }

    g_uiRecCount = DP_UML_INIT_VALUE;

    // Finding the total size of the file
    fseek(fpAuthFile, 0L, SEEK_END);
    int size = ftell(fpAuthFile);

    // Computing Total Number of Records
    if (size != DP_UML_INIT_VALUE)
    {
        g_uiRecCount = (ftell(fpAuthFile) - 32) / sizeof(S_USER_DETAILS);
    }
    else
    {
        return DP_UML_FILE_IS_EMPTY;
    }

    // Move pointer to the start of the file
    fseek(fpAuthFile, 0L, SEEK_SET);

    /** Reading file data to structure object */
    fread(&arrSUserDetails, sizeof(S_USER_DETAILS), g_uiRecCount, fpAuthFile);

    /** Decrypt data using AES */
    DecryptData (arrSUserDetails, g_arrSUserDetails);

    /** Closing the authentication file */
    fclose(fpAuthFile);
    fpAuthFile = NULL;

    return DP_UML_SUCCESS;
}

void CUserManagement::Encrypt(char *in_szArray, int in_iArraySize, char *out_szArray)
{
    int iLoop;
    unsigned char ucSecret[DATA_SIZE_32] = {22, 53, 44, 71, 66, 177, 253, 122, 55, 95, 177, 200, 110, 49, 240, 100, 22, 53, 44, 71, 66, 177, 253, 122, 55, 95, 177, 200, 110, 49, 240, 100};
    for (iLoop = DP_UML_INIT_VALUE; iLoop < in_iArraySize; iLoop++)
    {
        out_szArray[iLoop] = in_szArray[iLoop] ^ ucSecret[iLoop];
    }
}

void CUserManagement::Decrypt(char *in_szArray, int in_iArraySize, char *out_szArray)
{
    this->Encrypt (in_szArray, in_iArraySize, out_szArray);
}

int CUserManagement::EncryptData(S_USER_DETAILS *in_SUserDetailsTemp, S_USER_DETAILS *out_SUserDetailsEncoded)
{
    int iLoop;

    /** Encrypt Username */
    for(iLoop = DP_UML_INIT_VALUE; iLoop < g_uiRecCount; iLoop++)
    {
        Encrypt (in_SUserDetailsTemp[iLoop].m_szUserName, DATA_SIZE_32, out_SUserDetailsEncoded[iLoop].m_szUserName);
    }

    /** Copying the same password (Password is already Encrypted using SHA-256) */
    for (iLoop = DP_UML_INIT_VALUE; iLoop < g_uiRecCount; iLoop++)
    {
        strcpy(out_SUserDetailsEncoded[iLoop].m_szUserPassword, in_SUserDetailsTemp[iLoop].m_szUserPassword);
    }

    /** Encrypt Previlage */
    for (iLoop = DP_UML_INIT_VALUE; iLoop < g_uiRecCount; iLoop++)
    {
        Encrypt (in_SUserDetailsTemp[iLoop].m_szUserPrevilege, DATA_SIZE_16, out_SUserDetailsEncoded[iLoop].m_szUserPrevilege);
    }

    return DP_UML_SUCCESS;
}

int CUserManagement::DecryptData(S_USER_DETAILS *in_SUserDetailsTemp, S_USER_DETAILS *out_SUserDetailsDecoded)
{
    int iLoop;

    /** Decrypt Username */
    for(iLoop = DP_UML_INIT_VALUE; iLoop < g_uiRecCount; iLoop++)
    {
        Encrypt (in_SUserDetailsTemp[iLoop].m_szUserName, DATA_SIZE_32, out_SUserDetailsDecoded[iLoop].m_szUserName);
    }

    /** Copying the same password */
    for (iLoop = DP_UML_INIT_VALUE; iLoop < g_uiRecCount; iLoop++)
    {
        strcpy(out_SUserDetailsDecoded[iLoop].m_szUserPassword, in_SUserDetailsTemp[iLoop].m_szUserPassword);
    }

    /** Decrypt Previlage */
    for (iLoop = DP_UML_INIT_VALUE; iLoop < g_uiRecCount; iLoop++)
    {
        Encrypt (in_SUserDetailsTemp[iLoop].m_szUserPrevilege, DATA_SIZE_16, out_SUserDetailsDecoded[iLoop].m_szUserPrevilege);
    }

    return DP_UML_SUCCESS;
}

void CUserManagement::UpdateAuthfile()
{
    FILE *fpAuthFile;
    S_USER_DETAILS arrSUserDetails[255];

    /** Encrypt Data using AES */
    EncryptData (g_arrSUserDetails, arrSUserDetails);

    // Update the file
    fpAuthFile = fopen(g_szAuthFileName, "wb");

    if(fpAuthFile != NULL)
    {
        fwrite(&arrSUserDetails, sizeof(S_USER_DETAILS), g_uiRecCount, fpAuthFile);
        fclose(fpAuthFile);
        fpAuthFile = NULL;
    }
    else
    {
        qDebug("Error while updating Authentication file");
    }
}

int CUserManagement::IsSpclCharExist(char *in_szData)
{
    int iLoop = DP_UML_INIT_VALUE;
    unsigned char ucSpclCharExist = DP_UML_FAILURE;

    char cTemp = '\0';

    while (in_szData[iLoop] != '\0')
    {
        cTemp = in_szData[iLoop];
        if((cTemp >= 33 && cTemp <= 45) \
                || (cTemp >= 58 && cTemp <= 64) \
                || (cTemp >= 91 && cTemp <= 96) \
                || (cTemp >= 123 && cTemp <= 126) \
                || cTemp == 47)
        {
            ucSpclCharExist = DP_UML_SUCCESS;
            break;
        }
        iLoop++;
    }
    return ucSpclCharExist;
}

int CUserManagement::IsDigitExist(char *in_szData)
{
    int iLoop = DP_UML_INIT_VALUE;
    unsigned char ucDigitExist = DP_UML_FAILURE;

    char cTemp = '\0';

    while(in_szData[iLoop] != '\0')
    {
        cTemp = in_szData[iLoop];
        if (cTemp >= '0' && cTemp <= '9')
        {
            ucDigitExist = DP_UML_SUCCESS;
            break;
        }
        iLoop++;
    }
    return ucDigitExist;
}

int CUserManagement::check_file_checksum(const char *in_szFileName)
{
    QByteArray bytearrFileHashData, bytearrFileData, bytearrCheck;
    qint64 iFileSize;
    QFile file(in_szFileName);

    if (file.open (QIODevice::ReadOnly))
    {
        iFileSize = file.size ();
        if (iFileSize != 0)
        {
            /** Reading contents of the file */
            bytearrFileData = file.read ((iFileSize - 32));

            /** Encrypting the file data using MD-5 */
            bytearrFileHashData = QCryptographicHash::hash (bytearrFileData, QCryptographicHash::Md5);

            file.seek (iFileSize - 32);
            bytearrCheck = file.read (32);

            if (strcmp(bytearrCheck, bytearrFileHashData.toHex ()) != DP_UML_SUCCESS)
            {
                file.close ();
                return DP_UML_FILE_CORRUPTED;
            }
        }
        file.close ();
    }
    else
    {
        return DP_UML_FILE_NOT_FOUND;
    }

    return DP_UML_SUCCESS;
}

int CUserManagement::update_file_checksum(const char *in_szFileName, int in_iNoOfUsers)
{
    QByteArray bytearrayFileHashData, bytearrayFileData;
//    int iNoOfUsers;
    qint64 iFileSize;
    QFile file(in_szFileName);

#if 0
    /** Get Total Number of Users */
    DP_UML_GetNoOfUsers (&iNoOfUsers);
#endif

    /** Computing total file size */
    iFileSize = in_iNoOfUsers * sizeof(S_USER_DETAILS);

    if (file.open (QIODevice::ReadOnly))
    {
        /// Reading the content of the file
        bytearrayFileData = file.read (iFileSize);

        /** Encrypting the file data */
        bytearrayFileHashData = QCryptographicHash::hash (bytearrayFileData, QCryptographicHash::Md5);

        file.close ();
    }
    else
    {
        return DP_UML_FILE_NOT_FOUND;
    }

    /** Update the authentication file */
    UpdateAuthfile ();

    /** Adding the File Hash Data to the file */
    file.open (QIODevice::Append);
    file.write (bytearrayFileHashData.toHex ());
    file.close ();

    return DP_UML_SUCCESS;
}

