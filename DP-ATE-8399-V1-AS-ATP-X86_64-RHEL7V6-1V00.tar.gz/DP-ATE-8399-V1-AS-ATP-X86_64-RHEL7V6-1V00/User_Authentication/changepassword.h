#ifndef CCHANGEPASSWORD_H
#define CCHANGEPASSWORD_H

#include <QDialog>
#include <QDebug>
#include <QMessageBox>
#include "authentication.h"
#include<QCryptographicHash>
#include "usermanagement.h"
#include <QDir>




namespace Ui {
class CChangePassword;
}

class CChangePassword : public QDialog
{
    Q_OBJECT

public:
    explicit CChangePassword(QWidget *parent = 0);
    char  m_szUserName[256];
    void Msg_display(int in_iError);
    ~CChangePassword();

private slots:
    void on_pb_ChgCnfirmUsrPwd_clicked();

    void on_pb_ChgPwdCancel_clicked();

    void closeEvent(QCloseEvent *in_CloseEvent);

   // void update_file_checksum();

    //void check_file_checksum();


private:
    Ui::CChangePassword *ui;
};

#endif // CCHANGEPASSWORD_H
