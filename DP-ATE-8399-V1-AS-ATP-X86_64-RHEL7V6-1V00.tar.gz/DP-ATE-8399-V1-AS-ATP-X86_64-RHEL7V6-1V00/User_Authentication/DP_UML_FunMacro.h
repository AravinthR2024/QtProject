/**
*	\file DP_UML_FunMacro.h
*	\brief Function macros 
*
*	This file contains the validation macros and functional macros 
	\author 
*	\date 
*
*	\revision 
*	- Initial version
*	
*	\copyright Copyright (C) 2011 Data Patterns (India) Pvt. Ltd. / Indus Teqsite Pvt. Ltd. \n
*	All Rights Reserved.\n
*	Address: Plot # H9, Fourth Main Road, SIPCOT IT Park, Siruseri, \n
*   Off Rajiv Gandhi Salai (OMR), Pudupakkam P.O., \n
*   Chennai-603103 | India\n
*	Website : http://www.datapatternsindia.com/\n
*	Phone: 91-44-4741-4000\n
*	FAX: 91-44-4741-4444 \n
*	
*/

/*************Functional Macro ******************/
/**
*	\def DP_UML_VALIDATE_MAX_USERNAME_LEN
*	\brief This macro is used to validate username max length
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_MAX_USERNAME_LEN(ucUsernamelen, ucMaxUsernamelen) \
{ \
	if ((ucUsernamelen > g_ucMaxUsernamelen)) \
		return DP_UML_USERNAME_LEN_MAXERR; \
}

/**
*	\def DP_UML_VALIDATE_MAX_PASSWORD_LEN
*	\brief This macro is used to validate password max length
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_MAX_PASSWORD_LEN(ucPasslen, ucMaxPasslen) \
{ \
	if ((ucPasslen > ucMaxPasslen)) \
		return DP_UML_PASS_LEN_MAXERR; \
}

/*************Functional Macro ******************/
/**
*	\def DP_UML_VALIDATE_MIN_USERNAME_LEN
*	\brief This macro is used to validate username min length
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_MIN_USERNAME_LEN(ucUsernamelen, ucMinUsernamelen) \
{ \
	if ((ucUsernamelen < ucMinUsernamelen)) \
		return DP_UML_USERNAME_LEN_MINERR; \
}

/**
*	\def DP_UML_VALIDATE_MIN_PASSWORD_LEN
*	\brief This macro is used to validate password min length
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_MIN_PASSWORD_LEN(ucPasslen, ucMinPasslen) \
{ \
	if((ucPasslen < ucMinPasslen)) \
		return DP_UML_PASS_LEN_MINERR; \
}

/**
*	\def DP_UML_VALIDATE_MAX_USER
*	\brief This macro is used to validate Max user avilable
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_MAX_USER(ucTotalUser, ucMaxUsers) \
{ \
	if ((ucTotalUser > ucMaxUsers)) \
		return DP_UML_USER_MAX_ERR; \
}

/**
*	\def DP_UML_VALIDATE_SPCL_CHAR
*	\brief This macro is used to validate special charecter available
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_SPCL_CHAR(cData) \
{ \
	if ((IsSpclCharExist(cData)) != DP_UML_SUCCESS) \
		return DP_UML_PASS_SPLCHAR_ERR; \
}

/**
*	\def DP_UML_VALIDATE_DIGIT
*	\brief This macro is used to validate digit available
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_DIGIT(cData) \
{ \
	if ((IsDigitExist(cData)) != DP_UML_SUCCESS) \
		return DP_UML_PASS_DIGIT_ERR; \
}

/**
*	\def DP_UML_VALIDATE_SUPERUSER_PRIVILAGE
*	\brief This macro is used to validate super user privilage
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_SUPERUSER_PRIVILAGE(ucData) \
{ \
	if (ucData != DP_UML_SUPER_USER) \
		return DP_UML_PRIVILAGE_ERR; \
}

/**
*	\def DP_UML_VALIDATE_NORMALUSER_PRIVILAGE
*	\brief This macro is used to validate normal user privilage
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_NORMALUSER_PRIVILAGE(ucData) \
{ \
	if (ucData != DP_UML_NORMAL_USER) \
		return DP_UML_PRIVILAGE_ERR; \
}

/**
*	\def DP_UML_VALIDATE_SPCL_CHAR_USERNAME
*	\brief This macro is used to validate special charecter available
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_SPCL_CHAR_USERNAME(cData) \
{ \
	if ((IsSpclCharExist(cData)) == DP_UML_SUCCESS) \
		return DP_UML_SPLCHAR_NAME_ERR; \
}

/**
*	\def DP_UML_VALIDATE_USERNAME_EMPTY
*	\brief This macro is used to validate username empty
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_USERNAME_EMPTY(ucUsernamelen) \
{ \
	if ((ucUsernamelen == 0)) \
		return DP_UML_USERNAME_LEN_EMPTY; \
}

/**
*	\def DP_UML_VALIDATE_PASSWORD_EMPTY
*	\brief This macro is used to validate password empty
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_PASSWORD_EMPTY(ucPasslen) \
{ \
	if ((ucPasslen == 0)) \
		return DP_UML_PASS_LEN_EMPTY; \
}

/**
*	\def DP_UML_VALIDATE_NEWPASSWORD_EMPTY
*	\brief This macro is used to validate new password empty
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_NEWPASSWORD_EMPTY(ucPasslen) \
{ \
	if ((ucPasslen == 0)) \
		return DP_UML_NEWPASS_LEN_EMPTY; \
}

/**
*	\def DP_UML_VALIDATE_CONFPASSWORD_EMPTY
*	\brief This macro is used to validate confirm password empty
*	\retval	Not Applicable
*/
#define DP_UML_VALIDATE_CONFPASSWORD_EMPTY(ucPasslen) \
{ \
	if ((ucPasslen == 0)) \
		return DP_UML_CONFPASS_LEN_EMPTY; \
}

/**
 *  \def DP_UML_VALIDATE_USER_EXISTS
 *  \brief This macro is used to validate if the username is already exists or not
 *  \retval Not Applicable
 */
#define DP_UML_VALIDATE_USER_EXISTS(szUsername)\
{\
    if(DP_UML_IsUserNameExists (szUsername) >= DP_UML_SUCCESS)\
    {\
        return DP_UML_USER_ALREADY_EXIST;\
    }\
}

/**
 *      \def DP_UML_VALIDATE_NEW_AND_CONF_PASSWORD
 *      \brief This macro is used to check if new password and confirm password are equal
 *      \retval Not Applicable
 */
#define DP_UML_VALIDATE_NEW_AND_CONF_PASSWORD(szNewPass, szConfPass)\
{\
    if (strcmp (szNewPass, szConfPass) != DP_UML_SUCCESS)\
    {\
        return DP_UML_NOT_VALID_CONFPASSWORD;\
    }\
}
