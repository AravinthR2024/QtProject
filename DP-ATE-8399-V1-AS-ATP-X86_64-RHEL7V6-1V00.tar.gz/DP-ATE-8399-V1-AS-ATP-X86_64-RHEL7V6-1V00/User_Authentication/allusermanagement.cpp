#include "allusermanagement.h"
#include "ui_allusermanagement.h"

extern char g_arrAuthfileName[500];
extern S_GLOBAL_HANDLES g_Handles;

CAllUserManagement::CAllUserManagement(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CAllUserManagement)
{
    ui->setupUi(this);
    this->setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);
    ui->swUserManagement->setCurrentIndex(TAB_ADMIN_CONTROL);

    le_objUserName = ui->leChangeUserName;

    CUserManagement manage;
    ui->twAllUsers->horizontalHeader()->setStretchLastSection(true);
    ui->twAllUsers->horizontalHeader()->setSectionsClickable(false);

    m_objAdminAuthWindow = new CAdminAuthentication (parent);
    m_objAuthWindow = new CAuthentication (parent);

//    ui->pbAddUser->hide();
//    ui->pbDeleteUser->hide();

//    if (strcmp(window->m_strUsrName.toLatin1 ().data (), ADMIN_USERNAME) == DP_UML_SUCCESS)
//    {
//        ui->leChangeUserName->setReadOnly (false);
//    }
//    else
//    {
//        ui->leChangeUserName->setText (window->m_strUsrName);
//        ui->leChangeUserName->setReadOnly (true);
//    }

    ui->pbDeleteUser->setDisabled(true);
    int iNoofUsers = DP_UML_INIT_VALUE;
    int iRetVal = manage.DP_UML_Init_UMLLib(255, 32, 32, 6, 6, g_arrAuthfileName);
    if (iRetVal == DP_UML_FILE_CORRUPTED)
    {
        QMessageBox :: information(this, "Error", "Authentication file corrupted", QMessageBox::Ok);
        exit(DP_UML_SUCCESS);
    }

    S_USER_DETAILS strArrNoofusers[255];
    QString str = "";

    if(manage.DP_UML_GetNoOfUsers(&iNoofUsers) == DP_UML_INIT_VALUE)
    {
        if(iNoofUsers == DP_UML_INIT_VALUE)
        {
            QString strPrivelage;
            strPrivelage = ADMIN_USER_STR;
            QByteArray byte;
            byte = strPrivelage.toLatin1();
            manage.DP_UML_AddNewUser ((char*)ADMIN_USERNAME, (char*) ADMIN_PASSWORD, (char*) ADMIN_PASSWORD, byte.data());
        }
    }

    if(manage.DP_UML_GetNoOfUsers(&iNoofUsers) == DP_UML_INIT_VALUE)
    {
        /* Get the user names */
        if(manage.DP_UML_GetAllUserDetails (strArrNoofusers) == DP_UML_INIT_VALUE)
        {
            for(int iLoop = DP_UML_INIT_VALUE; iLoop < iNoofUsers; iLoop++)
            {
                int icount = ui->twAllUsers->rowCount();
                ui->twAllUsers->insertRow(icount);
                str.sprintf("%s", strArrNoofusers[iLoop].m_szUserName);
                ui->twAllUsers->setItem(iLoop, DP_UML_INIT_VALUE, new QTableWidgetItem(str));
            }
        }
    }

    if(iNoofUsers == DP_UML_INIT_VALUE)
    {
        ui->twAllUsers->setItem(DP_UML_INIT_VALUE, DP_UML_INIT_VALUE, new QTableWidgetItem(ADMIN_USERNAME));
    }

    int iNoOfUsr;
    manage.DP_UML_GetNoOfUsers(&iNoOfUsr);
    int iRetvalue = manage.update_file_checksum(g_arrAuthfileName, iNoOfUsr);
    displayMessage(iRetvalue);
}

CAllUserManagement::~CAllUserManagement()
{
    delete ui;
}

void CAllUserManagement::updateuser()
{
    int iNoofUsers = DP_UML_INIT_VALUE;
    QString str = "";
    S_USER_DETAILS SArrNoofusers[255];
    CUserManagement manage;
    ui->twAllUsers->clearContents();

    /** Memset the no of user array **/
    memset (SArrNoofusers, DP_UML_INIT_VALUE, sizeof (SArrNoofusers));

    /** Get the no of user */
    if(manage.DP_UML_GetNoOfUsers(&iNoofUsers) == DP_UML_INIT_VALUE)
    {
        /* Get the user names */
        if(manage.DP_UML_GetAllUserDetails (SArrNoofusers) == DP_UML_INIT_VALUE)
        {
            for(int iLoop = DP_UML_INIT_VALUE; iLoop < iNoofUsers; iLoop++)
            {
                int icount = ui->twAllUsers->rowCount();
                if(iNoofUsers > icount )
                {
                    ui->twAllUsers->insertRow(icount);
                }
                else if(icount > iNoofUsers)
                {
                    ui->twAllUsers->removeRow(icount);
                }
                str.sprintf("%s", SArrNoofusers[iLoop].m_szUserName);
                ui->twAllUsers->setItem(iLoop, DP_UML_INIT_VALUE, new QTableWidgetItem(str));
            }
        }
    }
    int iNoOfUsr;
    manage.DP_UML_GetNoOfUsers(&iNoOfUsr);
    int iRetval = manage.update_file_checksum(g_arrAuthfileName, iNoOfUsr);
    displayMessage(iRetval);
}

void CAllUserManagement::displayMessage(int in_iError)
{
    switch(in_iError)
    {
    case DP_UML_NOT_VALID_USERNAME:
        QMessageBox :: information(this, "Error", "Invalid Username");
        break;
    case DP_UML_NOT_VALID_PASSWORD:
        QMessageBox :: information(this, "Error", "Invalid Password");
        break;
    case DP_UML_NOT_VALID_OLDPASSWORD:
        QMessageBox :: information(this, "Error", "Invalid Old Password");
        break;
    case DP_UML_NOT_VALID_CONFPASSWORD:
        QMessageBox :: information(this, "Error", "Invalid Confirm Password");
        break;
    case DP_UML_USER_ALREADY_EXIST:
        QMessageBox :: information(this, "Error", "User already exists");
        break;
    case DP_UML_USERNAME_LEN_MINERR:
        QMessageBox :: information(this, "Error", "Username must be of minimum 6 characters");
        break;
    case DP_UML_USERNAME_LEN_MAXERR:
        QMessageBox :: information(this, "Error", "Username must be less than 32 characters");
        break;
    case DP_UML_PASS_LEN_MINERR:
        QMessageBox :: information(this, "Error", "Password must be of minimum 6 characters");
        break;
    case DP_UML_PASS_LEN_MAXERR:
        QMessageBox :: information(this, "Error", "Password must be less than 32 characters");
        break;
    case DP_UML_USER_MAX_ERR:
        QMessageBox :: information(this, "Error", "Maximum number of users reached");
        break;
    case DP_UML_PASS_SPLCHAR_ERR:
        QMessageBox :: information(this, "Error", "Password must contain atleast one special character");
        break;
    case DP_UML_PASS_DIGIT_ERR:
        QMessageBox :: information(this, "Error", "Password must contain atleast one numeric character");
        break;
    case DP_UML_SPLCHAR_NAME_ERR:
        QMessageBox :: information(this, "Error", "Username must not contain any special characters other than '.'");
        break;
    case DP_UML_USERNAME_LEN_EMPTY:
        QMessageBox :: information(this, "Error", "Username field is empty");
        break;
    case DP_UML_PASS_LEN_EMPTY:
        QMessageBox :: information(this, "Error", "Password field is empty");
        break;
    case DP_UML_NEWPASS_LEN_EMPTY:
        QMessageBox :: information(this, "Error", "NewPassword field is empty");
        break;
    case DP_UML_CONFPASS_LEN_EMPTY:
        QMessageBox :: information(this, "Error", "ConfirmPassword field is empty");
        break;
    case DP_UML_FILE_CORRUPTED:
        QMessageBox :: information(this, "Error", "Authentication file corrupted", QMessageBox::Ok);
        break;
    case DP_UML_FILE_NOT_FOUND:
        QMessageBox :: information(this, "Error", "Authentication file not found", QMessageBox::Ok);
        break;
    case DP_UML_FILE_IS_EMPTY:
        QMessageBox :: information(this, "Error", "Authentication file is empty", QMessageBox::Ok);
        break;
    default:
        break;
    }
}

void CAllUserManagement::changePasswordTrigger()
{
    this->exec ();
    on_pbChangePassword_clicked ();
}

void CAllUserManagement::closeEvent(QCloseEvent *in_CloseEvent)
{
    Q_UNUSED(in_CloseEvent);

    ui->swUserManagement->setCurrentIndex (TAB_ADMIN_CONTROL);
}

void CAllUserManagement::on_pbAddUser_clicked()
{
    m_objAdminAuthWindow->exec ();
    if (m_objAdminAuthWindow->m_bIsAdmin)
    {
        ui->swUserManagement->setCurrentIndex (TAB_ADD_USER);
    }
    else
    {
        QMessageBox::information (this, "Error", "Only admins can add new users");
    }
}

void CAllUserManagement::on_pbClose_clicked()
{
    this->close ();
}

void CAllUserManagement::on_pbAddUserOk_clicked()
{
    CUserManagement manage;
    int iRetVal = DP_UML_INIT_VALUE;
    iRetVal = manage.check_file_checksum(g_arrAuthfileName);
    if (iRetVal == -77 || iRetVal == -76)
    {
        displayMessage(iRetVal);
        exit(DP_UML_SUCCESS);
    }

    iRetVal = DP_UML_INIT_VALUE;
    QString strPrivelage;
    if(ui->rbPrevilageSuperUser->isChecked ())
    {
            strPrivelage = ADMIN_USER_STR;
    }
    else
    {
            strPrivelage = NORMAL_USER_STR;
    }
    QByteArray byte;
    byte = strPrivelage.toLatin1();

    //Adding New User
    iRetVal =  manage.DP_UML_AddNewUser (ui->leNewUserName->text().toLatin1().data(), ui->leNewUserPassword->text().toLatin1().data(), ui->leNewUserConfPassword->text().toLatin1().data(), byte.data());
    if(iRetVal == DP_UML_INIT_VALUE)
    {
        updateuser();
        QMessageBox :: information(this, "Information", "User added successfully");
        ui->leNewUserConfPassword->clear();
        ui->leNewUserPassword->clear();
        ui->leNewUserName->clear();
    }
    else
    {
        displayMessage(iRetVal);
    }
}

void CAllUserManagement::on_pbAddUserCancel_clicked()
{
    ui->leNewUserConfPassword->clear ();
    ui->leNewUserName->clear ();
    ui->leNewUserPassword->clear ();

    update ();

    ui->swUserManagement->setCurrentIndex (TAB_ADMIN_CONTROL);
}

void CAllUserManagement::on_pbChangePassword_clicked()
{
    CUserManagement manage;
    int iRetVal = DP_UML_INIT_VALUE;
    iRetVal = manage.check_file_checksum(g_arrAuthfileName);
    if (iRetVal == DP_UML_FILE_CORRUPTED || iRetVal == DP_UML_FILE_NOT_FOUND || iRetVal == DP_UML_FILE_IS_EMPTY)
    {
        displayMessage (iRetVal);
        exit(DP_UML_SUCCESS);
    }

    m_objAuthWindow->exec ();

    if (m_objAuthWindow->m_bAuth_Sts)
    {
        m_objAuthWindow->m_bAuth_Sts = false;
        int row = ui->twAllUsers->currentRow ();
        QString str;
        QTableWidgetItem* itm = ui->twAllUsers->item (row, DP_UML_INIT_VALUE);
        if (itm)
        {
            str = itm->text ();
            if (strcasecmp (g_Handles.m_UserDetails.m_sUserName.toStdString ().c_str (), ADMIN_USERNAME) == DP_UML_SUCCESS)
            {
                if(str.isEmpty ())
                {
                    ui->leChangeUserName->setText (ADMIN_USERNAME);
                }
                else
                {
                    ui->leChangeUserName->setText (str);
                }
                ui->leChangeUserName->setReadOnly (false);
            }
            else
            {
                ui->leChangeUserName->setText (g_Handles.m_UserDetails.m_sUserName);
                ui->leChangeUserName->setReadOnly (true);
            }
            ui->swUserManagement->setCurrentIndex (TAB_CHANGE_PASSWORD);
        }
        m_objAuthWindow->close ();
    }
}

void CAllUserManagement::on_pbChangePasswordOk_clicked()
{
    CUserManagement manage;
    int iRetVal = DP_UML_INIT_VALUE;
    iRetVal = manage.check_file_checksum(g_arrAuthfileName);
    if (iRetVal == DP_UML_FILE_CORRUPTED || iRetVal == DP_UML_FILE_NOT_FOUND || iRetVal == DP_UML_FILE_IS_EMPTY)
    {
        displayMessage (iRetVal);
        exit(DP_UML_SUCCESS);
    }

    iRetVal = DP_UML_INIT_VALUE;
    iRetVal = manage.DP_UML_ChangePasswordAdmin (ui->leChangeUserName->text().toLatin1().data(), ui->leChangeNewPassword->text().toLatin1().data(), ui->leChangeConfirmPassword->text().toLatin1().data());
    if(iRetVal == DP_UML_INIT_VALUE)
    {
        int iNoOfUsr;
        manage.DP_UML_GetNoOfUsers(&iNoOfUsr);
        int iRetvalue = manage.update_file_checksum(g_arrAuthfileName, iNoOfUsr);
        displayMessage (iRetvalue);
        QMessageBox :: information(this, "Information", "Password  changed successfully");
    }
    else
    {
        displayMessage (iRetVal);
    }
    ui->leChangeNewPassword->clear();
    ui->leChangeConfirmPassword->clear();
}

void CAllUserManagement::on_pbChangePasswordCancel_clicked()
{
    ui->leChangeNewPassword->clear ();
    ui->leChangeConfirmPassword->clear ();

    ui->swUserManagement->setCurrentIndex (TAB_ADMIN_CONTROL);
}

void CAllUserManagement::on_pbDeleteUser_clicked()
{
    if(ui->twAllUsers->currentRow() == DP_UML_INIT_VALUE)
    {
        QMessageBox::information(this, "Information", "Administrator account cannot be deleted...!");
        return;
    }

    CUserManagement manage;
    int iRetVal = DP_UML_INIT_VALUE;
    iRetVal = manage.check_file_checksum(g_arrAuthfileName);
    if (iRetVal == -77 || iRetVal == -76)
    {
        displayMessage (iRetVal);
        exit(DP_UML_SUCCESS);
    }
    iRetVal = DP_UML_INIT_VALUE;
    QTableWidgetItem* itm;int row;QString str = "";
    m_objAdminAuthWindow->exec();

    if(m_objAdminAuthWindow->m_bIsAdmin)
    {
        m_objAdminAuthWindow->m_bIsAdmin = false;
        row = ui->twAllUsers->currentRow();
        itm = ui->twAllUsers->item(row, DP_UML_INIT_VALUE );
        if (itm)
        {
            str = itm->text();
        }
        switch(QMessageBox::question(this, "Information", "Do you want to remove the selected user?", QMessageBox::No, QMessageBox::Yes))
        {
        case QMessageBox::Yes:
            iRetVal = manage.DP_UML_DeleteUser (str.toLatin1().data());

            if(iRetVal == DP_UML_INIT_VALUE)
            {
                QMessageBox :: information(this, "Information", "User deleted successfully");
                ui->twAllUsers->removeRow(row);
                updateuser();
            }
            else
            {
                displayMessage (iRetVal);
            }
            break;
        case QMessageBox::No:
            break;
        }
    }
    else
    {
        QMessageBox::information (this, "Error", "Only administrator can delete a user");
    }
}

void CAllUserManagement::on_twAllUsers_cellClicked(int in_iRow)
{
    if (in_iRow == DP_UML_INIT_VALUE)
    {
        ui->pbDeleteUser->setDisabled (true);
    }
    else
    {
        ui->pbDeleteUser->setEnabled (true);
    }
}

void CAllUserManagement::on_leNewUserName_textChanged(const QString &in_strText)
{
    if(in_strText == " ")
    {
        ui->leNewUserName->setText("");
    }
    else if(in_strText.endsWith(" "))
    {
        QString strTemp = in_strText;
        strTemp.chop(1);
        ui->leNewUserName->setText(strTemp);
    }
}

void CAllUserManagement::on_twAllUsers_itemSelectionChanged()
{
    on_twAllUsers_cellClicked(ui->twAllUsers->currentRow ());
}
