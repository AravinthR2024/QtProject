#include "adminauthentication.h"
#include "ui_adminauthentication.h"

CAdminAuthentication::CAdminAuthentication(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CAdminAuthentication)
{
    ui->setupUi(this);
    this->setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);
    m_bIsAdmin = false;
}

CAdminAuthentication::~CAdminAuthentication()
{
    delete ui;
}

void CAdminAuthentication::closeEvent(QCloseEvent *in_CloseEvent)
{
    Q_UNUSED(in_CloseEvent);

    ui->lePassword->clear ();
}

void CAdminAuthentication::on_pbCancel_clicked()
{
    ui->lePassword->clear ();
    this->close ();
}

void CAdminAuthentication::on_pbLogin_clicked()
{
    m_bIsAdmin = false;

    /** Check if the username is Administrator username */
    if (strcasecmp (ui->leUserName->text ().toLatin1 ().data (), ADMIN_USERNAME) == DP_UML_SUCCESS)
    {
        /** Check the Administrator password */
        if (strcmp(ui->lePassword->text ().toLatin1 ().data (), ADMIN_PASSWORD) == DP_UML_SUCCESS)
        {
            ui->lePassword->clear ();
            m_bIsAdmin = true;
            m_strUsrName = ui->leUserName->text ();
        }
    }
    this->close ();
}
