/*******************************************************************************
 File Name    : dp-lins-atp_mainwindow.cpp
 Author       : Manikandan K
 Created Date : Mar 11,2019
 Description  : Test Thread function definitions.
*******************************************************************************/

/*******************************************************************************
 Company Name : DATA PATTERNS INDIA PRIVATE LIMITED
 Address      : No. H9,4th MainRoad,SIPCOT IT Park,Siruseri,Chennai-603103
 Email        : support@datapatterns.co.in
 Phone        : +91 44 47414000
 Fax          : +91 44 47414444
*******************************************************************************/

/******************************************************************************
 Copyright (c) 2019 DATA PATTERNS

 All rights reserved. These materials are confidential and proprietary to
 DATA PATTERNS and no part of these materials should be reproduced or published
 in any form by any means, electronic or mechanical, including photocopy, on any
 information storage or retrieval system, nor should the materials be disclosed
 to third parties without the explicit written authorization of DATA PATTERNS.

*******************************************************************************/


#include "dp-lins-atp_mainwindow.h"
#include "ui_dp-lins-atp_mainwindow.h"

#define DP_1553B_TEST_ENABLE

#undef _TESTING_

int g_iCnt;

extern SGLOBAL g_SGlobal;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QDir dir(DP_LINS_LOGFILE_DIR);
    if(!dir.exists())
    {
        dir.mkpath(DP_LINS_LOGFILE_DIR);
    }
    m_qsLogFileName.clear();
    m_qsLogFileName.append(DP_LINS_LOGFILE_DIR+"/");
    m_qsLogFileName.append(QDateTime::currentDateTime().toString("yyyy-MM-dd_"));
    m_qsLogFileName.append("A8399-300_dp-lins-atp_logfile.txt");
    m_qfActionLog.setFileName(m_qsLogFileName);
    if(!m_qfActionLog.exists())
    {
        m_qfActionLog.open(QIODevice::WriteOnly);
        m_qfActionLog.write("Application Started.\n");
    }
    else
    {
        m_qfActionLog.open(QIODevice::Append);
        m_qfActionLog.write(LOG_NEW_START);
        m_qfActionLog.write("Application Started.\n");
    }
    m_qfActionLog.close();

    m_objUserManagement = new CAllUserManagement(this);
    m_objChangePassword = new CChangePassword(this);

    m_obj3096Board.m_u16NoOfDetBoards = 0;
    m_obj1105Board.m_u16NoOfDetBoards = 0;
    m_obj1123Board.m_u16NoOfDetBoards = 0;
    m_objC1553BWrapper.m_u16NoOfDeviceFound = 0;

    m_bIsTestTypeAuto = true;
    m_bIsTestActive = false;
    m_bPropertiesVisible = true;
    ui->sw_Test->setCurrentIndex(TAB_DETECTION_STATUS);

    ui->tw_EquipmentConfigDetails->setSelectionMode(QAbstractItemView::NoSelection);
    ui->tw_EquipmentConfigDetails->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tw_EquipmentConfigDetails->verticalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    ui->tw_EquipmentConfigDetails->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    //    ui->rb_BypassTest->hide();

    if(!QDir(qApp->applicationDirPath()+"/Reports").exists())
        QDir().mkdir(qApp->applicationDirPath()+"/Reports");

    ConfigFileCreation();

    Sizes.clear();
    Sizes.append(0.75 * this->height());
    Sizes.append(0.25 * this->height());
    ui->splitter->setSizes(Sizes);

    m_qProcTestThread = new CTestThread;
    obj_CDP_PSU_Wrapper = new CDP_PSU_Wrapper;

    m_qProcTestThread->m_obj_CPSUWrapper = obj_CDP_PSU_Wrapper;
    m_qProcTestThread->m_p3096Wrapper = &m_obj3096Board;
    m_qProcTestThread->m_p1105Wrapper = &m_obj1105Board;
    m_qProcTestThread->m_p1123Wrapper = &m_obj1123Board;
    m_qProcTestThread->m_pobjC1553BWrapper = &m_objC1553BWrapper;

    ReadConfigFile ();

    m_objSystDet = new CSystemDetails(this);

    m_WDTimer.setInterval(2000);
    m_SurTimer.setInterval(700);

    connect(&m_WDTimer, SIGNAL(timeout()), this, SLOT(WatchDogTimerReset()));
    connect(&m_SurTimer, SIGNAL(timeout()), this, SLOT(SurveillanceTimerReset()));
    connect(&m_STemTimer, SIGNAL(timeout()), this, SLOT(SurveillanceError()));


#ifdef _ENABLE_BOARD_

    m_qProcTestThread->m_obj_CPSUWrapper->DP_PSU_Open("COM1", 9600, 8, 1);

#endif

    connect(ui->treew_TestCase,SIGNAL(itemClicked(QTreeWidgetItem*,int)),this,SLOT(DP_TestCase_Checked(QTreeWidgetItem*,int)));

    connect(m_qProcTestThread,SIGNAL(SigErrorNo(int)),this,SLOT(DisplayError(int)), (Qt::ConnectionType)(Qt::BlockingQueuedConnection | Qt::UniqueConnection));
    connect(m_qProcTestThread,SIGNAL(SigTestResult(int,bool)),this,SLOT(UpdateResult(int,bool)), (Qt::ConnectionType)(Qt::BlockingQueuedConnection | Qt::UniqueConnection));
    connect(m_qProcTestThread,SIGNAL(SigTestComplete()),this,SLOT(OnTestThreadFinish()), (Qt::ConnectionType)(Qt::BlockingQueuedConnection | Qt::UniqueConnection));
    connect(m_qProcTestThread,SIGNAL(SigHighLightTestCase(int)),this,SLOT(HighLightTestCase(int)), (Qt::ConnectionType)(Qt::BlockingQueuedConnection | Qt::UniqueConnection));
    connect(m_qProcTestThread,SIGNAL(SigReHighLightTestCase(int)),this,SLOT(ReHighLightTestCase(int)), (Qt::ConnectionType)(Qt::BlockingQueuedConnection | Qt::UniqueConnection));
    connect(m_qProcTestThread,SIGNAL(Sig_GetUserInput(int, QString)),this,SLOT(GetUserInput(int, QString)), (Qt::ConnectionType)(Qt::BlockingQueuedConnection | Qt::UniqueConnection));

    /* AddedBy      Aravinth R */
    connect(m_qProcTestThread, SIGNAL(Sig_PauseOnFailure(int)), this, SLOT(DisplayPauseOnFailMsg(int)), (Qt::ConnectionType)(Qt::BlockingQueuedConnection | Qt::UniqueConnection));
    connect(m_qProcTestThread, SIGNAL(Sig_PauseOnFailureMsg(QString)), this, SLOT(PauseOnFailurMessage(QString)), (Qt::ConnectionType)(Qt::BlockingQueuedConnection | Qt::UniqueConnection));
    /*******/

    connect(m_qProcTestThread,SIGNAL(Sig_StartWDTReset()), &m_WDTimer, SLOT(start()));
    connect(m_qProcTestThread,SIGNAL(Sig_StopWDTReset()), &m_WDTimer, SLOT(stop()));
    connect(m_qProcTestThread,SIGNAL(Sig_DisableSurveillance()), this, SLOT(SurveillanceError()));

    //connect(m_qProcTestThread,SIGNAL(finished()),this,SLOT(OnTestThreadFinish()),(Qt::ConnectionType)(Qt::BlockingQueuedConnection | Qt::UniqueConnection));
    connect(m_qProcTestThread,SIGNAL(Sig_PrintLog(QString,int)),this,SLOT(PrintActionLog(QString,int)), (Qt::ConnectionType)(Qt::BlockingQueuedConnection | Qt::UniqueConnection));
    connect(m_qProcTestThread,SIGNAL(Sig_MsgBox(QString,int)),this,SLOT(DisplayMsg(QString,int)), (Qt::ConnectionType)(Qt::BlockingQueuedConnection | Qt::UniqueConnection));

    /************************************************ Init Test-Case TreeWidget *****************************************/
    ui->treew_TestCase->header()->setSectionsMovable(false);
    ui->treew_TestCase->setColumnWidth(0,ui->treew_TestCase->width()*0.70);
    ui->treew_TestCase->setColumnWidth(1,ui->treew_TestCase->width()*0.10);
    ui->treew_TestCase->setColumnWidth(2,ui->treew_TestCase->width()*0.20);
    ui->treew_TestCase->header()->setSectionResizeMode(QHeaderView::Fixed);

    ui->treew_TestCase->header()->setDefaultAlignment(Qt::AlignCenter);
    ui->treew_TestCase->setFocusPolicy(Qt::NoFocus);
    ui->treew_TestCase->expandAll();

    //    for(int iIdx=0; iIdx< ui->treew_TestCase->topLevelItemCount(); iIdx++)
    //    {
    //        DP_TestCase_Checked(ui->treew_TestCase->topLevelItem(iIdx),0);
    //    }

    /*****************  Init Module Detection Table ****************************************************/

    ui->treew_BoardStatus->header()->setSectionResizeMode(QHeaderView::ResizeToContents);
    ui->treew_BoardStatus->setSelectionMode(QAbstractItemView::NoSelection);
    ui->treew_BoardStatus->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->treew_BoardStatus->header ()->setSectionResizeMode(QHeaderView::Stretch);
    ui->treew_BoardStatus->header ()->setSectionResizeMode (INDEX_SERIAL_NO, QHeaderView::ResizeToContents);
    ui->treew_BoardStatus->header ()->setSectionResizeMode (INDEX_STATUS, QHeaderView::ResizeToContents);
    ui->treew_BoardStatus->header ()->setSectionResizeMode (INDEX_BOARD_NAME, QHeaderView::ResizeToContents);

    /******** Formatting Scrollbar *********/

    QScrollBar *scrollBar = new QScrollBar(ui->te_ActionLog);
    scrollBar->setStyleSheet ("QScrollBar { background-color: #aaaaaa } \
                              QScrollBar::handle:vertical{ \
                                  background-color:palette(alternate-base); \
                                  border-radius:2px; \
                                  min-height:20px; \
                                  margin:2px 4px 2px 4px; \
                              }");

                              ui->te_ActionLog->setVerticalScrollBar (scrollBar);

            QScrollBar *scrollBar1 = new QScrollBar(ui->treew_BoardStatus);
    scrollBar1->setStyleSheet ("QScrollBar { background-color: #aaaaaa }");
    ui->treew_BoardStatus->setVerticalScrollBar (scrollBar1);

    QScrollBar *scrollBar2 = new QScrollBar(ui->treew_TestCase);
    scrollBar2->setStyleSheet ("QScrollBar { background-color: #aaaaaa } \
                               QScrollBar::handle:vertical{ \
                                   background-color:palette(alternate-base); \
                                   border-radius:2px; \
                                   min-height:20px; \
                                   margin:2px 4px 2px 4px; \
                               }");
                               ui->treew_TestCase->setVerticalScrollBar (scrollBar2);

            /*********************************************/

            if(!ReadConfigFile())//read configuraton data from configuration file
    {
        QMessageBox::information(this, "PSU Configuration", "Default Configuration is loaded for PSU's - Configuration details will be available in \"Help -> Power Supply Configuratin Details\".");
    }

    /********* Initialize all Modules ********/
    Board_Init();

    Update_Board_Details();
    /*****************************************/

    m_WDTimer.start();
    m_SurTimer.start();
}

MainWindow::~MainWindow()
{
    short sRetVal = 0;
    SDP1553B_BC_INT in_pSBC_INT;

    in_pSBC_INT.u8EnaDis = 0;
    in_pSBC_INT.u32IntEventMasks = 1;

    for(int iLoop = 0; iLoop < 3 ; iLoop++)
    {
        sRetVal = m_objC1553BWrapper.DP1553B_BC_EnableDisableInt(iLoop, &in_pSBC_INT);
        if(sRetVal)
        {
            PrintActionLog("1553B Interrupt Disable FAILURE", MSGTYPE_ERROR);
        }
    }

    sRetVal = m_objC1553BWrapper.DP1553B_Close();
    if(sRetVal)
    {
        PrintActionLog("1553B Board Close FAILURE", MSGTYPE_ERROR);
    }

    free(m_out3096BrdDetails);
    free(m_out1105BrdDetails);
    free(m_out1123BrdDetails);
    for(int iLoop = 0; iLoop < 4 ; iLoop++)
    {
        free(m_pS1553B_DevLoc[iLoop]);
    }

    //    system("chmod +x remove_modules.sh");
    //    system("./remove_modules.sh");
    delete ui;
}

void MainWindow::WatchDogTimerReset()
{
    m_obj3096Board.SetOutput(DO_WDT_RESET, 1);
    QThread::msleep(1500);
    m_obj3096Board.SetOutput(DO_WDT_RESET, 0);
    QThread::msleep(100);
}

void MainWindow::SurveillanceTimerReset()
{
    m_obj3096Board.SetOutput(DO_SURVEIL_ERROR, 1);
}

void MainWindow::SurveillanceError()
{
    QThread::msleep(200);
    m_obj3096Board.SetOutput(DO_SURVEIL_ERROR, 0);
}

void MainWindow::Board_Init()
{
    DP3096_BoardInit();

    DP_1105_BoardInit();

    DP_MM1123_BoardInit();

    DP_1553B_BoardInit();
}

int MainWindow::DP3096_BoardInit()
{
    char cErrString[100];
    short sRetVal = 0;
    int  iErrorCode = 0;
    QString str;

    m_out3096BrdDetails = (SDPCPCI3096_DeviceLocation *) malloc(LINS_MAX_CPCI3096_BRDS * sizeof(SDPCPCI3096_DeviceLocation));

    sRetVal = m_obj3096Board.Init(LINS_MAX_CPCI3096_BRDS, m_S3096ExpDevLocation, m_out3096BrdDetails);
    if(sRetVal)
    {
        m_obj3096Board.GetLastErrorMsg(&iErrorCode, cErrString);
        str.sprintf("DP-cPCI-3096-300 Board open Failed. - Error %d (%s)",iErrorCode,cErrString);
        PrintActionLog(str, MSGTYPE_ERROR);
        return 1;
    }
    else
    {
        PrintActionLog("DP-cPCI-3096-300 Board Open Success", MSGTYPE_SUCCESS);
    }

    sRetVal = m_obj3096Board.Configure();
    if(sRetVal)
    {
        m_obj3096Board.GetLastErrorMsg(&iErrorCode, cErrString);
        str.sprintf("Error %d : %s",iErrorCode,cErrString);
        PrintActionLog(str, MSGTYPE_ERROR);
        return 1;
    }
}

int MainWindow::DP_1105_BoardInit()
{
    char cErrString[100];
    short sRetVal = 0;
    int  iErrorCode = 0;
    QString str;

    m_out1105BrdDetails = (SDPMM1105_DeviceLocation *)malloc(LINS_MAX_MM1105_BRDS * sizeof(SDPMM1105_DeviceLocation));

    sRetVal = m_obj1105Board.Init(LINS_MAX_MM1105_BRDS, m_S1105ExpDevLocation, m_out1105BrdDetails);
    if(sRetVal)
    {
        m_obj1105Board.GetLastErrorMsg(&iErrorCode, cErrString);
        str.sprintf("DP-MM-1105-300 Board open Failed. - Error %d (%s)",iErrorCode,cErrString);
        PrintActionLog(str, MSGTYPE_ERROR);
        return 1;
    }
    else
    {
        str = "DP-MM-1105-300 Board open Success";
        PrintActionLog(str, MSGTYPE_SUCCESS);
    }

    sRetVal = m_obj1105Board.Config();
    if(sRetVal)
    {
        str.sprintf("DP-MM-1105-300 Board Configuration Failed");
        PrintActionLog(str, MSGTYPE_ERROR);
        return 1;
    }
}

int MainWindow::DP_MM1123_BoardInit()
{
    char cErrString[100];
    short sRetVal = 0;
    int  iErrorCode = 0;
    QString str;

    m_out1123BrdDetails = (SDPMM1123_DeviceLocation *)malloc(LINS_MAX_MM1123_BRDS * sizeof(SDPMM1123_DeviceLocation));

    sRetVal = m_obj1123Board.Init(LINS_MAX_MM1123_BRDS, m_S1123ExpDevLocation, m_out1123BrdDetails);
    if(sRetVal)
    {
        m_obj1123Board.GetLastErrorMsg(&iErrorCode, cErrString);
        str.sprintf("DP-MM-1123-300 Board open Failed. - Error %d (%s)",iErrorCode,cErrString);
        PrintActionLog(str, MSGTYPE_ERROR);
        return 1;
    }
    else
    {
        str = "DP-MM-1123-300 Board open Success";
        PrintActionLog(str, MSGTYPE_SUCCESS);
    }

    sRetVal = m_obj1123Board.Config(0);
    if(sRetVal)
    {
        m_obj1123Board.GetLastErrorMsg(&iErrorCode, cErrString);
        str.sprintf("DP-MM-1123 Board Configuration Failed. - Error %d (%s)",iErrorCode,cErrString);
        PrintActionLog(str, MSGTYPE_ERROR);
        return 1;
    }
}

int MainWindow::DP_1553B_BoardInit()
{
    short sRetVal = 0;
    unsigned short us5019BrdCnt = 4;
    QString str;
    int iLoop  = 0;

    for(iLoop = 0; iLoop < us5019BrdCnt; iLoop++)
    {
        m_pS1553B_DevLoc[iLoop] = (PSDP1553_DEVICE_LOC) calloc(1, sizeof(SDP1553_DEVICE_LOC));
    }

    sRetVal = m_objC1553BWrapper.DP1553B_Open(us5019BrdCnt, NULL, m_pS1553B_DevLoc);
    if(sRetVal)
    {
        for(iLoop = 0; iLoop < us5019BrdCnt; iLoop++)
        {
            m_pS1553B_DevLoc[iLoop]->u8BusNo = m_uc1553BExpBusNo;
            m_pS1553B_DevLoc[iLoop]->u8SlotNo = m_uc1553BExpSlotNo;
            m_pS1553B_DevLoc[iLoop]->u8FunctionNo = m_uc1553BExpSlotNo;
            m_pS1553B_DevLoc[iLoop]->u8ChnlSts = DP_BORDS_STATUS_ZERO;
        }

        if(m_objC1553BWrapper.m_u16NoOfDeviceFound == 0)
        {
            str.sprintf("DP-XMC-5019-606 Board Open Failed. - No Modules Detected");
        }
        else
        {
            str.sprintf("Error %d : %s",sRetVal,"DP-XMC-5019-606 Board Open Failed");
        }
        PrintActionLog(str, MSGTYPE_ERROR);
    }
    else
    {
        str = "DP-XMC-5019-606 Board open Success";
        PrintActionLog(str, MSGTYPE_SUCCESS);
    }
}

void MainWindow::Update_Board_Details()
{
    unsigned short usLoop = 0;
    int iRow = 1;
    QString strData;
    QString qsErrMsg;

    QIcon ico_Success;
    QPixmap bkgnd(":/images/images/success.ico");
    ico_Success.addPixmap(bkgnd);

    QIcon ico_Failure;
    QPixmap bkgnd2(":/images/images/error.ico");
    ico_Failure.addPixmap (bkgnd2);

    QTreeWidgetItem *item;

    U8BIT u8TempSts = 0;

    if(m_obj3096Board.m_u16NoOfDetBoards < LINS_MAX_CPCI3096_BRDS)
    {
        for(usLoop = 0; usLoop < LINS_MAX_CPCI3096_BRDS; usLoop++, iRow++)
        {
            item = new QTreeWidgetItem;
            item->setTextAlignment (INDEX_BOARD_NAME, Qt::AlignCenter);
            item->setTextAlignment (INDEX_BOARD_NO, Qt::AlignCenter);
            item->setTextAlignment (INDEX_BUS_NO, Qt::AlignCenter);
            item->setTextAlignment (INDEX_FUNC_NO, Qt::AlignCenter);
            //        item->setText (INDEX_SERIAL_NO, "1");
            item->setText (INDEX_BOARD_NAME, "DP-cPCI-3096-300");
            item->setFont (INDEX_SERIAL_NO, QFont("Times New Roman", -1, QFont::Bold));
            item->setFont (INDEX_BOARD_NAME, QFont("Times New Roman", -1, QFont::Bold));
            strData.sprintf("DP-cPCI-3096-300");
            item->setText (INDEX_SERIAL_NO, QString::number (iRow));
            item->setText (INDEX_BOARD_NAME, strData);
            item->setText (INDEX_BOARD_NO, QString::number (usLoop + 1));

            item->setText (INDEX_BUS_NO, QString::number (m_out3096BrdDetails[usLoop].u8BusNo));
            item->setText (INDEX_SLOT_NO, QString::number (m_out3096BrdDetails[usLoop].u8SlotNo));
            item->setText (INDEX_FUNC_NO, QString::number (m_out3096BrdDetails[usLoop].u8FunctionNo));

            if (m_out3096BrdDetails[usLoop].s8BoardSts == DP_BORDS_STATUS_ONE)
            {
                item->setIcon (INDEX_STATUS, ico_Success);
            }
            else
            {
                qsErrMsg.sprintf("DP-MM-3096-300 Board-%d Expected in Slot-%d and Not Detected.",\
                                 usLoop+1, m_out3096BrdDetails[usLoop].u8SlotNo);

                PrintActionLog(qsErrMsg,MSGTYPE_ERROR);
                item->setIcon (INDEX_STATUS, ico_Failure);
            }

            ui->treew_BoardStatus->addTopLevelItem (item);
        }
    }
    else
    {
        for(usLoop = 0; usLoop < m_obj3096Board.m_u16NoOfDetBoards; usLoop++, iRow++)
        {
            item = new QTreeWidgetItem;
            item->setTextAlignment (INDEX_BOARD_NAME, Qt::AlignCenter);
            item->setTextAlignment (INDEX_BOARD_NO, Qt::AlignCenter);
            item->setTextAlignment (INDEX_BUS_NO, Qt::AlignCenter);
            item->setTextAlignment (INDEX_FUNC_NO, Qt::AlignCenter);
            //        item->setText (INDEX_SERIAL_NO, "1");
            item->setText (INDEX_BOARD_NAME, "DP-cPCI-3096-300");
            item->setFont (INDEX_SERIAL_NO, QFont("Times New Roman", -1, QFont::Bold));
            item->setFont (INDEX_BOARD_NAME, QFont("Times New Roman", -1, QFont::Bold));
            strData.sprintf("DP-cPCI-3096-300");
            item->setText (INDEX_SERIAL_NO, QString::number (iRow));
            item->setText (INDEX_BOARD_NAME, strData);
            item->setText (INDEX_BOARD_NO, QString::number (usLoop + 1));

            item->setText (INDEX_BUS_NO, QString::number (m_obj3096Board.m_pSAllDevLocDetails[usLoop].u8BusNo));
            item->setText (INDEX_SLOT_NO, QString::number (m_obj3096Board.m_pSAllDevLocDetails[usLoop].u8ExpSlotNo));
            item->setText (INDEX_FUNC_NO, QString::number (m_obj3096Board.m_pSAllDevLocDetails[usLoop].u8FunctionNo));

            if (m_obj3096Board.m_pSAllDevLocDetails[usLoop].s8BoardSts == DP_BORDS_STATUS_ONE)
            {
                item->setIcon (INDEX_STATUS, ico_Success);
            }
            else
            {
                if(usLoop < LINS_MAX_CPCI3096_BRDS)
                {
                    qsErrMsg.sprintf("DP-MM-3096-300 Board-%d Expected in Slot-%d and Detected in Slot-%d",\
                                     usLoop+1, m_obj3096Board.m_pSAllDevLocDetails[usLoop].u8ExpSlotNo, \
                                     m_obj3096Board.m_pSAllDevLocDetails[usLoop].u8SlotNo);
                }
                else
                {
                    qsErrMsg.sprintf("DP-MM-3096-300 Board-%d extra modules Detected in Slot-%d",\
                                     usLoop+1, m_obj3096Board.m_pSAllDevLocDetails[usLoop].u8SlotNo);
                }

                PrintActionLog(qsErrMsg,MSGTYPE_ERROR);
                item->setIcon (INDEX_STATUS, ico_Failure);
            }

            ui->treew_BoardStatus->addTopLevelItem (item);
        }
    }

    //    ui->treew_BoardStatus->addTopLevelItem (item);

    item = NULL;

    if(m_obj1105Board.m_u16NoOfDetBoards < LINS_MAX_MM1105_BRDS)
    {
        for(usLoop = 0; usLoop < LINS_MAX_MM1105_BRDS; usLoop++, iRow++)
        {
            item = new QTreeWidgetItem;
            item->setTextAlignment (INDEX_BOARD_NAME, Qt::AlignCenter);
            item->setTextAlignment (INDEX_BOARD_NO, Qt::AlignCenter);
            item->setTextAlignment (INDEX_BUS_NO, Qt::AlignCenter);
            item->setTextAlignment (INDEX_FUNC_NO, Qt::AlignCenter);
            item->setText (INDEX_BOARD_NAME, "DP-MM-1105-300");
            item->setFont (INDEX_SERIAL_NO, QFont("Times New Roman", -1, QFont::Bold));
            item->setFont (INDEX_BOARD_NAME, QFont("Times New Roman", -1, QFont::Bold));
            strData.sprintf("DP-MM-1105-300");
            item->setText (INDEX_SERIAL_NO, QString::number (iRow));
            item->setText (INDEX_BOARD_NAME, strData);
            item->setText (INDEX_BOARD_NO, QString::number(usLoop + 1));
            item->setText (INDEX_BUS_NO, QString::number(m_out1105BrdDetails[usLoop].u8BusNo));
            item->setText (INDEX_SLOT_NO, QString::number(m_out1105BrdDetails[usLoop].u8SlotNo) +":"+\
                           QString::number(m_out1105BrdDetails[usLoop].u8MMSlotNo));
            item->setText (INDEX_FUNC_NO, QString::number(m_out1105BrdDetails[usLoop].u8FunctionNo));
            item->setIcon (INDEX_STATUS, ico_Success);

            if (m_out1105BrdDetails[usLoop].s8BoardSts == DP_BORDS_STATUS_ONE)
            {
                item->setIcon (INDEX_STATUS, ico_Success);
            }
            else
            {
                qsErrMsg.sprintf("DP-MM-1105-300 Board-%d Expected in Slot-%d and Not Detected",\
                                 usLoop+1, m_out1105BrdDetails[usLoop].u8SlotNo);

                PrintActionLog(qsErrMsg,MSGTYPE_ERROR);
                item->setIcon (INDEX_STATUS, ico_Failure);
            }

            ui->treew_BoardStatus->addTopLevelItem (item);
        }
    }
    else
    {
        for(usLoop = 0; usLoop < m_obj1105Board.m_u16NoOfDetBoards; usLoop++, iRow++)
        {
            item = new QTreeWidgetItem;
            item->setTextAlignment (INDEX_BOARD_NAME, Qt::AlignCenter);
            item->setTextAlignment (INDEX_BOARD_NO, Qt::AlignCenter);
            item->setTextAlignment (INDEX_BUS_NO, Qt::AlignCenter);
            item->setTextAlignment (INDEX_FUNC_NO, Qt::AlignCenter);
            item->setText (INDEX_BOARD_NAME, "DP-MM-1105-300");
            item->setFont (INDEX_SERIAL_NO, QFont("Times New Roman", -1, QFont::Bold));
            item->setFont (INDEX_BOARD_NAME, QFont("Times New Roman", -1, QFont::Bold));
            strData.sprintf("DP-MM-1105-300");
            item->setText (INDEX_SERIAL_NO, QString::number (iRow));
            item->setText (INDEX_BOARD_NAME, strData);
            item->setText (INDEX_BOARD_NO, QString::number(usLoop + 1));
            item->setText (INDEX_BUS_NO, QString::number(m_obj1105Board.m_pSAllDevLocDetails[usLoop].u8BusNo));
            item->setText (INDEX_SLOT_NO, QString::number(m_obj1105Board.m_pSAllDevLocDetails[usLoop].u8ExpSlotNo) +":"+\
                           QString::number(m_obj1105Board.m_pSAllDevLocDetails[usLoop].u8MMSlotNo));
            item->setText (INDEX_FUNC_NO, QString::number(m_obj1105Board.m_pSAllDevLocDetails[usLoop].u8FunctionNo));
            item->setIcon (INDEX_STATUS, ico_Success);

            if (m_out1105BrdDetails[usLoop].s8BoardSts == DP_BORDS_STATUS_ONE)
            {
                item->setIcon (INDEX_STATUS, ico_Success);
            }
            else
            {
                if(usLoop < LINS_MAX_MM1105_BRDS)
                {
                    qsErrMsg.sprintf("DP-MM-1105-300 Board-%d Expected in Slot-%d and Detected in Slot-%d",\
                                     usLoop+1, m_obj1105Board.m_pSAllDevLocDetails[usLoop].u8ExpSlotNo, \
                                     m_obj1105Board.m_pSAllDevLocDetails[usLoop].u8SlotNo);
                }
                else
                {
                    qsErrMsg.sprintf("DP-MM-1105-300 Board-%d extra modules Detected in Slot-%d",\
                                     usLoop+1, m_obj1105Board.m_pSAllDevLocDetails[usLoop].u8SlotNo);
                }

                PrintActionLog(qsErrMsg,MSGTYPE_ERROR);
                item->setIcon (INDEX_STATUS, ico_Failure);
            }

            ui->treew_BoardStatus->addTopLevelItem (item);
        }
    }

    //    ui->treew_BoardStatus->addTopLevelItem (item);

    item = NULL;

    if(m_obj1123Board.m_u16NoOfDetBoards < LINS_MAX_MM1123_BRDS)
    {
        for(usLoop = 0; usLoop < LINS_MAX_MM1123_BRDS; usLoop++, iRow++)
        {
            item = new QTreeWidgetItem;
            item->setTextAlignment (INDEX_BOARD_NAME, Qt::AlignCenter);
            item->setTextAlignment (INDEX_BOARD_NO, Qt::AlignCenter);
            item->setTextAlignment (INDEX_BUS_NO, Qt::AlignCenter);
            item->setTextAlignment (INDEX_FUNC_NO, Qt::AlignCenter);
            item->setText (INDEX_BOARD_NAME, "DP-MM-1123-300");
            item->setFont (INDEX_SERIAL_NO, QFont("Times New Roman", -1, QFont::Bold));
            item->setFont (INDEX_BOARD_NAME, QFont("Times New Roman", -1, QFont::Bold));
            strData.sprintf("DP-MM-1123-300");
            item->setText (INDEX_SERIAL_NO, QString::number (iRow));
            item->setText (INDEX_BOARD_NAME, strData);
            item->setText (INDEX_BOARD_NO, QString::number(usLoop + 1));
            item->setText (INDEX_BUS_NO, QString::number(m_out1123BrdDetails[usLoop].u8BusNo));
            item->setText (INDEX_SLOT_NO, QString::number(m_out1123BrdDetails[usLoop].u8SlotNo) +":"+\
                           QString::number(m_out1123BrdDetails[usLoop].u8MMSlotNo));
            item->setText (INDEX_FUNC_NO, QString::number(m_out1123BrdDetails[usLoop].u8FunctionNo));
            item->setIcon (INDEX_STATUS, ico_Success);

            if (m_out1123BrdDetails[usLoop].s8BoardSts == DP_BORDS_STATUS_ONE)
            {
                item->setIcon (INDEX_STATUS, ico_Success);
            }
            else
            {
                qsErrMsg.sprintf("DP-MM-1123-300 Board-%d Expected in Slot-%d and Not Detected",\
                                 usLoop+1, m_out1123BrdDetails[usLoop].u8SlotNo);

                PrintActionLog(qsErrMsg,MSGTYPE_ERROR);
                item->setIcon (INDEX_STATUS, ico_Failure);
            }

            ui->treew_BoardStatus->addTopLevelItem (item);
        }
    }
    else
    {
        for(usLoop = 0; usLoop < m_obj1123Board.m_u16NoOfDetBoards; usLoop++, iRow++)
        {
            item = new QTreeWidgetItem;
            item->setTextAlignment (INDEX_BOARD_NAME, Qt::AlignCenter);
            item->setTextAlignment (INDEX_BOARD_NO, Qt::AlignCenter);
            item->setTextAlignment (INDEX_BUS_NO, Qt::AlignCenter);
            item->setTextAlignment (INDEX_FUNC_NO, Qt::AlignCenter);
            item->setText (INDEX_BOARD_NAME, "DP-MM-1123-300");
            item->setFont (INDEX_SERIAL_NO, QFont("Times New Roman", -1, QFont::Bold));
            item->setFont (INDEX_BOARD_NAME, QFont("Times New Roman", -1, QFont::Bold));
            strData.sprintf("DP-MM-1123-300");
            item->setText (INDEX_SERIAL_NO, QString::number (iRow));
            item->setText (INDEX_BOARD_NAME, strData);
            item->setText (INDEX_BOARD_NO, QString::number(usLoop + 1));
            item->setText (INDEX_BUS_NO, QString::number(m_obj1123Board.m_pSAllDevLocDetails[usLoop].u8BusNo));
            item->setText (INDEX_SLOT_NO, QString::number(m_obj1123Board.m_pSAllDevLocDetails[usLoop].u8ExpSlotNo) +":"+\
                           QString::number(m_obj1123Board.m_pSAllDevLocDetails[usLoop].u8MMSlotNo));
            item->setText (INDEX_FUNC_NO, QString::number(m_obj1123Board.m_pSAllDevLocDetails[usLoop].u8FunctionNo));

            if (m_obj1123Board.m_pSAllDevLocDetails[usLoop].s8BoardSts == DP_BORDS_STATUS_ONE)
            {
                item->setIcon (INDEX_STATUS, ico_Success);
            }
            else
            {
                if(usLoop < LINS_MAX_MM1123_BRDS)
                {
                    qsErrMsg.sprintf("DP-MM-1123-300 Board-%d Expected in Slot-%d and Detected in Slot-%d",\
                                     usLoop+1, m_obj1123Board.m_pSAllDevLocDetails[usLoop].u8ExpSlotNo, \
                                     m_obj1123Board.m_pSAllDevLocDetails[usLoop].u8SlotNo);
                }
                else
                {
                    qsErrMsg.sprintf("DP-MM-1123-300 Board-%d extra modules Detected in Slot-%d",\
                                     usLoop+1, m_obj1123Board.m_pSAllDevLocDetails[usLoop].u8SlotNo);
                }

                PrintActionLog(qsErrMsg,MSGTYPE_ERROR);
                item->setIcon (INDEX_STATUS, ico_Failure);
            }

            ui->treew_BoardStatus->addTopLevelItem (item);
        }
    }

    //    ui->treew_BoardStatus->addTopLevelItem (item);

    item = NULL;
    item = new QTreeWidgetItem;
    item->setTextAlignment (INDEX_BOARD_NAME, Qt::AlignCenter);
    item->setTextAlignment (INDEX_BOARD_NO, Qt::AlignCenter);
    item->setTextAlignment (INDEX_BUS_NO, Qt::AlignCenter);
    item->setTextAlignment (INDEX_FUNC_NO, Qt::AlignCenter);

    item->setFont (INDEX_SERIAL_NO, QFont("Times New Roman", -1, QFont::Bold));
    item->setFont (INDEX_BOARD_NAME, QFont("Times New Roman", -1, QFont::Bold));

    for(usLoop = 0; usLoop < m_objC1553BWrapper.m_u16NoOfDeviceFound; usLoop++)
    {
        QTreeWidgetItem *child = new QTreeWidgetItem;
        child->setTextAlignment (INDEX_BOARD_NAME, Qt::AlignCenter);
        child->setTextAlignment (INDEX_BOARD_NO, Qt::AlignCenter);
        child->setTextAlignment (INDEX_BUS_NO, Qt::AlignCenter);
        child->setTextAlignment (INDEX_FUNC_NO, Qt::AlignCenter);
        strData.sprintf("Channel %d",(usLoop+1));
        child->setText (INDEX_SERIAL_NO, QString::number (usLoop + 1));
        child->setText (INDEX_BOARD_NAME, strData);
        child->setText (INDEX_BOARD_NO, "1");
        child->setText (INDEX_BUS_NO, QString::number(m_pS1553B_DevLoc[usLoop]->u8BusNo));
        child->setText (INDEX_SLOT_NO, QString::number(m_pS1553B_DevLoc[usLoop]->u8SlotNo));
        child->setText (INDEX_FUNC_NO, QString::number(m_pS1553B_DevLoc[usLoop]->u8FunctionNo));
        child->setIcon (INDEX_STATUS, ico_Success);

        if(usLoop == 0)
        {
            u8TempSts = (m_pS1553B_DevLoc[usLoop]->u8ChnlSts == DP_BORDS_STATUS_ONE);
        }
        else
        {
            u8TempSts &= (m_pS1553B_DevLoc[usLoop]->u8ChnlSts == DP_BORDS_STATUS_ONE);
        }

        if (m_pS1553B_DevLoc[usLoop]->u8ChnlSts == DP_BORDS_STATUS_ONE)
        {
            child->setIcon (INDEX_STATUS, ico_Success);
        }
        else
        {
            child->setIcon (INDEX_STATUS, ico_Failure);
        }

        item->addChild (child);
    }

    item->setText (INDEX_SERIAL_NO, QString::number (iRow));
    item->setText (INDEX_BOARD_NAME, "DP-XMC-5019-606");
    item->setText (INDEX_BOARD_NO, "1");
    item->setText (INDEX_BUS_NO, QString::number(m_pS1553B_DevLoc[0]->u8BusNo));
    item->setText (INDEX_SLOT_NO, QString::number(m_pS1553B_DevLoc[0]->u8SlotNo));
    item->setText (INDEX_FUNC_NO, QString::number(m_pS1553B_DevLoc[0]->u8FunctionNo));
    if (u8TempSts == DP_BORDS_STATUS_ONE)
    {
        item->setIcon (INDEX_STATUS, ico_Success);
    }
    else
    {
        item->setIcon (INDEX_STATUS, ico_Failure);
        if(m_objC1553BWrapper.m_u16NoOfDeviceFound == 0)
        {
            qsErrMsg.sprintf("DP-XMC-5019-606 Expected in Bus-%d Slot-%d and Not Detected",\
                             m_pS1553B_DevLoc[0]->u8BusNo, m_pS1553B_DevLoc[0]->u8SlotNo);
            PrintActionLog(qsErrMsg,MSGTYPE_ERROR);
        }
    }

    ui->treew_BoardStatus->addTopLevelItem (item);

    item = NULL;

    //    ui->treew_BoardStatus->expandAll ();
}

void MainWindow::DP_TestCase_Checked(QTreeWidgetItem *item, int column)
{
    if(column != 0)
    {
        return;
    }

    int iIndex = 0, iIndex2 = 0;

    Qt::CheckState state;
    if(item->checkState(column))
        state = Qt::Checked;
    else
        state = Qt::Unchecked;

    if(item->childCount())
    {
#if 1
        /* To check/uncheck the children */
        for(iIndex = 0;iIndex < item->childCount();iIndex++)
        {
            item->child(iIndex)->setCheckState(0, state);

            for(iIndex2 = 0; iIndex2 < item->child(iIndex)->childCount(); iIndex2++)
            {
                item->child(iIndex)->child(iIndex2)->setCheckState(0, state);
            }
        }
        /**End*****To check/uncheck the children*/
#endif
        /*To check is parent available for the item. If available need to update parent checkbox*/
        if(item->parent() != NULL)
        {
            bool bChecked = false, bUnchecked = false;
            for(iIndex = 0;iIndex < item->parent()->childCount();iIndex++)
            {

                if(item->parent()->child(iIndex)->checkState(0))
                    bChecked = true;
                else
                    bUnchecked = true;
            }

            if(bChecked && bUnchecked)
                item->parent()->setCheckState(0, Qt::PartiallyChecked);
            else if(bChecked && !bUnchecked)
                item->parent()->setCheckState(0, Qt::Checked);
            else if(!bChecked && bUnchecked)
                item->parent()->setCheckState(0, Qt::Unchecked);
        }
        /**End*************************************To check is parent available for the item.*/
    }
    else
    {
        if(item->parent() == ui->treew_TestCase->topLevelItem(5))
        {
            for(int iCnt = 0; iCnt < ui->treew_TestCase->topLevelItemCount()-2; iCnt++)
            {
                if((item->parent() != ui->treew_TestCase->topLevelItem(iCnt)) && ui->treew_TestCase->topLevelItem(iCnt)->checkState(0) && (item->parent()->parent() != ui->treew_TestCase->topLevelItem(iCnt)))
                {
                    item->setCheckState(0,Qt::Unchecked);
                    QMessageBox::information(this,"Information",tr("Cannot perform PSU and RS232 Test at same time"));
                    return;
                }
            }
        }

        /*To check is parent available for the item. If available need to update parent checkbox*/
        bool bChecked = false, bUnchecked = false;
        for(iIndex = 0;iIndex < item->parent()->childCount();iIndex++)
        {
            //            if((item->parent() == ui->treew_TestCase->topLevelItem(4)) && (iIndex == 0))
            //                continue;
            if(item->parent()->child(iIndex)->checkState(0))
                bChecked = true;
            else
                bUnchecked = true;
        }
        if(bChecked && bUnchecked)
            item->parent()->setCheckState(0, Qt::PartiallyChecked);
        else if(bChecked && !bUnchecked)
            item->parent()->setCheckState(0, Qt::Checked);
        else if(!bChecked && bUnchecked)
            item->parent()->setCheckState(0, Qt::Unchecked);
        /**End****************************************To check is parent available for the item.*/

        /*To check is parent available for the parent item. If available need to update parent checkbox*/
        if(item->parent()->parent() != NULL)
        {
            bool bChecked2 = false, bUnchecked2 = false;
            for(iIndex2 = 0; iIndex2 < item->parent()->parent()->childCount(); iIndex2++)
            {
                if(item->parent()->parent()->child(iIndex2)->checkState(0))
                    bChecked2 = true;
                else
                    bUnchecked2 = true;
            }

            if(bChecked2 && bUnchecked2)
                item->parent()->parent()->setCheckState(0, Qt::PartiallyChecked);
            else if(bChecked2 && !bUnchecked2)
                item->parent()->parent()->setCheckState(0, Qt::Checked);
            else if(!bChecked2 && bUnchecked2)
                item->parent()->parent()->setCheckState(0, Qt::Unchecked);
        }
        /**End*****************To check is parent available for the parent item.*/
#if 0
        /*To disable/enable PSU options from the treeview by select/deselect RS232*/
        if(item->parent() == ui->treew_TestCase->topLevelItem(5))
        {
            bool bState = false;
            if(item->parent()->checkState(0))
            {
                bState = true;
            }

            for(int iIdx = 0; iIdx < ui->treew_TestCase->topLevelItemCount()-2; iIdx++)
            {
                ui->treew_TestCase->topLevelItem(iIdx)->setDisabled(bState);
            }
        }
        /**End***********************************************To disable/enable PSU*/
#endif
    }
}

void MainWindow::on_pb_Proceed_clicked()
{
    ui->actionAutoTest->setCheckable(true);
    ui->actionAutoTest->setChecked(true);

    ui->actionManualTest->setCheckable(false);
    ui->actionManualTest->setChecked(false);
    ui->sw_Test->setCurrentIndex(TAB_AUTO_TEST);
}

void MainWindow::on_actionDetection_Status_triggered()
{
    ui->actionAutoTest->setCheckable(false);
    ui->actionAutoTest->setChecked(false);

    ui->actionSynchronize_Start_Test->setCheckable(false);
    ui->actionSynchronize_Start_Test->setChecked(false);

    ui->actionManualTest->setCheckable(false);
    ui->actionManualTest->setChecked(false);

    ui->sw_Test->setCurrentIndex(TAB_DETECTION_STATUS);
    int iRetVal = 0;
    char cErrMsg[50];
    PSDPMMCRDRV_CARRIER_DEVICE_INFO pSAllCarrierDevInfo = NULL;
    PSDPMM1105_CARRIER_DEVICE_INFO pSAllCarrDevLocDetails = NULL;

#ifdef _ENABLE_BOARD_
    /* Get Total Devices Found */
    iRetVal = DPMMCRDRV_GetTotalDeviceFound(&m_usCards);
    if (iRetVal || (m_usCards == 0))
    {
        DPMM1105_GetErrorMessage(iRetVal, cErrMsg, sizeof(cErrMsg));
        QMessageBox::critical(this, "Board Operations", "MM driver module is not loaded / No carrier board is present in the system");
        return ;
    }
#ifndef WINDOWS
    /* Get All Carrier Device Location */
    pSAllCarrierDevInfo = (PSDPMMCRDRV_CARRIER_DEVICE_INFO)malloc(sizeof(SDPMMCRDRV_CARRIER_DEVICE_INFO) * m_usCards);
    if(pSAllCarrierDevInfo == NULL)
    {
        QMessageBox::warning( this, "Board Operations", "Error in memory creation for all carrier device location details\n");
        return ;
    }
    else
    {
        iRetVal = DPMMCRDRV_GetAllDeviceInformation(pSAllCarrierDevInfo, m_usCards);
        if (iRetVal)
        {
            DPMM1105_GetErrorMessage(iRetVal, cErrMsg, sizeof(cErrMsg));
            QMessageBox::critical(this, "Board Operations", cErrMsg);
            free(pSAllCarrierDevInfo);
            return ;
        }
    }

    pSAllCarrDevLocDetails = (PSDPMM1105_CARRIER_DEVICE_INFO)malloc(sizeof(SDPMM1105_CARRIER_DEVICE_INFO) * m_usCards);
    if(pSAllCarrDevLocDetails == NULL)
    {
        QMessageBox::warning( this, "Board Operations", "Error in memory creation for all carrier device location details\n");
        return ;
    }

    memcpy(pSAllCarrDevLocDetails, pSAllCarrierDevInfo, (sizeof(SDPMM1105_CARRIER_DEVICE_INFO) * m_usCards));

    iRetVal = DPMM1105_SetResource(m_usCards, pSAllCarrDevLocDetails, 0);
    if (iRetVal || (m_usCards == 0))
    {
        DPMM1105_GetErrorMessage(iRetVal, cErrMsg, sizeof(cErrMsg));
        QMessageBox::critical( this, "Board Operations", "DPMM1105 driver module is not loaded / No board is present in the system");
        return ;
    }
#endif

    iRetVal = DPMM1105_GetTotalDeviceFound(&m_usCards);
    if (iRetVal || (m_usCards == 0))
    {
        DPMM1105_GetErrorMessage(iRetVal, cErrMsg, sizeof(cErrMsg));
        QMessageBox::critical( this, "Board Operations", "DPMM1105 driver module is not loaded / No board is present in the system");
        return ;
    }

    /* Get All Device Location */
    m_pSAllDevLocDetails = (PSDPMM1105_DEVICE_LOCATION)malloc(sizeof(SDPMM1105_DEVICE_LOCATION) * m_usCards);
    if(m_pSAllDevLocDetails == NULL)
    {
        QMessageBox::warning( this, "Board Operations", "Error in memory creation for all device location details\n");
        return ;
    }
    else
    {
        iRetVal = DPMM1105_GetAllDeviceLocations(m_pSAllDevLocDetails, m_usCards);
        if (iRetVal)
        {
            DPMM1105_GetErrorMessage(iRetVal, cErrMsg, sizeof(cErrMsg));
            QMessageBox::critical(this, "Board operations", cErrMsg);
            free(m_pSAllDevLocDetails);
            return ;
        }
    }
#endif
}

void MainWindow::on_actionAbout_triggered()
{
    m_objAbout.exec();
}

//void MainWindow::DP_TestCase_Checked(QTreeWidgetItem *item, int )
//{
//    if((ui->treew_TestCase->topLevelItem(0)->checkState(0) && ui->treew_TestCase->topLevelItem(1)->checkState(0)) ||\
//            (ui->treew_TestCase->topLevelItem(1)->checkState(0) && ui->treew_TestCase->topLevelItem(2)->checkState(0)) ||\
//            (ui->treew_TestCase->topLevelItem(0)->checkState(0) && ui->treew_TestCase->topLevelItem(2)->checkState(0)))
//    {
//        item->setCheckState(0,Qt::Unchecked);
//        QMessageBox::warning(this,"Interface Test",tr("Either one of the test can be performed (J1 / J2 / J3)"));
//        return;
//    }

//    if(item->childCount() > 0)
//    {
//        for(int iTopLvlIdx = 0; iTopLvlIdx < item->childCount(); iTopLvlIdx++)
//        {
//            item->child(iTopLvlIdx)->setCheckState(0,item->checkState(0));
////            item->child(iTopLvlIdx)->setDisabled(item->checkState(0) == Qt::Unchecked);

//            if(item->child(iTopLvlIdx)->childCount()>0)
//            {
//                DP_TestCase_Checked(item->child(iTopLvlIdx), 0);
//            }
//        }
//    }
//}

void MainWindow::resetTreeWidget()
{
    m_iRowIndex = 0;
    for(int iIdx=0; iIdx< ui->treew_TestCase->topLevelItemCount(); iIdx++)
    {
        resetTreeWidgetColor(ui->treew_TestCase->topLevelItem(iIdx));
    }
}

void MainWindow::resetTreeWidgetColor(QTreeWidgetItem *item)
{
    ++m_iRowIndex;

    if( item->backgroundColor(0) == Qt::darkBlue)
    {
        if(m_iRowIndex % 2)
        {
            item->setBackgroundColor(0,0xffffff);
            item->setTextColor(0,Qt::black);
        }
        else
        {
            item->setBackgroundColor(0,0xf6f6f6);
            item->setTextColor(0,Qt::black);
        }
    }
    item->setText(2,"");

    if((item->childCount() > 0) && (item->isExpanded()))
    {
        for(int iTopLvlIdx = 0; iTopLvlIdx < item->childCount(); iTopLvlIdx++)
        {
            ++m_iRowIndex;
            if( item->child(iTopLvlIdx)->backgroundColor(0) == Qt::darkBlue)
            {
                if(m_iRowIndex % 2)
                {
                    item->child(iTopLvlIdx)->setBackgroundColor(0,0xffffff);
                    item->child(iTopLvlIdx)->setTextColor(0,Qt::black);
                }
                else
                {
                    item->child(iTopLvlIdx)->setBackgroundColor(0,0xf6f6f6);
                    item->child(iTopLvlIdx)->setTextColor(0,Qt::black);
                }
            }
            item->child(iTopLvlIdx)->setText(2,"");

            if(item->child(iTopLvlIdx)->childCount()>0)
            {
                --m_iRowIndex;
                resetTreeWidgetColor(item->child(iTopLvlIdx));
            }
        }
    }
}

void MainWindow::getTestSelection(QTreeWidgetItem *item, unsigned char *TestSelList, int *Cnt)
{
    for(int iIdx = 0; iIdx < item->childCount(); iIdx++)
    {
        //If the test has Sub-Test
        if(item->child(iIdx)->childCount() > 0)
        {
            //Traverse into Sub-Tests
            getTestSelection(item->child(iIdx),TestSelList, Cnt);
        }
        else
        {
            if(item->child(iIdx)->checkState(0) == Qt::Checked)
            {
                *Cnt = *Cnt+1;
                TestSelList[m_iTestCaseIndex] = 1;
                qDebug("%d : %s",m_iTestCaseIndex, item->child(iIdx)->text(0).toStdString().c_str());
            }

            //Total Sub-test count
            m_iTestCaseIndex++;
        }
    }
}

void MainWindow::on_pb_StartStopTest_clicked()
{
    int iIndex = 0, iTestSelCnt = 0;

    unsigned char ucTestSelList[DP_LINS_TESTCASE_MAX]={0};

    memset(m_qProcTestThread->m_ucTestSelect, 0, sizeof(m_qProcTestThread->m_ucTestSelect));
    memset(m_qProcTestThread->m_ucMainTestCaseSelection, 0, sizeof(m_qProcTestThread->m_ucMainTestCaseSelection));
    memset(m_qProcTestThread->m_bPSU_LoadSelect, 0, sizeof(m_qProcTestThread->m_bPSU_LoadSelect));

    if(m_bIsTestActive == false)
    {
        resetTreeWidget();

        ReadConfigFile();//read configuraton data from configuration file

        m_iTestCaseIndex = 0;
        for(iIndex = 0; iIndex < ui->treew_TestCase->topLevelItemCount(); iIndex++)//for resetting the coloumns in GUI
        {
            getTestSelection(ui->treew_TestCase->topLevelItem(iIndex),ucTestSelList,&iTestSelCnt);
        }

        if(iTestSelCnt == 0)
        {
            QMessageBox::information(this,"Auto Test","Test case not selected");
            return;
        }
        else
        {
            m_qProcTestThread->m_ucMainTestCaseSelection[0] = ui->treew_TestCase->topLevelItem(0)->checkState(0);
            m_qProcTestThread->m_ucMainTestCaseSelection[1] = ui->treew_TestCase->topLevelItem(1)->checkState(0);
            m_qProcTestThread->m_ucMainTestCaseSelection[2] = ui->treew_TestCase->topLevelItem(2)->checkState(0);
            m_qProcTestThread->m_ucMainTestCaseSelection[3] = ui->treew_TestCase->topLevelItem(3)->checkState(0);
            m_qProcTestThread->m_ucMainTestCaseSelection[4] = ui->treew_TestCase->topLevelItem(4)->checkState(0);
            m_qProcTestThread->m_bPSU_LoadSelect[0] = ui->treew_TestCase->topLevelItem(0)->checkState(1);
            m_qProcTestThread->m_bPSU_LoadSelect[1] = ui->treew_TestCase->topLevelItem(1)->checkState(1);
            m_qProcTestThread->m_bPSU_LoadSelect[2] = ui->treew_TestCase->topLevelItem(2)->checkState(1);
            memcpy(m_qProcTestThread->m_ucTestSelect, ucTestSelList,DP_LINS_TESTCASE_MAX);
        }

        m_objSystDet->ShowDialog();
        if(m_objSystDet->m_ucContinue)
            return;

        strcpy(m_qProcTestThread->m_SReportInfo.carrSerNo, m_objSystDet->m_leSlNo->text().toStdString().c_str());
        strcpy(m_qProcTestThread->m_SReportInfo.carrUserName, m_objSystDet->m_leTestBy->text().toStdString().c_str());
        strcpy(m_qProcTestThread->m_SReportInfo.carrTestLocation, m_objSystDet->m_leLoca->text().toStdString().c_str());
        strcpy(m_qProcTestThread->m_SReportInfo.carrPartNumber, "DP-ATE-8399-300");
        strcpy(m_qProcTestThread->m_SReportInfo.carrVersion, m_objAbout.m_strAppVer.toStdString().c_str());
        strcpy(m_qProcTestThread->m_SReportInfo.carrChecksum, QString::number(g_SGlobal.ulAppChecksum, 16).toUpper().toStdString().c_str());

        if(ucTestSelList[DP_1553B_Terminal_Test] || ucTestSelList[DP_1553B_Combined_Mode_Test] ||\
                ucTestSelList[DP_1553B_Sync_Test] || ucTestSelList[DP_1553B_Async_Test])
        {
            m_qProcTestThread->m_b1553BTestEnable = true;
        }
        else
        {
            m_qProcTestThread->m_b1553BTestEnable = false;
        }

        m_bIsTestTypeAuto = true;
        m_bIsTestActive = true;
        m_qProcTestThread->m_bPauseOnFailure = ui->cb_PauseOnFailure->isChecked();

        ui->pb_StartStopTest->setText("Stop");

        m_qProcTestThread->Start(m_bIsTestTypeAuto);
        PrintActionLog("AutoMode Test Started", MSGTYPE_INFO);
    }
    else if(m_bIsTestActive == true)\
    {
        m_bIsTestTypeAuto = false;
        m_bIsTestActive = false;

        ui->pb_StartStopTest->setText("Start");

        m_qProcTestThread->Stop();
        PrintActionLog("AutoMode Test Stopped", MSGTYPE_INFO);
    }
}

void MainWindow::ConfigFileCreation()
{
    QString fileLinsGAtpConf = qApp->applicationDirPath() + "/config/LINS_CM_ATPConfiguration.ini";
    QFile qLinsGAtpConfFile(fileLinsGAtpConf);
    if (!qLinsGAtpConfFile.exists())
    {
        QString strLinsGAtpConfigData = "#Power Supplies Configuration\n[PSU_CONFIGURATION]\n#PSU = \"PSUaddress,NominalVoltage,UnderVoltage,OverVoltage,CurrentLimit,MaxVoltage,TestStartRange,TestStopRange,StepUpRange\"\n#PSU_1			address 1\nPSU_1 = \"1,28.00,18.00,45.00,07.00,40.00,22.00,36.00,02.00\"\n\n#PSU_2			address 2\nPSU_2 = \"2,28.00,18.00,45.00,07.00,40.00,22.00,36.00,02.00\"\n\n#PSU_3			address 3\nPSU_3 = \"3,28.00,18.00,45.00,07.00,40.00,22.00,36.00,02.00\"\n\n#PSU_4			address 4\nPSU_4 = \"4,28.00,18.00,45.00,07.00,40.00,22.00,36.00,02.00\"\n\n[LOAD_IMPEDANCE_VALUE]\n#LINS, LVOBC, SENSOR laod value\nLLS_IMP = \"14.0\"\n#RESET load value\nRESET_IMP = \"3.5\"\n#DPU load value\nDPU_IMP = \"7.0\"\n\n#RS232 Configuration details\n[RS232_CONFIGURATION]\n\n#COM1 Configuration (PSU communication \"ttyS0\")\n# OneStop = 1,  OneAndHalfStop = 3,  TwoStop = 2\nCOM_1_Stop_Bit = \"1\"  \n\nCOM_1_BaudRate = \"9600\"\n\n#Min - 5, Max = 8\nCOM_1_Data_Bit = \"8\"\n\n#No Parity = 0, Even Parity = 2,  Odd Parity = 3\nCOM_1_Parity = \"0\"\n\n#Test Data selection\n#Counter = 0 and pattern = 1\nCOM_1_Data_Type = \"0\"\n\n#if pattern\nCOM_1_Pattern_Data = \"0xAA\"\n\n#COM2 Configuration\n# OneStop = 1,  OneAndHalfStop = 3,  TwoStop = 2\nCOM_2_Stop_Bit = \"1\"  \n\nCOM_2_BaudRate = \"9600\"\n\n#Min - 5, Max = 8\nCOM_2_Data_Bit = \"8\"\n\n#No Parity = 0, Even Parity = 2,  Odd Parity = 3\nCOM_2_Parity = \"0\"\n\n#Test Data selection\n#Counter = 0 and pattern = 1\nCOM_2_Data_Type = \"0\"\n\n#if pattern\nCOM_2_Pattern_Data = \"0xAA\"\n\n\n#1553B Configuration details\n[1553B_CONFIGURATION]\n#Bus Configuration 1 - CH_A, 0 - CH_B\nCH1_Bus = \"1\"\nCH2_Bus = \"1\"\nCH3_Bus = \"1\"\nCH4_Bus = \"1\"\n\n#RT address and RT sub-address selection 1-31\nRT_ADDR = \"1\"\nRT_SUB_ADDR = \"1\"\n\n#Test Data selection\n#Counter = 0 and pattern = 1\nData_Type = \"0\"\n\n#if pattern\nPattern_Data = \"0xAAAA\"\n";
        if(qLinsGAtpConfFile.open(QFile::ReadWrite | QFile::Text))
        {
            qLinsGAtpConfFile.write(strLinsGAtpConfigData.toLatin1().data());
            qLinsGAtpConfFile.flush();
        }
        qLinsGAtpConfFile.close();
    }

    QString fileSystDet = qApp->applicationDirPath() + "/config/SystemDetails.txt";
    QFile qSystConfFile(fileSystDet);
    if (!qSystConfFile.exists())
    {
        QString strSystDetails = "001,DP-INTEG,User";
        if(qSystConfFile.open(QFile::ReadWrite | QFile::Text))
        {
            qSystConfFile.write(strSystDetails.toLatin1().data());
            qSystConfFile.flush();
        }
        qSystConfFile.close();
    }
}

bool MainWindow::ReadConfigFile()
{
    bool bOpt;
    int iLoop = DP_UML_INIT_VALUE;
    QSettings *ptATPConfigurationFile;
    QString qsFilePath = DP_FILE_ATP_CONFIG;

    QStringList strData;
    QSettings *ptATPBoardDetailsFile;

    SDP_PSU_CONFIG STempPSUConfig[TOTAL_PSU];

    float fCompVoltage = 60.0f;
    float fCompCurrent = 12.5f;

    unsigned char ucFailure = 0;

    QString strTemp = "", strRead = "", strPSUAddr[TOTAL_PSU];

    QString ExpTempVal = "";
    QString ExpResVal = "";
    QStringList strListTempVal;
    QStringList strListResVal;
    float fTolTemp = 0.0;
    float fTolRes = 0.0;

    QStringList strListData;

    QString qsBoardDetFilePath = qApp->applicationDirPath() + "/config/BoardDetails.ini";

    QFileInfo check_Board_file(qsBoardDetFilePath);
    if (check_Board_file.exists()&& check_Board_file.isFile())
    {
        ptATPBoardDetailsFile = new(QSettings)(qsBoardDetFilePath, QSettings::IniFormat);
    }
    else
    {
        QMessageBox::warning(this,"File not available","Board details file not found.\nKindly place a board detail file or re-start the application to auto-generate default board detail file");
        return false;
    }

    //Read 3096 Board Slot Details from Configuration file
    for(int iLoop = 0; iLoop < LINS_MAX_CPCI3096_BRDS; iLoop++)
    {
        strTemp = "DP-cPCI-3096/Board_"+QString::number(iLoop+1);
        strRead = ptATPBoardDetailsFile->value(strTemp).toString();
        if(!strRead.isEmpty())
        {
            strData = strRead.split(",");
            strTemp = strData.at(0);
            m_S3096ExpDevLocation[iLoop].u8BusNo = strTemp.toInt(&bOpt);
            strTemp = strData.at(1);
            m_S3096ExpDevLocation[iLoop].u8SlotNo = strTemp.toInt(&bOpt);
            strTemp = strData.at(2);
            m_S3096ExpDevLocation[iLoop].u8FunctionNo = strTemp.toInt(&bOpt);
        }
        else
        {
            strTemp = "Board details found in file for "+strTemp+" is invalid.Proceeding with default details.";
            PrintActionLog(strTemp.toStdString().c_str(), MSGTYPE_ERROR);
            m_S3096ExpDevLocation[iLoop].u8BusNo = 6;
            m_S3096ExpDevLocation[iLoop].u8FunctionNo = 0;
            m_S3096ExpDevLocation[iLoop].u8SlotNo = 14+iLoop;
        }
        //        qDebug("rd slot : %d",m_S3096ExpDevLocation[iLoop].u8SlotNo);
    }

    //Read 1105 Board Slot Details from Configuration file
    for(int iLoop = 0; iLoop < LINS_MAX_MM1105_BRDS; iLoop++)
    {
        strTemp = "DP-MM-1105/Board_"+QString::number(iLoop+1);
        strRead = ptATPBoardDetailsFile->value(strTemp).toString();
        if(!strRead.isEmpty())
        {
            strData = strRead.split(",");
            strTemp = strData.at(0);
            m_S1105ExpDevLocation[iLoop].u8BusNo = strTemp.toInt(&bOpt);
            strTemp = strData.at(1);
            m_S1105ExpDevLocation[iLoop].u8SlotNo = strTemp.toInt(&bOpt);
            strTemp = strData.at(2);
            m_S1105ExpDevLocation[iLoop].u8FunctionNo = strTemp.toInt(&bOpt);
            strTemp = strData.at(3);
            m_S1105ExpDevLocation[iLoop].u8MMSlotNo = strTemp.toInt(&bOpt);
        }
        else
        {
            strTemp = "Board details found in file for "+strTemp+" is invalid.Proceeding with default details.";
            PrintActionLog(strTemp.toStdString().c_str(), MSGTYPE_ERROR);
            m_S1105ExpDevLocation[iLoop].u8BusNo = 6;
            m_S1105ExpDevLocation[iLoop].u8FunctionNo = 0;
            m_S1105ExpDevLocation[iLoop].u8SlotNo = 12;
            m_S1105ExpDevLocation[iLoop].u8MMSlotNo = iLoop+1;
        }
    }

    //Read 1123 Board Slot Details from Configuration file
    for(int iLoop = 0; iLoop < LINS_MAX_MM1123_BRDS; iLoop++)
    {
        strTemp = "DP-MM-1123/Board_"+QString::number(iLoop+1);
        strRead = ptATPBoardDetailsFile->value(strTemp).toString();
        if(!strRead.isEmpty())
        {
            strData = strRead.split(",");
            strTemp = strData.at(0);
            m_S1123ExpDevLocation[iLoop].u8BusNo = strTemp.toInt(&bOpt);
            strTemp = strData.at(1);
            m_S1123ExpDevLocation[iLoop].u8SlotNo = strTemp.toInt(&bOpt);
            strTemp = strData.at(2);
            m_S1123ExpDevLocation[iLoop].u8FunctionNo = strTemp.toInt(&bOpt);
            strTemp = strData.at(3);
            m_S1123ExpDevLocation[iLoop].u8MMSlotNo = strTemp.toInt(&bOpt);
        }
        else
        {
            strTemp = "Board details found in file for "+strTemp+" is invalid.Proceeding with default details.";
            PrintActionLog(strTemp.toStdString().c_str(), MSGTYPE_ERROR);
            m_S1123ExpDevLocation[iLoop].u8BusNo = 6;
            m_S1123ExpDevLocation[iLoop].u8FunctionNo = 0;
            m_S1123ExpDevLocation[iLoop].u8SlotNo = 13;
            m_S1123ExpDevLocation[iLoop].u8MMSlotNo = iLoop+1;
        }
    }

    strTemp = "DP-XMC-5019-606/Board_1";
    strRead = ptATPBoardDetailsFile->value(strTemp).toString();
    if(!strRead.isEmpty())
    {
        strData = strRead.split(",");
        strTemp = strData.at(0);
        m_uc1553BExpBusNo = strTemp.toInt(&bOpt);
        strTemp = strData.at(1);
        m_uc1553BExpSlotNo = strTemp.toInt(&bOpt);
    }
    else
    {
        strTemp = "Board details found in file for "+strTemp+" is invalid.Proceeding with default details.";
        PrintActionLog(strTemp.toStdString().c_str(), MSGTYPE_ERROR);
        m_uc1553BExpBusNo = 8;
        m_uc1553BExpSlotNo = 0;
    }

    QFileInfo check_file(qsFilePath);
    if (check_file.exists()&& check_file.isFile())
    {
        ptATPConfigurationFile = new(QSettings)(qsFilePath, QSettings::IniFormat);
    }
    else
    {
        QMessageBox::warning(this,"File not available","Board details file not found.\nKindly place a board detail file or re-start the application to auto-generate default board detail file");
        return false;
    }

    //Read COM 1 Configurations from Configuration file
    m_qProcTestThread->m_stAutomodeIp.usCOM1_Baudrate = ptATPConfigurationFile->value("RS232_CONFIGURATION/COM_1_BaudRate").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.ucCOM1_StopBit = ptATPConfigurationFile->value("RS232_CONFIGURATION/COM_1_Stop_Bit").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.ucCOM1_DataBit = ptATPConfigurationFile->value("RS232_CONFIGURATION/COM_1_Data_Bit").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.ucCOM1_Parity = ptATPConfigurationFile->value("RS232_CONFIGURATION/COM_1_Parity").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.ucCOM1_DataType = ptATPConfigurationFile->value("RS232_CONFIGURATION/COM_1_Data_Type").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.ucCOM1_PatternData = ptATPConfigurationFile->value("RS232_CONFIGURATION/COM_1_Pattern_Data").toString().toInt(&bOpt);

    //Read COM 2 Configurations from Configuration file
    m_qProcTestThread->m_stAutomodeIp.usCOM2_Baudrate = ptATPConfigurationFile->value("RS232_CONFIGURATION/COM_2_BaudRate").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.ucCOM2_StopBit = ptATPConfigurationFile->value("RS232_CONFIGURATION/COM_2_Stop_Bit").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.ucCOM2_DataBit = ptATPConfigurationFile->value("RS232_CONFIGURATION/COM_2_Data_Bit").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.ucCOM2_Parity = ptATPConfigurationFile->value("RS232_CONFIGURATION/COM_2_Parity").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.ucCOM2_DataType = ptATPConfigurationFile->value("RS232_CONFIGURATION/COM_2_Data_Type").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.ucCOM2_PatternData = ptATPConfigurationFile->value("RS232_CONFIGURATION/COM_2_Pattern_Data").toString().toInt(&bOpt);

    //Read 1553B Configurations from Configuration file
    m_qProcTestThread->m_stAutomodeIp.carr1553B_BusSelect[0] = ptATPConfigurationFile->value("1553B_CONFIGURATION/CH1_Bus").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.carr1553B_BusSelect[1] = ptATPConfigurationFile->value("1553B_CONFIGURATION/CH2_Bus").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.carr1553B_BusSelect[2] = ptATPConfigurationFile->value("1553B_CONFIGURATION/CH3_Bus").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.carr1553B_BusSelect[3] = ptATPConfigurationFile->value("1553B_CONFIGURATION/CH4_Bus").toString().toInt(&bOpt);

#ifndef _ADDRESS_INCREMENTAL
    m_qProcTestThread->m_ucRTAddr = ptATPConfigurationFile->value("1553B_CONFIGURATION/RT_ADDR").toString().toInt(&bOpt);
    m_qProcTestThread->m_ucRXRTSubAddr = ptATPConfigurationFile->value("1553B_CONFIGURATION/RT_SUB_ADDR").toString().toInt(&bOpt);
    m_qProcTestThread->m_ucTXRTSubAddr = ptATPConfigurationFile->value("1553B_CONFIGURATION/RT_SUB_ADDR").toString().toInt(&bOpt);
#endif
    m_qProcTestThread->m_stAutomodeIp.uc1553B_DataType = ptATPConfigurationFile->value("1553B_CONFIGURATION/Data_Type").toString().toInt(&bOpt);
    m_qProcTestThread->m_stAutomodeIp.uc1553B_PatternData = ptATPConfigurationFile->value("1553B_CONFIGURATION/Pattern_Data").toString().toInt(&bOpt);

    /*** Reading PSU Details ***/

    /** Default PSU Configurations */
    m_qProcTestThread->m_SPSUConfig[0].m_fNominalVolt = 28.0f;
    m_qProcTestThread->m_SPSUConfig[0].m_fUnderVolt = 18.0f;
    m_qProcTestThread->m_SPSUConfig[0].m_fOverVolt = 45.0f;
    m_qProcTestThread->m_SPSUConfig[0].m_fCurrentLimit = 7.0f;
    m_qProcTestThread->m_SPSUConfig[0].m_fMaxVolt = 40.0f;
    m_qProcTestThread->m_SPSUConfig[0].m_fTestStartRange = 22.0f;
    m_qProcTestThread->m_SPSUConfig[0].m_fTestStopRange = 36.0f;
    m_qProcTestThread->m_SPSUConfig[0].m_fStepupRange = 2.0f;

    m_qProcTestThread->m_SPSUConfig[1] = m_qProcTestThread->m_SPSUConfig[0];
    m_qProcTestThread->m_SPSUConfig[2] = m_qProcTestThread->m_SPSUConfig[0];
    m_qProcTestThread->m_SPSUConfig[3] = m_qProcTestThread->m_SPSUConfig[0];

    /** Removing all rows in the Table */
    while(ui->tw_EquipmentConfigDetails->rowCount () > DP_UML_INIT_VALUE)
    {
        ui->tw_EquipmentConfigDetails->removeRow (DP_UML_INIT_VALUE);
    }

    /** Thermistance Value Read **/
    ExpTempVal = ptATPConfigurationFile->value ("THERMISTOR_VALUE/EXP_TEMP").toString();
    ExpResVal = ptATPConfigurationFile->value ("THERMISTOR_VALUE/EXP_RES").toString();
    fTolTemp = ptATPConfigurationFile->value ("THERMISTOR_VALUE/TOLERENCE_TEMP").toFloat();
    fTolRes = ptATPConfigurationFile->value ("THERMISTOR_VALUE/TOLERENCE_RES").toFloat();

    if(!ExpTempVal.isEmpty())
    {
        strListTempVal = ExpTempVal.split (",");
        strListResVal = ExpResVal.split (",");
    }

    if(ExpTempVal.count() < 4)
    {
        ExpTempVal = "-24.5,1.1,25.0,92.8";
        ExpResVal = "100.0,28.0,10.0,1.0";
        fTolTemp = 2.0;
        fTolRes = 1.0;
    }

    for (iLoop = 0; iLoop < 4; iLoop++)
    {
        m_qProcTestThread->m_fExpTemp[iLoop] = QString(strListTempVal.at(iLoop)).toFloat();
        m_qProcTestThread->m_fExpRes[iLoop] = QString(strListResVal.at(iLoop)).toFloat();
        //        qDebug("%f,%f",m_qProcTestThread->m_fExpTemp[iLoop],m_qProcTestThread->m_fExpRes[iLoop]);
    }

    m_qProcTestThread->m_fTolTemp = fTolTemp;
    m_qProcTestThread->m_fTolRes = fTolRes;

    for (iLoop = DP_UML_INIT_VALUE; iLoop < TOTAL_PSU; iLoop++)
    {
        strTemp = "PSU_CONFIGURATION/PSU_" + QString::number (iLoop + 1);

        strRead = ptATPConfigurationFile->value (strTemp).toString ();

        if (!strRead.isEmpty ())
        {
            STempPSUConfig[iLoop].m_strPSUName.sprintf ("PSU_%d", (iLoop + 1));
            strListData = strRead.split (",");
            strPSUAddr[iLoop] = strListData.at (PSU_CONFIG_PSU_ADDR);
            strTemp = strListData.at (PSU_CONFIG_NOMINAL_VOLT);
            STempPSUConfig[iLoop].m_fNominalVolt = strTemp.toFloat (&bOpt);
            strTemp = strListData.at (PSU_CONFIG_UNDER_VOLT);
            STempPSUConfig[iLoop].m_fUnderVolt = strTemp.toFloat (&bOpt);
            strTemp = strListData.at (PSU_CONFIG_OVER_VOLT);
            STempPSUConfig[iLoop].m_fOverVolt = strTemp.toFloat (&bOpt);
            strTemp = strListData.at (PSU_CONFIG_CURRENT_LIMIT);
            STempPSUConfig[iLoop].m_fCurrentLimit = strTemp.toFloat (&bOpt);
            strTemp = strListData.at (PSU_CONFIG_MAX_VOLT);
            STempPSUConfig[iLoop].m_fMaxVolt = strTemp.toFloat (&bOpt);
            strTemp = strListData.at (PSU_CONFIG_TEST_START_RANGE);
            STempPSUConfig[iLoop].m_fTestStartRange = strTemp.toFloat (&bOpt);
            strTemp = strListData.at (PSU_CONFIG_TEST_STOP_RANGE);
            STempPSUConfig[iLoop].m_fTestStopRange = strTemp.toFloat (&bOpt);
            strTemp = strListData.at (PSU_CONFIG_STEPUP_RANGE);
            STempPSUConfig[iLoop].m_fStepupRange = strTemp.toFloat (&bOpt);

            if ((STempPSUConfig[iLoop].m_fNominalVolt < 1.0f) || (STempPSUConfig[iLoop].m_fNominalVolt > fCompVoltage))
            {
                QMessageBox::information (this, STempPSUConfig[iLoop].m_strPSUName + " Nominal Voltage", STempPSUConfig[iLoop].m_strPSUName + " Nominal Voltage in configuration file exceeded exptected voltage\nExpected range : 1.00V - " + QString::number (fCompVoltage, 'f', 2) + "V");
                ucFailure = 1;
            }
            if (STempPSUConfig[iLoop].m_fUnderVolt < (STempPSUConfig[iLoop].m_fNominalVolt * 0.05))
            {
                QMessageBox::information (this, STempPSUConfig[iLoop].m_strPSUName + " Under Voltage", STempPSUConfig[iLoop].m_strPSUName + " Under Voltage in configuration file cannot be less than 5% of Nominal Voltage\nExpected Voltage >= " + QString::number ((STempPSUConfig[iLoop].m_fNominalVolt * 0.05), 'f', 2) + "V");
                ucFailure = 1;
            }
            if ((STempPSUConfig[iLoop].m_fMaxVolt < 1.0f) || (STempPSUConfig[iLoop].m_fMaxVolt > fCompVoltage))
            {
                QMessageBox::information (this, STempPSUConfig[iLoop].m_strPSUName + " Maximum Voltage", STempPSUConfig[iLoop].m_strPSUName + " Maximum Voltage in configuration file exceeded exptected voltage\nExpected range : 1.00V - " + QString::number (fCompVoltage, 'f', 2) + "V");
                ucFailure = 1;
            }
            if (STempPSUConfig[iLoop].m_fOverVolt < (STempPSUConfig[iLoop].m_fMaxVolt - (STempPSUConfig[iLoop].m_fMaxVolt * 0.05)))
            {
                QMessageBox::information (this, STempPSUConfig[iLoop].m_strPSUName + " Over Voltage", STempPSUConfig[iLoop].m_strPSUName + " Over Voltage in configuration file cannot be less than (Maximum Voltage - (50% of Maximum Voltage)\nExpected range >= " + QString::number ((STempPSUConfig[iLoop].m_fMaxVolt - (STempPSUConfig[iLoop].m_fMaxVolt * 0.05)), 'f', 2) + "V");
                ucFailure = 1;
            }
            if ((STempPSUConfig[iLoop].m_fCurrentLimit < 0.0f) || (STempPSUConfig[iLoop].m_fCurrentLimit > fCompCurrent))
            {
                QMessageBox::information (this, STempPSUConfig[iLoop].m_strPSUName + " Current Limit", STempPSUConfig[iLoop].m_strPSUName + " Current Limit in configuration file exceeded exptected voltage\nExpected range : 0.00A - " + QString::number (fCompVoltage, 'f', 2) + "A");
                ucFailure = 1;
            }
            if ((STempPSUConfig[iLoop].m_fTestStartRange < 1.0f) || (STempPSUConfig[iLoop].m_fTestStartRange > fCompVoltage))
            {
                QMessageBox::information (this, STempPSUConfig[iLoop].m_strPSUName + " Start Voltage", STempPSUConfig[iLoop].m_strPSUName + " Start Voltage in configuration file exceeded exptected voltage\nExpected range : 1.00V - " + QString::number (fCompVoltage, 'f', 2) + "V");
                ucFailure = 1;
            }
            if ((STempPSUConfig[iLoop].m_fTestStopRange < 1.0f) || (STempPSUConfig[iLoop].m_fTestStopRange > fCompVoltage))
            {
                QMessageBox::information (this, STempPSUConfig[iLoop].m_strPSUName + " Stop Voltage", STempPSUConfig[iLoop].m_strPSUName + " Stop Voltage in configuration file exceeded exptected voltage\nExpected range : 1.00V - " + QString::number (fCompVoltage, 'f', 2) + "V");
                ucFailure = 1;
            }
            if ((STempPSUConfig[iLoop].m_fStepupRange < 1.0f) || (STempPSUConfig[iLoop].m_fStepupRange > 36.0f))
            {
                QMessageBox::information (this, STempPSUConfig[iLoop].m_strPSUName + " Step Up Voltage", STempPSUConfig[iLoop].m_strPSUName + " Step Up Voltage in configuration file exceeded exptected voltage\nExpected range : 1.00V - 36.00V");
                ucFailure = 1;
            }

            if (ucFailure == DP_UML_SUCCESS)
            {
                m_qProcTestThread->m_SPSUConfig[iLoop] = STempPSUConfig[iLoop];
            }
        }
        else
        {
            strPSUAddr[iLoop] = (iLoop + 1);
            ucFailure = 1;
        }

        /**** Updating PS Configuration Table *******/

        ui->tw_EquipmentConfigDetails->insertRow (iLoop);
        ui->tw_EquipmentConfigDetails->setItem (iLoop, TABLE_IDX_PSU_NAME, new QTableWidgetItem(QString(m_qProcTestThread->m_SPSUConfig[iLoop].m_strPSUName)));
        ui->tw_EquipmentConfigDetails->setItem (iLoop, TABLE_IDX_PSU_ADDR, new QTableWidgetItem(QString(strPSUAddr[iLoop])));
        ui->tw_EquipmentConfigDetails->setItem (iLoop, TABLE_IDX_NOMINAL_VOLT, new QTableWidgetItem(QString::number (m_qProcTestThread->m_SPSUConfig[iLoop].m_fNominalVolt)));
        ui->tw_EquipmentConfigDetails->setItem (iLoop, TABLE_IDX_UNDER_VOLT, new QTableWidgetItem(QString::number (m_qProcTestThread->m_SPSUConfig[iLoop].m_fUnderVolt)));
        ui->tw_EquipmentConfigDetails->setItem (iLoop, TABLE_IDX_OVER_VOLT, new QTableWidgetItem(QString::number (m_qProcTestThread->m_SPSUConfig[iLoop].m_fOverVolt)));
        ui->tw_EquipmentConfigDetails->setItem (iLoop, TABLE_IDX_MAX_VOLT, new QTableWidgetItem(QString::number (m_qProcTestThread->m_SPSUConfig[iLoop].m_fMaxVolt)));
        ui->tw_EquipmentConfigDetails->setItem (iLoop, TABLE_IDX_CURRENT_LIMIT, new QTableWidgetItem(QString::number (m_qProcTestThread->m_SPSUConfig[iLoop].m_fCurrentLimit)));

        ui->tw_EquipmentConfigDetails->item (iLoop, TABLE_IDX_PSU_NAME)->setTextAlignment (Qt::AlignLeft | Qt::AlignVCenter);
        ui->tw_EquipmentConfigDetails->item (iLoop, TABLE_IDX_PSU_ADDR)->setTextAlignment (Qt::AlignCenter);
        ui->tw_EquipmentConfigDetails->item (iLoop, TABLE_IDX_NOMINAL_VOLT)->setTextAlignment (Qt::AlignCenter);
        ui->tw_EquipmentConfigDetails->item (iLoop, TABLE_IDX_UNDER_VOLT)->setTextAlignment (Qt::AlignCenter);
        ui->tw_EquipmentConfigDetails->item (iLoop, TABLE_IDX_OVER_VOLT)->setTextAlignment (Qt::AlignCenter);
        ui->tw_EquipmentConfigDetails->item (iLoop, TABLE_IDX_MAX_VOLT)->setTextAlignment (Qt::AlignCenter);
        ui->tw_EquipmentConfigDetails->item (iLoop, TABLE_IDX_CURRENT_LIMIT)->setTextAlignment (Qt::AlignCenter);

        /*******************************************/
    }
    /******************************************************/
    if(ucFailure)
        return false;
    else
        return true;
}

void MainWindow::highlightTest(QTreeWidgetItem *item, int in_iTestIdx, int in_iHiType, int *in_iStatus)
{
    int headNode = 0;
    QBrush qcParentTest;

    for(int iIdx = 0; iIdx < item->childCount(); iIdx++)
    {
        //If the test has Sub-Test
        if(item->child(iIdx)->childCount() > 0)
        {
            headNode = 1;

            //Traverse into Sub-Tests
            highlightTest(item->child(iIdx),in_iTestIdx, in_iHiType, in_iStatus);
        }
        else
        {

            if(m_iTestCaseIndex == in_iTestIdx)
            {
                *in_iStatus = 1;

                switch(in_iHiType)
                {
                case DP_TEST_INPROGRESS:
                {
                    qcSubTest = item->child(iIdx)->background(0);
                    item->child(iIdx)->setBackgroundColor(0,Qt::darkBlue);
                    item->child(iIdx)->setTextColor(0,Qt::white);
                } break;
                case DP_TEST_COMPLETED:
                {
                    item->child(iIdx)->setBackground(0,qcSubTest);
                    item->child(iIdx)->setTextColor(0,Qt::black);
                } break;
                case DP_TEST_PASS:
                {
                    item->child(iIdx)->setBackground(0,qcSubTest);
                    item->child(iIdx)->setTextColor(0,Qt::black);

                    item->child(iIdx)->setFont(2,QFont( "MS Shell Dlg 2", 9, QFont::Bold));
                    item->child(iIdx)->setText(2,"PASS");
                    item->child(iIdx)->setTextColor(2,Qt::darkGreen);
                    item->child(iIdx)->setTextAlignment(2,Qt::AlignCenter);
                } break;
                case DP_TEST_FAIL:
                {
                    item->child(iIdx)->setBackground(0,qcSubTest);
                    item->child(iIdx)->setTextColor(0,Qt::black);

                    item->child(iIdx)->setFont(2,QFont( "MS Shell Dlg 2", 9, QFont::Bold));
                    item->child(iIdx)->setText(2,"FAIL");
                    item->child(iIdx)->setTextColor(2,Qt::darkRed);
                    item->child(iIdx)->setTextAlignment(2,Qt::AlignCenter);
                } break;
                case DP_TEST_RESET:
                {
                    item->child(iIdx)->setBackground(0,qcSubTest);
                    item->child(iIdx)->setTextColor(0,Qt::black);
                    item->child(iIdx)->setText(2,"");
                } break;
                default:
                {
                    if(iIdx%2)
                    {
                        item->child(iIdx)->setBackgroundColor(0,Qt::white);
                    }
                    else
                    {
                        item->child(iIdx)->setBackgroundColor(0,Qt::lightGray);
                    }

                    item->child(iIdx)->setTextColor(0,Qt::black);
                }
                }

                if((in_iHiType == DP_TEST_PASS)||(in_iHiType == DP_TEST_FAIL))
                {
                    if(item->child(iIdx)->text(2) == "FAIL")
                    {
                        m_iOverAllResult =1;
                    }
                }
            }

            //            if((in_iHiType == DP_TEST_PASS)||(in_iHiType == DP_TEST_FAIL))
            {
                if(item->child(iIdx)->text(2) == "FAIL")
                {
                    m_iTopLevelResult=1;
                }
            }

            m_iTestCaseIndex++;
        }

        if(*in_iStatus == 1)
        {
            if(headNode == 1)
            {
                if(in_iHiType == DP_TEST_INPROGRESS)
                {
                    qcParentTest = item->child(iIdx)->background(0);
                    item->child(iIdx)->setBackgroundColor(0,Qt::darkBlue);
                    item->child(iIdx)->setTextColor(0,Qt::white);
                }
                else
                {
                    item->child(iIdx)->setBackground(0,qcParentTest);
                    item->child(iIdx)->setTextColor(0,Qt::black);
                }
            }
            break;
        }
    }

    //    if(((in_iHiType == DP_TEST_PASS)||(in_iHiType == DP_TEST_FAIL)) && (*in_iStatus == 1))
    //    {
    //        if(m_iOverAllResult == 1)
    //        {
    //            item->setFont(2,QFont( "MS Shell Dlg 2", 9, QFont::Bold));
    //            item->setText(2,"FAIL");
    //            item->setTextColor(2,Qt::darkRed);
    //            item->setTextAlignment(2,Qt::AlignCenter);
    //        }
    //        else
    //        {
    //            item->setFont(2,QFont( "MS Shell Dlg 2", 9, QFont::Bold));
    //            item->setText(2,"PASS");
    //            item->setTextColor(2,Qt::darkGreen);
    //            item->setTextAlignment(2,Qt::AlignCenter);
    //        }
    //    }
}

void MainWindow::HighLightTestCase(int iTestCaseNo)
{
    int iStatus = 0;

    m_iTestCaseIndex = 0;
    for(int iIdx = 0; iIdx <ui->treew_TestCase->topLevelItemCount(); iIdx++)
    {
        highlightTest(ui->treew_TestCase->topLevelItem(iIdx), iTestCaseNo, DP_TEST_INPROGRESS, &iStatus);

        if(iStatus == 1)
        {
            qcRootTest = ui->treew_TestCase->topLevelItem(iIdx)->background(0);
            ui->treew_TestCase->topLevelItem(iIdx)->setBackgroundColor(0,Qt::darkBlue);
            ui->treew_TestCase->topLevelItem(iIdx)->setTextColor(0,Qt::white);
            break;
        }
    }
    repaint();
}

void MainWindow::ReHighLightTestCase(int iTestCaseNo)
{
    int iStatus = 0;

    m_iTestCaseIndex = 0;
    for(int iIdx = 0; iIdx <ui->treew_TestCase->topLevelItemCount(); iIdx++)
    {
        highlightTest(ui->treew_TestCase->topLevelItem(iIdx), iTestCaseNo, DP_TEST_COMPLETED, &iStatus);

        if(iStatus == 1)
        {
            ui->treew_TestCase->topLevelItem(iIdx)->setBackground(0,qcRootTest);
            ui->treew_TestCase->topLevelItem(iIdx)->setTextColor(0,Qt::black);
            break;
        }
    }
}

void MainWindow::UpdateResult(int iTestId, bool bResult)
{
    int iStatus = 0, iResult = 0;

    iResult = (bResult)? DP_TEST_PASS:DP_TEST_FAIL;

    m_iTestCaseIndex = 0;
    for(int iIdx = 0; iIdx <ui->treew_TestCase->topLevelItemCount(); iIdx++)
    {
        m_iOverAllResult=0;
        m_iTopLevelResult=0;
        highlightTest(ui->treew_TestCase->topLevelItem(iIdx), iTestId, iResult, &iStatus);

        if(iStatus == 1)
        {

            ui->treew_TestCase->topLevelItem(iIdx)->setBackground(0,qcRootTest);
            ui->treew_TestCase->topLevelItem(iIdx)->setTextColor(0,Qt::black);
            break;
        }

        //        if(m_iTopLevelResult == 1)
        //        {
        //            ui->treew_TestCase->topLevelItem(iIdx)->setFont(2,QFont( "MS Shell Dlg 2", 9, QFont::Bold));
        //            ui->treew_TestCase->topLevelItem(iIdx)->setText(2,"FAIL");
        //            ui->treew_TestCase->topLevelItem(iIdx)->setTextColor(2,Qt::darkRed);
        //            ui->treew_TestCase->topLevelItem(iIdx)->setTextAlignment(2,Qt::AlignCenter);
        //        }
    }
}

void MainWindow::on_actionAutoTest_triggered()
{
    ui->actionAutoTest->setCheckable(true);
    ui->actionAutoTest->setChecked(true);

    ui->actionManualTest->setCheckable(false);
    ui->actionManualTest->setChecked(false);

    ui->sw_Test->setCurrentIndex(TAB_AUTO_TEST);
}

void MainWindow::on_actionManualTest_triggered()
{
    ui->actionAutoTest->setCheckable(false);
    ui->actionAutoTest->setChecked(false);

    ui->actionManualTest->setCheckable(true);
    ui->actionManualTest->setChecked(true);

    ui->sw_Test->setCurrentIndex(TAB_MANUAL_TEST);
}

void MainWindow::on_pb_ManualTstBtn_clicked()
{
    SREPORTINFO SReportInfo;

    if(m_bIsTestActive == true)
    {
        QMessageBox::information(this, "Manual Test", tr("Kindly wait till the previous test ccompletes."));
    }
    else
    {
        memset(m_qProcTestThread->m_ucTestSelect,0,sizeof(m_qProcTestThread->m_ucTestSelect));

        m_objSystDet->ShowDialog();
        if(m_objSystDet->m_ucContinue)
            return;

        strcpy(m_qProcTestThread->m_SReportInfo.carrSerNo, m_objSystDet->m_leSlNo->text().toStdString().c_str());
        strcpy(m_qProcTestThread->m_SReportInfo.carrUserName, m_objSystDet->m_leTestBy->text().toStdString().c_str());
        strcpy(m_qProcTestThread->m_SReportInfo.carrTestLocation, m_objSystDet->m_leLoca->text().toStdString().c_str());
        strcpy(m_qProcTestThread->m_SReportInfo.carrPartNumber, "DP-ATE-8399-300");
        strcpy(m_qProcTestThread->m_SReportInfo.carrVersion, m_objAbout.m_strAppVer.toStdString().c_str());
        strcpy(m_qProcTestThread->m_SReportInfo.carrChecksum, QString::number(g_SGlobal.ulAppChecksum, 16).toUpper().toStdString().c_str());

        if(ui->rb_COS_Test->isChecked())
        {
            m_qProcTestThread->m_ucTestSelect[DP_COS_Power_Test] = 1;
        }
        else if(ui->rb_WDT_Test->isChecked())
        {
            m_qProcTestThread->m_ucTestSelect[DP_WDT_Alarm_Test] = 1;
        }
        else if(ui->rb_EmergencySwitch_Test->isChecked())
        {
            m_qProcTestThread->m_ucTestSelect[DP_Emergency_Switch_Test] = 1;
        }
        else
        {
            QMessageBox::information(this, "Information", tr("Select atlease one test-case to proceed."));
        }

        if(!m_qProcTestThread->isRunning())
        {
            m_bIsTestTypeAuto = false;
            m_bIsTestActive = true;

            m_qProcTestThread->Start(m_bIsTestTypeAuto);
        }
    }
}

void MainWindow::GetUserInput(int iTestCase, QString in_Message)
{
    switch(iTestCase)
    {
    case 2:
    {
        QMessageBox::StandardButton resBtn = QMessageBox::information(this, "Question",in_Message,QMessageBox::Yes | QMessageBox::No);
        if(resBtn == QMessageBox::Yes)
        {
            m_qProcTestThread->m_iBuzzerRing = 1;
            //                            strLog.append(" Yes");
        }
        else
        {
            m_qProcTestThread->m_iBuzzerRing = 0;
            //                            strLog.append(" No");
        }
    }
        break;

    case 1:
    {
        QMessageBox msgBox;
        msgBox.setWindowTitle(tr("Information"));
        msgBox.setText(in_Message);
        QAbstractButton* pbStop = msgBox.addButton(tr("Stop"), QMessageBox::YesRole);
        pbStop->setToolTip("Stop entire test");
        QAbstractButton* pbContinue = msgBox.addButton(tr("Continue"), QMessageBox::YesRole);
        pbContinue->setToolTip("Continue with next test case");

        msgBox.exec();

        if(msgBox.clickedButton() == pbContinue)
        {
            m_qProcTestThread->m_bTestStop = false;
            //                            strLog.append(" Continue with next test case");
        }
        else
        {
            m_qProcTestThread->m_bTestStop = true;
            //                            strLog.append(" Testing Stopped");
        }
    }
    default:
        break;
    }
}

void MainWindow::OnTestThreadFinish()
{
    if(m_bIsTestActive == true)
    {
        m_bIsTestTypeAuto = true;
        m_bIsTestActive = false;

        ui->pb_StartStopTest->setText("Start");

        QMessageBox::information(this,"Information",tr("Test Case Completed"),"Ok");
        PrintActionLog("AutoMode Test Finished", MSGTYPE_INFO);
        ui->pb_ManualTstBtn->setEnabled(true);
    }
}

void MainWindow::PrintActionLog(QString msgText, int msgType)
{
    char Temp[1024]={0};

    sprintf(Temp,"[%s]    %s",QTime::currentTime().toString("HH:mm:ss.zzz").toStdString().c_str(),msgText.toStdString().c_str());

    switch(msgType)
    {
    case MSGTYPE_INFO:
        ui->te_ActionLog->setTextColor(QColor(Qt::blue));
        break;
    case MSGTYPE_SUCCESS:
        ui->te_ActionLog->setTextColor(QColor(Qt::darkGreen));
        break;
    case MSGTYPE_ERROR:
        ui->te_ActionLog->setTextColor(QColor(Qt::darkRed));
        break;
    case MSGTYPE_TEXT:
        ui->te_ActionLog->setTextColor(QColor(Qt::black));
        break;
    default:
        break;
    }

    m_qfActionLog.open(QIODevice::Append);
    m_qfActionLog.write(Temp);
    m_qfActionLog.write("\n");
    m_qfActionLog.close();

    ui->te_ActionLog->append(Temp);
    ui->te_ActionLog->setTextColor(QColor(Qt::black));
}

void MainWindow::DisplayMsg(QString qDisplayData, int iMsgType)
{
    int iButtonClicked;
    if(iMsgType == MSGTYPE_INFO || iMsgType == MSGTYPE_SUCCESS)
    {
        QMessageBox::StandardButtons iButtons = QMessageBox::Ok;
        QMessageBox qMessage( QMessageBox::Information, "Information", "<FONT COLOR = black>"+qDisplayData+"</FONT>", iButtons );
        qMessage.layout()->setSizeConstraint(QLayout::SetFixedSize);
        //    qMessage.setStyleSheet(STYLESHEET);
        qMessage.exec();
    }

    if(iMsgType == MSGTYPE_ERROR)
    {
        QMessageBox::StandardButtons iButtons = QMessageBox::Ok;
        QMessageBox qMessage( QMessageBox::Warning, "Error", "<FONT COLOR = black>"+qDisplayData+"</FONT>", iButtons );
        qMessage.layout()->setSizeConstraint(QLayout::SetFixedSize);
        //    qMessage.setStyleSheet(STYLESHEET);
        qMessage.exec();
    }

    if(iMsgType == MSGTYPE_QUEST)
    {
        QMessageBox::StandardButtons iButtons = QMessageBox::Yes | QMessageBox::No;
        QMessageBox qMessage( QMessageBox::Question, "JIG VALIDATION", "<FONT COLOR = black>"+qDisplayData+"</FONT>", iButtons );
        qMessage.layout()->setSizeConstraint(QLayout::SetFixedSize);
        //    qMessage.setStyleSheet(STYLESHEET);
        iButtonClicked = qMessage.exec();

        if(iButtonClicked == QMessageBox::Yes)
        {
            m_qProcTestThread->m_bJigConnected = true;
        }
        else
        {
            m_qProcTestThread->m_bJigConnected = false;
        }
    }

}

/**
 * @brief MainWindow::DisplayPauseOnFailMsg
 * @param in_strDisplayData Content to display
 * @author Aravinth R
 */
void MainWindow::DisplayPauseOnFailMsg(int in_iErrorNo)
{
    QString strLog = "Info : ";
    QMessageBox msgBox;
    msgBox.setWindowTitle ("Pause on Failure");
    msgBox.setText (getErrorMessage (in_iErrorNo));
    QAbstractButton *pbStopBtn = msgBox.addButton ("&Stop", QMessageBox::YesRole);
    QAbstractButton *pbSkipBtn = msgBox.addButton ("S&kip", QMessageBox::YesRole);
    QAbstractButton *pbContinueBtn = msgBox.addButton ("&Continue", QMessageBox::YesRole);
    QAbstractButton *pbRetryBtn = msgBox.addButton ("&Retry", QMessageBox::YesRole);
    pbStopBtn->setToolTip ("Stop the whole test");
    pbSkipBtn->setToolTip ("Skip the current test and continue with next test");
    pbContinueBtn->setToolTip ("Continue the current test");
    pbRetryBtn->setToolTip ("Retry the last action");

    msgBox.exec ();

    strLog.append (getErrorMessage (in_iErrorNo) + ". - User Action : ");

    if(msgBox.clickedButton () == pbRetryBtn)
    {
        m_qProcTestThread->m_bRetryOnFailure = true;
        m_qProcTestThread->m_bSkipTestOnFailure = false;
        m_qProcTestThread->m_bTestStop = false;
        strLog.append (" Retry last action");
    }
    else if (msgBox.clickedButton () == pbStopBtn)
    {
        m_qProcTestThread->m_bRetryOnFailure = false;
        m_qProcTestThread->m_bSkipTestOnFailure = true;
        m_qProcTestThread->m_bTestStop = true;
        strLog.append (" Testing stopped");
    }
    else if (msgBox.clickedButton () == pbSkipBtn)
    {
        m_qProcTestThread->m_bRetryOnFailure = false;
        m_qProcTestThread->m_bSkipTestOnFailure = true;
        m_qProcTestThread->m_bTestStop = false;
        strLog.append (" Current test case skipped");
    }
    else
    {
        m_qProcTestThread->m_bRetryOnFailure = false;
        m_qProcTestThread->m_bSkipTestOnFailure = false;
        m_qProcTestThread->m_bTestStop = false;
        strLog.append (" Continue next action in current test");
    }
    PrintActionLog (strLog, MSGTYPE_INFO);
}

void MainWindow::PauseOnFailurMessage(QString in_strError)
{
    QString strLog = "Info : ";
    QMessageBox msgBox;
    msgBox.setWindowTitle ("Pause on Failure");
    msgBox.setText (in_strError);
    QAbstractButton *pbStopBtn = msgBox.addButton ("&Stop", QMessageBox::YesRole);
    QAbstractButton *pbSkipBtn = msgBox.addButton ("S&kip", QMessageBox::YesRole);
    QAbstractButton *pbContinueBtn = msgBox.addButton ("&Continue", QMessageBox::YesRole);
    QAbstractButton *pbRetryBtn = msgBox.addButton ("&Retry", QMessageBox::YesRole);
    pbStopBtn->setToolTip ("Stop the whole test");
    pbSkipBtn->setToolTip ("Skip the current test and continue with next test");
    pbContinueBtn->setToolTip ("Continue the current test");
    pbRetryBtn->setToolTip ("Retry the last action");

    msgBox.exec ();

    strLog.append ("User Action : ");

    if(msgBox.clickedButton () == pbRetryBtn)
    {
        m_qProcTestThread->m_bRetryOnFailure = true;
        m_qProcTestThread->m_bSkipTestOnFailure = false;
        m_qProcTestThread->m_bTestStop = false;
        strLog.append (" Retry last action");
    }
    else if (msgBox.clickedButton () == pbStopBtn)
    {
        m_qProcTestThread->m_bRetryOnFailure = false;
        m_qProcTestThread->m_bSkipTestOnFailure = true;
        m_qProcTestThread->m_bTestStop = true;
        strLog.append (" Testing stopped");
    }
    else if (msgBox.clickedButton () == pbSkipBtn)
    {
        m_qProcTestThread->m_bRetryOnFailure = false;
        m_qProcTestThread->m_bSkipTestOnFailure = true;
        m_qProcTestThread->m_bTestStop = false;
        strLog.append (" Current test case skipped");
    }
    else
    {
        m_qProcTestThread->m_bRetryOnFailure = false;
        m_qProcTestThread->m_bSkipTestOnFailure = false;
        m_qProcTestThread->m_bTestStop = false;
        strLog.append (" Continue next action in current test");
    }
    PrintActionLog (strLog, MSGTYPE_INFO);
}

void MainWindow::onPSU_ADC_Test()
{
    ui->sw_Test->setCurrentIndex(TAB_DETECTION_STATUS);
}

QString MainWindow::getErrorMessage(int in_iErrNo)
{
    switch (in_iErrNo)
    {
    case DP1553BXT_ERR_DEV_OPRN_INITIALIZED:
        return "Device operation mode initialized";
    case DP1553BXT_ERR_INVALID_HANDLE:
        return "Invalid device handle";
    case DP1553BXT_ERR_INVALID_PARAM:
        return "Invalid Param";
    default:
        return "Unknown Error [Error Code : " + QString::number (in_iErrNo) + "]";
    }
}

void MainWindow::DisplayError(int in_iErrNo)
{
    QMessageBox::warning (this, "Error", getErrorMessage (in_iErrNo));
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    QMessageBox::StandardButtons iButtons = QMessageBox::Yes | QMessageBox::No;
    QMessageBox msgClose( QMessageBox::Question, "Exit", "Are you sure, you want to exit.", iButtons);
    msgClose.setDefaultButton (QMessageBox::No);
    msgClose.layout()->setSizeConstraint(QLayout::SetFixedSize);
    //        msgClose.setStyleSheet(STYLESHEET);

    int ret = msgClose.exec();

    switch (ret) {
    case QMessageBox::Yes:
        PrintActionLog("Application Closed.", MSGTYPE_INFO);
        this->close();
        break;
    case QMessageBox::No:
        event->ignore();
        break;
    }
}

void MainWindow::on_actionChange_Password_triggered()
{
    m_objUserManagement->m_objAdminAuthWindow->exec ();

    if (m_objUserManagement->m_objAdminAuthWindow->m_bIsAdmin)
    {
        m_objUserManagement->m_objAdminAuthWindow->m_bIsAdmin = false;
        m_objChangePassword->exec ();
    }
}

void MainWindow::on_actionChannel_Mapping_triggered()
{
    //    QDesktopServices::openUrl (QUrl::fromLocalFile ("./documents/Channel_Mapping_Details.pdf"));
    QDesktopServices::openUrl(QUrl::fromLocalFile(qApp->applicationDirPath() + "/documents/" + "Channel_Mapping_Details.pdf"));
}

void MainWindow::on_cb_PauseOnFailure_stateChanged (int in_iState)
{
    m_qProcTestThread->m_bPauseOnFailure = in_iState;
}

void MainWindow::on_actionEquipment_Configuration_Details_triggered()
{
    ui->sw_Test->setCurrentIndex (TAB_EQUIPMENT_DETAILS);
}
