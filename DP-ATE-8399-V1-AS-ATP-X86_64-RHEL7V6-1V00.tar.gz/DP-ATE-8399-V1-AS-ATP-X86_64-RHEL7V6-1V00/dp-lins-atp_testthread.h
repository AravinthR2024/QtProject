#ifndef TESTTHREAD_H
#define TESTTHREAD_H

#include <QThread>
#include <QSerialPort>
#include <QFile>
#include "dp-lins-atp_includes.h"
#include "dp_lins-atp_asyncthread.h"

class CTestThread : public QThread
{
public:
    Q_OBJECT

public:
    CTestThread();

    enum Msg_Type{
        Success = 1,
        Failure,
        Action
    };

    float m_fExpTemp[4];
    float m_fExpRes[4];
    float m_fTolTemp;
    float m_fTolRes;
    SReportStruct m_SReportData;
    SREPORTINFO m_SReportInfo;
    int m_LoadStatus;
    char m_errString[1024];
    unsigned short m_usTestID;
    unsigned short m_usInsideConnectStatus;
    unsigned int m_uiMTMsgNo;
    unsigned int m_uiMT2MsgNo;
    unsigned int m_uiRTMsgNo;
    unsigned char m_ucBusSel;
    int iPortNum;

    unsigned char m_ucCount_Op_Test;

    QString m_qUnitNo;
    QString m_qTestedBy;
    unsigned char m_ucStopFlag;

    int m_iCountIndex;
    int m_iTermiChnCombination;
    int m_iChnChange;
    int m_iTestStart;
    int m_iCombinedChnChange;
    int m_iCombinedTestStart;
    int m_iAutoMode;
    int m_iManualTstSel;
    int m_iBuzzerRing;
    int m_isStart;
    unsigned int m_uiMsgCnt;

    bool m_bStatusCheck ;
    SDP1553B_MRT_CONFIG m_S_pMRT_Config;
    QString m_qUserSelected;
    QString m_qObservedVal ;
    unsigned int m_uiRAMAddrFailSts;
    unsigned int m_uiRAMDataFailSts;
    unsigned int m_uiRAMIntegrityFailSts;
    int m_iNextChnTest;
    int m_iNextChnStartTest;
    int m_iAsyncNextChnTest;
    int m_iAsyncNextChnStartTest;
    int m_iSyncSNOTestNo;
    int m_iAsynSNOTestNo;
    int m_iPSUSNOTestNo;
    int m_iDiscreteTestStart;
    int m_iAsyncTestStart;
    int m_iTransAsyncMsgID;
    QString m_qs1553BLogDir;
    QFile m_qfReport;
    QString m_qsReportContent;
    QString m_qsSyncFileName;
    unsigned short m_usTransAsyncBCChNo;
    unsigned short m_usTransAsyncRTChNo;
    unsigned short m_usTransAsyncMT1ChNo;
    unsigned short m_usTransAsyncMT2ChNo;
    SDP_PSU_Test m_stJig1_Sensor;
    SDP_Demag_PSU m_stDemag_PSU;
    SDP_PSU_Test m_stJig2_LINSCE;
    SDP_PSU_Test m_stJig3_LVOBC;
    SDP_RESET_PSU m_stReset;
    SDP_RESET_PULSE m_stRstPulseTest;
    SDP_DPU_PSU m_stDPU_PSU;
    SDP_PSU_CONFIG m_SPSUConfig[TOTAL_PSU];

    int m_iRS485TestPassCnt;
    int m_iAsyncChnTestPassCnt;
    int m_iTerminalChnTestPassCnt;
    int m_iCombinedChnTestPassCnt;

    SDP_AUTOMODE_INPUT m_stAutomodeIp;

    unsigned char m_ucTestSelect[DP_LINS_TESTCASE_MAX];
    unsigned char m_ucMainTestCaseSelection[6];
    bool m_bPSU_LoadSelect[3];
    float m_fLLSloadImpedance;

    bool m_b1553BTestEnable;
    bool m_bTestTypeAuto;
    bool m_bTestStop;
    bool m_bPauseOnFailure;
    bool m_bRetryOnFailure;
    bool m_bSkipTestOnFailure;

    bool m_bSyncTestSts;
    bool m_bJigConnected;
    bool m_bPwrRatingNotSet;

    int m_iCycleCnt;
    int m_iAsyncMsgID;
    unsigned short m_usDataPointer[32];
    SAsynHPMsg m_sAsyncHPMsg;
    cDP1553BWrapper *m_pobjC1553BWrapper;
    DPCPCI3096_Wrapper  *m_p3096Wrapper;
    DPMM1105_Wrapper    *m_p1105Wrapper;
    DPMM1123_Wrapper    *m_p1123Wrapper;
    CDP_PSU_Wrapper     *m_obj_CPSUWrapper;
    QSerialPort m_objCOM1;
    QSerialPort m_objCOM2;
    C_BC_READ_THREAD *m_pobjBCReadThread;
    C_RT_READ_THREAD *m_pobjRTReadThread;
    C_MT_READ_THREAD *m_pobjMT1ReadThread;
    C_MT_READ_THREAD *m_pobjMT2ReadThread;

    int m_iCommType;
    unsigned char m_ucRTAddr;
    unsigned char m_ucRXRTSubAddr;
    unsigned char m_ucTXRTSubAddr;
    unsigned short usTerminalTestStart;
    unsigned short usCombinedTestStart;
    int m_iCombinedModeSNO;
    void OnCreateAutoReport(int iTestid,int iCycleCount);
    int DP_1553B_InitializeMode(unsigned short usChNo, unsigned char ucBC_Operation, unsigned char ucRT_Operation, unsigned char ucMT_Operation);
    int DP_1553B_BC_Config(unsigned short usBCChNo);
    int DP_1553B_RT_Config(unsigned short usRTChnNo, unsigned short usRTAddr, unsigned short usMsgTypeTxRx);
    int DP_1553B_MT_Config(unsigned short usMTChnNo);
    int DP_1553B_Async_Trans_Test(unsigned short usChannelNo, int iCommType, unsigned short usBusSel);
    int DP_1553B_AsyncSend_Data_High_Low_Priority(unsigned short usBCChnNo, unsigned short usPrioritySel);
    int DP_1553B_BC_RT_MT_Test(int iChannelNo, int iCommType, unsigned char ucBusSel, int iSubAddrSize);
    int DP_1553B_CombinedModeTest(unsigned short usChannelNo, unsigned char ucBusSelect, int iCommType);
    int DP_1553B_Sync_Start_Test(int iCommType);
    short MT_LogFile(SDP_All_Msg *inS_p1553B_Msg, QString qsFileName);
    short MT2_LogFile(SDP_All_Msg *inS_p1553B_Msg, QString qsFileName);
    short BC_LogFile(SDP_All_Msg *inS_p1553B_Msg, QString qsFileName);
    short RT_LogFile(SDP_All_Msg *inS_p1553B_Msg, QString qsFileName);
    int DP_5733_Ch_onfig(unsigned short usRamSel, unsigned char ucBaudrate, unsigned char ucStartBit);
    short openCOMPort(QString in_qsComNo = "COM2", unsigned int in_uiBaudRate = 9600, unsigned char in_ucStopBit = 1,unsigned char in_ucParity = 0, unsigned char in_ucDataBits = 8);
    QString DigitalTestReportCreation(SDP_All_Msg *inS_All_Msg,int iTestID,unsigned short usBCChannelNo ,int iCycleCount);
    bool COSPowerON();
    bool COSPowerOFF();
    void Start(bool in_bTestType);
    void Stop();
    void logTestData(SReportStruct in_SReportData);

    void initReport();
    void closeReport();
    void reportAddInfo(SREPORTINFO in_reportInfo);
    void reportAddSection(int TestCaseId, int iIdx);
    void reportInsertTable(int in_Load, int TestCaseId);
    void reportAddTableHeader(int in_Load, int in_TestCaseId);
    void reportUpdateTable(SReportStruct in_SReportData);
    void reportFinishTable();

    bool StartStopADCAcquisition(unsigned char in_ucStrStp);
signals:
    //msgToPrintlog(QString);
    void SigErrorNo(int);
    void SigTestResult(int iTestid, bool bResult);
    void SigAsyncTestResult(int iTestid,int iPassCount,int iFailCount,int iTestResult);
    void SigTestComplete();
    void SigHighLightTestCase(int iTestCaseNo);
    void SigReHighLightTestCase(int iTestCaseNo);
    void Sig_UpdateTable(unsigned short usChnNo, unsigned short usTimeTag, int iSNo,int iIndicateFirst_LastMsg);
    void Sig_GetUserInput(int iTestCase, QString strMessage);
    void Sig_PrintLog(QString, int);
    void Sig_MsgBox(QString, int);
    void Sig_PauseOnFailure(int);
    void Sig_PauseOnFailureMsg(QString);
    void Sig_StartWDTReset();
    void Sig_StopWDTReset();
    void Sig_DisableSurveillance();

public slots:
    void DP_LINS_PowerControlTest(int in_iPSUIdx, int in_iChIdx, int *out_piStatus);
    void DP_LINS_PowerControlReset(int in_iPSUIdx, int in_iChIdx, int in_iOpt = 0x3);
    void DP_LINS_TeleCmdPSUTest(int in_iPSUIdx, int in_iConnNo, int* out_piStatus);
    void DP_LINS_TeleCmdTest(int in_iPSUIdx, int in_iConnNo, int* out_piStatus);
    void DP_LINS_TeleCmdStsReadbackTest(int in_iPSUIdx, int in_iBankNo, int* out_piStatus);
    void DP_LINS_SpareDIOTest(int in_iPSUIdx, int in_iBankNo, int* out_piStatus);
    void DP_LINS_PSU_PinOutTest(int in_iPSUIdx, int in_iConnNo, int* out_piStatus);
    void DP_LINS_ThermistorTest(unsigned short in_u16SignalId, int in_iConnNo, unsigned char in_Switch, int* out_piStatus);
    void DP_LINS_COSPowerTest(int *out_piStatus);
    void DP_LINS_WDTAlarmTest(int *out_piStatus);
    void DP_LINS_BypassTest(int *out_piStatus);
    void DP_LINS_EmergencyTest(int *out_piStatus);
    void DP_LINS_RS232_LoopbackTest(int opt, int *out_piStatus);
    void DP_LINS_1553B_SelfTest(int *out_piStatus);
    void readPowerRating(int in_iPSUIdx);

    void PSU_TestReport(QString qsTestName, QString qsReportFile, QString qsTable);

    void CheckBCAsynMsg(void *in_SBCMsg);
    void CheckRTAsynMsg(void *in_SRTMsg);
    void CheckMTAsynMsg(void *in_SMTMsg);
    void HandleBCData(void *SDP_Msg_BC, int iMsgID, unsigned short usFirstMsgTT, unsigned char ucChNo);

private:
    void run();
    short enablePSUOutput(unsigned char in_ucPSUID);
    //void GetConfigurationData(short in_sTestCase, char *out_ConfigData, short *out_spErrorValue);


};

#endif // TESTTHREAD_H
