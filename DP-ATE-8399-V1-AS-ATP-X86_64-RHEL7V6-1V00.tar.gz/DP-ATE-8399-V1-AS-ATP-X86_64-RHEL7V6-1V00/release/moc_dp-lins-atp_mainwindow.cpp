/****************************************************************************
** Meta object code from reading C++ file 'dp-lins-atp_mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../dp-lins-atp_mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dp-lins-atp_mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[64];
    char stringdata0[1075];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 10), // "closeEvent"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 12), // "QCloseEvent*"
QT_MOC_LITERAL(4, 36, 5), // "event"
QT_MOC_LITERAL(5, 42, 21), // "on_pb_Proceed_clicked"
QT_MOC_LITERAL(6, 64, 27), // "on_pb_StartStopTest_clicked"
QT_MOC_LITERAL(7, 92, 27), // "on_actionAutoTest_triggered"
QT_MOC_LITERAL(8, 120, 26), // "on_pb_ManualTstBtn_clicked"
QT_MOC_LITERAL(9, 147, 29), // "on_actionManualTest_triggered"
QT_MOC_LITERAL(10, 177, 35), // "on_actionDetection_Status_tri..."
QT_MOC_LITERAL(11, 213, 24), // "on_actionAbout_triggered"
QT_MOC_LITERAL(12, 238, 34), // "on_actionChange_Password_trig..."
QT_MOC_LITERAL(13, 273, 34), // "on_actionChannel_Mapping_trig..."
QT_MOC_LITERAL(14, 308, 33), // "on_cb_PauseOnFailure_stateCha..."
QT_MOC_LITERAL(15, 342, 9), // "in_iState"
QT_MOC_LITERAL(16, 352, 50), // "on_actionEquipment_Configurat..."
QT_MOC_LITERAL(17, 403, 18), // "WatchDogTimerReset"
QT_MOC_LITERAL(18, 422, 22), // "SurveillanceTimerReset"
QT_MOC_LITERAL(19, 445, 17), // "SurveillanceError"
QT_MOC_LITERAL(20, 463, 15), // "resetTreeWidget"
QT_MOC_LITERAL(21, 479, 20), // "resetTreeWidgetColor"
QT_MOC_LITERAL(22, 500, 16), // "QTreeWidgetItem*"
QT_MOC_LITERAL(23, 517, 4), // "item"
QT_MOC_LITERAL(24, 522, 16), // "getTestSelection"
QT_MOC_LITERAL(25, 539, 14), // "unsigned char*"
QT_MOC_LITERAL(26, 554, 11), // "TestSelList"
QT_MOC_LITERAL(27, 566, 4), // "int*"
QT_MOC_LITERAL(28, 571, 3), // "Cnt"
QT_MOC_LITERAL(29, 575, 13), // "highlightTest"
QT_MOC_LITERAL(30, 589, 11), // "in_iTestIdx"
QT_MOC_LITERAL(31, 601, 10), // "in_iHiType"
QT_MOC_LITERAL(32, 612, 10), // "in_iStatus"
QT_MOC_LITERAL(33, 623, 14), // "onPSU_ADC_Test"
QT_MOC_LITERAL(34, 638, 10), // "Board_Init"
QT_MOC_LITERAL(35, 649, 20), // "Update_Board_Details"
QT_MOC_LITERAL(36, 670, 19), // "DP_TestCase_Checked"
QT_MOC_LITERAL(37, 690, 6), // "column"
QT_MOC_LITERAL(38, 697, 18), // "DP_1553B_BoardInit"
QT_MOC_LITERAL(39, 716, 16), // "DP3096_BoardInit"
QT_MOC_LITERAL(40, 733, 17), // "DP_1105_BoardInit"
QT_MOC_LITERAL(41, 751, 19), // "DP_MM1123_BoardInit"
QT_MOC_LITERAL(42, 771, 12), // "DisplayError"
QT_MOC_LITERAL(43, 784, 9), // "in_iErrNo"
QT_MOC_LITERAL(44, 794, 12), // "UpdateResult"
QT_MOC_LITERAL(45, 807, 7), // "iTestId"
QT_MOC_LITERAL(46, 815, 7), // "bResult"
QT_MOC_LITERAL(47, 823, 17), // "HighLightTestCase"
QT_MOC_LITERAL(48, 841, 11), // "iTestCaseNo"
QT_MOC_LITERAL(49, 853, 19), // "ReHighLightTestCase"
QT_MOC_LITERAL(50, 873, 12), // "GetUserInput"
QT_MOC_LITERAL(51, 886, 9), // "iTestCase"
QT_MOC_LITERAL(52, 896, 10), // "in_Message"
QT_MOC_LITERAL(53, 907, 18), // "OnTestThreadFinish"
QT_MOC_LITERAL(54, 926, 18), // "ConfigFileCreation"
QT_MOC_LITERAL(55, 945, 14), // "ReadConfigFile"
QT_MOC_LITERAL(56, 960, 14), // "PrintActionLog"
QT_MOC_LITERAL(57, 975, 12), // "qDisplayData"
QT_MOC_LITERAL(58, 988, 8), // "iMsgType"
QT_MOC_LITERAL(59, 997, 10), // "DisplayMsg"
QT_MOC_LITERAL(60, 1008, 21), // "DisplayPauseOnFailMsg"
QT_MOC_LITERAL(61, 1030, 11), // "in_iErrorNo"
QT_MOC_LITERAL(62, 1042, 20), // "PauseOnFailurMessage"
QT_MOC_LITERAL(63, 1063, 11) // "in_strError"

    },
    "MainWindow\0closeEvent\0\0QCloseEvent*\0"
    "event\0on_pb_Proceed_clicked\0"
    "on_pb_StartStopTest_clicked\0"
    "on_actionAutoTest_triggered\0"
    "on_pb_ManualTstBtn_clicked\0"
    "on_actionManualTest_triggered\0"
    "on_actionDetection_Status_triggered\0"
    "on_actionAbout_triggered\0"
    "on_actionChange_Password_triggered\0"
    "on_actionChannel_Mapping_triggered\0"
    "on_cb_PauseOnFailure_stateChanged\0"
    "in_iState\0on_actionEquipment_Configuration_Details_triggered\0"
    "WatchDogTimerReset\0SurveillanceTimerReset\0"
    "SurveillanceError\0resetTreeWidget\0"
    "resetTreeWidgetColor\0QTreeWidgetItem*\0"
    "item\0getTestSelection\0unsigned char*\0"
    "TestSelList\0int*\0Cnt\0highlightTest\0"
    "in_iTestIdx\0in_iHiType\0in_iStatus\0"
    "onPSU_ADC_Test\0Board_Init\0"
    "Update_Board_Details\0DP_TestCase_Checked\0"
    "column\0DP_1553B_BoardInit\0DP3096_BoardInit\0"
    "DP_1105_BoardInit\0DP_MM1123_BoardInit\0"
    "DisplayError\0in_iErrNo\0UpdateResult\0"
    "iTestId\0bResult\0HighLightTestCase\0"
    "iTestCaseNo\0ReHighLightTestCase\0"
    "GetUserInput\0iTestCase\0in_Message\0"
    "OnTestThreadFinish\0ConfigFileCreation\0"
    "ReadConfigFile\0PrintActionLog\0"
    "qDisplayData\0iMsgType\0DisplayMsg\0"
    "DisplayPauseOnFailMsg\0in_iErrorNo\0"
    "PauseOnFailurMessage\0in_strError"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      39,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  209,    2, 0x08 /* Private */,
       5,    0,  212,    2, 0x08 /* Private */,
       6,    0,  213,    2, 0x08 /* Private */,
       7,    0,  214,    2, 0x08 /* Private */,
       8,    0,  215,    2, 0x08 /* Private */,
       9,    0,  216,    2, 0x08 /* Private */,
      10,    0,  217,    2, 0x08 /* Private */,
      11,    0,  218,    2, 0x08 /* Private */,
      12,    0,  219,    2, 0x08 /* Private */,
      13,    0,  220,    2, 0x08 /* Private */,
      14,    1,  221,    2, 0x08 /* Private */,
      16,    0,  224,    2, 0x08 /* Private */,
      17,    0,  225,    2, 0x0a /* Public */,
      18,    0,  226,    2, 0x0a /* Public */,
      19,    0,  227,    2, 0x0a /* Public */,
      20,    0,  228,    2, 0x0a /* Public */,
      21,    1,  229,    2, 0x0a /* Public */,
      24,    3,  232,    2, 0x0a /* Public */,
      29,    4,  239,    2, 0x0a /* Public */,
      33,    0,  248,    2, 0x0a /* Public */,
      34,    0,  249,    2, 0x0a /* Public */,
      35,    0,  250,    2, 0x0a /* Public */,
      36,    2,  251,    2, 0x0a /* Public */,
      38,    0,  256,    2, 0x0a /* Public */,
      39,    0,  257,    2, 0x0a /* Public */,
      40,    0,  258,    2, 0x0a /* Public */,
      41,    0,  259,    2, 0x0a /* Public */,
      42,    1,  260,    2, 0x0a /* Public */,
      44,    2,  263,    2, 0x0a /* Public */,
      47,    1,  268,    2, 0x0a /* Public */,
      49,    1,  271,    2, 0x0a /* Public */,
      50,    2,  274,    2, 0x0a /* Public */,
      53,    0,  279,    2, 0x0a /* Public */,
      54,    0,  280,    2, 0x0a /* Public */,
      55,    0,  281,    2, 0x0a /* Public */,
      56,    2,  282,    2, 0x0a /* Public */,
      59,    2,  287,    2, 0x0a /* Public */,
      60,    1,  292,    2, 0x0a /* Public */,
      62,    1,  295,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 22,   23,
    QMetaType::Void, 0x80000000 | 22, 0x80000000 | 25, 0x80000000 | 27,   23,   26,   28,
    QMetaType::Void, 0x80000000 | 22, QMetaType::Int, QMetaType::Int, 0x80000000 | 27,   23,   30,   31,   32,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 22, QMetaType::Int,   23,   37,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Int,
    QMetaType::Void, QMetaType::Int,   43,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,   45,   46,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Int,   48,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   51,   52,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   57,   58,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   57,   58,
    QMetaType::Void, QMetaType::Int,   61,
    QMetaType::Void, QMetaType::QString,   63,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        case 1: _t->on_pb_Proceed_clicked(); break;
        case 2: _t->on_pb_StartStopTest_clicked(); break;
        case 3: _t->on_actionAutoTest_triggered(); break;
        case 4: _t->on_pb_ManualTstBtn_clicked(); break;
        case 5: _t->on_actionManualTest_triggered(); break;
        case 6: _t->on_actionDetection_Status_triggered(); break;
        case 7: _t->on_actionAbout_triggered(); break;
        case 8: _t->on_actionChange_Password_triggered(); break;
        case 9: _t->on_actionChannel_Mapping_triggered(); break;
        case 10: _t->on_cb_PauseOnFailure_stateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->on_actionEquipment_Configuration_Details_triggered(); break;
        case 12: _t->WatchDogTimerReset(); break;
        case 13: _t->SurveillanceTimerReset(); break;
        case 14: _t->SurveillanceError(); break;
        case 15: _t->resetTreeWidget(); break;
        case 16: _t->resetTreeWidgetColor((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1]))); break;
        case 17: _t->getTestSelection((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< unsigned char*(*)>(_a[2])),(*reinterpret_cast< int*(*)>(_a[3]))); break;
        case 18: _t->highlightTest((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int*(*)>(_a[4]))); break;
        case 19: _t->onPSU_ADC_Test(); break;
        case 20: _t->Board_Init(); break;
        case 21: _t->Update_Board_Details(); break;
        case 22: _t->DP_TestCase_Checked((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 23: { int _r = _t->DP_1553B_BoardInit();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 24: { int _r = _t->DP3096_BoardInit();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 25: { int _r = _t->DP_1105_BoardInit();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 26: { int _r = _t->DP_MM1123_BoardInit();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 27: _t->DisplayError((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 28: _t->UpdateResult((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 29: _t->HighLightTestCase((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 30: _t->ReHighLightTestCase((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 31: _t->GetUserInput((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 32: _t->OnTestThreadFinish(); break;
        case 33: _t->ConfigFileCreation(); break;
        case 34: { bool _r = _t->ReadConfigFile();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 35: _t->PrintActionLog((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 36: _t->DisplayMsg((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 37: _t->DisplayPauseOnFailMsg((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 38: _t->PauseOnFailurMessage((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 39)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 39;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 39)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 39;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
