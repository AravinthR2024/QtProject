/****************************************************************************
** Meta object code from reading C++ file 'dp-lins-atp_testthread.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../dp-lins-atp_testthread.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dp-lins-atp_testthread.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_CTestThread_t {
    QByteArrayData data[62];
    char stringdata0[876];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CTestThread_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CTestThread_t qt_meta_stringdata_CTestThread = {
    {
QT_MOC_LITERAL(0, 0, 11), // "CTestThread"
QT_MOC_LITERAL(1, 12, 10), // "SigErrorNo"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 13), // "SigTestResult"
QT_MOC_LITERAL(4, 38, 7), // "iTestid"
QT_MOC_LITERAL(5, 46, 7), // "bResult"
QT_MOC_LITERAL(6, 54, 18), // "SigAsyncTestResult"
QT_MOC_LITERAL(7, 73, 10), // "iPassCount"
QT_MOC_LITERAL(8, 84, 10), // "iFailCount"
QT_MOC_LITERAL(9, 95, 11), // "iTestResult"
QT_MOC_LITERAL(10, 107, 15), // "SigTestComplete"
QT_MOC_LITERAL(11, 123, 20), // "SigHighLightTestCase"
QT_MOC_LITERAL(12, 144, 11), // "iTestCaseNo"
QT_MOC_LITERAL(13, 156, 22), // "SigReHighLightTestCase"
QT_MOC_LITERAL(14, 179, 15), // "Sig_UpdateTable"
QT_MOC_LITERAL(15, 195, 7), // "usChnNo"
QT_MOC_LITERAL(16, 203, 9), // "usTimeTag"
QT_MOC_LITERAL(17, 213, 4), // "iSNo"
QT_MOC_LITERAL(18, 218, 22), // "iIndicateFirst_LastMsg"
QT_MOC_LITERAL(19, 241, 16), // "Sig_GetUserInput"
QT_MOC_LITERAL(20, 258, 9), // "iTestCase"
QT_MOC_LITERAL(21, 268, 10), // "strMessage"
QT_MOC_LITERAL(22, 279, 12), // "Sig_PrintLog"
QT_MOC_LITERAL(23, 292, 10), // "Sig_MsgBox"
QT_MOC_LITERAL(24, 303, 18), // "Sig_PauseOnFailure"
QT_MOC_LITERAL(25, 322, 21), // "Sig_PauseOnFailureMsg"
QT_MOC_LITERAL(26, 344, 17), // "Sig_StartWDTReset"
QT_MOC_LITERAL(27, 362, 16), // "Sig_StopWDTReset"
QT_MOC_LITERAL(28, 379, 23), // "Sig_DisableSurveillance"
QT_MOC_LITERAL(29, 403, 24), // "DP_LINS_PowerControlTest"
QT_MOC_LITERAL(30, 428, 10), // "in_iPSUIdx"
QT_MOC_LITERAL(31, 439, 9), // "in_iChIdx"
QT_MOC_LITERAL(32, 449, 4), // "int*"
QT_MOC_LITERAL(33, 454, 12), // "out_piStatus"
QT_MOC_LITERAL(34, 467, 22), // "DP_LINS_TeleCmdPSUTest"
QT_MOC_LITERAL(35, 490, 19), // "DP_LINS_TeleCmdTest"
QT_MOC_LITERAL(36, 510, 10), // "in_iConnNo"
QT_MOC_LITERAL(37, 521, 22), // "DP_LINS_ThermistorTest"
QT_MOC_LITERAL(38, 544, 14), // "in_u16SignalId"
QT_MOC_LITERAL(39, 559, 6), // "in_Jig"
QT_MOC_LITERAL(40, 566, 20), // "DP_LINS_COSPowerTest"
QT_MOC_LITERAL(41, 587, 20), // "DP_LINS_WDTAlarmTest"
QT_MOC_LITERAL(42, 608, 18), // "DP_LINS_BypassTest"
QT_MOC_LITERAL(43, 627, 21), // "DP_LINS_EmergencyTest"
QT_MOC_LITERAL(44, 649, 26), // "DP_LINS_RS232_LoopbackTest"
QT_MOC_LITERAL(45, 676, 3), // "opt"
QT_MOC_LITERAL(46, 680, 22), // "DP_LINS_1553B_SelfTest"
QT_MOC_LITERAL(47, 703, 14), // "PSU_TestReport"
QT_MOC_LITERAL(48, 718, 10), // "qsTestName"
QT_MOC_LITERAL(49, 729, 12), // "qsReportFile"
QT_MOC_LITERAL(50, 742, 7), // "qsTable"
QT_MOC_LITERAL(51, 750, 14), // "CheckBCAsynMsg"
QT_MOC_LITERAL(52, 765, 9), // "in_SBCMsg"
QT_MOC_LITERAL(53, 775, 14), // "CheckRTAsynMsg"
QT_MOC_LITERAL(54, 790, 9), // "in_SRTMsg"
QT_MOC_LITERAL(55, 800, 14), // "CheckMTAsynMsg"
QT_MOC_LITERAL(56, 815, 9), // "in_SMTMsg"
QT_MOC_LITERAL(57, 825, 12), // "HandleBCData"
QT_MOC_LITERAL(58, 838, 10), // "SDP_Msg_BC"
QT_MOC_LITERAL(59, 849, 6), // "iMsgID"
QT_MOC_LITERAL(60, 856, 12), // "usFirstMsgTT"
QT_MOC_LITERAL(61, 869, 6) // "ucChNo"

    },
    "CTestThread\0SigErrorNo\0\0SigTestResult\0"
    "iTestid\0bResult\0SigAsyncTestResult\0"
    "iPassCount\0iFailCount\0iTestResult\0"
    "SigTestComplete\0SigHighLightTestCase\0"
    "iTestCaseNo\0SigReHighLightTestCase\0"
    "Sig_UpdateTable\0usChnNo\0usTimeTag\0"
    "iSNo\0iIndicateFirst_LastMsg\0"
    "Sig_GetUserInput\0iTestCase\0strMessage\0"
    "Sig_PrintLog\0Sig_MsgBox\0Sig_PauseOnFailure\0"
    "Sig_PauseOnFailureMsg\0Sig_StartWDTReset\0"
    "Sig_StopWDTReset\0Sig_DisableSurveillance\0"
    "DP_LINS_PowerControlTest\0in_iPSUIdx\0"
    "in_iChIdx\0int*\0out_piStatus\0"
    "DP_LINS_TeleCmdPSUTest\0DP_LINS_TeleCmdTest\0"
    "in_iConnNo\0DP_LINS_ThermistorTest\0"
    "in_u16SignalId\0in_Jig\0DP_LINS_COSPowerTest\0"
    "DP_LINS_WDTAlarmTest\0DP_LINS_BypassTest\0"
    "DP_LINS_EmergencyTest\0DP_LINS_RS232_LoopbackTest\0"
    "opt\0DP_LINS_1553B_SelfTest\0PSU_TestReport\0"
    "qsTestName\0qsReportFile\0qsTable\0"
    "CheckBCAsynMsg\0in_SBCMsg\0CheckRTAsynMsg\0"
    "in_SRTMsg\0CheckMTAsynMsg\0in_SMTMsg\0"
    "HandleBCData\0SDP_Msg_BC\0iMsgID\0"
    "usFirstMsgTT\0ucChNo"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CTestThread[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      30,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      15,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  164,    2, 0x06 /* Public */,
       3,    2,  167,    2, 0x06 /* Public */,
       6,    4,  172,    2, 0x06 /* Public */,
      10,    0,  181,    2, 0x06 /* Public */,
      11,    1,  182,    2, 0x06 /* Public */,
      13,    1,  185,    2, 0x06 /* Public */,
      14,    4,  188,    2, 0x06 /* Public */,
      19,    2,  197,    2, 0x06 /* Public */,
      22,    2,  202,    2, 0x06 /* Public */,
      23,    2,  207,    2, 0x06 /* Public */,
      24,    1,  212,    2, 0x06 /* Public */,
      25,    1,  215,    2, 0x06 /* Public */,
      26,    0,  218,    2, 0x06 /* Public */,
      27,    0,  219,    2, 0x06 /* Public */,
      28,    0,  220,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      29,    3,  221,    2, 0x0a /* Public */,
      34,    2,  228,    2, 0x0a /* Public */,
      35,    3,  233,    2, 0x0a /* Public */,
      37,    3,  240,    2, 0x0a /* Public */,
      40,    1,  247,    2, 0x0a /* Public */,
      41,    1,  250,    2, 0x0a /* Public */,
      42,    1,  253,    2, 0x0a /* Public */,
      43,    1,  256,    2, 0x0a /* Public */,
      44,    2,  259,    2, 0x0a /* Public */,
      46,    1,  264,    2, 0x0a /* Public */,
      47,    3,  267,    2, 0x0a /* Public */,
      51,    1,  274,    2, 0x0a /* Public */,
      53,    1,  277,    2, 0x0a /* Public */,
      55,    1,  280,    2, 0x0a /* Public */,
      57,    4,  283,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,    4,    5,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,    4,    7,    8,    9,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::UShort, QMetaType::UShort, QMetaType::Int, QMetaType::Int,   15,   16,   17,   18,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   20,   21,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::Int, 0x80000000 | 32,   30,   31,   33,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 32,   30,   33,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, 0x80000000 | 32,   30,   36,   33,
    QMetaType::Void, QMetaType::UShort, QMetaType::UChar, 0x80000000 | 32,   38,   39,   33,
    QMetaType::Void, 0x80000000 | 32,   33,
    QMetaType::Void, 0x80000000 | 32,   33,
    QMetaType::Void, 0x80000000 | 32,   33,
    QMetaType::Void, 0x80000000 | 32,   33,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 32,   45,   33,
    QMetaType::Void, 0x80000000 | 32,   33,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString,   48,   49,   50,
    QMetaType::Void, QMetaType::VoidStar,   52,
    QMetaType::Void, QMetaType::VoidStar,   54,
    QMetaType::Void, QMetaType::VoidStar,   56,
    QMetaType::Void, QMetaType::VoidStar, QMetaType::Int, QMetaType::UShort, QMetaType::UChar,   58,   59,   60,   61,

       0        // eod
};

void CTestThread::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        CTestThread *_t = static_cast<CTestThread *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->SigErrorNo((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->SigTestResult((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 2: _t->SigAsyncTestResult((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 3: _t->SigTestComplete(); break;
        case 4: _t->SigHighLightTestCase((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->SigReHighLightTestCase((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->Sig_UpdateTable((*reinterpret_cast< unsigned short(*)>(_a[1])),(*reinterpret_cast< unsigned short(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4]))); break;
        case 7: _t->Sig_GetUserInput((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 8: _t->Sig_PrintLog((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 9: _t->Sig_MsgBox((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 10: _t->Sig_PauseOnFailure((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->Sig_PauseOnFailureMsg((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 12: _t->Sig_StartWDTReset(); break;
        case 13: _t->Sig_StopWDTReset(); break;
        case 14: _t->Sig_DisableSurveillance(); break;
        case 15: _t->DP_LINS_PowerControlTest((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int*(*)>(_a[3]))); break;
        case 16: _t->DP_LINS_TeleCmdPSUTest((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int*(*)>(_a[2]))); break;
        case 17: _t->DP_LINS_TeleCmdTest((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int*(*)>(_a[3]))); break;
        case 18: _t->DP_LINS_ThermistorTest((*reinterpret_cast< unsigned short(*)>(_a[1])),(*reinterpret_cast< unsigned char(*)>(_a[2])),(*reinterpret_cast< int*(*)>(_a[3]))); break;
        case 19: _t->DP_LINS_COSPowerTest((*reinterpret_cast< int*(*)>(_a[1]))); break;
        case 20: _t->DP_LINS_WDTAlarmTest((*reinterpret_cast< int*(*)>(_a[1]))); break;
        case 21: _t->DP_LINS_BypassTest((*reinterpret_cast< int*(*)>(_a[1]))); break;
        case 22: _t->DP_LINS_EmergencyTest((*reinterpret_cast< int*(*)>(_a[1]))); break;
        case 23: _t->DP_LINS_RS232_LoopbackTest((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int*(*)>(_a[2]))); break;
        case 24: _t->DP_LINS_1553B_SelfTest((*reinterpret_cast< int*(*)>(_a[1]))); break;
        case 25: _t->PSU_TestReport((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 26: _t->CheckBCAsynMsg((*reinterpret_cast< void*(*)>(_a[1]))); break;
        case 27: _t->CheckRTAsynMsg((*reinterpret_cast< void*(*)>(_a[1]))); break;
        case 28: _t->CheckMTAsynMsg((*reinterpret_cast< void*(*)>(_a[1]))); break;
        case 29: _t->HandleBCData((*reinterpret_cast< void*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< unsigned short(*)>(_a[3])),(*reinterpret_cast< unsigned char(*)>(_a[4]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (CTestThread::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::SigErrorNo)) {
                *result = 0;
            }
        }
        {
            typedef void (CTestThread::*_t)(int , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::SigTestResult)) {
                *result = 1;
            }
        }
        {
            typedef void (CTestThread::*_t)(int , int , int , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::SigAsyncTestResult)) {
                *result = 2;
            }
        }
        {
            typedef void (CTestThread::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::SigTestComplete)) {
                *result = 3;
            }
        }
        {
            typedef void (CTestThread::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::SigHighLightTestCase)) {
                *result = 4;
            }
        }
        {
            typedef void (CTestThread::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::SigReHighLightTestCase)) {
                *result = 5;
            }
        }
        {
            typedef void (CTestThread::*_t)(unsigned short , unsigned short , int , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::Sig_UpdateTable)) {
                *result = 6;
            }
        }
        {
            typedef void (CTestThread::*_t)(int , QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::Sig_GetUserInput)) {
                *result = 7;
            }
        }
        {
            typedef void (CTestThread::*_t)(QString , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::Sig_PrintLog)) {
                *result = 8;
            }
        }
        {
            typedef void (CTestThread::*_t)(QString , int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::Sig_MsgBox)) {
                *result = 9;
            }
        }
        {
            typedef void (CTestThread::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::Sig_PauseOnFailure)) {
                *result = 10;
            }
        }
        {
            typedef void (CTestThread::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::Sig_PauseOnFailureMsg)) {
                *result = 11;
            }
        }
        {
            typedef void (CTestThread::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::Sig_StartWDTReset)) {
                *result = 12;
            }
        }
        {
            typedef void (CTestThread::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::Sig_StopWDTReset)) {
                *result = 13;
            }
        }
        {
            typedef void (CTestThread::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&CTestThread::Sig_DisableSurveillance)) {
                *result = 14;
            }
        }
    }
}

const QMetaObject CTestThread::staticMetaObject = {
    { &QThread::staticMetaObject, qt_meta_stringdata_CTestThread.data,
      qt_meta_data_CTestThread,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *CTestThread::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CTestThread::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_CTestThread.stringdata0))
        return static_cast<void*>(const_cast< CTestThread*>(this));
    return QThread::qt_metacast(_clname);
}

int CTestThread::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QThread::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 30)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 30;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 30)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 30;
    }
    return _id;
}

// SIGNAL 0
void CTestThread::SigErrorNo(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void CTestThread::SigTestResult(int _t1, bool _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void CTestThread::SigAsyncTestResult(int _t1, int _t2, int _t3, int _t4)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void CTestThread::SigTestComplete()
{
    QMetaObject::activate(this, &staticMetaObject, 3, Q_NULLPTR);
}

// SIGNAL 4
void CTestThread::SigHighLightTestCase(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void CTestThread::SigReHighLightTestCase(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void CTestThread::Sig_UpdateTable(unsigned short _t1, unsigned short _t2, int _t3, int _t4)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void CTestThread::Sig_GetUserInput(int _t1, QString _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void CTestThread::Sig_PrintLog(QString _t1, int _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void CTestThread::Sig_MsgBox(QString _t1, int _t2)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void CTestThread::Sig_PauseOnFailure(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void CTestThread::Sig_PauseOnFailureMsg(QString _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void CTestThread::Sig_StartWDTReset()
{
    QMetaObject::activate(this, &staticMetaObject, 12, Q_NULLPTR);
}

// SIGNAL 13
void CTestThread::Sig_StopWDTReset()
{
    QMetaObject::activate(this, &staticMetaObject, 13, Q_NULLPTR);
}

// SIGNAL 14
void CTestThread::Sig_DisableSurveillance()
{
    QMetaObject::activate(this, &staticMetaObject, 14, Q_NULLPTR);
}
QT_END_MOC_NAMESPACE
