#include "dp-lins-atp_testthread.h"
#include "dp-lins-atp_mainwindow.h"

extern int g_iCnt;

void CTestThread::DP_LINS_1553B_SelfTest(int *out_piStatus)
{
    int iLoop = 0;
    int iRetVal = 0, iResult = 1;
    SDP_All_Msg in_SDP_Msg;
    S_DP_SELF_TEST_STATUS SelfTestStatus[4];

    for(iLoop = 0; iLoop < 4; iLoop++)
    {
        iRetVal = m_pobjC1553BWrapper->DP1553B_Internal_Self_Test(iLoop,&SelfTestStatus[iLoop]);
        if(iRetVal != 0)
        {
            emit Sig_PrintLog("Unable to perform 1553B Self Test",MSGTYPE_ERROR);
        }
        else
        {
            if(SelfTestStatus[iLoop].SBIST_Sts.ucSinglePortState == DP1553BXT_COMPLETE)
            {
                if(SelfTestStatus[iLoop].SBIST_Sts.ucSinglePortResult == 2)
                {
                    in_SDP_Msg.SDP_InternalSelf_Test[iLoop].ucSinglePortRslt = 1;
                    sprintf(m_errString,"1553B Module %d : Single Port Test PASS",iLoop + 1);
                    emit Sig_PrintLog(m_errString, MSGTYPE_SUCCESS);
                }
                else
                {
                    iResult = 0;
                    in_SDP_Msg.SDP_InternalSelf_Test[iLoop].ucSinglePortRslt = 0;
                    sprintf(m_errString,"1553B Module %d : Single Port Test FAILED",iLoop + 1);
                    emit Sig_PrintLog(m_errString, MSGTYPE_ERROR);
                }
            }

            if(SelfTestStatus[iLoop].SBIST_Sts.ucRAMBISTState == DP1553BXT_COMPLETE)
            {
                if(SelfTestStatus[iLoop].SBIST_Sts.ucRAMBistResult == 2)
                {
                    in_SDP_Msg.SDP_InternalSelf_Test[iLoop].ucRAM_BIST_Rslt = 1;
                    sprintf(m_errString,"1553B Module %d : RAM BIST PASS",iLoop + 1);
                    emit Sig_PrintLog(m_errString, MSGTYPE_SUCCESS);
                }
                else
                {
                    iResult = 0;
                    in_SDP_Msg.SDP_InternalSelf_Test[iLoop].ucRAM_BIST_Rslt = 0;
                    sprintf(m_errString,"1553B Module %d : RAM BIST FAILED",iLoop + 1);
                    emit Sig_PrintLog(m_errString,  MSGTYPE_ERROR);
                }
            }

            if(SelfTestStatus[iLoop].SBIST_Sts.ucROMBISTState == DP1553BXT_COMPLETE)
            {
                if(SelfTestStatus[iLoop].SBIST_Sts.ucROMBISTResult == 2)
                {
                    in_SDP_Msg.SDP_InternalSelf_Test[iLoop].ucROM_BIST_Rslt = 1;
                    sprintf(m_errString,"1553B Module %d : ROM BIST PASS",iLoop + 1);
                    emit Sig_PrintLog(m_errString, MSGTYPE_SUCCESS);
                }
                else
                {
                    iResult = 0;
                    in_SDP_Msg.SDP_InternalSelf_Test[iLoop].ucROM_BIST_Rslt = 0;
                    sprintf(m_errString,"1553B Module %d : ROM BIST FAILED",iLoop + 1);
                    emit Sig_PrintLog(m_errString, MSGTYPE_ERROR);
                }
            }

            if(SelfTestStatus[iLoop].uiRAMSelfTestAddrBusSts == 0)
            {
                in_SDP_Msg.SDP_InternalSelf_Test[iLoop].ucRAM_AddrBus_Rslt = 1;
                sprintf(m_errString,"1553B Module %d : RAM Address Bus Test PASS",iLoop + 1);
                emit Sig_PrintLog(m_errString, MSGTYPE_SUCCESS);
            }
            else
            {
                iResult = 0;
                in_SDP_Msg.SDP_InternalSelf_Test[iLoop].ucRAM_AddrBus_Rslt = 0;
                sprintf(m_errString,"1553B Module %d : RAM Address Bus lines %X  FAILED",iLoop + 1, SelfTestStatus[iLoop].uiRAMSelfTestAddrBusSts);
                emit Sig_PrintLog(m_errString, MSGTYPE_ERROR);
            }

            if(SelfTestStatus[iLoop].uiRAMSelfTestDataBusSts == 0)
            {
                in_SDP_Msg.SDP_InternalSelf_Test[iLoop].ucRAM_DataBus_Rslt = 1;
                sprintf(m_errString,"1553B Module %d : RAM Data Bus Test PASS",iLoop + 1);
                emit Sig_PrintLog(m_errString, MSGTYPE_SUCCESS);
            }
            else
            {
                iResult = 0;
                in_SDP_Msg.SDP_InternalSelf_Test[iLoop].ucRAM_DataBus_Rslt = 0;
                sprintf(m_errString,"1553B Module %d : RAM Data Bus lines %X FAILED",iLoop + 1, SelfTestStatus[iLoop].uiRAMSelfTestDataBusSts);
                emit Sig_PrintLog(m_errString, MSGTYPE_ERROR);
            }

            if(SelfTestStatus[iLoop].uiRAMSelfTestIntergritySts == 0)
            {
                in_SDP_Msg.SDP_InternalSelf_Test[iLoop].ucIntergrityTest = 1;
                sprintf(m_errString,"1553B Module %d : RAM Integrity Test PASS",iLoop + 1);
                emit Sig_PrintLog(m_errString, MSGTYPE_SUCCESS);
            }
            else
            {
                iResult = 0;
                in_SDP_Msg.SDP_InternalSelf_Test[iLoop].ucIntergrityTest = 0;
                sprintf(m_errString,"1553B Module %d : RAM Integrity Test Address lines %d FAILED",iLoop + 1, SelfTestStatus[iLoop].uiRAMSelfTestIntergritySts);
                emit Sig_PrintLog(m_errString, MSGTYPE_ERROR);
            }
        }
    }

    *out_piStatus = iResult;

    DigitalTestReportCreation(&in_SDP_Msg,DP_1553B_Internal_selfTest,DP_1553B_ONE,m_iCycleCnt);
}

int CTestThread::DP_1553B_BC_RT_MT_Test(int iChannelNo,int iCommType,unsigned char ucBusSel,int iSubAddrSize)
{
    SDP1553B_BC_MSG_DEF S_pBCMsgDef;
    QString qsBCLogFineName;
    QString qsRTLogFineName;
    QString qsMT1LogFineName;
    QString qsLogDirPath;
    unsigned short usBCChnNo = 0;
    unsigned short usRTChnNo = 0;
    unsigned short usMT1ChnNo = 0;
    unsigned short usMT2ChnNo = 0;
    int iRetVal = 0;
    int iIndex = 0;
    bool bTestRst = true;
    unsigned short usNextData = 0;
    int iMessages = 0;
    unsigned short usDataPointer[32];
    unsigned short usMinorFrameIdList[1024];
    unsigned short usMsgIdList[2048];
    unsigned short usAvailMsgs = 0;
    unsigned short usMsgTypeTxRx = 0;
    SDP1553BXT_BC_MSG  S_pBC_Config;
    SDP1553BXT_RT_MSG out_SRTMsg;
    SDP1553BXT_MT_MSG out_MT1Msg;
    SDP1553BXT_MT_MSG out_MT2Msg;
    SDP_All_Msg inS_p1553B_Msg;
    SDP1553B_BC_INT in_pSBC_INT;
    SDP1553B_RT_INT in_pSRT_INT;
    SDP1553B_MT_INT in_pSMT_INT;
    inS_p1553B_Msg.iBCError = 0;
    inS_p1553B_Msg.iRTError = 0;
    inS_p1553B_Msg.iRTDATAError = 0;
    inS_p1553B_Msg.iMT1Error = 0;
    inS_p1553B_Msg.iMT2Error = 0;
    inS_p1553B_Msg.ucBusSel = ucBusSel;

    if(iCommType == DP_1553B_ZERO)
    {
        qsLogDirPath = m_qs1553BLogDir+DP_LINS_REPORT_1553B_TERMINAL_DIR + "/CH"+ QString::number(iChannelNo + 1)+"_BC-RT";
    }
    else
    {
        qsLogDirPath = m_qs1553BLogDir+DP_LINS_REPORT_1553B_TERMINAL_DIR + "/CH"+ QString::number(iChannelNo + 1)+"_RT-BC";
    }

    QDir dir(qsLogDirPath);
    if(!dir.exists())
    {
        dir.mkpath(qsLogDirPath);
    }

    if(iCommType == DP_1553B_ZERO)
    {
        inS_p1553B_Msg.ucCommTypeTxRx = 0;
        usMsgTypeTxRx = DP1553BXT_RT_MSGTYPE_RX;
        qsBCLogFineName = qsLogDirPath+"/CH"+ QString::number(iChannelNo + 1) +"_BCLogFile_BC-RT.txt";
        qsRTLogFineName = qsLogDirPath+"/CH"+ QString::number(iChannelNo + 1) +"_RTLogFile_BC-RT.txt";
        qsMT1LogFineName = qsLogDirPath+"/CH"+ QString::number(iChannelNo + 1) +"_MTLogFile_BC-RT.txt";
        //        qsMT2LogFineName = QDir::currentPath() + "/Reports/Logs/TerminalTestLog/CH"+ QString::number(iChannelNo + 1) +"_MT2LogFile_BC-RT.txt";
    }
    else if(iCommType == DP_1553B_ONE)
    {
        inS_p1553B_Msg.ucCommTypeTxRx = 1;
        usMsgTypeTxRx = DP1553BXT_RT_MSGTYPE_TX;
        qsBCLogFineName = qsLogDirPath+"/CH"+ QString::number(iChannelNo + 1) +"_BCLogFile_RT-BC.txt";
        qsRTLogFineName = qsLogDirPath+"/CH"+ QString::number(iChannelNo + 1) +"_RTLogFile_RT-BC.txt";
        qsMT1LogFineName = qsLogDirPath+"/CH"+ QString::number(iChannelNo + 1) +"_MTLogFile_RT-BC.txt";
        //        qsMT2LogFineName = QDir::currentPath() + "/Reports/Logs/TerminalTestLog/CH"+ QString::number(iChannelNo + 1) +"_MT2LogFile_RT-BC.txt";
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_Reset(DP1553BXT_RESET_REGISTER|DP1553BXT_RESET_MEMORY);
    if(iRetVal)
    {
        return iRetVal;
    }

    if(iChannelNo == 0)
    {
        usBCChnNo = DP_1553B_ZERO;
        usRTChnNo = DP_1553B_ONE;
        usMT1ChnNo = DP_1553B_TWO;
        //        usMT2ChnNo = DP_1553B_THREE;
    }
    else if(iChannelNo == 1)
    {
        usBCChnNo = DP_1553B_ONE;
        usRTChnNo = DP_1553B_TWO;
        usMT1ChnNo = DP_1553B_ZERO;
        //        usMT2ChnNo = DP_1553B_ZERO;
    }
    else if(iChannelNo == 2)
    {
        usBCChnNo = DP_1553B_TWO;
        usRTChnNo = DP_1553B_ZERO;
        usMT1ChnNo = DP_1553B_ONE;
        //        usMT2ChnNo = DP_1553B_ONE;
    }
    //    else if(iChannelNo == 3)
    //    {
    //        usBCChnNo = DP_1553B_THREE;
    //        usRTChnNo = DP_1553B_ZERO;
    //        usMT1ChnNo = DP_1553B_ONE;
    ////        usMT2ChnNo = DP_1553B_TWO;
    //    }

    iRetVal = DP_1553B_InitializeMode(usBCChnNo, DP_1553B_BC_MODE_TRUE, DP_1553B_RT_MODE_FALSE, DP_1553B_MT_MODE_FALSE);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_BC_Config(usBCChnNo);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_InitializeMode(usRTChnNo, DP_1553B_BC_MODE_FALSE, DP_1553B_RT_MODE_TRUE, DP_1553B_MT_MODE_FALSE);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_RT_Config(usRTChnNo, m_ucRTAddr, usMsgTypeTxRx);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_InitializeMode(usMT1ChnNo, DP_1553B_BC_MODE_FALSE, DP_1553B_RT_MODE_FALSE, DP_1553B_MT_MODE_TRUE);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_MT_Config(usMT1ChnNo);
    if(iRetVal)
    {
        return iRetVal;
    }

    //    iRetVal = DP_1553B_InitializeMode(usMT2ChnNo, DP_1553B_BC_MODE_FALSE, DP_1553B_RT_MODE_FALSE, DP_1553B_MT_MODE_TRUE);
    //    if(iRetVal)
    //    {
    //        return iRetVal;
    //    }

    //    iRetVal = DP_1553B_MT_Config(usMT2ChnNo);
    //    if(iRetVal)
    //    {
    //        return iRetVal;
    //    }

    in_pSBC_INT.u8EnaDis = 0;
    in_pSBC_INT.u32IntEventMasks = 0;

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_EnableDisableInt(usBCChnNo, &in_pSBC_INT);
    if(iRetVal)
    {
        return iRetVal;
    }

    in_pSRT_INT.u8EnaDis = 0;
    in_pSRT_INT.u32IntEventMasks = 0;
    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_EnableDisableInt(usRTChnNo, &in_pSRT_INT);
    if(iRetVal)
    {
        return iRetVal;
    }
    in_pSMT_INT.u8EnaDis = 0;
    in_pSMT_INT.u32IntEventMasks = 0;
    in_pSMT_INT.u32MsgCntThreshold = 1024;
    in_pSMT_INT.u32WrdCntThreshold = 1024;
    in_pSMT_INT.u32TimeIntThreshold = 10;
    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_EnableDisableInt(usMT1ChnNo, &in_pSMT_INT);
    if(iRetVal)
    {
        return iRetVal;
    }

    //    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_EnableDisableInt(usMT2ChnNo, &in_pSMT_INT);
    //    if(iRetVal)
    //    {
    //        return iRetVal;
    //    }

#ifdef _ADDRESS_INCREMENTAL
    for(iMessages = 0; iMessages < 8 ; iMessages++)
    {
#endif
        if(m_stAutomodeIp.uc1553B_DataType)
        {
            for(iIndex = 0 ; iIndex < 32; iIndex++)
            {
                usDataPointer[iIndex] = m_stAutomodeIp.uc1553B_PatternData;
            }
        }
        else
        {
            for(iIndex = 0 ; iIndex < 32; iIndex++)
            {
                if(iCommType == DP_1553B_ZERO)
                    usDataPointer[iIndex] = iIndex+1;
                else if(iCommType == DP_1553B_ONE)
                    usDataPointer[iIndex] = iIndex+100;

                if(iIndex == 31)
                {
                    usNextData = usDataPointer[iIndex] + 1;
                }
            }
        }

        if(iCommType == DP_1553B_ZERO)
        {
            S_pBCMsgDef.u8MsgType = DP1553B_BC_MSG_TYPE_BCTORT;
#ifdef _ADDRESS_INCREMENTAL
            m_ucRXRTSubAddr += 1;
#endif
        }
        else if(iCommType == DP_1553B_ONE)
        {
            m_pobjC1553BWrapper->usRTBCTest = 1;
#ifdef _ADDRESS_INCREMENTAL
            m_ucRXRTSubAddr += 1;
            m_ucTXRTSubAddr += 1;
#endif
            S_pBCMsgDef.u8MsgType = DP1553B_BC_MSG_TYPE_RTTOBC;
            iRetVal = m_pobjC1553BWrapper->DP1553B_RT_WriteSAData(usRTChnNo, m_ucTXRTSubAddr , usDataPointer, 30, DP_1553B_ZERO, &m_S_pMRT_Config);
            if(iRetVal)
            {
                return iRetVal;
            }
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Destroy(usBCChnNo,1);
        if(iRetVal)
        {
            return iRetVal;
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateDataBlock(usBCChnNo, iMessages, NULL, 0);
        if(iRetVal)
        {
            return iRetVal;
        }

        S_pBCMsgDef.u16MsgBlkID = iMessages;
#ifdef _ADDRESS_INCREMENTAL
        S_pBCMsgDef.u8RxRTAddress = 1;
#endif
        S_pBCMsgDef.u8RxRTAddress = m_ucRTAddr;
        S_pBCMsgDef.u8RxRTSubAddress = m_ucRXRTSubAddr;
        S_pBCMsgDef.u8RxWordCount = 30;
        S_pBCMsgDef.u8TxRTAddress = 2;
        S_pBCMsgDef.u8TxRTSubAddress = m_ucTXRTSubAddr;
        S_pBCMsgDef.u8TxWordCount = 0;
        S_pBCMsgDef.u8BusSelection = m_stAutomodeIp.carr1553B_BusSelect[iChannelNo];
        S_pBCMsgDef.u16TimeToNextMsg = 0;
        S_pBCMsgDef.u8MsgRetrySel = DP_1553B_ZERO;
        S_pBCMsgDef.u8DontBufferSel = DP_1553B_ZERO;
        S_pBCMsgDef.u8DoubleBufferSel = DP_1553B_ZERO;
        S_pBCMsgDef.u16DataBlkID = iMessages;

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMessage(usBCChnNo,iMessages,&S_pBCMsgDef ,NULL , 4);
        if(iRetVal)
        {
            return iRetVal;
        }

        if(iCommType == DP_1553B_ZERO)
        {
            iRetVal = m_pobjC1553BWrapper->DP1553B_BC_WriteMessageData(usBCChnNo,iMessages , usDataPointer, 30,  0, 0);
            if(iRetVal)
            {
                return iRetVal;
            }
        }

        usMsgIdList[0] = iMessages;

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMinorFrame(usBCChnNo, DP_1553B_ZERO, DP_1553B_ONE, usMsgIdList, 0);
        if(iRetVal)
        {
            return iRetVal;
        }

        usMinorFrameIdList[0] = DP_1553B_ZERO;
        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMajorFrame(usBCChnNo,DP_1553B_ZERO , DP_1553B_ONE, usMinorFrameIdList,DP_1553B_ONE, DP_1553B_ZERO);
        if(iRetVal)
        {
            return iRetVal;
        }

        m_uiMsgCnt = 0;
        iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usMT1ChnNo, DP_1553B_START);
        if(iRetVal)
        {
            return iRetVal;
        }

        //        iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usMT2ChnNo, DP_1553B_START);
        //        if(iRetVal)
        //        {
        //            return iRetVal;
        //        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_RT_Start_Stop(usRTChnNo, DP_1553B_START, &m_S_pMRT_Config);
        if(iRetVal)
        {
            return iRetVal;
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Start_Stop(usBCChnNo , DP_1553B_START, DP_1553B_ZERO, DP_1553B_UNBLOCK_WAIT_FALSE);
        if(iRetVal)
        {
            return iRetVal;
        }

        QThread::usleep(1000);

        iRetVal = m_pobjC1553BWrapper->DP1553B_RT_ReadMessage(usRTChnNo,&out_SRTMsg,1, &usAvailMsgs, NULL, &m_S_pMRT_Config);
        if(iRetVal)
        {
            return iRetVal;
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_MT_ReadMessage(usMT1ChnNo, DP_1553B_ONE, NULL, &out_MT1Msg, &usAvailMsgs);
        if(iRetVal)
        {
            return iRetVal;
        }

        //        iRetVal = m_pobjC1553BWrapper->DP1553B_MT_ReadMessage(usMT2ChnNo, DP_1553B_ONE, NULL, &out_MT2Msg, &usAvailMsgs);
        //        if(iRetVal)
        //        {
        //            return iRetVal;
        //        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_ReadMessage(usBCChnNo,&S_pBC_Config,1, &usAvailMsgs, NULL);
        if(iRetVal)
        {
            return iRetVal;
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Start_Stop(usBCChnNo , DP_1553B_STOP, DP_1553B_ZERO, DP_1553B_UNBLOCK_WAIT_FALSE);
        if(iRetVal)
        {
            return iRetVal;
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_RT_Start_Stop(usRTChnNo, DP_1553B_STOP, &m_S_pMRT_Config);
        if(iRetVal)
        {
            return iRetVal;
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usMT1ChnNo, DP_1553B_STOP);
        if(iRetVal)
        {
            return iRetVal;
        }

        //        iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usMT2ChnNo, DP_1553B_STOP);
        //        if(iRetVal)
        //        {
        //            return iRetVal;
        //        }

        unsigned short out_usSubAddr;
        unsigned short out_usWC_MC;
        unsigned short out_usTxRx;
        unsigned short out_usRTAddr;
        DP1553BXT_GET_CMD_WORD(S_pBC_Config.u16CmdWord1, out_usRTAddr, out_usSubAddr, out_usWC_MC, out_usTxRx);

        if((S_pBC_Config.u16BlockStsWord == 0x8000) || (S_pBC_Config.u16BlockStsWord == 0x8010) || (S_pBC_Config.u16BlockStsWord == 0xa000) || (S_pBC_Config.u16BlockStsWord == 0xa010))
        {
            inS_p1553B_Msg.iBCError = DP_1553B_ZERO;
            if((out_SRTMsg.u16BlockStsWord == 0x8000) || (out_SRTMsg.u16BlockStsWord == 0xa000))
            {
                if(out_usTxRx == DP_1553B_ZERO)
                {
                    for(int iDataCnt = 0; iDataCnt < out_SRTMsg.u16WordCount;iDataCnt++)
                    {
                        if(usDataPointer[iDataCnt] != out_SRTMsg.u16Data[iDataCnt])
                        {
                            inS_p1553B_Msg.iRTError = DP_1553B_ONE;
                            bTestRst = false;
                        }
                        inS_p1553B_Msg.iRTError = DP_1553B_ZERO;

                        if((out_MT1Msg.u16BlockStatusWord == 0x8100) || (out_MT1Msg.u16BlockStatusWord == 0xa100))
                        {
                            if(usDataPointer[iDataCnt] != out_MT1Msg.u16Data[iDataCnt])
                            {
                                inS_p1553B_Msg.iMT1Error = DP_1553B_ONE;
                                bTestRst = false;
                            }
                            inS_p1553B_Msg.iMT1Error = DP_1553B_ZERO;
                        }
                        else
                        {
                            inS_p1553B_Msg.iMT1Error = DP_1553B_ONE;
                            bTestRst = false;
                        }

                        //                        if((out_MT2Msg.u16BlockStatusWord == 0x8100) || (out_MT2Msg.u16BlockStatusWord == 0xa100))
                        //                        {
                        //                            if(usDataPointer[iDataCnt] != out_MT2Msg.u16Data[iDataCnt])
                        //                            {
                        //                                inS_p1553B_Msg.iMT2Error = DP_1553B_ONE;
                        //                                bTestRst = false;
                        //                            }
                        //                            inS_p1553B_Msg.iMT2Error = DP_1553B_ZERO;
                        //                        }
                        //                        else
                        //                        {
                        //                            inS_p1553B_Msg.iMT2Error = DP_1553B_ONE;
                        //                            bTestRst = false;
                        //                        }
                    }
                }
                else if(out_usTxRx == DP_1553B_ONE)
                {
                    for(int iDataCnt = 0; iDataCnt < out_SRTMsg.u16WordCount;iDataCnt++)
                    {
                        if(usDataPointer[iDataCnt] != S_pBC_Config.u16Data[iDataCnt])
                        {
                            inS_p1553B_Msg.iBCError = DP_1553B_ONE;
                            bTestRst = false;
                        }

                        if((out_MT1Msg.u16BlockStatusWord == 0x8100) || (out_MT1Msg.u16BlockStatusWord == 0xa100))
                        {
                            if(usDataPointer[iDataCnt] != out_MT1Msg.u16Data[iDataCnt])
                            {
                                inS_p1553B_Msg.iMT1Error = DP_1553B_ONE;
                                bTestRst = false;
                            }
                            inS_p1553B_Msg.iMT1Error = DP_1553B_ZERO;
                        }
                        else
                        {
                            inS_p1553B_Msg.iMT1Error = DP_1553B_ONE;
                            bTestRst = false;
                        }

                        //                        if((out_MT2Msg.u16BlockStatusWord == 0x8100) || (out_MT2Msg.u16BlockStatusWord == 0xa100))
                        //                        {
                        //                            if(usDataPointer[iDataCnt] != out_MT2Msg.u16Data[iDataCnt])
                        //                            {
                        //                                inS_p1553B_Msg.iMT2Error = DP_1553B_ONE;
                        //                                bTestRst = false;
                        //                            }
                        //                            inS_p1553B_Msg.iMT2Error = DP_1553B_ZERO;
                        //                        }
                        //                        else
                        //                        {
                        //                            inS_p1553B_Msg.iMT2Error = DP_1553B_ONE;
                        //                            bTestRst = false;
                        //                        }
                    }
                }
            }
            else
            {
                inS_p1553B_Msg.iRTError = DP_1553B_ONE;
                inS_p1553B_Msg.iMT1Error = DP_1553B_ONE;
                //                inS_p1553B_Msg.iMT2Error = DP_1553B_ONE;
                bTestRst = false;
            }
        }
        else
        {
            inS_p1553B_Msg.iBCError = DP_1553B_ONE;
            inS_p1553B_Msg.iRTError = DP_1553B_ONE;
            inS_p1553B_Msg.iMT1Error = DP_1553B_ONE;
            //            inS_p1553B_Msg.iMT2Error = DP_1553B_ONE;
            bTestRst = false;
        }
        memcpy(&inS_p1553B_Msg.DP_1553B_BC_Strct,&S_pBC_Config,sizeof(S_pBC_Config));
        memcpy(&inS_p1553B_Msg.DP_1553B_RT_Strct,&out_SRTMsg,sizeof(out_SRTMsg));
        memcpy(&inS_p1553B_Msg.DP_1553B_MT1_Strct,&out_MT1Msg,sizeof(out_MT1Msg));
        //        memcpy(&inS_p1553B_Msg.DP_1553B_MT2_Strct,&out_MT2Msg,sizeof(out_MT2Msg));
        inS_p1553B_Msg.iTestNo = iMessages;
        inS_p1553B_Msg.iTerminalTestStart = usTerminalTestStart;

        if(bTestRst)
        {
            m_iTerminalChnTestPassCnt++;
        }

        DigitalTestReportCreation(&inS_p1553B_Msg,DP_1553B_Terminal_Test,iChannelNo,m_iCycleCnt);

        BC_LogFile(&inS_p1553B_Msg,qsBCLogFineName);
        RT_LogFile(&inS_p1553B_Msg,qsRTLogFineName);
        MT_LogFile(&inS_p1553B_Msg,qsMT1LogFineName);
        //        MT2_LogFile(&inS_p1553B_Msg,qsMT2LogFineName);
        usTerminalTestStart = 0;

        if(iRetVal)
        {
            return iRetVal;
        }
#ifdef _ADDRESS_INCREMENTAL
    }
#endif
    return 0;
}

int CTestThread::DP_1553B_InitializeMode(unsigned short usChNo, unsigned char ucBC_Operation, unsigned char ucRT_Operation, unsigned char ucMT_Operation)
{
    int iRetVal = 0;
    int iOprnMode = 0, iOptions = 0;

    if(ucBC_Operation)
    {
        iOprnMode = iOprnMode | DP1553BXT_OPRN_MODE_BC;
    }
    if(ucRT_Operation)
    {
        iOprnMode = iOprnMode | DP1553BXT_OPRN_MODE_RT;
    }
    if(ucMT_Operation)
    {
        iOprnMode = iOprnMode | DP1553BXT_OPRN_MODE_MT;
    }

    iOptions = 0;

    iRetVal = m_pobjC1553BWrapper->DP1553B_InitializeMode(usChNo,iOprnMode, iOptions);
    if(iRetVal)
    {
        return iRetVal;
    }
}

int CTestThread::DP_1553B_CombinedModeTest(unsigned short usChannelNo, unsigned char ucBusSelect,int iCommType)
{
    int iRetVal = 0;
    int iIndex = 0;
    bool bTestRst = true;
    SDP1553B_BC_MSG_DEF S_pBCAlternateMsgDef;
    SDP1553B_BC_MSG_DEF S_pBCMsgDef;
    unsigned short usDoubBufEnDis = 0, usNextData = 0;
    unsigned short usDataPointer[32];
    unsigned short usMinorFrameIdList[1024];
    unsigned short usMsgIdList[2048];
    SDP1553BXT_BC_MSG  S_pBC_Config;
    SDP1553BXT_RT_MSG out_pSRTMsg;
    SDP1553BXT_MT_MSG out_pMT1Msg;
    unsigned short usAvailMsgs = 0;
    SDP_All_Msg inS_p1553B_Msg;
    inS_p1553B_Msg.iBCError = 0;
    inS_p1553B_Msg.iRTError = 0;
    inS_p1553B_Msg.iRTDATAError = 0;
    inS_p1553B_Msg.iMT1Error = 0;
    inS_p1553B_Msg.iMT2Error = 0;
    unsigned short usLogRTAddr = 0;
    unsigned short usLogSubAddr = 0;
    unsigned short usLogWC_MC = 0;
    unsigned short usLogTxRx = 0;
    unsigned short usBCChannelNo = usChannelNo+1;
    QString qsLogDirPath;

    qsLogDirPath = m_qs1553BLogDir+DP_LINS_REPORT_1553B_COMBINED_DIR+"/CH"+ QString::number(usChannelNo + 1) +"_BC-RT-MT";
    QDir dir(qsLogDirPath);
    if(!dir.exists())
    {
        dir.mkpath(qsLogDirPath);
    }

    QString qsBCLogFineName = qsLogDirPath+"/CH"+ QString::number(usChannelNo + 1) +"_BCLogFile.txt";
    QString qsRTLogFineName = qsLogDirPath+"/CH"+ QString::number(usChannelNo + 1) +"_RTLogFile.txt";
    QString qsMT1LogFineName = qsLogDirPath+"/CH"+ QString::number(usChannelNo + 1) +"_MTLogFile.txt";

    m_qsReportContent.clear();

    m_pobjC1553BWrapper->usTestSel = DP_1553B_Combined_Mode_Test;

    iRetVal = m_pobjC1553BWrapper->DP1553B_Reset(DP1553BXT_RESET_REGISTER|DP1553BXT_RESET_MEMORY);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_InitializeMode(usChannelNo,DP_1553B_BC_MODE_TRUE, DP_1553B_RT_MODE_TRUE, DP_1553B_MT_MODE_TRUE);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_BC_Config(usChannelNo);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_RT_Config(usChannelNo, m_ucRTAddr, DP1553BXT_RT_MSGTYPE_RX);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_MT_Config(usChannelNo);
    if(iRetVal)
    {
        return iRetVal;
    }

    if(m_stAutomodeIp.uc1553B_DataType)
    {
        for(iIndex = 0 ; iIndex < 32; iIndex++)
        {
            usDataPointer[iIndex] = m_stAutomodeIp.uc1553B_PatternData;
        }
    }
    else
    {
        for(iIndex = 0 ; iIndex < 32; iIndex++)
        {
            usDataPointer[iIndex] = iIndex+1;
            if(iIndex == 31)
            {
                usNextData = usDataPointer[iIndex] + 1;
            }
        }
    }

    m_pobjC1553BWrapper->usRTBCTest = 1;

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Destroy(usChannelNo,1);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateDataBlock(usChannelNo, DP_1553B_ZERO, NULL, 0);
    if(iRetVal)
    {
        return iRetVal;
    }

    if(iCommType == 1)
    {
        S_pBCMsgDef.u8MsgType = DP_1553B_RT_BC;
    }
    else
    {
        S_pBCMsgDef.u8MsgType = DP_1553B_BC_RT;
    }

    S_pBCMsgDef.u16MsgBlkID = DP_1553B_ZERO;
#ifdef _ADDRESS_INCREMENTAL
    S_pBCMsgDef.u8RxRTAddress = 1;
#endif
    S_pBCMsgDef.u8RxRTAddress = m_ucRTAddr;
    S_pBCMsgDef.u8RxRTSubAddress = m_ucRXRTSubAddr;
    S_pBCMsgDef.u8RxWordCount = 30;
    S_pBCMsgDef.u8BusSelection = ucBusSelect;
    S_pBCMsgDef.u16TimeToNextMsg = 0;
    S_pBCMsgDef.u8MsgRetrySel = DP_1553B_ZERO;
    S_pBCMsgDef.u8DontBufferSel = DP_1553B_ZERO;
    S_pBCMsgDef.u8DoubleBufferSel = DP_1553B_ZERO;
    S_pBCMsgDef.u16DataBlkID = DP_1553B_ZERO;

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMessage(usChannelNo,DP_1553B_ZERO,&S_pBCMsgDef ,NULL , 4);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_WriteMessageData(usChannelNo,DP_1553B_ZERO , usDataPointer, 30,  0, 0);
    if(iRetVal)
    {
        return iRetVal;
    }

    memset(usMsgIdList, 0, sizeof(usMsgIdList));
    usMsgIdList[0] = DP_1553B_ZERO;
    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMinorFrame(usChannelNo, DP_1553B_ZERO, DP_1553B_ONE, usMsgIdList, 0);
    if(iRetVal)
    {
        return iRetVal;
    }

    memset(usMinorFrameIdList, 0, sizeof(usMinorFrameIdList));
    usMinorFrameIdList[0] = DP_1553B_ZERO;
    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMajorFrame(usChannelNo,DP_1553B_ZERO , DP_1553B_ONE, usMinorFrameIdList, DP_1553B_ONE, DP_1553B_ZERO);
    if(iRetVal)
    {
        return iRetVal;
    }

    m_uiMsgCnt = 0;
    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usChannelNo, DP_1553B_START);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_Start_Stop(usChannelNo, DP_1553B_START, &m_S_pMRT_Config);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Start_Stop(usChannelNo , DP_1553B_START, /*MajorFrame*/DP_1553B_ZERO, DP_1553B_UNBLOCK_WAIT_FALSE);
    if(iRetVal)
    {
        return iRetVal;
    }

    QThread::usleep(1000);

    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_ReadMessage(usChannelNo, DP_1553B_ONE, NULL, &out_pMT1Msg, &usAvailMsgs);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_ReadMessage(usChannelNo,&out_pSRTMsg,1, &usAvailMsgs, NULL, &m_S_pMRT_Config);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_ReadMessage(usChannelNo,&S_pBC_Config,1, &usAvailMsgs, NULL);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Start_Stop(usChannelNo , DP_1553B_STOP, DP_1553B_ZERO, DP_1553B_ZERO);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_Start_Stop(usChannelNo, DP_1553B_STOP, &m_S_pMRT_Config);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usChannelNo, DP_1553B_STOP);
    if(iRetVal)
    {
        return iRetVal;
    }

    if((S_pBC_Config.u16BlockStsWord == 0x8000) || (S_pBC_Config.u16BlockStsWord == 0x8010) || (S_pBC_Config.u16BlockStsWord == 0xa000) || (S_pBC_Config.u16BlockStsWord == 0xa010))
    {
        inS_p1553B_Msg.iBCError = DP_1553B_ZERO;
        if((out_pSRTMsg.u16BlockStsWord == 0x8000) || (out_pSRTMsg.u16BlockStsWord == 0xa000))
        {
            for(int iDataCnt = 0; iDataCnt < out_pSRTMsg.u16WordCount;iDataCnt++)
            {
                if(usDataPointer[iDataCnt] != out_pSRTMsg.u16Data[iDataCnt])
                {
                    inS_p1553B_Msg.iRTError = DP_1553B_ERROR_DATA;
                    iRetVal = DP_1553B_ERROR_DATA;
                    bTestRst = false;
                }
                inS_p1553B_Msg.iRTError = DP_1553B_ZERO;

                if((out_pMT1Msg.u16BlockStatusWord == 0x8100) || (out_pMT1Msg.u16BlockStatusWord == 0xa100))
                {
                    if(usDataPointer[iDataCnt] != out_pMT1Msg.u16Data[iDataCnt])
                    {
                        inS_p1553B_Msg.iMT1Error = DP_1553B_ERROR_DATA;
                        iRetVal = DP_1553B_ERROR_DATA;
                        bTestRst = false;
                    }
                    inS_p1553B_Msg.iMT1Error = DP_1553B_ZERO;
                }
                else
                {
                    inS_p1553B_Msg.iMT1Error = DP_1553B_ERR_MT_ERROR_FLAG_SET;
                    iRetVal = DP_1553B_ERR_MT_ERROR_FLAG_SET;
                    bTestRst = false;
                }
            }
        }
        else
        {
            inS_p1553B_Msg.iRTError = DP_1553B_ONE;
            inS_p1553B_Msg.iMT1Error = DP_1553B_ONE;
            bTestRst = false;
        }
    }
    else
    {
        inS_p1553B_Msg.iBCError = DP_1553B_ONE;
        inS_p1553B_Msg.iRTError = DP_1553B_ONE;
        inS_p1553B_Msg.iMT1Error = DP_1553B_ONE;
        bTestRst = false;
    }

    if(bTestRst)
    {
        m_iCombinedChnTestPassCnt++;
    }

    memcpy(&inS_p1553B_Msg.DP_1553B_BC_Strct,&S_pBC_Config,sizeof(S_pBC_Config));
    memcpy(&inS_p1553B_Msg.DP_1553B_RT_Strct,&out_pSRTMsg,sizeof(out_pSRTMsg));
    memcpy(&inS_p1553B_Msg.DP_1553B_MT1_Strct,&out_pMT1Msg,sizeof(out_pMT1Msg));
    int iFrameMsg = 0;
    iFrameMsg++;
    inS_p1553B_Msg.iTestNo = iFrameMsg;
    inS_p1553B_Msg.iCombinedTestStart = usCombinedTestStart;

    DigitalTestReportCreation(&inS_p1553B_Msg,DP_1553B_Combined_Mode_Test,usChannelNo,m_iCycleCnt);

    BC_LogFile(&inS_p1553B_Msg,qsBCLogFineName);
    RT_LogFile(&inS_p1553B_Msg,qsRTLogFineName);
    MT_LogFile(&inS_p1553B_Msg,qsMT1LogFineName);

    usCombinedTestStart = 0;
    return iRetVal;
}
#if 0
int CTestThread::DP_1553B_Async_Trans_Test(unsigned short usChannelNo,int iCommType, unsigned short usBusSel)
{
    int iRetVal = 0;
    int iIndex = 0;
    SDP1553B_BC_MSG_DEF S_pBCAlternateMsgDef;
    SDP1553B_BC_MSG_DEF S_pBCMsgDef;
    unsigned short usDoubBufEnDis = 0;
    unsigned short usDataPointer[32];
    unsigned short usBuff[32];
    unsigned short usMinorFrameIdList[1024];
    unsigned short usMsgIdList[2048];
    unsigned short usMsgID = 0;
    unsigned short usBCChnNo = 0;
    unsigned short usRTChnNo = 0;
    unsigned short usMT1ChnNo = 0;
    //    unsigned short usMT2ChnNo = 0;
    int iMessage = 0;
    int iCountNo = 0;
    unsigned char ucRTAddr = 1;
    unsigned char ucRTSAAddr = 1;
    unsigned short usNextData = 32;
    unsigned short usRTNextData = 100;
    SDP1553B_BC_INT in_pSBC_INT;
    SDP1553B_RT_INT in_pSRT_INT;
    SDP1553B_MT_INT in_pSMT_INT;
    SDP_All_Msg inS_p1553B_Msg;
    unsigned short usAvailMsgs = 0;
    SDP1553BXT_BC_MSG  S_pBC_Config[1000];
    SDP1553BXT_MT_MSG out_pSMTMsg[1000];
    SDP1553BXT_RT_MSG out_pSRTMsg[1000];
    unsigned int uiEventStatus = 0;
    unsigned short usFirstMsgTT = 0;
    inS_p1553B_Msg.iBCError = 0;
    inS_p1553B_Msg.iRTError = 0;
    inS_p1553B_Msg.iRTDATAError = 0;
    inS_p1553B_Msg.iMT1Error = 0;
    //    inS_p1553B_Msg.iMT2Error = 0;

    if(usChannelNo == 0)
    {
        inS_p1553B_Msg.iAsyncTestStart = 1;
    }
    else
    {
        inS_p1553B_Msg.iAsyncTestStart = 0;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_Reset(DP1553BXT_RESET_REGISTER|DP1553BXT_RESET_MEMORY);
    if(iRetVal)
    {
        return iRetVal;
    }

    if(usChannelNo == 0)
    {
        usBCChnNo = DP_1553B_ZERO;
        usRTChnNo = DP_1553B_ONE;
        usMT1ChnNo = DP_1553B_TWO;
        //        usMT2ChnNo = DP_1553B_THREE;
        m_usTransAsyncBCChNo = DP_1553B_ZERO;
        m_usTransAsyncRTChNo = DP_1553B_ONE;
        m_usTransAsyncMT1ChNo = DP_1553B_TWO;
        //        m_usTransAsyncMT2ChNo = DP_1553B_THREE;

    }
    else if(usChannelNo == 1)
    {
        usBCChnNo = DP_1553B_ONE;
        usRTChnNo = DP_1553B_TWO;
        usMT1ChnNo = DP_1553B_ZERO;
        //        usMT2ChnNo = DP_1553B_ZERO;

        m_usTransAsyncBCChNo = DP_1553B_ONE;
        m_usTransAsyncRTChNo = DP_1553B_TWO;
        m_usTransAsyncMT1ChNo = DP_1553B_ZERO;
        //        m_usTransAsyncMT2ChNo = DP_1553B_ZERO;
    }
    else if(usChannelNo == 2)
    {
        usBCChnNo = DP_1553B_TWO;
        usRTChnNo = DP_1553B_ZERO;
        usMT1ChnNo = DP_1553B_ONE;
        //        usMT2ChnNo = DP_1553B_ONE;

        m_usTransAsyncBCChNo = DP_1553B_TWO;
        m_usTransAsyncRTChNo = DP_1553B_ZERO;
        m_usTransAsyncMT1ChNo = DP_1553B_ONE;
        //        m_usTransAsyncMT2ChNo = DP_1553B_ONE;
    }
    //    else if(usChannelNo == 3)
    //    {
    //        usBCChnNo = DP_1553B_THREE;
    //        usRTChnNo = DP_1553B_ZERO;
    //        usMT1ChnNo = DP_1553B_ONE;
    //        usMT2ChnNo = DP_1553B_TWO;

    //        m_usTransAsyncBCChNo = DP_1553B_THREE;
    //        m_usTransAsyncRTChNo = DP_1553B_ZERO;
    //        m_usTransAsyncMT1ChNo = DP_1553B_ONE;
    //        m_usTransAsyncMT2ChNo = DP_1553B_TWO;
    //    }

    m_pobjBCReadThread = new C_BC_READ_THREAD(usBCChnNo);
    m_pobjRTReadThread = new C_RT_READ_THREAD(usRTChnNo);
    m_pobjMT1ReadThread = new C_MT_READ_THREAD(usMT1ChnNo, 1);
    //    m_pobjMT2ReadThread = new C_MT_READ_THREAD(usMT2ChnNo, 2);

    m_pobjBCReadThread->m_pobj1553WrBC = m_pobjC1553BWrapper;
    m_pobjRTReadThread->m_pobj1553WrRT = m_pobjC1553BWrapper;
    m_pobjMT1ReadThread->m_pobj1553WrMT = m_pobjC1553BWrapper;
    //    m_pobjMT2ReadThread->m_pobj1553WrMT = m_pobjC1553BWrapper;

    m_pobjBCReadThread->m_1553B_BC_Strct = &inS_p1553B_Msg.DP_1553B_BC_Strct;
    m_pobjRTReadThread->m_1553B_RT_Strct = &inS_p1553B_Msg.DP_1553B_RT_Strct;
    m_pobjMT1ReadThread->m_1553B_MT_Strct = &inS_p1553B_Msg.DP_1553B_MT1_Strct;
    //    m_pobjMT2ReadThread->m_1553B_MT_Strct = &inS_p1553B_Msg.DP_1553B_MT2_Strct;

    iRetVal = DP_1553B_InitializeMode(usBCChnNo,DP_1553B_BC_MODE_TRUE, DP_1553B_RT_MODE_FALSE, DP_1553B_MT_MODE_FALSE);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_BC_Config(usBCChnNo);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_InitializeMode(usRTChnNo,DP_1553B_BC_MODE_FALSE, DP_1553B_RT_MODE_TRUE, DP_1553B_MT_MODE_FALSE);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_RT_Config(usRTChnNo, DP1553BXT_RT_MSGTYPE_RX);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_InitializeMode(usMT1ChnNo,DP_1553B_BC_MODE_FALSE, DP_1553B_RT_MODE_FALSE, DP_1553B_MT_MODE_TRUE);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_MT_Config(usMT1ChnNo);
    if(iRetVal)
    {
        return iRetVal;
    }

    //    iRetVal = DP_1553B_InitializeMode(usMT2ChnNo,DP_1553B_BC_MODE_FALSE, DP_1553B_RT_MODE_FALSE, DP_1553B_MT_MODE_TRUE);
    //    if(iRetVal)
    //    {
    //        return iRetVal;
    //    }

    //    iRetVal = DP_1553B_MT_Config(usMT2ChnNo);
    //    if(iRetVal)
    //    {
    //        return iRetVal;
    //    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Destroy(usBCChnNo,1);
    if(iRetVal)
    {
        return iRetVal;
    }

    in_pSBC_INT.u8EnaDis = 1;
    in_pSBC_INT.u32IntEventMasks = 1;

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_EnableDisableInt(usBCChnNo, &in_pSBC_INT);
    if(iRetVal)
    {
        return iRetVal;
    }

    in_pSRT_INT.u8EnaDis = 1;
    in_pSRT_INT.u32IntEventMasks = 1;
    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_EnableDisableInt(usRTChnNo, &in_pSRT_INT);
    if(iRetVal)
    {
        return iRetVal;
    }
    in_pSMT_INT.u8EnaDis = 1;
    in_pSMT_INT.u32IntEventMasks = 1;
    in_pSMT_INT.u32MsgCntThreshold = 1;
    in_pSMT_INT.u32WrdCntThreshold = 0;
    in_pSMT_INT.u32TimeIntThreshold = 0;
    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_EnableDisableInt(usMT1ChnNo, &in_pSMT_INT);
    if(iRetVal)
    {
        return iRetVal;
    }

    //    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_EnableDisableInt(usMT2ChnNo, &in_pSMT_INT);
    //    if(iRetVal)
    //    {
    //        return iRetVal;
    //    }

    /**** Frame 1 ****/
    for(iMessage = 0; iMessage < 5;iMessage++)
    {
        if(m_stAutomodeIp.uc1553B_DataType)
        {
            for(iIndex = 0 ; iIndex < 32; iIndex++)
            {
                usDataPointer[iIndex] = m_stAutomodeIp.uc1553B_PatternData;
            }
        }
        else
        {
            for(iIndex = 0 ; iIndex < 32; iIndex++)
            {
                usDataPointer[iIndex] = iIndex + 1;
                //                usBuff[iIndex] = usRTNextData + iIndex;
                if(iIndex == 31)
                {
                    usNextData = usDataPointer[iIndex] + 1;
                    usNextData = usBuff[iIndex] + 1;
                }
            }
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateDataBlock(usBCChnNo, usMsgID, NULL, 0);
        if(iRetVal)
        {
            return iRetVal;
        }

        if(iCommType == 0)
        {
            S_pBCMsgDef.u8MsgType = DP_1553B_BC_RT;
        }
        else if(iCommType == 1)
        {
            S_pBCMsgDef.u8MsgType = DP_1553B_RT_BC;
        }
        S_pBCMsgDef.u16MsgBlkID = usMsgID;
        S_pBCMsgDef.u8RxRTAddress = ucRTAddr;
        S_pBCMsgDef.u8RxRTSubAddress = ucRTSAAddr;
        S_pBCMsgDef.u8RxWordCount = 30;
        S_pBCMsgDef.u16TimeToNextMsg = 200;
        S_pBCMsgDef.u8MsgRetrySel = DP_1553B_ZERO;
        S_pBCMsgDef.u8DontBufferSel = DP_1553B_ZERO;
        S_pBCMsgDef.u8DoubleBufferSel = DP_1553B_ZERO;
        S_pBCMsgDef.u16DataBlkID = usMsgID;
        S_pBCMsgDef.u8BusSelection = m_stAutomodeIp.carr1553B_BusSelect[usChannelNo];

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMessage(usBCChnNo,usMsgID,&S_pBCMsgDef , NULL , 4);
        if(iRetVal)
        {
            return iRetVal;
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_WriteMessageData(usBCChnNo,usMsgID , usDataPointer, 30,  0, 0);
        if(iRetVal)
        {
            return iRetVal;
        }

        usMsgIdList[iMessage] = usMsgID;
        usMsgID++;
        ucRTSAAddr++;

        if(ucRTSAAddr == 32)
        {
            ucRTSAAddr = 1;
        }
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMinorFrame(usBCChnNo, DP_1553B_ONE, DP_1553B_FIVE, usMsgIdList, DP_1553B_FRAME_TIME);
    if(iRetVal)
    {
        return iRetVal;
    }

    /**** Frame 2 *****/
    for(iMessage = 5; iMessage < 10;iMessage++)
    {
        for(iIndex = 0 ; iIndex < 32; iIndex++)
        {
            usDataPointer[iIndex] = iIndex + 1;
            //            usBuff[iIndex] = usRTNextData + iIndex;
            if(iIndex == 31)
            {
                usNextData = usDataPointer[iIndex] + 1;
                usNextData = usBuff[iIndex] + 1;
            }
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateDataBlock(usBCChnNo, usMsgID, NULL, 0);
        if(iRetVal)
        {
            return iRetVal;
        }

        if(iCommType == 0)
        {
            S_pBCMsgDef.u8MsgType = DP_1553B_BC_RT;
        }
        else if(iCommType == 1)
        {
            S_pBCMsgDef.u8MsgType = DP_1553B_RT_BC;
        }
        S_pBCMsgDef.u16MsgBlkID = usMsgID;
        S_pBCMsgDef.u8RxRTAddress = ucRTAddr;
        S_pBCMsgDef.u8RxRTSubAddress = ucRTSAAddr;
        S_pBCMsgDef.u8RxWordCount = 30;
        S_pBCMsgDef.u16TimeToNextMsg = 200;
        S_pBCMsgDef.u8MsgRetrySel = DP_1553B_ZERO;
        S_pBCMsgDef.u8DontBufferSel = DP_1553B_ZERO;
        S_pBCMsgDef.u8DoubleBufferSel = DP_1553B_ZERO;
        S_pBCMsgDef.u16DataBlkID = usMsgID;
        S_pBCMsgDef.u8BusSelection = m_stAutomodeIp.carr1553B_BusSelect[usChannelNo];

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMessage(usBCChnNo,usMsgID,&S_pBCMsgDef ,NULL , 4);
        if(iRetVal)
        {
            return iRetVal;
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_WriteMessageData(usBCChnNo,usMsgID , usDataPointer, 30,  0, 0);
        if(iRetVal)
        {
            return iRetVal;
        }

        usMsgIdList[iMessage] = usMsgID;
        usMsgID++;
        ucRTSAAddr++;

        if(ucRTSAAddr == 32)
        {
            ucRTSAAddr = 1;
        }
    }


    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMinorFrame(usBCChnNo, DP_1553B_TWO, DP_1553B_FIVE, &usMsgIdList[5], DP_1553B_FRAME_TIME);
    if(iRetVal)
    {
        return iRetVal;
    }

    usMinorFrameIdList[0] = DP_1553B_ONE;
    usMinorFrameIdList[1] = DP_1553B_TWO;
    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMajorFrame(usBCChnNo,DP_1553B_ONE , DP_1553B_TWO, usMinorFrameIdList,DP_1553B_FRAME_COUNT, DP_1553B_ZERO);
    if(iRetVal)
    {
        return iRetVal;
    }

    //    usMsgID = 10;
    m_iTransAsyncMsgID = m_pobjBCReadThread->m_iAsyncMsgID = usMsgID;
    /**** Async Message ****/
    for(iIndex = 0 ; iIndex < 32; iIndex++)
    {
        m_usDataPointer[iIndex] = 32 + iIndex;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateDataBlock(usBCChnNo, usMsgID, NULL, 0);
    if(iRetVal)
    {
        return iRetVal;
    }

    S_pBCMsgDef.u8MsgType = DP_1553B_BC_RT;
    S_pBCMsgDef.u8BusSelection = m_stAutomodeIp.carr1553B_BusSelect[usChannelNo];
    S_pBCMsgDef.u16MsgBlkID = usMsgID;
    S_pBCMsgDef.u8RxRTAddress = 1;
    S_pBCMsgDef.u8RxRTSubAddress = 1;
    S_pBCMsgDef.u8RxWordCount = 30;
    S_pBCMsgDef.u16TimeToNextMsg = 10;
    S_pBCMsgDef.u8MsgRetrySel = DP_1553B_ZERO;
    S_pBCMsgDef.u8DontBufferSel = DP_1553B_ZERO;
    S_pBCMsgDef.u8DoubleBufferSel = DP_1553B_ZERO;
    S_pBCMsgDef.u16DataBlkID = usMsgID;

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMessage(usBCChnNo,usMsgID,&S_pBCMsgDef, NULL, 4);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_WriteMessageData(usBCChnNo,usMsgID, m_usDataPointer, 30,  0, 0);
    if(iRetVal)
    {
        return iRetVal;
    }

    m_pobjC1553BWrapper->usAsynData[0] = usMsgID;
    /********************* start thread for receiving data ********************/

    m_pobjMT1ReadThread->m_bFlagStartStop = true;
    m_pobjMT1ReadThread->start();

    //    m_pobjMT2ReadThread->m_bFlagStartStop = true;
    //    m_pobjMT2ReadThread->start();

    m_pobjRTReadThread->m_bFlagStartStop = true;
    m_pobjRTReadThread->start();

    m_pobjBCReadThread->m_bFlagStartStop = true;
    m_pobjBCReadThread->start();

    /***************************************************************************/

    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usMT1ChnNo, DP_1553B_START);
    if(iRetVal)
    {
        return iRetVal;
    }

    //    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usMT2ChnNo, DP_1553B_START);
    //    if(iRetVal)
    //    {
    //        return iRetVal;
    //    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_Start_Stop(usRTChnNo, DP_1553B_START, &m_S_pMRT_Config);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Start_Stop(usBCChnNo , DP_1553B_START, DP_1553B_ONE, DP_1553B_UNBLOCK_WAIT_FALSE);
    if(iRetVal)
    {
        return iRetVal;
    }

    QThread::sleep(1);
    //    qDebug() << "AsyncData Sent";
    iRetVal = DP_1553B_AsyncSend_Data_High_Low_Priority(usBCChnNo,DP1553BXT_BC_PRIORITY_QUEUE_HIGH);
    if(iRetVal)
    {
        return iRetVal;
    }

    QThread::sleep(10);

    m_pobjBCReadThread->m_bFlagStartStop = false;
    m_pobjRTReadThread->m_bFlagStartStop = false;
    m_pobjMT1ReadThread->m_bFlagStartStop = false;
    //    m_pobjMT2ReadThread->m_bFlagStartStop = false;

    DigitalTestReportCreation(&inS_p1553B_Msg,DP_1553B_Async_Test,usChannelNo,m_iCycleCnt);

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Start_Stop(usBCChnNo , DP_1553B_STOP, DP_1553B_ONE, DP_1553B_UNBLOCK_WAIT_FALSE);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_Start_Stop(usRTChnNo, DP_1553B_STOP, &m_S_pMRT_Config);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usMT1ChnNo, DP_1553B_STOP);
    if(iRetVal)
    {
        return iRetVal;
    }

    //    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usMT2ChnNo, DP_1553B_STOP);
    //    if(iRetVal)
    //    {
    //        return iRetVal;
    //    }

    return iRetVal;
}
#endif

int CTestThread::DP_1553B_Async_Trans_Test(unsigned short usChannelNo,int iCommType, unsigned short usBusSel)
{
    int iRetVal = 0;
    int iIndex = 0;
    SDP1553B_BC_MSG_DEF S_pBCAlternateMsgDef;
    SDP1553B_BC_MSG_DEF S_pBCMsgDef;
    unsigned short usDoubBufEnDis = 0;
    unsigned short usDataPointer[32];
    unsigned short usBuff[32];
    unsigned short usMinorFrameIdList[1024];
    unsigned short usMsgIdList[2048];
    unsigned short usMsgID = 0;
    unsigned short usBCChnNo = 0;
    unsigned short usRTChnNo = 0;
    unsigned short usMT1ChnNo = 0;
    //    unsigned short usMT2ChnNo = 0;
    int iMessage = 0;
    int iCountNo = 0;
    unsigned char ucRTAddr = m_ucRTAddr;
    unsigned char ucRTSAAddr = 1;
    unsigned short usNextData = 32;
    unsigned short usRTNextData = 100;
    SDP1553B_BC_INT in_pSBC_INT;
    SDP1553B_RT_INT in_pSRT_INT;
    SDP1553B_MT_INT in_pSMT_INT;
    SDP_All_Msg inS_p1553B_Msg;
    unsigned short usAvailMsgs = 0;
    SDP1553BXT_BC_MSG  S_pBC_Config[1000];
    SDP1553BXT_MT_MSG out_pSMTMsg[1000];
    SDP1553BXT_RT_MSG out_pSRTMsg[1000];
    unsigned int uiEventStatus = 0;
    unsigned short usFirstMsgTT = 0;
    inS_p1553B_Msg.iBCError = 0;
    inS_p1553B_Msg.iRTError = 0;
    inS_p1553B_Msg.iRTDATAError = 0;
    inS_p1553B_Msg.iMT1Error = 0;
    //    inS_p1553B_Msg.iMT2Error = 0;

    if(usChannelNo == 0)
    {
        inS_p1553B_Msg.iAsyncTestStart = 1;
    }
    else
    {
        inS_p1553B_Msg.iAsyncTestStart = 0;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_Reset(DP1553BXT_RESET_REGISTER|DP1553BXT_RESET_MEMORY);
    if(iRetVal)
    {
        return iRetVal;
    }

    if(usChannelNo == 0)
    {
        usBCChnNo = DP_1553B_ZERO;
        usRTChnNo = DP_1553B_ONE;
        usMT1ChnNo = DP_1553B_TWO;
        //        usMT2ChnNo = DP_1553B_THREE;
        m_usTransAsyncBCChNo = DP_1553B_ZERO;
        m_usTransAsyncRTChNo = DP_1553B_ONE;
        m_usTransAsyncMT1ChNo = DP_1553B_TWO;
        //        m_usTransAsyncMT2ChNo = DP_1553B_THREE;
    }
    else if(usChannelNo == 1)
    {
        usBCChnNo = DP_1553B_ONE;
        usRTChnNo = DP_1553B_TWO;
        usMT1ChnNo = DP_1553B_ZERO;
        //        usMT2ChnNo = DP_1553B_ZERO;

        m_usTransAsyncBCChNo = DP_1553B_ONE;
        m_usTransAsyncRTChNo = DP_1553B_TWO;
        m_usTransAsyncMT1ChNo = DP_1553B_ZERO;
        //        m_usTransAsyncMT2ChNo = DP_1553B_ZERO;
    }
    else if(usChannelNo == 2)
    {
        usBCChnNo = DP_1553B_TWO;
        usRTChnNo = DP_1553B_ZERO;
        usMT1ChnNo = DP_1553B_ONE;
        //        usMT2ChnNo = DP_1553B_ONE;

        m_usTransAsyncBCChNo = DP_1553B_TWO;
        m_usTransAsyncRTChNo = DP_1553B_ZERO;
        m_usTransAsyncMT1ChNo = DP_1553B_ONE;
        //        m_usTransAsyncMT2ChNo = DP_1553B_ONE;
    }
    //    else if(usChannelNo == 3)
    //    {
    //        usBCChnNo = DP_1553B_THREE;
    //        usRTChnNo = DP_1553B_ZERO;
    //        usMT1ChnNo = DP_1553B_ONE;
    //        usMT2ChnNo = DP_1553B_TWO;

    //        m_usTransAsyncBCChNo = DP_1553B_THREE;
    //        m_usTransAsyncRTChNo = DP_1553B_ZERO;
    //        m_usTransAsyncMT1ChNo = DP_1553B_ONE;
    //        m_usTransAsyncMT2ChNo = DP_1553B_TWO;
    //    }

    m_pobjBCReadThread = new C_BC_READ_THREAD(usBCChnNo, m_qs1553BLogDir);
    m_pobjRTReadThread = new C_RT_READ_THREAD(usRTChnNo, m_qs1553BLogDir);
    m_pobjMT1ReadThread = new C_MT_READ_THREAD(usMT1ChnNo, 1, m_qs1553BLogDir);
    //    m_pobjMT2ReadThread = new C_MT_READ_THREAD(usMT2ChnNo, 2);

    m_pobjBCReadThread->m_pobj1553WrBC = m_pobjC1553BWrapper;
    m_pobjRTReadThread->m_pobj1553WrRT = m_pobjC1553BWrapper;
    m_pobjMT1ReadThread->m_pobj1553WrMT = m_pobjC1553BWrapper;
    //    m_pobjMT2ReadThread->m_pobj1553WrMT = m_pobjC1553BWrapper;

    m_pobjBCReadThread->m_1553B_BC_Strct = &inS_p1553B_Msg.DP_1553B_BC_Strct;
    m_pobjRTReadThread->m_1553B_RT_Strct = &inS_p1553B_Msg.DP_1553B_RT_Strct;
    m_pobjMT1ReadThread->m_1553B_MT_Strct = &inS_p1553B_Msg.DP_1553B_MT1_Strct;
    //    m_pobjMT2ReadThread->m_1553B_MT_Strct = &inS_p1553B_Msg.DP_1553B_MT2_Strct;

    iRetVal = DP_1553B_InitializeMode(usBCChnNo,DP_1553B_BC_MODE_TRUE, DP_1553B_RT_MODE_FALSE, DP_1553B_MT_MODE_FALSE);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_BC_Config(usBCChnNo);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_InitializeMode(usRTChnNo,DP_1553B_BC_MODE_FALSE, DP_1553B_RT_MODE_TRUE, DP_1553B_MT_MODE_FALSE);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_RT_Config(usRTChnNo, ucRTAddr, DP1553BXT_RT_MSGTYPE_RX);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_InitializeMode(usMT1ChnNo,DP_1553B_BC_MODE_FALSE, DP_1553B_RT_MODE_FALSE, DP_1553B_MT_MODE_TRUE);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = DP_1553B_MT_Config(usMT1ChnNo);
    if(iRetVal)
    {
        return iRetVal;
    }

    //    iRetVal = DP_1553B_InitializeMode(usMT2ChnNo,DP_1553B_BC_MODE_FALSE, DP_1553B_RT_MODE_FALSE, DP_1553B_MT_MODE_TRUE);
    //    if(iRetVal)
    //    {
    //        return iRetVal;
    //    }

    //    iRetVal = DP_1553B_MT_Config(usMT2ChnNo);
    //    if(iRetVal)
    //    {
    //        return iRetVal;
    //    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Destroy(usBCChnNo,1);
    if(iRetVal)
    {
        return iRetVal;
    }

    in_pSBC_INT.u8EnaDis = 1;
    in_pSBC_INT.u32IntEventMasks = 1;

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_EnableDisableInt(usBCChnNo, &in_pSBC_INT);
    if(iRetVal)
    {
        return iRetVal;
    }

    in_pSRT_INT.u8EnaDis = 1;
    in_pSRT_INT.u32IntEventMasks = 1;
    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_EnableDisableInt(usRTChnNo, &in_pSRT_INT);
    if(iRetVal)
    {
        return iRetVal;
    }
    in_pSMT_INT.u8EnaDis = 1;
    in_pSMT_INT.u32IntEventMasks = 1;
    in_pSMT_INT.u32MsgCntThreshold = 1;
    in_pSMT_INT.u32WrdCntThreshold = 0;
    in_pSMT_INT.u32TimeIntThreshold = 0;
    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_EnableDisableInt(usMT1ChnNo, &in_pSMT_INT);
    if(iRetVal)
    {
        return iRetVal;
    }

    //    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_EnableDisableInt(usMT2ChnNo, &in_pSMT_INT);
    //    if(iRetVal)
    //    {
    //        return iRetVal;
    //    }

    /**** Frame 1 ****/
    for(iMessage = 0; iMessage < 5;iMessage++)
    {
        if(m_stAutomodeIp.uc1553B_DataType)
        {
            for(iIndex = 0 ; iIndex < 32; iIndex++)
            {
                usDataPointer[iIndex] = m_stAutomodeIp.uc1553B_PatternData;
            }
        }
        else
        {
            for(iIndex = 0 ; iIndex < 32; iIndex++)
            {
                usDataPointer[iIndex] = iIndex + 1;
                //                usBuff[iIndex] = usRTNextData + iIndex;
                if(iIndex == 31)
                {
                    usNextData = usDataPointer[iIndex] + 1;
                    usNextData = usBuff[iIndex] + 1;
                }
            }
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateDataBlock(usBCChnNo, usMsgID,  NULL, 0);
        if(iRetVal)
        {
            return iRetVal;
        }

        if(iCommType == 0)
        {
            S_pBCMsgDef.u8MsgType = DP_1553B_BC_RT;
        }
        else if(iCommType == 1)
        {
            S_pBCMsgDef.u8MsgType = DP_1553B_RT_BC;
        }
        S_pBCMsgDef.u16MsgBlkID = usMsgID;
        S_pBCMsgDef.u8RxRTAddress = ucRTAddr;
        S_pBCMsgDef.u8RxRTSubAddress = ucRTSAAddr;
        S_pBCMsgDef.u8RxWordCount = 30;
        S_pBCMsgDef.u16TimeToNextMsg = 200;
        S_pBCMsgDef.u8MsgRetrySel = DP_1553B_ZERO;
        S_pBCMsgDef.u8DontBufferSel = DP_1553B_ZERO;
        S_pBCMsgDef.u8DoubleBufferSel = DP_1553B_ZERO;
        S_pBCMsgDef.u16DataBlkID = usMsgID;
        S_pBCMsgDef.u8BusSelection = usBusSel;

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMessage(usBCChnNo,usMsgID,&S_pBCMsgDef, NULL , 4);
        if(iRetVal)
        {
            return iRetVal;
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_WriteMessageData(usBCChnNo,usMsgID , usDataPointer, 30,  0, 0);
        if(iRetVal)
        {
            return iRetVal;
        }

        usMsgIdList[iMessage] = usMsgID;
        usMsgID++;
        ucRTSAAddr++;

        if(ucRTSAAddr == 32)
        {
            ucRTSAAddr = 1;
        }
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMinorFrame(usBCChnNo, DP_1553B_ONE, DP_1553B_FIVE, usMsgIdList, DP_1553B_FRAME_TIME);
    if(iRetVal)
    {
        return iRetVal;
    }

    /**** Frame 2 *****/
    for(iMessage = 5; iMessage < 10;iMessage++)
    {
        for(iIndex = 0 ; iIndex < 32; iIndex++)
        {
            usDataPointer[iIndex] = iIndex + 1;
            //            usBuff[iIndex] = usRTNextData + iIndex;
            if(iIndex == 31)
            {
                usNextData = usDataPointer[iIndex] + 1;
                usNextData = usBuff[iIndex] + 1;
            }
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateDataBlock(usBCChnNo, usMsgID,  NULL, 0);
        if(iRetVal)
        {
            return iRetVal;
        }

        if(iCommType == 0)
        {
            S_pBCMsgDef.u8MsgType = DP_1553B_BC_RT;
        }
        else if(iCommType == 1)
        {
            S_pBCMsgDef.u8MsgType = DP_1553B_RT_BC;
        }
        S_pBCMsgDef.u16MsgBlkID = usMsgID;
        S_pBCMsgDef.u8RxRTAddress = ucRTAddr;
        S_pBCMsgDef.u8RxRTSubAddress = ucRTSAAddr;
        S_pBCMsgDef.u8RxWordCount = 30;
        S_pBCMsgDef.u16TimeToNextMsg = 200;
        S_pBCMsgDef.u8MsgRetrySel = DP_1553B_ZERO;
        S_pBCMsgDef.u8DontBufferSel = DP_1553B_ZERO;
        S_pBCMsgDef.u8DoubleBufferSel = DP_1553B_ZERO;
        S_pBCMsgDef.u16DataBlkID = usMsgID;
        S_pBCMsgDef.u8BusSelection = usBusSel;

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMessage(usBCChnNo,usMsgID,&S_pBCMsgDef ,NULL , 4);
        if(iRetVal)
        {
            return iRetVal;
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_WriteMessageData(usBCChnNo,usMsgID , usDataPointer, 30,  0, 0);
        if(iRetVal)
        {
            return iRetVal;
        }

        usMsgIdList[iMessage] = usMsgID;
        usMsgID++;
        ucRTSAAddr++;

        if(ucRTSAAddr == 32)
        {
            ucRTSAAddr = 1;
        }
    }


    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMinorFrame(usBCChnNo, DP_1553B_TWO, DP_1553B_FIVE, &usMsgIdList[5], DP_1553B_FRAME_TIME);
    if(iRetVal)
    {
        return iRetVal;
    }

    usMinorFrameIdList[0] = DP_1553B_ONE;
    usMinorFrameIdList[1] = DP_1553B_TWO;
    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMajorFrame(usBCChnNo,DP_1553B_ONE , DP_1553B_TWO, usMinorFrameIdList,DP_1553B_FRAME_COUNT, DP_1553B_ZERO);
    if(iRetVal)
    {
        return iRetVal;
    }

    //    usMsgID = 10;
    m_iTransAsyncMsgID = m_pobjBCReadThread->m_iAsyncMsgID = usMsgID;
    /**** Async Message ****/
    for(iIndex = 0 ; iIndex < 32; iIndex++)
    {
        m_usDataPointer[iIndex] = 32 + iIndex;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateDataBlock(usBCChnNo, usMsgID, NULL, 0);
    if(iRetVal)
    {
        return iRetVal;
    }

    S_pBCMsgDef.u8MsgType = DP_1553B_BC_RT;
    S_pBCMsgDef.u8BusSelection = usBusSel;
    S_pBCMsgDef.u16MsgBlkID = usMsgID;
    S_pBCMsgDef.u8RxRTAddress = ucRTAddr;
    S_pBCMsgDef.u8RxRTSubAddress = ucRTSAAddr;
    S_pBCMsgDef.u8RxWordCount = 30;
    S_pBCMsgDef.u16TimeToNextMsg = 10;
    S_pBCMsgDef.u8MsgRetrySel = DP_1553B_ZERO;
    S_pBCMsgDef.u8DontBufferSel = DP_1553B_ZERO;
    S_pBCMsgDef.u8DoubleBufferSel = DP_1553B_ZERO;
    S_pBCMsgDef.u16DataBlkID = usMsgID;

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMessage(usBCChnNo,usMsgID,&S_pBCMsgDef ,NULL, 4);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_WriteMessageData(usBCChnNo,usMsgID , m_usDataPointer, 30,  0, 0);
    if(iRetVal)
    {
        return iRetVal;
    }

    m_pobjC1553BWrapper->usAsynData[0] = usMsgID;
    /********************* start thread for receiving data ********************/

    m_pobjMT1ReadThread->m_bFlagStartStop = true;
    m_pobjMT1ReadThread->start();

    //    m_pobjMT2ReadThread->m_bFlagStartStop = true;
    //    m_pobjMT2ReadThread->start();

    m_pobjRTReadThread->m_bFlagStartStop = true;
    m_pobjRTReadThread->start();

    m_pobjBCReadThread->m_bFlagStartStop = true;
    m_pobjBCReadThread->start();

    /***************************************************************************/

    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usMT1ChnNo, DP_1553B_START);
    if(iRetVal)
    {
        return iRetVal;
    }

    //    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usMT2ChnNo, DP_1553B_START);
    //    if(iRetVal)
    //    {
    //        return iRetVal;
    //    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_Start_Stop(usRTChnNo, DP_1553B_START, &m_S_pMRT_Config);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Start_Stop(usBCChnNo , DP_1553B_START, DP_1553B_ONE, DP_1553B_UNBLOCK_WAIT_FALSE);
    if(iRetVal)
    {
        return iRetVal;
    }

    sleep(1);
    //    qDebug() << "AsyncData Sent";
    iRetVal = DP_1553B_AsyncSend_Data_High_Low_Priority(usBCChnNo,DP1553BXT_BC_PRIORITY_QUEUE_HIGH);
    if(iRetVal)
    {
        return iRetVal;
    }

    sleep(10);

    m_pobjBCReadThread->m_bFlagStartStop = false;
    m_pobjRTReadThread->m_bFlagStartStop = false;
    m_pobjMT1ReadThread->m_bFlagStartStop = false;
    //    m_pobjMT2ReadThread->m_bFlagStartStop = false;

    DigitalTestReportCreation(&inS_p1553B_Msg,DP_1553B_Async_Test,usChannelNo,m_iCycleCnt);

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Start_Stop(usBCChnNo , DP_1553B_STOP, DP_1553B_ONE, DP_1553B_UNBLOCK_WAIT_FALSE);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_Start_Stop(usRTChnNo, DP_1553B_STOP, &m_S_pMRT_Config);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usMT1ChnNo, DP_1553B_STOP);
    if(iRetVal)
    {
        return iRetVal;
    }

    //    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_StartStopMonitor(usMT2ChnNo, DP_1553B_STOP);
    //    if(iRetVal)
    //    {
    //        return iRetVal;
    //    }
    return iRetVal;
}

int CTestThread::DP_1553B_Sync_Start_Test(int iCommType)
{
    SDP_All_Msg SDP_Msg;
    SDP1553B_BC_MSG_DEF S_pBCAlternateMsgDef;
    SDP1553B_BC_MSG_DEF S_pBCMsgDef;
    unsigned int uiMessageCnt = 0;
    unsigned int uiLastMessageCnt = 0;
    unsigned short usDoubBufEnDis = 0;
    unsigned short usBusSel = 0;
    int iRetVal = 0;
    int iIndex = 0;
    unsigned short usNextData = 0;
    unsigned short usDataPointer[32];
    unsigned short usMinorFrameIdList[1024], usSyncMinorFrmList[2] = {0};
    unsigned short usMsgIdList[2048];
    unsigned short usMsgID = 0;
    unsigned short ucRTAddr = m_ucRTAddr;
    unsigned short ucRTSAAddr = m_ucRXRTSubAddr;
    unsigned short usAvailMsgs = 0;
    unsigned short usFirstMsgTT[3];
    SDP1553BXT_BC_MSG S_pBC_ConfigFirstMsg[5];
    SDP1553BXT_BC_MSG S_pBC_ConfigLastMsg;
    unsigned short usChannelSel = 0;
    int iSNo;
    int iMinorFrameCnt = 0;
    SDP1553B_BC_INT in_pSBC_INT;
    QString qsLogDirPath;

    QString qsBCLogFileName[4];

    qsLogDirPath = m_qs1553BLogDir+DP_LINS_REPORT_1553B_SYNC_DIR;
    QDir dir(qsLogDirPath);
    if(!dir.exists())
    {
        dir.mkpath(qsLogDirPath);
    }

    qsBCLogFileName[0] = qsLogDirPath+"/Sync_BC_1_LogFile.txt";
    qsBCLogFileName[1] = qsLogDirPath+"/Sync_BC_2_LogFile.txt";
    qsBCLogFileName[2] = qsLogDirPath+"/Sync_BC_3_LogFile.txt";
    //    qsBCLogFileName[3] = QDir::currentPath() + "/Reports/Logs/SyncTestReport/Sync_BC_4_LogFile.txt";

    iRetVal = m_pobjC1553BWrapper->DP1553B_Reset(DP1553BXT_RESET_REGISTER|DP1553BXT_RESET_MEMORY);
    if(iRetVal)
    {
        return iRetVal;
    }

    DP1553BXT_BC_OPCODE_DEF sMemOpcodes[2];

    memset(sMemOpcodes,0,sizeof(sMemOpcodes));

    sMemOpcodes[0].u16Condition = DP1553BXT_CND_ALWAYS;
    sMemOpcodes[0].u16OpCodeType = DP1553BXT_OPCODE_LTT;
    sMemOpcodes[0].u32Parameter1 =  0; //Load TimeTag value to zero
    sMemOpcodes[0].u32Parameter2 =  0;

    sMemOpcodes[1].u16Condition = DP1553BXT_CND_ALWAYS;
    sMemOpcodes[1].u16OpCodeType = DP1553BXT_OPCODE_RTN;
    sMemOpcodes[1].u32Parameter1 =  0;
    sMemOpcodes[1].u32Parameter2 =  0;

    for(usChannelSel = 0; usChannelSel < DP_1553B_MAX_CHANNEL_SEL ; usChannelSel++)
    {
        usBusSel = m_stAutomodeIp.carr1553B_BusSelect[usChannelSel];
        iRetVal = DP_1553B_InitializeMode(usChannelSel, DP_1553B_BC_MODE_TRUE, DP_1553B_RT_MODE_FALSE, DP_1553B_MT_MODE_FALSE);
        if(iRetVal)
        {
            return iRetVal;
        }

        iRetVal = DP_1553B_BC_Config(usChannelSel);
        if(iRetVal)
        {
            return iRetVal;
        }
        QThread::msleep(10);

        //        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Destroy(usChannelSel, 1);
        //        if(iRetVal)
        //        {
        //            return iRetVal;
        //        }
        /*
        in_pSBC_INT.u8EnaDis = 1;
        in_pSBC_INT.u32IntEventMasks = 1;

        m_iRetval = m_pobjC1553BWrapper->DP1553B_BC_EnableDisableInt(usChannelSel, &in_pSBC_INT);//enable interrupt for reading messges
        if(m_iRetval)
        {
            return m_iRetval;
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_EnableExtTriggerStart(usChannelSel, DP_ENABLE_EXT_TRIGGER);
        if(iRetVal)
        {
            return iRetVal;
        }
*/
        usMsgID = 0;
        ucRTAddr = m_ucRTAddr;
        ucRTSAAddr = m_ucRXRTSubAddr;

        for(iMinorFrameCnt = 0; iMinorFrameCnt < 5;iMinorFrameCnt++)
        {
            if(m_stAutomodeIp.uc1553B_DataType)
            {
                for(iIndex = 0 ; iIndex < 32; iIndex++)
                {
                    usDataPointer[iIndex] = m_stAutomodeIp.uc1553B_PatternData;
                }
            }
            else
            {
                for(iIndex = 0 ; iIndex < 32; iIndex++)
                {
                    usDataPointer[iIndex] = iIndex+1;
                    if(iIndex == 31)
                    {
                        usNextData = usDataPointer[iIndex] + 1;
                    }
                }
            }

            if(iCommType == 0)
            {
                S_pBCMsgDef.u8MsgType = DP_1553B_BC_RT;
            }
            else if(iCommType == 1)
            {
                S_pBCMsgDef.u8MsgType = DP_1553B_RT_BC;
            }
            S_pBCMsgDef.u8BusSelection = usBusSel;
            S_pBCMsgDef.u16MsgBlkID = usMsgID;
            S_pBCMsgDef.u8RxRTAddress = ucRTAddr;
            S_pBCMsgDef.u8RxRTSubAddress = ucRTSAAddr;
            S_pBCMsgDef.u8RxWordCount = 30;
            S_pBCMsgDef.u16TimeToNextMsg = 200;
            S_pBCMsgDef.u8MsgRetrySel = DP_1553B_ZERO;
            S_pBCMsgDef.u8DontBufferSel = DP_1553B_ZERO;
            S_pBCMsgDef.u8DoubleBufferSel = DP_1553B_ZERO;
            S_pBCMsgDef.u16DataBlkID = usMsgID;


            iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateDataBlock(usChannelSel, usMsgID, NULL, 0);
            if(iRetVal)
            {
                return iRetVal;
            }

            iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMessage(usChannelSel,usMsgID,&S_pBCMsgDef ,NULL , 4);
            if(iRetVal)
            {
                return iRetVal;
            }

            iRetVal = m_pobjC1553BWrapper->DP1553B_BC_WriteMessageData(usChannelSel,usMsgID, usDataPointer, 30,  0, 0);
            if(iRetVal)
            {
                return iRetVal;
            }

            usMsgIdList[iMinorFrameCnt] = usMsgID;
            usMsgID++;
            ucRTSAAddr++;

            if((ucRTAddr == 32) && (ucRTSAAddr == 32))
            {
                ucRTAddr = m_ucRTAddr;
                ucRTSAAddr = m_ucRXRTSubAddr;
            }
        }

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMinorFrame(usChannelSel, 0, DP_1553B_FIVE, usMsgIdList, 0);
        if(iRetVal)
        {
            return iRetVal;
        }

        usMinorFrameIdList[0] = 0;
        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMajorFrame(usChannelSel,0 , DP_1553B_ONE, usMinorFrameIdList,DP_1553B_ONE, DP_1553B_ONE);
        if(iRetVal)
        {
            return iRetVal;
        }
    }

    for(usChannelSel = 0; usChannelSel < DP_1553B_MAX_CHANNEL_SEL ; usChannelSel++)
    {
        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMinorFrameEx(usChannelSel,1,2,sMemOpcodes);
        if(iRetVal)
        {
            return iRetVal;
        }

        usSyncMinorFrmList[0] = 1;
        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_CreateMajorFrame(usChannelSel,1 , DP_1553B_ONE, usSyncMinorFrmList,DP_1553B_ONE, DP_1553B_ONE);
        if(iRetVal)
        {
            return iRetVal;
        }

        QThread::msleep(10);

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Start_Stop(usChannelSel, DP_1553B_START, 1, DP_1553B_UNBLOCK_WAIT_FALSE);
        if(iRetVal)
        {
            return iRetVal;
        }
    }

    QThread::msleep(10);

    /* Trigger to synchornise all four channel timetag */
    iRetVal = m_pobjC1553BWrapper->DP1553B_GenerateSWExtTrigger(DP_1553B_ZERO);
    if(iRetVal)
    {
        return iRetVal;
    }

    QThread::msleep(50);

    //    QThread::sleep(2);

    /* Stop all four channel sync */
    for(int i = 0; i < DP_1553B_MAX_CHANNEL_SEL; i++)
    {
        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Start_Stop(i, DP_1553B_STOP, 0, DP_1553B_UNBLOCK_WAIT_FALSE);
        if(iRetVal)
        {
            return iRetVal;
        }
    }

    QThread::msleep(50);

    for(usChannelSel = 0; usChannelSel < DP_1553B_MAX_CHANNEL_SEL ; usChannelSel++)
    {
        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Start_Stop(usChannelSel , DP_1553B_START, 0, DP_1553B_UNBLOCK_WAIT_FALSE);
        if(iRetVal)
        {
            return iRetVal;
        }
    }
    QThread::msleep(50);

    iRetVal = m_pobjC1553BWrapper->DP1553B_GenerateSWExtTrigger(DP_1553B_ZERO);
    if(iRetVal)
    {
        return iRetVal;
    }
    QThread::msleep(50);

    m_pobjC1553BWrapper->usTestSel = DP_1553B_Sync_Test;

    for(usChannelSel = 0;usChannelSel< DP_1553B_MAX_CHANNEL_SEL;usChannelSel++)
    {
        iSNo++;

        iRetVal = m_pobjC1553BWrapper->DP1553B_BC_ReadMessage(usChannelSel,S_pBC_ConfigFirstMsg,5, &usAvailMsgs, NULL);
        if(iRetVal)
        {
            return iRetVal;
        }

        SDP_All_Msg inS_p1553B_Msg[5];

        m_uiMsgCnt = 0;
        for(int i = 0; i < usAvailMsgs; i++)
        {
            memcpy(&inS_p1553B_Msg[i].DP_1553B_BC_Strct,&S_pBC_ConfigFirstMsg[i],sizeof(S_pBC_ConfigFirstMsg));
            BC_LogFile(&inS_p1553B_Msg[i], qsBCLogFileName[usChannelSel]);
            SDP_Msg.sDP_Sync_Reslt.usLastMsgTT[usChannelSel] = S_pBC_ConfigFirstMsg[i].u64TimeTagVal;
        }

        SDP_Msg.sDP_Sync_Reslt.usFirstMsgTT[usChannelSel] = S_pBC_ConfigFirstMsg[0].u64TimeTagVal;
        usFirstMsgTT[usChannelSel] = S_pBC_ConfigFirstMsg[0].u64TimeTagVal;
        SDP_Msg.sDP_Sync_Reslt.u16TimetagRes[usChannelSel] = S_pBC_ConfigFirstMsg[0].u16TimetagRes;
        SDP_Msg.sDP_Sync_Reslt.u16WordCount[usChannelSel] = S_pBC_ConfigFirstMsg[0].u16WordCount;
    }

    while(1)
    {
        iSNo = 0;

        m_pobjC1553BWrapper->m_usMsgCnt = usAvailMsgs;

        for(usChannelSel = 0;usChannelSel< DP_1553B_MAX_CHANNEL_SEL;usChannelSel++)
        {
            iSNo++;

            iRetVal = m_pobjC1553BWrapper->DP1553B_BC_GetBufferInfo(usChannelSel,&uiMessageCnt,&uiLastMessageCnt);
            if(iRetVal)
            {
                return iRetVal;
            }

            if(uiMessageCnt == 5000)
            {
                iRetVal = m_pobjC1553BWrapper->DP1553B_BC_ReadMessageFromID(usChannelSel,DP_1553B_FIVE,&S_pBC_ConfigLastMsg, &usAvailMsgs);
                if(iRetVal)
                {
                    return iRetVal;
                }
                SDP_Msg.sDP_Sync_Reslt.usLastMsgTT[usChannelSel] = S_pBC_ConfigLastMsg.u16TimetagRes;
            }
        }
        break;
    }

    SDP_Msg.sDP_Sync_Reslt.usFirstFailCount = 0;
    SDP_Msg.sDP_Sync_Reslt.usLastFailCount = 0;
    for(int iIndex = 0;iIndex < DP_1553B_MAX_CHANNEL_SEL;iIndex++)
    {
        for(int iCount = 0;iCount < DP_1553B_MAX_CHANNEL_SEL;iCount++)
        {
            short usFirstDiff = 0;
            short usLastDiff = 0;

            if(iIndex != iCount)
            {
                usFirstDiff = SDP_Msg.sDP_Sync_Reslt.usFirstMsgTT[iIndex] - SDP_Msg.sDP_Sync_Reslt.usFirstMsgTT[iCount];
                usLastDiff = SDP_Msg.sDP_Sync_Reslt.usLastMsgTT[iIndex] - SDP_Msg.sDP_Sync_Reslt.usLastMsgTT[iCount];

                if((usFirstDiff > 10) || (usFirstDiff < (-10)))
                {
                    SDP_Msg.sDP_Sync_Reslt.usFirstFailCount += 1;
                }
                if((usLastDiff > 10) || (usLastDiff < (-10)))
                {
                    SDP_Msg.sDP_Sync_Reslt.usLastFailCount += 1;
                }
            }
        }
    }
    int n = sizeof(usFirstMsgTT) / sizeof(usFirstMsgTT[0]);
    std::sort(usFirstMsgTT, usFirstMsgTT + n);

    if((SDP_Msg.sDP_Sync_Reslt.usFirstFailCount != 0) || (SDP_Msg.sDP_Sync_Reslt.usLastFailCount != 0))
    {
        SDP_Msg.sDP_Sync_Reslt.qsSyncResult = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
        m_bSyncTestSts = false;
    }
    else
    {
        SDP_Msg.sDP_Sync_Reslt.qsSyncResult = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
        m_bSyncTestSts = true;
    }

    SDP_Msg.usMsgCnt = m_pobjC1553BWrapper->m_usMsgCnt;
    SDP_Msg.usTimeToNextMsg = S_pBCMsgDef.u16TimeToNextMsg;
    SDP_Msg.usMaxDiff = usFirstMsgTT[2] - usFirstMsgTT[0];

    DigitalTestReportCreation(&SDP_Msg,DP_1553B_Sync_Test,DP_1553B_ONE,m_iCycleCnt);

    return iRetVal;
}

void CTestThread::HandleBCData(void *DP_Msg_BC,int iMsgID,unsigned short usFirstMsgTT, unsigned char ucChNo)
{
    SDP_All_Msg SDP_All_Rslt;
    SDP1553BXT_BC_MSG *SDP_Msg_BC;
    QString qsBCLogFineName = qApp->applicationDirPath()+"/Reports/Logs/AsynchronousStartTestLog/CH"+ QString::number(ucChNo) +"_BCLogFile.txt";
    m_iAsynSNOTestNo += 1;
    SDP_Msg_BC = (SDP1553BXT_BC_MSG *)DP_Msg_BC;
    memcpy(&SDP_All_Rslt.SDP_Async_Test_Rslt.SDP_BC_Msg,SDP_Msg_BC,sizeof(SDP1553BXT_BC_MSG));
    memcpy(&SDP_All_Rslt.DP_1553B_BC_Strct,SDP_Msg_BC,sizeof(SDP1553BXT_BC_MSG));
    SDP_All_Rslt.SDP_Async_Test_Rslt.iMsgID = iMsgID;
    SDP_All_Rslt.SDP_Async_Test_Rslt.usFirstMsgTT = usFirstMsgTT;
    SDP_All_Rslt.SDP_Async_Test_Rslt.usBCChNo = m_usTransAsyncBCChNo;
    SDP_All_Rslt.SDP_Async_Test_Rslt.usRTChNo = m_usTransAsyncRTChNo;
    SDP_All_Rslt.SDP_Async_Test_Rslt.usMT1ChNo = m_usTransAsyncMT1ChNo;
    SDP_All_Rslt.SDP_Async_Test_Rslt.usMT2ChNo = m_usTransAsyncMT2ChNo;

    SDP_All_Rslt.SDP_Async_Test_Rslt.iResult = 0;

    BC_LogFile(&SDP_All_Rslt,qsBCLogFineName);

    g_iCnt = 0;

    emit SigAsyncTestResult(DP_1553B_Async_Test,DP_1553B_ONE,0,0);


    //    if(iAsyncChnTestFailCnt == 0)
    //    {
    //        iAsyncTestPassCnt++;
    //        emit SigTestResult(DP_1553B_Combined_Mode_Test,iAsyncTestPassCnt,iAsyncTestFailCnt,1);
    //    }
    //    else
    //    {
    //        iAsyncTestFailCnt++;
    //        emit SigTestResult(DP_1553B_Combined_Mode_Test,iAsyncTestPassCnt,iAsyncTestFailCnt,1);
    //    }
    //    emit SigEnableButton();
}

int CTestThread::DP_1553B_BC_Config(unsigned short usBCChNo)
{
    int iRetVal = 0;
    SDP1553_BC_INIT S_BCInitInfo;
    SDP1553_BC_CONFIG  S_BCConfig;

    S_BCInitInfo.u16HPQSize = DP1553BXT_BC_HPQ_SIZE_512;
    S_BCInitInfo.u16LPQSize = DP1553BXT_BC_LPQ_SIZE_512;
    S_BCInitInfo.u16MaxDataBlocks = DP_1553B_MAX_DATA_BLOCKS;
    S_BCInitInfo.u16MaxMsgBlocks = DP_1553B_MAX_MSG_BLOCKS;
    S_BCInitInfo.u16HostMsgBufSize = DP_1553B_HOST_MSG_BUF_SIZE;

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Init(usBCChNo,S_BCInitInfo);
    if(iRetVal)
    {
        return iRetVal;
    }

    S_BCConfig.u16ConfigOptions =  0x0;
    S_BCConfig.u16NoRespTimeout = 0x0;
    S_BCConfig.u16NumOfRetries = DP_1553B_ZERO;
    S_BCConfig.u16ChannelSelect = DP_1553B_THREE;
    S_BCConfig.u16RetryOnErr = DP_1553B_THREE;

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_Config(usBCChNo, S_BCConfig);
    if(iRetVal)
    {
        return iRetVal;
    }
    return iRetVal;
}

int CTestThread::DP_1553B_RT_Config(unsigned short usRTChnNo, unsigned short usRTAddr, unsigned short usMsgTypeTxRx)
{
    SDP1553_RT_INIT S_pRTInitInfo;
    int iRetVal = 0;
    SDP1553B_MRT_CONFIG S_pMRT_Config;

    S_pRTInitInfo.u8RTtype = DP_1553B_ZERO;
    S_pRTInitInfo.u32MutiRTSel = DP_1553B_ONE;
#ifdef _ADDRESS_INCREMENTAL
    S_pRTInitInfo.u8RTAddress = 1;
#endif
    S_pRTInitInfo.u8RTAddress = usRTAddr;
    S_pRTInitInfo.u16RTStackSize = DP_1553B_THREE;
    S_pRTInitInfo.u8GlobalCirBuffSize = DP_1553B_ZERO;
    S_pRTInitInfo.u8TimetagAtEOM = DP_1553B_ZERO;
    S_pRTInitInfo.u8ModeCodeResetIO = DP_1553B_ZERO;
    S_pRTInitInfo.u8BroadcastDisable = DP_1553B_ONE;
    S_pRTInitInfo.u16HostMsgBufSize = DP_1553B_HOST_MSG_BUF_SIZE;

    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_Init(usRTChnNo, &S_pRTInitInfo);
    if(iRetVal)
    {
        return iRetVal;
    }

    S_pMRT_Config.u8RTNumber = 0;
    S_pMRT_Config.u8RTType = 0;

    memcpy(&m_S_pMRT_Config,&S_pMRT_Config,sizeof(S_pMRT_Config));

    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_Configure(usRTChnNo, DP_1553B_RT_CONFIG_OPTION, &S_pMRT_Config);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_SetNoRespTimeOut(usRTChnNo, DP_1553B_RT_RESPONSE_TIME, &S_pMRT_Config);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_RT_ConfigSubAddress(usRTChnNo, DP_1553B_SA_MASK, usMsgTypeTxRx, DP1553BXT_RT_BUF_CIR_128W, DP_1553B_ZERO, &S_pMRT_Config);
    if(iRetVal)
    {
        return iRetVal;
    }

    return iRetVal;
}

int CTestThread::DP_1553B_MT_Config(unsigned short usMTChNo)
{
    SDP1553_MT_INIT pStMTInitInfo;
    SDP1553_MT_CONFIG pStMTConfig;
    int iRetVal = 0;

    pStMTInitInfo.u8EnaSeleciveMon = DP_1553B_ZERO;
    pStMTInitInfo.u32InteQueBufSize = DP_1553B_HOST_MSG_BUF_SIZE;

    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_Init(usMTChNo,&pStMTInitInfo);
    if(iRetVal)
    {
        return iRetVal;
    }

    pStMTConfig.u8MTStackSize = DP_1553B_ZERO;
    pStMTConfig.u8MinGapChkEna = DP_1553B_ZERO;
    pStMTConfig.u8Broadcast = DP_1553B_ONE;
    pStMTConfig.u81553A_Format = DP_1553B_ZERO;
    pStMTConfig.u8EOMTimeTagEna = DP_1553B_ZERO;
    pStMTConfig.u8BusSwEnbDis = DP_1553B_ONE;
    pStMTConfig.u8BusSelction = DP_1553B_ZERO;
    pStMTConfig.u8EnaBlkStsComp = DP_1553B_ZERO;
    pStMTConfig.u8NoResTimeout = DP_1553B_ZERO;

    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_Config(usMTChNo, &pStMTConfig);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_MT_SetSelectiveMonitorOptions(usMTChNo, DP_1553B_ONE, DP_1553B_ZERO, DP1553BXT_RT_MSGTYPE_RX);
    if(iRetVal)
    {
        return iRetVal;
    }

    return iRetVal;
}

int CTestThread::DP_1553B_AsyncSend_Data_High_Low_Priority(unsigned short usBCChnNo,unsigned short usPrioritySel)
{
    int iRetVal = 0;
    unsigned short usQueueCnt = 0, usQueueCnt2 = 0;
    unsigned short usHp_LwPrioritySel;
    unsigned short usarrHPData[512];

    usarrHPData[0] = 0;

    if(usPrioritySel == 1)
    {
        usHp_LwPrioritySel = DP1553BXT_BC_PRIORITY_QUEUE_HIGH;
    }
    else if(usPrioritySel == 2)
    {
        usHp_LwPrioritySel = DP1553BXT_BC_PRIORITY_QUEUE_LOW;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_GetAsyncMessageCount(usBCChnNo,usHp_LwPrioritySel , &usQueueCnt);
    if(iRetVal)
    {
        return iRetVal;
    }

    iRetVal = m_pobjC1553BWrapper->DP1553B_BC_SendAsyncMessage(usBCChnNo,usHp_LwPrioritySel,DP_1553B_HIGH_PRIORITY_MSG_CNT,\
                                                               m_pobjC1553BWrapper->usAsynData,&usQueueCnt2);
    if(iRetVal)
    {
        return iRetVal;
    }
    return iRetVal;

}

void CTestThread::CheckBCAsynMsg(void *in_SBCMsg)
{
    SDP1553BXT_BC_MSG SBCReadMsg;
    int iIndex = 0;
    memcpy(&SBCReadMsg,in_SBCMsg,sizeof(SBCReadMsg));
    if((SBCReadMsg.u16BlockStsWord & 0x8000) == 0x8000)
    {

    }
    else
    {
        if(((SBCReadMsg.u16BlockStsWord << 3) & 0x8000) == 0x8000)
        {
            if(((SBCReadMsg.u16BlockStsWord << 5) & 0x8000) == 0x8000)
            {
                //                return DP_1553B_ERR_BC_NO_RESP_TIME_OUT;
            }
            else
            {
                //                return DP_1553B_ERR_BC_ERROR_FLAG_SET;
            }
        }

    }
}

void CTestThread::CheckRTAsynMsg(void *in_SRTMsg)
{
    SDP1553BXT_RT_MSG SRTReadMsg;
    int iIndex = 0;
    memcpy(&SRTReadMsg,in_SRTMsg,sizeof(SRTReadMsg));
    if((SRTReadMsg.u16BlockStsWord & 0x8000) == 0x8000)
    {
        for(iIndex = 0;iIndex < 32;iIndex++)
        {
            if(m_usDataPointer[iIndex] != SRTReadMsg.u16Data[iIndex])
            {

            }
        }

    }
    else
    {
        if(((SRTReadMsg.u16BlockStsWord << 3) & 0x8000) == 0x8000)
        {
            if(((SRTReadMsg.u16BlockStsWord << 5) & 0x8000) == 0x8000)
            {
                //                return DP_1553B_ERR_RT_NO_RESP_TIME_OUT;
            }
            else
            {
                //                return DP_1553B_ERR_RT_ERROR_FLAG_SET;
            }
        }
    }
}

void CTestThread::CheckMTAsynMsg(void *in_SMTMsg)
{
    SDP1553BXT_MT_MSG SMTReadMsg;
    int iIndex = 0;
    memcpy(&SMTReadMsg,in_SMTMsg,sizeof(SMTReadMsg));
    if(((SMTReadMsg.u16BlockStatusWord << 3) & 0x8000) != 0x8000)
    {
        if(((SMTReadMsg.u16BlockStatusWord << 5) & 0x8000) != 0x8000)
        {
            for(iIndex = 0;iIndex < 32;iIndex++)
            {
                if(m_usDataPointer[iIndex] != SMTReadMsg.u16Data[iIndex])
                {

                }
            }
        }
        else
        {
            //            return DP_1553B_ERR_MT_NO_RESP_TIME_OUT;
        }
    }
}


short CTestThread::BC_LogFile(SDP_All_Msg *inS_p1553B_Msg,QString qsFileName)
{
    SDP1553BXT_BC_MSG sbcResult;
    int iloop=0;
    char szTimetag[256] = "";
    QFile f_BCLogFile(qsFileName);
    QString qsDataLog1;
    QString qsDataLog2;
    QString qsDataLog3;
    QString qsDataFullLog;
    QString qsData;
    U16BIT u16RTAddr = 0, u16SubAddr1 = 0, u16WC_MC = 0,  u16TxRx = 0;
    QString qsRxData;

    m_uiMsgCnt++;

    qsDataLog1.sprintf(" Msg.No    Msg.Time                 CMD(RT-T/R-SA-WC)       BSW       STS1           DW01        DW02        DW03        DW04        DW05        DW06        DW07        DW08        DW09        DW10        DW11        DW12        DW13        DW14        DW15        DW16        DW17        DW18        DW19        DW20        DW21        DW22        DW23        DW24        DW25        DW26        DW27        DW28        DW29        DW30        DW31        DW32\n");

    memcpy(&sbcResult,&inS_p1553B_Msg->DP_1553B_BC_Strct,sizeof(SDP1553BXT_BC_MSG));

    m_pobjC1553BWrapper->GetTimeFromTimetag(sbcResult.u64TimeTagVal, sbcResult.u16TimetagRes, NULL, szTimetag,&qsData);
    //qDebug() << "LOG Resul:" << sbcResult.u16TimetagRes << "TT:" << sbcResult.u64TimeTagVal;
    DP1553BXT_GET_CMD_WORD(sbcResult.u16CmdWord1, u16RTAddr, u16SubAddr1, u16WC_MC,  u16TxRx );

    qsDataLog2.sprintf(" %4d      %s      0x%4X(%2d-%2d-%2d-%2d)      0x%4X    0x%3X    ",m_uiMsgCnt, qsData.toLatin1().data(), sbcResult.u16CmdWord1, u16RTAddr, u16TxRx, u16SubAddr1, u16WC_MC, sbcResult.u16BlockStsWord, sbcResult.u16RTStsWord1);

    for(iloop=0; iloop < u16WC_MC; iloop++)
    {
        qsDataLog3.append(qsRxData.sprintf("      0x%04X",sbcResult.u16Data[iloop]));
    }
    qsDataLog3.append("\n");

    if(f_BCLogFile.exists())
    {
        qsDataFullLog = qsDataLog2+qsDataLog3;
        if(f_BCLogFile.open(QIODevice::Append))
        {
            f_BCLogFile.write(qsDataFullLog.toLatin1().data());
        }
    }
    else
    {
        qsDataFullLog = qsDataLog1+qsDataLog2+qsDataLog3;
        if(f_BCLogFile.open(QIODevice::WriteOnly | QIODevice::Truncate))
        {
            f_BCLogFile.write(qsDataFullLog.toLatin1().data());
        }
    }

    f_BCLogFile.close();

    return 0;
}//End of Extract file function

short CTestThread::RT_LogFile(SDP_All_Msg *inS_p1553B_Msg, QString qsFileName)
{
    SDP1553BXT_RT_MSG srtResult;
    S_APP_TIMETAG_TIME s_TTTime;
    int iloop=0;
    char szTimetag[256] = "";
    QString qsDataLog1;
    QString qsDataLog2;
    QString qsDataLog3;
    QString qsRxData;

    QString qsDataFullLog,qsData;
    QFile f_RTLogFile(qsFileName);
    memcpy(&srtResult,&inS_p1553B_Msg->DP_1553B_RT_Strct,sizeof(SDP1553BXT_RT_MSG));
    U16BIT u16RTAddr = 0, u16SubAddr1 = 0, u16SubAddr2 = 0, u16WC_MC = 0, u16TxRx = 0;

    m_pobjC1553BWrapper->GetTimeFromTimetag(srtResult.u64TimeTag, srtResult.u16TimetagRes, NULL, szTimetag, &qsData);
//    qDebug() << "LOG Resul:" << srtResult.u16TimetagRes << "TT:" << srtResult.u64TimeTag << "str:" << qsData;

    qsDataLog1.sprintf("Msg.No    Msg.Time                 CMD(RT-T/R-SA-WC)        BSW             DW01        DW02        DW03        DW04        DW05        DW06        DW07        DW08        DW09        DW10        DW11        DW12        DW13        DW14        DW15        DW16        DW17        DW18        DW19        DW20        DW21        DW22        DW23        DW24        DW25        DW26        DW27        DW28        DW29        DW30        DW31        DW32\n");

    DP1553BXT_GET_CMD_WORD(srtResult.u16CmdWord, u16RTAddr, u16SubAddr1, u16WC_MC, u16TxRx );

    qsDataLog2.sprintf(" %4d     %s      0x%4X(%2d-%2d-%2d-%2d)       0x%4X    ",m_uiRTMsgNo, qsData.toLatin1().data(), srtResult.u16CmdWord, u16RTAddr, u16TxRx, u16SubAddr1, u16WC_MC, srtResult.u16BlockStsWord);

    for(iloop = 0; iloop < u16WC_MC; iloop++)
    {
        qsDataLog3.append(qsRxData.sprintf("      0x%04X",srtResult.u16Data[iloop]));
    }
    qsDataLog3.append("\n");

    if(f_RTLogFile.exists())
    {
        qsDataFullLog = qsDataLog2+qsDataLog3;

        if(f_RTLogFile.open(QIODevice::Append))
        {
            f_RTLogFile.write(qsDataFullLog.toLatin1().data());
        }
    }
    else
    {
        qsDataFullLog = qsDataLog1+qsDataLog2+qsDataLog3;

        if(f_RTLogFile.open(QIODevice::WriteOnly | QIODevice::Truncate))
        {
            f_RTLogFile.write(qsDataFullLog.toLatin1().data());
        }
    }

    f_RTLogFile.close();

    return 0;
}

short CTestThread::MT_LogFile(SDP_All_Msg *inS_p1553B_Msg, QString qsFileName)
{
    unsigned int uiLoop=0;
    char szTimetag[256] = "";
    QFile f_MTLogFile(qsFileName);
    SDP1553BXT_MT_MSG SMTResult;
    QString qsDataLog1;
    QString qsDataLog2;
    QString qsDataLog3;
    QString qsRxData;
    QString qsData;
    QString qsDataFullLog;
    U16BIT u16RTAddr1 = 0, u16SubAddr1 = 0, u16WC_MC1 = 0, u16TxRx1 = 0;
    U16BIT u16RTAddr2 = 0, u16SubAddr2 = 0, u16WC_MC2 = 0, u16TxRx2 = 0;
    U16BIT u16DataCnt = 0;

    memcpy(&SMTResult,&inS_p1553B_Msg->DP_1553B_MT1_Strct,sizeof(SDP1553BXT_MT_MSG));

    DP1553BXT_GET_CMD_WORD(SMTResult.u16CmdWord1, u16RTAddr1, u16SubAddr1, u16WC_MC1, u16TxRx1);
    DP1553BXT_GET_CMD_WORD(SMTResult.u16CmdWord2, u16RTAddr2, u16SubAddr2, u16WC_MC2, u16TxRx2);

    m_pobjC1553BWrapper->GetTimeFromTimetag(SMTResult.u64TimeTag, SMTResult.u16TimetagRes, NULL, szTimetag,&qsData);

    qsDataLog1.sprintf("Msg.No    Msg.Time                 CMD1(RT-T/R-SA-WC)       CMD2(RT-T/R-SA-WC)       BSW       RT_Sts1   RT_Sts2   Msg.Length  DW01        DW02        DW03        DW04        DW05        DW06        DW07        DW08        DW09        DW10        DW11        DW12        DW13        DW14        DW15        DW16        DW17        DW18        DW19        DW20        DW21        DW22        DW23        DW24        DW25        DW26        DW27        DW28        DW29        DW30        DW31        DW32\n");

    qsDataLog2.sprintf(" %4d     %s      0x%4X(%2d-%2d-%2d-%2d)       0x%4X(%2d-%2d-%2d-%2d)       0x%4X    0x%3X     0x%3X     %2d    ",m_uiMTMsgNo, qsData.toLatin1().data(), SMTResult.u16CmdWord1, u16RTAddr1, u16TxRx1, u16SubAddr1, u16WC_MC1, SMTResult.u16CmdWord2, u16RTAddr2, u16TxRx2, u16SubAddr2, u16WC_MC2, SMTResult.u16BlockStatusWord, SMTResult.u16RTStsWrd1, SMTResult.u16RTStsWrd2, SMTResult.u16LengthWord);

    if(u16WC_MC1)
    {
        u16DataCnt = u16WC_MC1;
    }
    else
    {
        u16DataCnt = u16WC_MC2;
    }

    for(uiLoop=0; uiLoop < u16DataCnt; uiLoop++)
    {
        qsDataLog3.append(qsRxData.sprintf("      0x%04X",SMTResult.u16Data[uiLoop]));
    }

    qsDataLog3.append("\n");

    if(f_MTLogFile.exists())
    {
        qsDataFullLog = qsDataLog2+qsDataLog3;
        if(f_MTLogFile.open(QIODevice::Append))
        {
            f_MTLogFile.write(qsDataFullLog.toLatin1().data());
        }
    }
    else
    {
        qsDataFullLog = qsDataLog1+qsDataLog2+qsDataLog3;
        if(f_MTLogFile.open(QIODevice::WriteOnly | QIODevice::Truncate))
        {
            f_MTLogFile.write(qsDataFullLog.toLatin1().data());
        }
    }

    f_MTLogFile.close();

    return 0;
}//End of Extract file function

short CTestThread::MT2_LogFile(SDP_All_Msg *inS_p1553B_Msg, QString qsFileName)
{
    unsigned int uiLoop=0;
    char szTimetag[256] = "";
    QFile f_MTLogFile(qsFileName);
    SDP1553BXT_MT_MSG SMTResult;
    QString qsDataLog1;
    QString qsDataLog2;
    QString qsDataLog3;
    QString qsRxData;
    QString qsData;
    QString qsDataFullLog;
    U16BIT u16RTAddr1 = 0, u16SubAddr1 = 0, u16WC_MC1 = 0, u16TxRx1 = 0;
    U16BIT u16RTAddr2 = 0, u16SubAddr2 = 0, u16WC_MC2 = 0, u16TxRx2 = 0;
    U16BIT u16DataCnt = 0;

    memcpy(&SMTResult,&inS_p1553B_Msg->DP_1553B_MT2_Strct,sizeof(SDP1553BXT_MT_MSG));

    DP1553BXT_GET_CMD_WORD(SMTResult.u16CmdWord1, u16RTAddr1, u16SubAddr1, u16WC_MC1, u16TxRx1);
    DP1553BXT_GET_CMD_WORD(SMTResult.u16CmdWord2, u16RTAddr2, u16SubAddr2, u16WC_MC2, u16TxRx2);

    m_pobjC1553BWrapper->GetTimeFromTimetag(SMTResult.u64TimeTag, SMTResult.u16TimetagRes, NULL, szTimetag,&qsData);

    DP1553BXT_GET_CMD_WORD(SMTResult.u16CmdWord1, u16RTAddr1, u16SubAddr1, u16WC_MC1, u16TxRx1);
    DP1553BXT_GET_CMD_WORD(SMTResult.u16CmdWord2, u16RTAddr2, u16SubAddr2, u16WC_MC2, u16TxRx2);

    m_pobjC1553BWrapper->GetTimeFromTimetag(SMTResult.u64TimeTag, SMTResult.u16TimetagRes, NULL, szTimetag,&qsData);

    qsDataLog1.sprintf("Msg.No    Msg.Time                 CMD1(RT-T/R-SA-WC)       CMD2(RT-T/R-SA-WC)       BSW       RT_Sts1   RT_Sts2   Msg.Length  DW01        DW02        DW03        DW04        DW05        DW06        DW07        DW08        DW09        DW10        DW11        DW12        DW13        DW14        DW15        DW16        DW17        DW18        DW19        DW20        DW21        DW22        DW23        DW24        DW25        DW26        DW27        DW28        DW29        DW30        DW31        DW32\n");

    qsDataLog2.sprintf(" %4d     %s      0x%4X(%2d-%2d-%2d-%2d)       0x%4X(%2d-%2d-%2d-%2d)       0x%4X    0x%3X     0x%3X     %2d    ",m_uiMTMsgNo, qsData.toLatin1().data(), SMTResult.u16CmdWord1, u16RTAddr1, u16TxRx1, u16SubAddr1, u16WC_MC1, SMTResult.u16CmdWord2, u16RTAddr2, u16TxRx2, u16SubAddr2, u16WC_MC2, SMTResult.u16BlockStatusWord, SMTResult.u16RTStsWrd1, SMTResult.u16RTStsWrd2, SMTResult.u16LengthWord);

    if(u16WC_MC1)
    {
        u16DataCnt = u16WC_MC1;
    }
    else
    {
        u16DataCnt = u16WC_MC2;
    }

    for(uiLoop=0; uiLoop < u16DataCnt; uiLoop++)
    {
        qsDataLog3.append(qsRxData.sprintf("      0x%04X",SMTResult.u16Data[uiLoop]));
    }

    qsDataLog3.append("\n");

    if(f_MTLogFile.exists())
    {
        qsDataFullLog = qsDataLog2+qsDataLog3;
        if(f_MTLogFile.open(QIODevice::Append))
        {
            f_MTLogFile.write(qsDataFullLog.toLatin1().data());
        }
    }
    else
    {
        qsDataFullLog = qsDataLog1+qsDataLog2+qsDataLog3;
        if(f_MTLogFile.open(QIODevice::WriteOnly | QIODevice::Truncate))
        {
            f_MTLogFile.write(qsDataFullLog.toLatin1().data());
        }
    }

    f_MTLogFile.close();

    return 0;
}//End of Extract file function

QString CTestThread::DigitalTestReportCreation(SDP_All_Msg *inS_All_Msg,int iTestID,unsigned short usBCChannelNo ,int iCycleCount)
{
    QString qHeader = " ";
    QString qsResult = " ";
    QString text = " ";
    QString qsTable = " ";
    QString qsTableHeader = " ";
    QString qsHead = " ";
    QString qsRetVal = " ";
    QString qHtmlBC ;
    QString qHtmlRT;
    QString qHtmlMT1;
    QString qHtmlMT2;
    QString qHtml;
    text.clear();
    unsigned short out_usRTAddr = 0;
    unsigned short out_usSubAddr = 0;
    unsigned short out_usWC_MC = 0;
    unsigned short out_usTxRx = 0;
    unsigned short out_usRTRTAddr = 0;
    unsigned short out_usRTSubAddr = 0;
    unsigned short out_usRTWC_MC = 0;
    unsigned short out_usRTTxRx = 0;
    unsigned short out_usMT1RTAddr = 0;
    unsigned short out_usMT1SubAddr = 0;
    unsigned short out_usMT1WC_MC = 0;
    unsigned short out_usMT1TxRx = 0;
    unsigned short out_usMT2RTAddr = 0;
    unsigned short out_usMT2SubAddr = 0;
    unsigned short out_usMT2WC_MC = 0;
    unsigned short out_usMT2TxRx = 0;
    unsigned short usBCChnNo = 0;
    unsigned short usRTChnNo = 0;
    unsigned short usMT1ChnNo = 0;
    unsigned short usMT2ChnNo = 0;
    QString header = "<article><div align=\"right\"><b>&#9733;Restricted &#169;Data Patterns (India) Limited</b></div><br><br><header><h1><center><font color=\"midnightblue\"> LINS-CM CHECKOUT ATP TEST REPORT</font></center></h1>";
    QString qHearder1 = "<html><img src= \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJoAAAAxCAMAAAAV+kAIAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAAwBQTFRFAAAAgAAAAIAAgIAAAACAgACAAICAwMDAwNzApsrwAAAAWRQRioqKk5OTnZ2dsikjtjYwurq6u0M+v7+/wFFMxMTExV5aymtnznl1zs7O04aD2JSR3aGe4eHh4q6s5ry668nI6+vr8NbV9eTj9fX1+vHx////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vwoKCkgICA/wAAAP8A//8AAAD//wD/AP//////7elzQQAAAylJREFUWEftWF2PozAM7Ps9JOKqFDUIokTx//+JN7YD/UjKdrurip6I1C6YSRiPx2HLgTY7Dm1mHJZL88HNSTv6BGRlYs1jp7ZahBV5GjXdckEP7xyP/f5hqu0duuwmDyrXCr/Tav9Ph+5eW/eab40/CPJHvqqTdvQG/+2JFYvxQGajw+3UXqjMR6mmduyPc57O81EfyuCTTkI6egY7RSv0NEO7+aAXlPcOMzFOrgPMn3WBzuPMAnDm6NWoVSNKfgr4dgqLdGIGo0fMD4FDI/XLEoiO+DDGBPnjgh8FaoP3RMGHHldywqFxjI6UrDGAaD7chxNNPqSvqfHtj5kU2WExnYLb6IHNuMk8QMvYJBhLNGkYDMr1QiCUGbjgzFGWxJ4uCTI1x5ftVS3kQtWhnJyuLjPPRPmOWo9VF/GZGkThPAAlyPElNbDCLQDO7AOm5uf0l4zXqJmkEkSIpeVbVAtDLsVAVPSIQj8BoQZaV+0kMJoyZWSi1GjUpK7GQ9WKEi6Bo5Z2ptZRN5ZQoQYZB9jxAm1QS+x/toezkaIkAorRCjWUmPJwR66mNttCKmXCmeskJp+pDRMvJSGhhpHYJvECbVDLaFfWiof2jDdIKVppA/bIlYFV+sprM7XI0CMNfiiTQI2b1ubJ+0sjzHBkX0GlsmLuBQV9S1+BmuFjoWY6mOSq71epQXoUaUxIFm0vG5FS85x/XBphuSmg4x20Sc2BDy/H1LANUZz7Pl0MvK6ap9xBIdmoNE+lZjMviX2ibClBjMObTAXVqfeqndE0vAcINRyLb7hV/ZOqwWDoy14zgmywqFLzJDs/LKauVUtybSroDbXoHD8zmCr4wnVKDT3BbSBcuV+vRstrYlV5GKRJoCCFdYSazbrLgbrukIUaHHgP5fOLaupz9A+m4dnQGVEfamdQO+UcYlqejcqvpuYM8isPqZssfnJy5DXLk7a1jm3c8qP+8/iJOL86d9uqbfhnS+O3++Vl5P5W8qE8jQv7q7/y0qcpmr7mrseWVQPb/eV80aBduQ8r6P5W8pV3uXsbvKDaX6jGH/mqTtrRG/y3Jz7doe2N+L3RfwKm4XY9Nn4DAAAAAElFTkSuQmCC\" alt=\"DataPatterns Logo\" style=\"float:left\"/>";
    QString qIndex;
    QString qRep = " ";
    QString qAll ;
    QString qsTestName, qsConfigDetails = "";
    int iLoop = 0;
    qIndex.clear();
    qsTestName.clear();

    qIndex += "<font color=\"darkblue\"><span style =font-size:18pt;>Tested on : <font color=\"black\"><span style =font-size:18pt;>"+ QDateTime::currentDateTime().toString("dd-MMM-yyyy HH:mm:ss") + "</span></font>" ;

    qAll.clear();
    qAll += qIndex;
    if(iTestID == DP_1553B_Internal_selfTest)
    {
        QString qsInternalRslt[6];
        QString qsInternalPass = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
        QString qsInternalFail = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
        qsTestName = "1553B INTERNAL SELF TEST";


        qsTableHeader +=("<tr><th>Channel No</th><th>Single Port Test</th><th>RAM BISTTest</th><th>ROM BIST Test</th><th>RAM Address Bus</th><th>RAM Data Bus</th><th>Integrity Test</th></tr>\n");

        for(iLoop = 0; iLoop < 4; iLoop++)
        {

            if(inS_All_Msg->SDP_InternalSelf_Test[iLoop].ucSinglePortRslt == 1)
            {
                qsInternalRslt[0] = qsInternalPass;
            }
            else
            {
                qsInternalRslt[0] = qsInternalFail;
            }

            if(inS_All_Msg->SDP_InternalSelf_Test[iLoop].ucRAM_BIST_Rslt == 1)
            {
                qsInternalRslt[1] = qsInternalPass;
            }
            else
            {
                qsInternalRslt[1] = qsInternalFail;
            }

            if(inS_All_Msg->SDP_InternalSelf_Test[iLoop].ucROM_BIST_Rslt == 1)
            {
                qsInternalRslt[2] = qsInternalPass;
            }
            else
            {
                qsInternalRslt[2] = qsInternalFail;
            }

            if(inS_All_Msg->SDP_InternalSelf_Test[iLoop].ucRAM_AddrBus_Rslt == 1)
            {
                qsInternalRslt[3] = qsInternalPass;
            }
            else
            {
                qsInternalRslt[3] = qsInternalFail;
            }

            if(inS_All_Msg->SDP_InternalSelf_Test[iLoop].ucRAM_DataBus_Rslt == 1)
            {
                qsInternalRslt[4] = qsInternalPass;
            }
            else
            {
                qsInternalRslt[4] = qsInternalFail;
            }

            if(inS_All_Msg->SDP_InternalSelf_Test[iLoop].ucIntergrityTest == 1)
            {
                qsInternalRslt[5] = qsInternalPass;
            }
            else
            {
                qsInternalRslt[5] = qsInternalFail;
            }

            text +=("<tr><td>"+ QString::number(iLoop+1) + "</td><td>"\
                    + qsInternalRslt[0] + "</td><td>"\
                    + qsInternalRslt[1] + "</td><td>"\
                    + qsInternalRslt[2] + "</td><td>"\
                    + qsInternalRslt[3] + "</td><td>"\
                    + qsInternalRslt[4] + "</td><td>"\
                    + qsInternalRslt[5] + "</td></tr>\n");
        }
        text += "</table>\n";

        qHeader.clear();
        qHeader = "<br><h2><font color=\"dimgray\">"+QString::number(m_iCountIndex)+")"+qsTestName+" (Time: "+ QDateTime::currentDateTime().toString("dd-MMM-yyyy HH:mm") +")</font></h2><table border=\"1\" style=\"background-color:ghostwhite;border:1px dotted black;width:80%;border-collapse:collapse;\"><tr style=\"background-color:gainsboro;color:black;\"></table>\n";
        qsTable += "<table>";

        qsRetVal = qHeader+qsTable+qsTableHeader+text;

        qRep = qsRetVal;
        m_qfReport.write(qRep.toLatin1().data());
        qsRetVal = " ";
    }
    else if(iTestID ==DP_1553B_Terminal_Test)
    {
        qsTestName = "TERMINAL MODE TEST";

        if(inS_All_Msg->iBCError != 0)
        {
            qHtmlBC = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
            qHtml = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
        }
        else
        {
            qHtmlBC = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
            qHtml = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
        }

        if(inS_All_Msg->iRTError != 0)
        {
            qHtmlRT = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
            qHtml = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
        }
        else
        {
            qHtmlRT = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
            qHtml = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
        }

        if(inS_All_Msg->iMT1Error != 0)
        {
            qHtmlMT1 = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
            qHtml = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
        }
        else
        {
            qHtmlMT1 = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
            qHtml = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
        }

        //        if(inS_All_Msg->iMT2Error != 0)
        //        {
        //            qHtmlMT2 = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
        //            qHtml = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
        //        }
        //        else
        //        {
        //            qHtmlMT2 = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
        //            qHtml = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
        //        }

        DP1553BXT_GET_CMD_WORD(inS_All_Msg->DP_1553B_BC_Strct.u16CmdWord1, out_usRTAddr, out_usSubAddr, out_usWC_MC, out_usTxRx);
        DP1553BXT_GET_CMD_WORD(inS_All_Msg->DP_1553B_RT_Strct.u16CmdWord, out_usRTRTAddr, out_usRTSubAddr, out_usRTWC_MC, out_usRTTxRx);
        DP1553BXT_GET_CMD_WORD(inS_All_Msg->DP_1553B_MT1_Strct.u16CmdWord1, out_usMT1RTAddr, out_usMT1SubAddr, out_usMT1WC_MC, out_usMT1TxRx);
        //        DP1553BXT_GET_CMD_WORD(inS_All_Msg->DP_1553B_MT2_Strct.u16CmdWord1, out_usMT2RTAddr, out_usMT2SubAddr, out_usMT2WC_MC, out_usMT2TxRx);
        if(out_usWC_MC == 0)
        {
            out_usWC_MC = 32;
        }

        if(usBCChannelNo == 0)
        {
            usBCChnNo = DP_1553B_ONE;
            usRTChnNo = DP_1553B_TWO;
            usMT1ChnNo = DP_1553B_THREE;
            //            usMT2ChnNo = DP_1553B_FOUR;
        }
        else if(usBCChannelNo == 1)
        {
            usBCChnNo = DP_1553B_TWO;
            usRTChnNo = DP_1553B_THREE;
            usMT1ChnNo = DP_1553B_ONE;
            //            usMT2ChnNo = DP_1553B_ONE;
        }
        else if(usBCChannelNo == 2)
        {
            usBCChnNo = DP_1553B_THREE;
            usRTChnNo = DP_1553B_ONE;
            usMT1ChnNo = DP_1553B_TWO;
            //            usMT2ChnNo = DP_1553B_TWO;
        }
        //        else if(usBCChannelNo == 3)
        //        {
        //            usBCChnNo = DP_1553B_FOUR;
        //            usRTChnNo = DP_1553B_ONE;
        //            usMT1ChnNo = DP_1553B_TWO;
        //            usMT2ChnNo = DP_1553B_THREE;
        //        }

        qsTableHeader +=("<tr><th>S.No</th><th>BC <br> (CH " +QString::number(usBCChnNo) +")\
                         </th><th>RT <br> (CH " +QString::number(usRTChnNo) +")\
                         </th><th>MT1 <br> (CH " +QString::number(usMT1ChnNo) +")\
                         </th><th>Result</th></tr>\n");

                         text +=("<tr><td>"+ QString::number(inS_All_Msg->iTestNo+1) + "</td>\
                                 <td>RT:" + QString::number(out_usRTAddr) +",SA:"+QString::number(out_usSubAddr)+",WC:"+QString::number(out_usWC_MC)+",TR:"+ QString::number(out_usTxRx)+"\
                                 BSW:0x" + QString::number(inS_All_Msg->DP_1553B_BC_Strct.u16BlockStsWord,16) +"\
                                 RTS:0x" + QString::number(inS_All_Msg->DP_1553B_BC_Strct.u16RTStsWord1,16) +"\
                                 -" + qHtmlBC +"\
                                 </td>\
                                 <td>RT:" + QString::number(out_usRTAddr) +",SA:"+QString::number(out_usRTSubAddr)+",WC:"+QString::number(out_usRTWC_MC)+",TR:"+ QString::number(out_usRTTxRx)+"\
                                 BSW:0x" + QString::number(inS_All_Msg->DP_1553B_RT_Strct.u16BlockStsWord,16) +"\
                                 -" + qHtmlRT +"\
                                 </td>\
                                 <td>RT:" + QString::number(out_usRTAddr) +",SA:"+QString::number(out_usMT1SubAddr)+",WC:"+QString::number(out_usMT1WC_MC)+",TR:"+ QString::number(out_usMT1TxRx)+"\
                                 BSW:0x" + QString::number(inS_All_Msg->DP_1553B_MT1_Strct.u16BlockStatusWord,16) +"\
                                 -" + qHtmlMT1 +"\
                                 </td>\
                                 <td>"+ qHtml + "</td></tr>\n");

                                 qHeader.clear();

                QString qsCommunicationType;
                unsigned char ucSec = 0;
        if(inS_All_Msg->ucCommTypeTxRx)
        {
            qsCommunicationType = " (RT-BC)";
            ucSec = 2;
        }
        else
        {
            qsCommunicationType = " (BC-RT)";
            ucSec = 1;
        }

        QString qsChnCombination;
        if(inS_All_Msg->ucBusSel == 1)
        {
            qsChnCombination = "<h3><font color=\"black\">"+QString::number(m_iCountIndex)+"."+QString::number(m_iTermiChnCombination)+"."+QString::number(ucSec)+". Channel Combination "+QString::number(m_iTermiChnCombination)+", Bus Selection A"+qsCommunicationType+"</font></h3>This test case has been validated with Counter data transreception";
        }
        else if(inS_All_Msg->ucBusSel == 0)
        {
            qsChnCombination = "<h3><font color=\"black\">"+QString::number(m_iCountIndex)+"."+QString::number(m_iTermiChnCombination)+"."+QString::number(ucSec)+". Channel Combination "+QString::number(m_iTermiChnCombination)+", Bus Selection B"+qsCommunicationType+"</font></h3>This test case has been validated with Counter data transreception";
        }

        qHeader = "<br><h2><font color=\"dimgray\">"+QString::number(m_iCountIndex)+")"+qsTestName+" (Time: "+ QDateTime::currentDateTime().toString("dd-MMM-yyyy HH:mm") +")</font></h2><table border=\"1\" style=\"background-color:ghostwhite;border:1px dotted black;width:80%;border-collapse:collapse;\"><tr style=\"background-color:gainsboro;color:black;\"></table>\n";
        qsTable += "<table>";

        qsRetVal = qHeader+qsChnCombination+qsTable+qsTableHeader+text;

        if(inS_All_Msg->iTerminalTestStart == 1)
        {
            if(m_iTestStart == 1)
            {
                qRep = "</table>\n"+qsRetVal;
                m_qfReport.write(qRep.toLatin1().data());
                qsRetVal = " ";
                qRep.clear();
                m_iChnChange = 0;
                m_iTestStart = 0;
            }
            else
            {
                if(m_iChnChange == 1)
                {
                    qRep = "</table><br>\n"+qsTable+qsTableHeader+text;
                    m_qfReport.write(qRep.toLatin1().data());
                    qsRetVal = " ";
                    qRep.clear();
                    m_iChnChange = 0;
                }
                else
                {
                    qRep = "</table>\n"+qsRetVal;
                    m_qfReport.write(qRep.toLatin1().data());
                    qsRetVal = " ";
                    qRep.clear();
                    m_iChnChange = 0;
                }
            }
        }
        else if(inS_All_Msg->iTerminalTestStart == 0)
        {
            if(m_iChnChange == 1)
            {
                qRep = "</table><br>\n"+qsChnCombination+qsTable+qsTableHeader+text;
                m_qfReport.write(qRep.toLatin1().data());
                qsRetVal = " ";
                qRep.clear();
                m_iChnChange = 0;
            }
            else
            {
                qRep = text;
                m_qfReport.write(qRep.toLatin1().data());
                qsRetVal = " ";
                qRep.clear();
            }
        }
    }
    else if(iTestID ==DP_1553B_Combined_Mode_Test)
    {
        qsTestName = "COMBINED MODE TEST";

        if(inS_All_Msg->iBCError != 0)
        {
            qHtmlBC = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
            qHtml = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
        }
        else
        {
            qHtmlBC = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
            qHtml = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
        }

        if(inS_All_Msg->iRTError != 0)
        {
            qHtmlRT = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
            qHtml = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
        }
        else
        {
            qHtmlRT = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
            qHtml = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
        }

        if(inS_All_Msg->iMT1Error != 0)
        {
            qHtmlMT1 = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
            qHtml = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
        }
        else
        {
            qHtmlMT1 = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
            qHtml = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
        }

        DP1553BXT_GET_CMD_WORD(inS_All_Msg->DP_1553B_BC_Strct.u16CmdWord1, out_usRTAddr, out_usSubAddr, out_usWC_MC, out_usTxRx);
        DP1553BXT_GET_CMD_WORD(inS_All_Msg->DP_1553B_RT_Strct.u16CmdWord, out_usRTRTAddr, out_usRTSubAddr, out_usRTWC_MC, out_usRTTxRx);
        DP1553BXT_GET_CMD_WORD(inS_All_Msg->DP_1553B_MT1_Strct.u16CmdWord1, out_usMT1RTAddr, out_usMT1SubAddr, out_usMT1WC_MC, out_usMT1TxRx);

        if(usBCChannelNo == 0)
        {
            usBCChnNo = DP_1553B_ONE;
            usRTChnNo = DP_1553B_ONE;
            usMT1ChnNo = DP_1553B_ONE;
        }
        else if(usBCChannelNo == 1)
        {
            usBCChnNo = DP_1553B_TWO;
            usRTChnNo = DP_1553B_TWO;
            usMT1ChnNo = DP_1553B_TWO;
        }
        else if(usBCChannelNo == 2)
        {
            usBCChnNo = DP_1553B_THREE;
            usRTChnNo = DP_1553B_THREE;
            usMT1ChnNo = DP_1553B_THREE;
        }
        else if(usBCChannelNo == 3)
        {
            usBCChnNo = DP_1553B_FOUR;
            usRTChnNo = DP_1553B_FOUR;
            usMT1ChnNo = DP_1553B_FOUR;
        }
        qsTableHeader +=("<tr><th>Channel No</th><th>BC</th><th>RT</th><th>MT1</th><th>Result</th></tr>\n");

        text +=("<tr><td>"+ QString::number(m_iCombinedModeSNO) + "</td>\
                <td>CMD : RT : " + QString::number(out_usRTAddr) +", SA : "+QString::number(out_usSubAddr)+" WC : "+QString::number(out_usWC_MC)+", TR -"+ QString::number(out_usTxRx)+"\
                BSW - 0x" + QString::number(inS_All_Msg->DP_1553B_BC_Strct.u16BlockStsWord,16) +"\
                RT Status - 0x" + QString::number(inS_All_Msg->DP_1553B_BC_Strct.u16RTStsWord1,16) +"\
                Result - " + qHtmlBC +"\
                </td>\
                <td>CMD : RT : " + QString::number(out_usRTAddr) +", SA : "+QString::number(out_usRTSubAddr)+" WC : "+QString::number(out_usRTWC_MC)+", TR -"+ QString::number(out_usRTTxRx)+"\
                BSW - 0x" + QString::number(inS_All_Msg->DP_1553B_RT_Strct.u16BlockStsWord,16) +"\
                Result - " + qHtmlRT +"\
                </td>\
                <td>CMD : RT : " + QString::number(out_usRTAddr) +", SA : "+QString::number(out_usMT1SubAddr)+" WC : "+QString::number(out_usMT1WC_MC)+", TR -"+ QString::number(out_usMT1TxRx)+"\
                BSW - 0x" + QString::number(inS_All_Msg->DP_1553B_MT1_Strct.u16BlockStatusWord,16) +"\
                Result - " + qHtmlMT1 +"\
                </td>\
                <td>"+ qHtml + "</td></tr>\n");
                //            text += "</table>\n";
                qHeader.clear();
                qHeader = "<br><h2><font color=\"dimgray\">"+QString::number(m_iCountIndex)+")"+qsTestName+" (Time: "+ QDateTime::currentDateTime().toString("dd-MMM-yyyy HH:mm") +")</font></h2><table border=\"1\" style=\"background-color:ghostwhite;border:1px dotted black;width:80%;border-collapse:collapse;\"><tr style=\"background-color:gainsboro;color:black;\"></table>\n";
        qsTable += "<table>";

        qsRetVal = qHeader+qsTable+qsTableHeader+text;

        if(inS_All_Msg->iCombinedTestStart == 1)
        {
            if(m_iCombinedTestStart == 1)
            {
                qRep = "</table>\n"+qsRetVal;
                m_qfReport.write(qRep.toLatin1().data());
                qsRetVal = " ";
                qRep.clear();
                m_iCombinedChnChange = 0;
                m_iCombinedTestStart = 0;
            }
            else
            {
                if(m_iCombinedChnChange == 1)
                {
                    qRep = "</table><br>\n"+qsTable+qsTableHeader+text;
                    m_qfReport.write(qRep.toLatin1().data());
                    qsRetVal = " ";
                    qRep.clear();
                    m_iCombinedChnChange = 0;
                }
                else
                {
                    qRep = "</table>\n"+qsRetVal;
                    m_qfReport.write(qRep.toLatin1().data());
                    qsRetVal = " ";
                    qRep.clear();
                    m_iCombinedChnChange = 0;
                }
            }
        }
        else if(inS_All_Msg->iCombinedTestStart == 0)
        {
            if(m_iCombinedChnChange == 1)
            {
                qRep = "</table><br>\n"+qsTable+qsTableHeader+text;
                m_iCombinedChnChange = 0;
            }
            else
            {
                qRep = text;
            }

            if(m_iCombinedModeSNO== 4)
            {
                qRep.append("</table>\n");
            }
            m_qfReport.write(qRep.toLatin1().data());
            qsRetVal = " ";
            qRep.clear();
        }
    }
    else if(iTestID ==DP_1553B_Sync_Test)
    {
        qsTestName = "SYNCHRONIZE BC START TEST";
        QString qsFirstFullTimeTag = " ";
        QString qsLastFullTimeTag = " ";
        S_APP_TIMETAG_TIME out_pTime;
        QString qsFirstData;
        QString qsLastData;
        char arrcData[200];

        qsTableHeader +=("<tr><th>Channel No</th><th>Message Count</th><th>Word Count</th><th>Time to Next Message(&#181;s)</th><th>Time Tag Resolution(ns)</th><th>First Message Time Tag<br>H:mm:ss.ms.&#181;s.ns</th>\
                         <th>Last Message Time Tag</th><th>Max. Diff observed in First Msg. TT<br>(Exp. < 1&#181;s)</th>\
                <th>Result</th></tr>\n");

                for(int iChnNo = 0; iChnNo < DP_1553B_MAX_CHANNEL_SEL;iChnNo++)
        {
            m_iSyncSNOTestNo += 1;

            m_pobjC1553BWrapper->GetTimeFromTimetag(inS_All_Msg->sDP_Sync_Reslt.usFirstMsgTT[iChnNo],inS_All_Msg->sDP_Sync_Reslt.u16TimetagRes[iChnNo], &out_pTime, arrcData,&qsFirstData);
            m_pobjC1553BWrapper->GetTimeFromTimetag(inS_All_Msg->sDP_Sync_Reslt.usLastMsgTT[iChnNo],inS_All_Msg->sDP_Sync_Reslt.u16TimetagRes[iChnNo], &out_pTime, arrcData,&qsLastData);
            qDebug() << "Report creation Resul:" << inS_All_Msg->sDP_Sync_Reslt.u16TimetagRes[iChnNo] << "TT:" << inS_All_Msg->sDP_Sync_Reslt.usFirstMsgTT[iChnNo];
            text +=("<tr><td>"+ QString::number(iChnNo+1) + "</td><td>"+ QString::number(inS_All_Msg->usMsgCnt) +"</td><td>"+ QString::number(inS_All_Msg->sDP_Sync_Reslt.u16WordCount[iChnNo]) +"</td><td>"\
                    + QString::number(inS_All_Msg->usTimeToNextMsg) +"</td>");

            text += "<td>100</td><td><b>"+qsFirstData + "</b></td><td>"+qsLastData + "</td></tr>\n";
            if(iChnNo == 0)
            {
                text.chop(6);
                text += "<td rowspan = \"4\">"+ QString::number((inS_All_Msg->usMaxDiff)/10.0f)+"</td><td rowspan = \"4\">"+ inS_All_Msg->sDP_Sync_Reslt.qsSyncResult+"</td></tr>\n";
            }
        }

        text += "</table>\n";

        qHeader.clear();
        qHeader = "</table>\n<br><h2><font color=\"dimgray\">"+QString::number(m_iCountIndex)+")"+qsTestName+" (Time: "+ QDateTime::currentDateTime().toString("dd-MMM-yyyy HH:mm") +")</font></h2><table border=\"1\" style=\"background-color:ghostwhite;border:1px dotted black;width:80%;border-collapse:collapse;\"><tr style=\"background-color:gainsboro;color:black;\"></table>\n";
        qsTable += "<table>";

        qsRetVal = qHeader+qsTable+qsTableHeader+text;

        qRep = qsRetVal;
        m_qfReport.write(qRep.toLatin1().data());
        qsRetVal = " ";
        m_iDiscreteTestStart = 0;
    }
    else if(iTestID == DP_1553B_Async_Test)
    {
        qsTestName = "ASYNCHRONOUS MESSAGE TRANSMIT TEST";
        QString qsHtml;

        if(usBCChannelNo == 0)
        {
            usBCChnNo = DP_1553B_ONE;
            usRTChnNo = DP_1553B_TWO;
            usMT1ChnNo = DP_1553B_THREE;
            //            usMT2ChnNo = DP_1553B_FOUR;
        }
        else if(usBCChannelNo == 1)
        {
            usBCChnNo = DP_1553B_TWO;
            usRTChnNo = DP_1553B_THREE;
            usMT1ChnNo = DP_1553B_ONE;
            //            usMT2ChnNo = DP_1553B_ONE;
        }
        else if(usBCChannelNo == 2)
        {
            usBCChnNo = DP_1553B_THREE;
            usRTChnNo = DP_1553B_ONE;
            usMT1ChnNo = DP_1553B_TWO;
            //            usMT2ChnNo = DP_1553B_TWO;
        }

        if((m_pobjBCReadThread->iResult == 1) && (m_pobjBCReadThread->m_iBCmsgCnt == m_pobjRTReadThread->m_iRTmsgCnt) && (m_pobjBCReadThread->m_iBCmsgCnt != 0))
        {
            m_iAsyncChnTestPassCnt++;
            qsHtml = "<b><span style =font-size:10pt;><font color=Green>PASS</font></span></b>";
        }
        else
        {
            qsHtml = "<b><span style =font-size:10pt;><font color=Red>FAIL</font></span></b>";
        }

        qsTableHeader +=("<tr><th>Channel No</th><th>Command</th><th>Async Msg ID</th><th>Async Msg Time Tag</th><th>Result</th></tr>\n");
        text +=("<tr><td>BC ChNo: "+ QString::number(usBCChannelNo+1) + "<br>RT ChNo: "+QString::number(usRTChnNo)+"</td><td>"+ m_pobjBCReadThread->m_strCmd + "</td><td>"+ QString::number(m_iTransAsyncMsgID)+"</td><td>"+ m_pobjBCReadThread->m_strTimeTag +"</td><td>"+ qsHtml +"</td></tr>\n");

        if(usBCChannelNo == 2)
            text += "</table>\n";

        qHeader.clear();
        qHeader = "<br><h2><font color=\"dimgray\">"+QString::number(m_iCountIndex)+")"+qsTestName+" (Time: "+ QDateTime::currentDateTime().toString("dd-MMM-yyyy HH:mm") +")</font></h2><table border=\"1\" style=\"background-color:ghostwhite;border:1px dotted black;width:80%;border-collapse:collapse;\"><tr style=\"background-color:gainsboro;color:black;\"></table>\n";
        qsTable += "<table>";
        qsRetVal = qHeader+qsTable+qsTableHeader+text;

        if(m_iAsyncTestStart == 1)
        {
            qRep = qsRetVal;
            m_qfReport.write(qRep.toLatin1().data());
            qsRetVal = " ";
            m_iAsyncNextChnTest = 0;
            m_iAsyncNextChnStartTest = 0;
            m_iAsyncTestStart = 0;
        }
        else
        {
            qRep = text;
            m_qfReport.write(qRep.toLatin1().data());
            qsRetVal = " ";
            m_iAsyncNextChnTest = 0;
            m_iAsyncNextChnStartTest = 0;
            m_iAsyncTestStart = 0;
        }
    }
    else if(iTestID == DP_RS232_CH1_Loopback_Test)
    {
        qsTestName = "RS232 CH1 Loopback Test ";

        qsConfigDetails.sprintf("Baudrate : %d,<br>Data Bit: %d,<br>Parity : %d,<br>Stop Bit : %d",m_stAutomodeIp.usCOM1_Baudrate, m_stAutomodeIp.ucCOM1_DataBit, m_stAutomodeIp.ucCOM1_Parity, m_stAutomodeIp.ucCOM1_StopBit);

        qsTableHeader +=("<tr><th width = \"20%\">Configuraton</th>\
                         <th width = \"35%\">Tx Data (Hex)</th>\
                <th width = \"35%\">Rx Data (Hex)</th>\
                <th width = \"10%\">Result</th></tr>\n");

        text +=("<tr><td>"+ qsConfigDetails +"</td><td> "+inS_All_Msg->qsRS232TxData + "</td><td>"\
                +inS_All_Msg->qsRS232RxData+ "</td><td>"\
                + inS_All_Msg->qsRS232Rslt+"</td></tr>\n");

        text += "</table>\n";

        qHeader.clear();
        qHeader = "<br><h2><font color=\"dimgray\">"+QString::number(m_iCountIndex)+")"+qsTestName+":Time: "+ QDateTime::currentDateTime().toString("dd-MMM-yyyy HH:mm") +")</font></h2><table border=\"1\" style=\"background-color:ghostwhite;border:1px dotted black;width:80%;border-collapse:collapse;\"><tr style=\"background-color:gainsboro;color:black;\"></table>\n";
        qsTable += "<table>";

        qsRetVal = qHeader+qsTable+qsTableHeader+text;

        qRep = qsRetVal;
        m_qfReport.write(qRep.toLatin1().data());
        qsRetVal = " ";
    }
    else if(iTestID == DP_RS232_CH2_Loopback_Test)
    {
        qsTestName = "RS232 CH2 Loopback Test ";

        qsConfigDetails.sprintf("Baudrate : %d,<br>Data Bit: %d,<br>Parity : %d,<br>Stop Bit : %d",m_stAutomodeIp.usCOM2_Baudrate, m_stAutomodeIp.ucCOM2_DataBit, m_stAutomodeIp.ucCOM2_Parity, m_stAutomodeIp.ucCOM2_StopBit);

        qsTableHeader +=("<tr><th width = \"20%\">Configuraton</th>\
                         <th width = \"35%\">Tx Data (Hex)</th>\
                <th width = \"35%\">Rx Data (Hex)</th>\
                <th width = \"10%\">Result</th></tr>\n");


        text +=("<tr><td> "+qsConfigDetails + "</td><td>"\
                +inS_All_Msg->qsRS232TxData + "</td><td>"\
                +inS_All_Msg->qsRS232RxData + "</td><td>"\
                + inS_All_Msg->qsRS232Rslt+"</td></tr>\n");

        text += "</table>\n";

        qHeader.clear();
        qHeader = "<br><h2><font color=\"dimgray\">"+QString::number(m_iCountIndex)+")"+qsTestName+": Time: "+ QDateTime::currentDateTime().toString("dd-MMM-yyyy HH:mm") +")</font></h2><table border=\"1\" style=\"background-color:ghostwhite;border:1px dotted black;width:80%;border-collapse:collapse;\"><tr style=\"background-color:gainsboro;color:black;\"></table>\n";

        qsTable += "<table>";

        qsRetVal = qHeader+qsTable+qsTableHeader+text;

        qRep = qsRetVal;
        m_qfReport.write(qRep.toLatin1().data());
        qsRetVal = " ";
    }
    else if(iTestID == DP_RS232_CH1_CH2_Loopback_Test)
    {
        qsTestName = "RS232 CH1 and RS232 CH2 Loopback Test ";

        qsConfigDetails.sprintf("Baudrate : %d,<br>Data Bit: %d,<br>Parity : %d,<br>Stop Bit : %d",m_stAutomodeIp.usCOM1_Baudrate, m_stAutomodeIp.ucCOM1_DataBit, m_stAutomodeIp.ucCOM1_Parity, m_stAutomodeIp.ucCOM1_StopBit);

        qsTableHeader +=("<tr><th width = \"10%\">Configuration</th>\
                         <th width = \"28%\">RS232 CH1 Tx Data (Hex)</th>\
                <th width = \"28%\">RS232 CH2 Rx and Tx Data (Hex)</th>\
                <th width = \"28%\">RS232 CH1 Rx Data (Hex)</th>\
                <th width = \"6%\">Result</th></tr>\n");


        text +=("<tr><td> "+qsConfigDetails + "</td><td>"\
                +inS_All_Msg->qsRS232TxData + "</td><td>"\
                +inS_All_Msg->qsRS232RxData + "</td><td>"\
                +inS_All_Msg->qsRS232RxData2 + "</td><td>"\
                + inS_All_Msg->qsRS232Rslt+"</td></tr>\n");

        text += "</table>\n";

        qHeader.clear();
        qHeader = "<br><h2><font color=\"dimgray\">"+QString::number(m_iCountIndex)+")"+qsTestName+" (Time: "+ QDateTime::currentDateTime().toString("dd-MMM-yyyy HH:mm") +")</font></h2><table border=\"1\" style=\"background-color:ghostwhite;border:1px dotted black;width:80%;border-collapse:collapse;\"><tr style=\"background-color:gainsboro;color:black;\"></table>\n";
        qsTable += "<table>";

        qsRetVal = qHeader+qsTable+qsTableHeader+text;

        qRep = qsRetVal;
        m_qfReport.write(qRep.toLatin1().data());
        qsRetVal = " ";
    }

    qRep.clear();

    return qsRetVal;
}
