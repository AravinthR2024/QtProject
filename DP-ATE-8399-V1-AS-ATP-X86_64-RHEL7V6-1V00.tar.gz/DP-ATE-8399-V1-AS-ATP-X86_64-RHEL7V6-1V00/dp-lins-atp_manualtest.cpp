#include "dp-lins-atp_testthread.h"
#include "dp-lins-atp_mainwindow.h"


void CTestThread::DP_LINS_COSPowerTest(int *out_piStatus)
{
    unsigned char ucDIOSts = 0;
    unsigned char ucDIOEnDis = 0;
    unsigned short usEnCh = 0;
    unsigned short usDisCh = 0;
    int iResult = 0;

    QString strTemp = "";
    QString strLogData = "";
    QString qsDisp = "";
    QString qsResTblVal[7] = {""};
    QString qsTestName, qsReportFile, qsTableContents;
    bool bResult = true;

    Sig_PrintLog("COS Power Test Started", MSGTYPE_INFO);

    QDir dir(DP_LINS_MANUAL_REPORT_DIR);
    if(!dir.exists())
    {
        dir.mkpath(DP_LINS_MANUAL_REPORT_DIR);
    }
    qsReportFile.clear();
    qsReportFile.append(DP_LINS_MANUAL_REPORT_DIR+"/");
    qsReportFile.append(QDateTime::currentDateTime().toString("yyyy-MM-dd_HH-mm-ss"));
    qsReportFile.append("_A8399-300_"+QString(m_SReportInfo.carrSerNo)+"_COS_Power_output_voltage_Test");
    qsReportFile.append(".html");

    qsTestName = "COS Power output voltage Test";

    emit Sig_MsgBox("Kindly ensure that the COS power supply is switched ON", MSGTYPE_INFO);


    strTemp = ("<tr><th colspan = \"2\" style=\"background-color:#ededed\">Relay Status</th><th colspan = \"2\" style=\"background-color:#ededed\">COS LED Status<br>in SIA</th><th rowspan = \"2\" style=\"background-color:#ededed\">Measured COS PSU Voltage(ADC) PSU_V-MON<br>Tol: 28&#177;0.5V</th><th rowspan = \"2\" style=\"background-color:#ededed\">Expected COS Output Voltage(ADC) (V)<br>COS_SW_V-MON</th><th rowspan = \"2\" style=\"background-color:#ededed\">Measured COS Output Voltage(ADC) (V)<br>COS_SW_V-MON</th><th rowspan = \"2\" style=\"background-color:#ededed\">Result</th></tr><tr><th style=\"background-color:#ededed\">Expected</th><th style=\"background-color:#ededed\">Observed</th><th style=\"background-color:#ededed\">Expected</th><th style=\"background-color:#ededed\">Observed</th></tr>\n");

    qsDisp = "Relay_Status    COS_PSU_Voltage(ADC)(V)   COS_Output_Voltage(ADC)(V)    Result";
    Sig_PrintLog(qsDisp, MSGTYPE_INFO);

    float fCOS_PSUVolt = 0.0f;
    float fCOS_RLVolt = 0.0f;

    for(int iTestItrr = 0; iTestItrr < 3; iTestItrr++)
    {
        qsDisp.clear();
        //        /* Initial State, no need to Set-Relay*/
        /* Enable COS Output */
        if(iTestItrr == 1)
        {
            usDisCh = DO_COS_PWR_OFF;
            usEnCh  = DO_COS_PWR_ON;
            ucDIOEnDis = 0;
            qsResTblVal[DP_COS_TEST_RL_EXP_STS] = REPORT_TABLE_TXT_FIXED("T3B1-RL1: ON");
        }
        /* Disable COS Output */
        else
        {
            usDisCh = DO_COS_PWR_ON;
            usEnCh  = DO_COS_PWR_OFF;
            ucDIOEnDis = 1;
            qsResTblVal[DP_COS_TEST_RL_EXP_STS] = REPORT_TABLE_TXT_FIXED("T3B1-RL1: OFF");
        }

        iResult = m_p3096Wrapper->SetOutput(usDisCh, DIO_DISABLE);
        if(iResult)
        {
            emit Sig_PrintLog("Unable to set relay status", MSGTYPE_ERROR);
            break;
        }
        msleep(DP_DIO_RESTTIME);

        iResult = m_p3096Wrapper->SetOutput(usEnCh, DIO_ENABLE);
        if(iResult)
        {
            emit Sig_PrintLog("Unable to set relay status", MSGTYPE_ERROR);
            break;
        }
        msleep(DP_DIO_RESTTIME);

        iResult = m_p3096Wrapper->SetOutput(usEnCh, DIO_DISABLE);
        if(iResult)
        {
            emit Sig_PrintLog("Unable to set relay status", MSGTYPE_ERROR);
            //                break;
        }
        msleep(DP_DIO_RESTTIME);

//        iResult = m_p3096Wrapper->SetOutput(DO_PS1_C1_PWR, DIO_ENABLE);
//        if(iResult)
//        {
//            emit Sig_PrintLog("Unable to set relay status", MSGTYPE_ERROR);
////            break;
//        }
//        msleep(DP_DIO_RESTTIME);

        iResult = m_p3096Wrapper->ReadInput(DI_COS_PWR_STS,&ucDIOSts);
        if(iResult)
        {
            emit Sig_PrintLog("Unable to read relay status", MSGTYPE_ERROR);
            //                break;
        }

        if(ucDIOSts != ucDIOEnDis)
        {
            iResult = LINS_TEST_FAIL;
            qsResTblVal[DP_COS_TEST_RL_OBS_STS] = REPORT_TABLE_VAL_TEXT((iTestItrr == 1)?"OFF":"ON");
            qsDisp.append((iTestItrr == 1)?"OFF\t":"ON\t");
            bResult = false;
            qDebug() << "Relay Status: Exp: " << ucDIOEnDis << "Obs:" << ucDIOSts;
        }
        else
        {
            qsResTblVal[DP_COS_TEST_RL_OBS_STS] = REPORT_TABLE_VAL_TEXT((iTestItrr == 1)?"ON":"OFF");
            qsDisp.append((iTestItrr == 1)?"ON\t":"OFF\t");
        }

        qsResTblVal[DP_COS_TEST_LED_EXP_STS] = REPORT_TABLE_TXT_FIXED((iTestItrr == 1)?"ON":"OFF");

        emit Sig_GetUserInput(2, "Is COS LED in SIA rack glowing?");

        if(!m_iBuzzerRing)
        {
            qsResTblVal[DP_COS_TEST_LED_OBS_STS] = (iTestItrr == 1)?REPORT_TABLE_VAL_TEXT("OFF"):\
                                                                    REPORT_TABLE_VAL_TEXT("OFF");
        }
        else
        {
            qsResTblVal[DP_COS_TEST_LED_OBS_STS] = (iTestItrr == 1)?REPORT_TABLE_VAL_TEXT("ON"):\
                                                                    REPORT_TABLE_VAL_TEXT("ON");
        }

        /* Read current on COS PSU and load */
        iResult =  m_p1105Wrapper->ReadRecentSample(AI_PS_COS_V, 1, &fCOS_PSUVolt, 1);
        if(iResult)
        {
            emit Sig_PrintLog("Unable to read COS PSU voltage", MSGTYPE_ERROR);
            break;
        }

        if((fCOS_PSUVolt > TEST_COSPSU_ON_MAX)||(fCOS_PSUVolt < TEST_COSPSU_ON_MIN))
        {
            qsResTblVal[DP_COS_TEST_ME_COS_IN_V] = REPORT_TABLE_VAL_TEXT(QString::number(fCOS_PSUVolt, 'f',2));
            strLogData.sprintf("%.2f\t",fCOS_PSUVolt);
            qsDisp.append(strLogData);
            bResult = false;
        }
        else
        {
            qsResTblVal[DP_COS_TEST_ME_COS_IN_V] = REPORT_TABLE_VAL_TEXT(QString::number(fCOS_PSUVolt, 'f',2));
            strLogData.sprintf("%.2f\t",fCOS_PSUVolt);
            qsDisp.append(strLogData);
        }
        qDebug() << "COS PSU Voltage:" << fCOS_PSUVolt;

        iResult =  m_p1105Wrapper->ReadRecentSample(AI_COS_V, 1, &fCOS_RLVolt, 1);
        if(iResult)
        {
            emit Sig_PrintLog("Unable to read COS Load voltage", MSGTYPE_ERROR);
            break;
        }

        if((((fCOS_RLVolt > TEST_COSPSU_OFF_MAX)||(fCOS_RLVolt < TEST_COSPSU_OFF_MIN)) && (ucDIOEnDis == 1)) ||\
                (((fCOS_RLVolt > TEST_COSPSU_ON_MAX)||(fCOS_RLVolt < TEST_COSPSU_ON_MIN)) && (ucDIOEnDis == 0)))
        {
            qsResTblVal[DP_COS_TEST_ME_COS_OUT_V] = REPORT_TABLE_VAL_TEXT(QString::number(fCOS_RLVolt, 'f',2));
            strLogData.sprintf("%.2f\t",fCOS_RLVolt);
            qsDisp.append(strLogData);
            iResult = LINS_TEST_FAIL;
            bResult = false;
        }
        else
        {
            qsResTblVal[DP_COS_TEST_ME_COS_OUT_V] = REPORT_TABLE_VAL_TEXT(QString::number(fCOS_RLVolt, 'f',2));
            strLogData.sprintf("%.2f\t",fCOS_RLVolt);
            qsDisp.append(strLogData);
        }
        qDebug() << "COS PSU ADC Voltage:" << fCOS_RLVolt;

//        iResult = m_p3096Wrapper->SetOutput(DO_PS1_C1_PWR, DIO_DISABLE);
//        if(iResult)
//        {
//            emit Sig_PrintLog("Unable to set relay status", MSGTYPE_ERROR);
////            break;
//        }
        msleep(DP_DIO_RESTTIME);

        qsResTblVal[DP_COS_TEST_RES] = bResult?REPORT_RESULT_PASS:REPORT_RESULT_FAIL;
        qsDisp.append(bResult?"PASS":"FAIL");

        strTemp += "<tr>"+qsResTblVal[DP_COS_TEST_RL_EXP_STS] \
                +qsResTblVal[DP_COS_TEST_RL_OBS_STS] \
                +qsResTblVal[DP_COS_TEST_LED_EXP_STS] \
                +qsResTblVal[DP_COS_TEST_LED_OBS_STS] \
                +qsResTblVal[DP_COS_TEST_ME_COS_IN_V] \
                +REPORT_TABLE_TXT_FIXED((iTestItrr == 1)?"28&#177;2.00V":"0&#177;2.00V") \
                +qsResTblVal[DP_COS_TEST_ME_COS_OUT_V] \
                +qsResTblVal[DP_COS_TEST_RES] \
                +"</tr>\n";

        bResult = true;

//        qsDisp.sprintf("T3B1-RL1:  %s     %s    %s    %s", qsResTblVal[DP_COS_TEST_RL_OBS_STS].toLatin1().data(), qsResTblVal[DP_COS_TEST_ME_COS_IN_V].toLatin1().data(), qsResTblVal[DP_COS_TEST_ME_COS_OUT_V].toLatin1().data(), qsResTblVal[DP_COS_TEST_RES].toLatin1().data());
        Sig_PrintLog(qsDisp, MSGTYPE_INFO);
    }

    if(iResult != 0)
    {
        emit Sig_PrintLog("COS Power Test FAIL", MSGTYPE_ERROR);
    }
    else
    {
        emit Sig_PrintLog("COS Power Test PASS", MSGTYPE_SUCCESS);
    }

    qsTableContents = strTemp+"</table>\n";

    PSU_TestReport(qsTestName,qsReportFile,qsTableContents);

    *out_piStatus = iResult;
}

void CTestThread::DP_LINS_WDTAlarmTest(int *out_piStatus)
{
    bool bCOSSts;
    QString qsTestName, qsReportFile, qsTableContents, qsResult[3];
    int iRetVal = 0;

    bCOSSts = COSPowerON();
    if(!bCOSSts)
    {
        emit Sig_PrintLog("Failed to Power ON COS", Failure);
        //            break;
    }

    bool bResult = true;
    m_iCountIndex += 1;
    Sig_PrintLog("WDT and Alarm Test Started", MSGTYPE_INFO);

    qsTestName = "WDT and Alarm Test";

    QDir dir(DP_LINS_MANUAL_REPORT_DIR);
    if(!dir.exists())
    {
        dir.mkpath(DP_LINS_MANUAL_REPORT_DIR);
    }
    qsReportFile.clear();
    qsReportFile.append(DP_LINS_MANUAL_REPORT_DIR+"/");
    qsReportFile.append(QDateTime::currentDateTime().toString("yyyy-MM-dd_HH-mm-ss"));
    qsReportFile.append("_A8399-300_"+QString(m_SReportInfo.carrSerNo)+"_WDT_and_Alarm_Test");
    qsReportFile.append(".html");

    iRetVal = m_p3096Wrapper->SetOutput(DO_BUZZER_DISABLE, 1);
    msleep(DP_CPCI_3096_SET_OP_DELAY);
    qsTableContents =("<tr><th style=\"background-color:#ededed\">Condition</th><th style=\"background-color:#ededed\">Expected LED Status</th><th style=\"background-color:#ededed\">Observed LED Status<br>(from user)</th><th style=\"background-color:#ededed\">Buzzer Enabled Status</th><th style=\"background-color:#ededed\">Expected Buzzer Tone</th><th style=\"background-color:#ededed\">Observed Buzzer Tone<br>(from user)</th><th style=\"background-color:#ededed\">Result</th></tr>\n");

    emit Sig_MsgBox("Monitor WD/SUR LED for color change", MSGTYPE_INFO);

    emit Sig_StopWDTReset();
    sleep(1);
    emit Sig_DisableSurveillance();

    emit Sig_GetUserInput(2, "Did WD/SUR LED glown in Red color for configured time,\nafter that glows in Amber colour continuously?");

    if(m_iBuzzerRing)
    {
        qsResult[0] = REPORT_TABLE_VAL_TEXT("As Expected");
    }
    else
    {
        qsResult[0] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }

    emit Sig_GetUserInput(2, "Are you hearing buzzer tone continuously?");

    emit Sig_StartWDTReset();

    if(m_iBuzzerRing)
    {
        qsResult[1] = REPORT_TABLE_VAL_TEXT("As Expected");
    }
    else
    {
        qsResult[1] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }

    if(bResult)
    {
        qsResult[2] = REPORT_RESULT_PASS;
    }
    else
    {
        qsResult[2] = REPORT_RESULT_FAIL;
    }
    qsTableContents += ("<tr><th style=\"background-color:#ededed\">Watch dog error and<br>Surveillance error</th><td style=\"background-color:#ededed\">Red (for configured time) & Red + Green (Amber) for rest</td>"+qsResult[0]+"<td style=\"background-color:#ededed\">Enabled</td><td style=\"background-color:#ededed\">Tone 1 continuous</td>"+qsResult[1]+qsResult[2]+"</tr>\n");
    bResult = true;

    sleep(2);

    emit Sig_GetUserInput(2, "Does WD/SUR LED glowing in Green colour?");

    if(m_iBuzzerRing)
    {
        qsResult[0] = REPORT_TABLE_VAL_TEXT("As Expected");
    }
    else
    {
        qsResult[0] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }

    emit Sig_GetUserInput(2, "Are you hearing any buzzer tone?");

    if(m_iBuzzerRing)
    {
        qsResult[1] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }
    else
    {
        qsResult[1] = REPORT_TABLE_VAL_TEXT("As Expected");
    }

    if(bResult)
    {
        qsResult[2] = REPORT_RESULT_PASS;
    }
    else
    {
        qsResult[2] = REPORT_RESULT_FAIL;
    }
    bResult = true;

    qsTableContents += ("<tr><th style=\"background-color:#ededed\">Surveillance OK,<br>Watch dog OK</th><td style=\"background-color:#ededed\">Green</td>"+qsResult[0]+"<td style=\"background-color:#ededed\">Enabled</td><td style=\"background-color:#ededed\">No tone</td>"+qsResult[1]+qsResult[2]+"</tr>\n");

    emit Sig_DisableSurveillance();
    sleep(1);

    emit Sig_GetUserInput(2, "Did WD/SUR LED glown in Red colour for configured time?");

    if(m_iBuzzerRing)
    {
        qsResult[0] = REPORT_TABLE_VAL_TEXT("As Expected");
    }
    else
    {
        qsResult[0] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }

    emit Sig_GetUserInput(2, "Did you heard buzzer tone for configured time?");

    if(m_iBuzzerRing)
    {
        qsResult[1] = REPORT_TABLE_VAL_TEXT("As Expected");
    }
    else
    {
        qsResult[1] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }

    if(bResult)
    {
        qsResult[2] = REPORT_RESULT_PASS;
    }
    else
    {
        qsResult[2] = REPORT_RESULT_FAIL;
    }
    bResult = true;
    qsTableContents += ("<tr><th style=\"background-color:#ededed\">Surveillance error,<br>Watch dog OK</th><td style=\"background-color:#ededed\">Red (for configured time)</td>"+qsResult[0]+"<td style=\"background-color:#ededed\">Enabled</td><td style=\"background-color:#ededed\">Tone 1 beep (for configured time)</td>"+qsResult[1]+qsResult[2]+"</tr>\n");

    emit Sig_StopWDTReset();
    sleep(1);
    emit Sig_GetUserInput(2, "Does WD/SUR LED glowing in Amber colour?");

    if(m_iBuzzerRing)
    {
        qsResult[0] = REPORT_TABLE_VAL_TEXT("As Expected");
    }
    else
    {
        qsResult[0] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }

    emit Sig_GetUserInput(2, "Are you hearing buzzer tone continuously?");

    if(m_iBuzzerRing)
    {
        qsResult[1] = REPORT_TABLE_VAL_TEXT("As Expected");
    }
    else
    {
        qsResult[1] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }

    if(bResult)
    {
        qsResult[2] = REPORT_RESULT_PASS;
    }
    else
    {
        qsResult[2] = REPORT_RESULT_FAIL;
    }
    bResult = true;
    qsTableContents += ("<tr><th style=\"background-color:#ededed\">Surveillance OK,<br>Watch dog error</th><td style=\"background-color:#ededed\">Red + Green (Amber)</td>"+qsResult[0]+"<td style=\"background-color:#ededed\">Enabled</td><td style=\"background-color:#ededed\">Tone 1 continuous</td>"+qsResult[1]+qsResult[2]+"</tr>\n");

    emit Sig_StartWDTReset();
    sleep(3);
    iRetVal = m_p3096Wrapper->SetOutput(DO_BUZZER_DISABLE, 0);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to set relay status", Failure);
        //                break;
    }

    emit Sig_MsgBox("Monitor WD/SUR LED for color change", MSGTYPE_INFO);

    emit Sig_StopWDTReset();
    sleep(1);
    emit Sig_DisableSurveillance();

    emit Sig_GetUserInput(2, "Did WD/SUR LED glown in Red color for configured time,\nafter that glows in Amber colour continuously?");

    if(m_iBuzzerRing)
    {
        qsResult[0] = REPORT_TABLE_VAL_TEXT("As Expected");
    }
    else
    {
        qsResult[0] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }

    emit Sig_GetUserInput(2, "Are you hearing any buzzer tone?");

    if(m_iBuzzerRing)
    {
        qsResult[1] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }
    else
    {
        qsResult[1] = REPORT_TABLE_VAL_TEXT("As Expected");
    }

    emit Sig_StartWDTReset();

    if(bResult)
    {
        qsResult[2] = REPORT_RESULT_PASS;
    }
    else
    {
        qsResult[2] = REPORT_RESULT_FAIL;
    }
    qsTableContents += ("<tr><th style=\"background-color:#ededed\">Watch dog error and<br>Surveillance error</th><td style=\"background-color:#ededed\">Red (for configured time) & Red + Green (Amber) for rest</td>"+qsResult[0]+"<td style=\"background-color:#ededed\">Disabled</td><td style=\"background-color:#ededed\">No tone</td>"+qsResult[1]+qsResult[2]+"</tr>\n");
    bResult = true;

    sleep(2);

    emit Sig_GetUserInput(2, "Does WD/SUR LED glowing in Green colour?");

    if(m_iBuzzerRing)
    {
        qsResult[0] = REPORT_TABLE_VAL_TEXT("As Expected");
    }
    else
    {
        qsResult[0] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }

    emit Sig_GetUserInput(2, "Are you hearing any buzzer tone?");

    if(m_iBuzzerRing)
    {
        qsResult[1] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }
    else
    {
        qsResult[1] = REPORT_TABLE_VAL_TEXT("As Expected");
    }

    if(bResult)
    {
        qsResult[2] = REPORT_RESULT_PASS;
    }
    else
    {
        qsResult[2] = REPORT_RESULT_FAIL;
    }
    bResult = true;

    qsTableContents += ("<tr><th style=\"background-color:#ededed\">Surveillance OK,<br>Watch dog OK</th><td style=\"background-color:#ededed\">Green</td>"+qsResult[0]+"<td style=\"background-color:#ededed\">Disabled</td><td style=\"background-color:#ededed\">No tone</td>"+qsResult[1]+qsResult[2]+"</tr>\n");

    emit Sig_DisableSurveillance();
    sleep(1);

    emit Sig_GetUserInput(2, "Did WD/SUR LED glowing in Red colour for configured time?");

    if(m_iBuzzerRing)
    {
        qsResult[0] = REPORT_TABLE_VAL_TEXT("As Expected");
    }
    else
    {
        qsResult[0] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }

    emit Sig_GetUserInput(2, "Are you hearing any buzzer tone?");

    if(m_iBuzzerRing)
    {
        qsResult[1] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }
    else
    {
        qsResult[1] = REPORT_TABLE_VAL_TEXT("As Expected");
    }

    if(bResult)
    {
        qsResult[2] = REPORT_RESULT_PASS;
    }
    else
    {
        qsResult[2] = REPORT_RESULT_FAIL;
    }
    bResult = true;
    qsTableContents += ("<tr><th style=\"background-color:#ededed\">Surveillance error,<br>Watch dog OK</th><td style=\"background-color:#ededed\">Red (for configured time)</td>"+qsResult[0]+"<td style=\"background-color:#ededed\">Disabled</td><td style=\"background-color:#ededed\">No tone</td>"+qsResult[1]+qsResult[2]+"</tr>\n");

    emit Sig_StopWDTReset();
    sleep(1);
    emit Sig_GetUserInput(2, "Does WD/SUR LED glowing in Amber colour?");

    if(m_iBuzzerRing)
    {
        qsResult[0] = REPORT_TABLE_VAL_TEXT("As Expected");
    }
    else
    {
        qsResult[0] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }

    emit Sig_GetUserInput(2, "Are you hearing any buzzer tone?");

    if(m_iBuzzerRing)
    {
        qsResult[1] = REPORT_TEXT_FAIL("Not as Expected");
        bResult = false;
    }
    else
    {
        qsResult[1] = REPORT_TABLE_VAL_TEXT("As Expected");
    }

    if(bResult)
    {
        qsResult[2] = REPORT_RESULT_PASS;
    }
    else
    {
        qsResult[2] = REPORT_RESULT_FAIL;
    }
    bResult = true;

    qsTableContents += ("<tr><th style=\"background-color:#ededed\">Surveillance OK,<br>Watch dog error</th><td style=\"background-color:#ededed\">Red + Green (Amber)</td>"+qsResult[0]+"<td style=\"background-color:#ededed\">Disabled</td><td style=\"background-color:#ededed\">No tone</td>"+qsResult[1]+qsResult[2]+"</tr>\n");
    qsTableContents += "</table>\n<b>Note: Configured time for Surveillance: 1.5sec</b>";

    PSU_TestReport(qsTestName,qsReportFile,qsTableContents);

    Sig_PrintLog("WDT and Alarm Test Completed", MSGTYPE_INFO);
    Sig_PrintLog("======================================================",MSGTYPE_INFO);
    Sig_PrintLog("",MSGTYPE_INFO);

    COSPowerOFF();
}

void CTestThread::PSU_TestReport(QString qsTestName, QString qsReportFile, QString qsTable)
{
    QString Str;
    QString qsRetVal,qRep,qIndex,m_qHeader,css,qsTbl;
    QString header = "<article><div align=\"right\"><b>&#9733;Restricted &#169;Data Patterns (India) Limited</b></div><br><br><header><h1><center><font color=\"midnightblue\"> LINS-CM CHECKOUT ATP TEST REPORT</font></center></h1>\n";
    QString qHearder1 = "<html><img src= \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJoAAAAxCAMAAAAV+kAIAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAAwBQTFRFAAAAgAAAAIAAgIAAAACAgACAAICAwMDAwNzApsrwAAAAWRQRioqKk5OTnZ2dsikjtjYwurq6u0M+v7+/wFFMxMTExV5aymtnznl1zs7O04aD2JSR3aGe4eHh4q6s5ry668nI6+vr8NbV9eTj9fX1+vHx////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vwoKCkgICA/wAAAP8A//8AAAD//wD/AP//////7elzQQAAAylJREFUWEftWF2PozAM7Ps9JOKqFDUIokTx//+JN7YD/UjKdrurip6I1C6YSRiPx2HLgTY7Dm1mHJZL88HNSTv6BGRlYs1jp7ZahBV5GjXdckEP7xyP/f5hqu0duuwmDyrXCr/Tav9Ph+5eW/eab40/CPJHvqqTdvQG/+2JFYvxQGajw+3UXqjMR6mmduyPc57O81EfyuCTTkI6egY7RSv0NEO7+aAXlPcOMzFOrgPMn3WBzuPMAnDm6NWoVSNKfgr4dgqLdGIGo0fMD4FDI/XLEoiO+DDGBPnjgh8FaoP3RMGHHldywqFxjI6UrDGAaD7chxNNPqSvqfHtj5kU2WExnYLb6IHNuMk8QMvYJBhLNGkYDMr1QiCUGbjgzFGWxJ4uCTI1x5ftVS3kQtWhnJyuLjPPRPmOWo9VF/GZGkThPAAlyPElNbDCLQDO7AOm5uf0l4zXqJmkEkSIpeVbVAtDLsVAVPSIQj8BoQZaV+0kMJoyZWSi1GjUpK7GQ9WKEi6Bo5Z2ptZRN5ZQoQYZB9jxAm1QS+x/toezkaIkAorRCjWUmPJwR66mNttCKmXCmeskJp+pDRMvJSGhhpHYJvECbVDLaFfWiof2jDdIKVppA/bIlYFV+sprM7XI0CMNfiiTQI2b1ubJ+0sjzHBkX0GlsmLuBQV9S1+BmuFjoWY6mOSq71epQXoUaUxIFm0vG5FS85x/XBphuSmg4x20Sc2BDy/H1LANUZz7Pl0MvK6ap9xBIdmoNE+lZjMviX2ibClBjMObTAXVqfeqndE0vAcINRyLb7hV/ZOqwWDoy14zgmywqFLzJDs/LKauVUtybSroDbXoHD8zmCr4wnVKDT3BbSBcuV+vRstrYlV5GKRJoCCFdYSazbrLgbrukIUaHHgP5fOLaupz9A+m4dnQGVEfamdQO+UcYlqejcqvpuYM8isPqZssfnJy5DXLk7a1jm3c8qP+8/iJOL86d9uqbfhnS+O3++Vl5P5W8qE8jQv7q7/y0qcpmr7mrseWVQPb/eV80aBduQ8r6P5W8pV3uXsbvKDaX6jGH/mqTtrRG/y3Jz7doe2N+L3RfwKm4XY9Nn4DAAAAAElFTkSuQmCC\" alt=\"DataPatterns Logo\" style=\"float:left\"/>";

    //qIndex += "<font color=\"darkblue\"><span style =font-size:18pt;>Unit S.No : <font color=\"black\">"+ m_qUnitNo + "</span></font><br>" ;
    //qIndex += "<font color=\"darkblue\"><span style =font-size:18pt;>Tested By : <font color=\"black\">"+ m_qTestedBy + "</span></font><br>" ;
    qIndex += "<font color=\"darkblue\"><span style =font-size:18pt;>Tested on : <font color=\"black\">"+ QDateTime::currentDateTime().toString("dd-MMM-yyyy HH:mm:ss") + "</span></font>\n" ;


    QFile qHtmlFile(qsReportFile);

    m_qHeader = "<br><h2><font color=\"dimgray\">"+qsTestName+" (Time: "+ QDateTime::currentDateTime().toString("dd-MMM-yyyy HH:mm") +")</font></h2></header></article>\n<table border=\"1\" style=\"background-color:ghostwhite;border:1px dotted black;width:80%;border-collapse:collapse;\"><tr style=\"background-color:gainsboro;color:black;\"></table>\n";

    qsTbl += "<table width=\"100%\" cellspacing=\"0\" class=\"tbl1\">";

    Str.append("<br>\n<table style = \"border: none; width: 35%;\">\n");

    Str.append(REPORT_TABLEROW_START);
    Str.append("<th style = \"border: none; text-align:left;\">ATE Part No.</th><th style = \"border: none; text-align:center;\">:</th><td style = \"border: none; text-align:left;\">"+QString(m_SReportInfo.carrPartNumber)+"</td>\n");
    Str.append(REPORT_TABLEROW_END);
    Str.append(REPORT_TABLEROW_START);
    Str.append("<th style = \"border: none; text-align:left;\">ATE Serial No.</th><th style = \"border: none; text-align:center;\">:</th><td style = \"border: none; text-align:left;\">"+QString(m_SReportInfo.carrSerNo)+"</td>\n");
    Str.append(REPORT_TABLEROW_END);
    Str.append(REPORT_TABLEROW_START);
    Str.append("<th style = \"border: none; text-align:left;\">ATE Test Location</th><th style = \"border: none; text-align:center;\">:</th><td style = \"border: none; text-align:left;\">"+QString(m_SReportInfo.carrTestLocation)+"</td>\n");
    Str.append(REPORT_TABLEROW_END);
    Str.append(REPORT_TABLEROW_START);
    Str.append("<th style = \"border: none; text-align:left;\">Application Version</th><th style = \"border: none; text-align:center;\">:</th><td style = \"border: none; text-align:left;\">"+QString(m_SReportInfo.carrVersion)+"</td>\n");
    Str.append(REPORT_TABLEROW_END);
    Str.append(REPORT_TABLEROW_START);
    Str.append("<th style = \"border: none; text-align:left;\">Application Checksum</th><th style = \"border: none; text-align:center;\">:</th><td style = \"border: none; text-align:left;\">"+QString(m_SReportInfo.carrChecksum)+"</td>\n");
    Str.append(REPORT_TABLEROW_END);
    Str.append(REPORT_TABLEROW_START);
    Str.append("<th style = \"border: none; text-align:left;\">Tested By</th><th style = \"border: none; text-align:center;\">:</th><td style = \"border: none; text-align:left;\">"+QString(m_SReportInfo.carrUserName)+"</td>");
    Str.append(REPORT_TABLEROW_END);

    Str.append(REPORT_TABLE_END);

    qsRetVal = QString(DP_LOGO)+QString(DP_LINS_HTML_HEADER)+QString(DP_LINS_DOC_HEADER)+Str+m_qHeader+qsTbl+qsTable+"\n</body>\n</html>\n";
    if (qHtmlFile.exists())
    {
        if(qHtmlFile.open(QIODevice::Append))
        {
            qRep = qsRetVal;
            qHtmlFile.write(qRep.toLatin1().data());
            qsRetVal = " ";
        }
        qHtmlFile.close();
    }
    else
    {
        if(qHtmlFile.open(QIODevice::ReadWrite))
        {
            qRep = qsRetVal;
            qHtmlFile.write(qRep.toLatin1().data());
            qsRetVal = " ";
        }
    }
    qHtmlFile.close();
}

void CTestThread::DP_LINS_BypassTest(int *out_piStatus)
{
#if 1
    QString qsRelay[18] = {""}, qsResult[7] = {""}, qsTableRes = "";
    unsigned char ucBSsts = 0;
    int iLoopVar = 0;
    int iRetVal = 0;
    QString qsTableContents = "";
    unsigned short usRelSts[18] = {DI_COS_PWR_STS,DI_TC_PWR_STS,DI_PS1_C1_PWR_STS,DI_PS1_C2_PWR_STS,DI_PS1_DEMAG_PWR_STS,\
                                   DI_PS2_C1_PWR_STS,DI_PS2_C2_PWR_STS,DI_PS2_C3_PWR_STS,\
                                   DI_PS3_C1_PWR_STS,DI_PS3_C2_PWR_STS,DI_PS3_C3_PWR_STS};
    unsigned short usDOsts[18] = {DO_COS_PWR_ON,DO_TC_PWR,DO_PS1_C1_PWR,DO_PS1_C2_PWR,DO_PS1_DEMAG_PWR,\
                                  DO_PS2_C1_PWR,DO_PS2_C2_PWR,DO_PS2_C3_PWR,\
                                  DO_PS3_C1_PWR,DO_PS3_C2_PWR,DO_PS3_C3_PWR};
    bool bReslut1 = true, bReslut2 = true;
    QString qsTestName = "Bypass and Emergency COS OFF Test";
    QString qsReportFile = "";
    float fPSU_Volt = 0.0, fLoadVolt = 0.0;

    QDir dir(DP_LINS_MANUAL_REPORT_DIR);
    if(!dir.exists())
    {
        dir.mkpath(DP_LINS_MANUAL_REPORT_DIR);
    }
    qsReportFile.clear();
    qsReportFile.append(DP_LINS_MANUAL_REPORT_DIR+"/");
    qsReportFile.append(QDateTime::currentDateTime().toString("yyyy-MM-dd_HH-mm-ss"));
    qsReportFile.append("_A8399-300_"+QString(m_SReportInfo.carrSerNo)+"_Bypass_and_Emergency_COS_OFF_Test");
    qsReportFile.append(".html");

        iLoopVar = 11;

    qsRelay[0] = "T3B1-RL1-COS";
    qsRelay[1] = "T3B1-RL2-TELECMD";
    qsRelay[2] = "T1B1-RL4-PSU1OUT1";
    qsRelay[3] = "T1B1-RL3-PSU1OUT2";
    qsRelay[4] = "T1B1-RL2-DEMAG (Spareb 1)";
    qsRelay[5] = "T1B2-RL4-PSU2OUT1";
    qsRelay[6] = "T1B2-RL3-PSU2OUT2";
    qsRelay[7] = "T1B2-RL2-DEMAG (Spare 2)";
    qsRelay[8] = "T1B3-RL4-PSU3OUT1";
    qsRelay[9] = "T1B3-RL3-PSU3OUT2";
    qsRelay[10] = "T1B3-RL2-DEMAG";

    iRetVal = StartStopADCAcquisition(1);
    if(!iRetVal)
        return;

    /*************************COS OFF, Bypass OFF and Emergency Switch OFF (1)*************************/
    COSPowerOFF();

    Sig_PrintLog("Bypass Test Started", MSGTYPE_INFO);
    emit Sig_MsgBox("Kindly ensure that Bypass Switch and Emergency COS Off switch is in OFF condition", MSGTYPE_INFO);
    emit Sig_GetUserInput(2, "Does BY-PASS CONTROL LED glowing?");

    if(!m_iBuzzerRing)
    {
        qsResult[DP_BPECOS_BP_LED_STS] = "OFF";
    }
    else
    {
        qsResult[DP_BPECOS_BP_LED_STS] = "ON";
        bReslut1 = false;
    }
    m_iBuzzerRing = 1;
    emit Sig_GetUserInput(2, "Does Emergency COS OFF switch LED glowing?");

    if(!m_iBuzzerRing)
    {
        qsResult[DP_BPECOS_ECOS_LED_STS] = "OFF";
    }
    else
    {
        qsResult[DP_BPECOS_ECOS_LED_STS] = "ON";
        bReslut1 = false;
    }

    qsTableContents = "<tr><th rowspan = \"2\" style=\"background-color:#ededed\">COS PSU CMD:<br>ON Pulse/OFF</th><th rowspan = \"2\" style=\"background-color:#ededed\">Bypass Switch Position</th><th rowspan = \"2\" style=\"background-color:#ededed\">Emergency Switch Position</th><th colspan = \"2\" style=\"background-color:#ededed\">Bypass Status</th><th colspan = \"2\" style=\"background-color:#ededed\">Bypass Control LED Status</th><th colspan = \"2\" style=\"background-color:#ededed\">Emergency COS-OFF LED Status<br>(Momentary)</th><th rowspan = \"2\" style=\"background-color:#ededed\">Measured COS PSU Voltage(ADC) (V) PSU_V-MON<br>Tol: 28&#177;"+QString::number(DP_TOL_COS_ADC_OUT_VOLT, 'f', 2)+"V</th><th colspan = \"2\" style=\"background-color:#ededed\">COS Output Voltage(ADC) (V) COS_SW_V-MON</th><th rowspan = \"2\" style=\"background-color:#ededed\">Relay Number</th><th colspan = \"2\" style=\"background-color:#ededed\">Relay Status</th><th rowspan = \"2\" style=\"background-color:#ededed\">Result</th></tr><tr><th style=\"background-color:#ededed\">Expected</th><th style=\"background-color:#ededed\">Observed</th><th style=\"background-color:#ededed\">Expected</th><th style=\"background-color:#ededed\">Observed</th><th style=\"background-color:#ededed\">Expected</th><th style=\"background-color:#ededed\">Observed</th><th style=\"background-color:#ededed\">Expected</th><th style=\"background-color:#ededed\">Measured</th><th style=\"background-color:#ededed\">Expected</th><th style=\"background-color:#ededed\">Observed</th></tr>\n";

    iRetVal = m_p3096Wrapper->ReadInput(DI_BYPASS_SWITCH_STS, &ucBSsts);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Bypass Switch status",Failure);
        StartStopADCAcquisition(0);
        return;
    }

    if(ucBSsts)
    {
        qsResult[DP_BPECOS_BP_STS] = "HIGH";
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_BP_STS] = "LOW";
    }

    /**********Read Voltage on COS PSU and load ****************************************/
    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_PS_COS_V, 1, &fPSU_Volt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read PSU Voltage", Failure);
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fPSU_Volt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fPSU_Volt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
    }

    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_COS_V, 1, &fLoadVolt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Load Voltage", Failure);
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fLoadVolt >= (0.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fLoadVolt <= (0.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
    }

    qsTableContents += "<tr><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF (Default Position)</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF (Default Position)</th><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">LOW</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ECOS_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_COS_V]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">0&#177;"+QString::number(DP_TOL_COS_ADC_OUT_VOLT, 'f', 2)+"V</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ME_COS_V]+"</td>";

    for(int iRelLop = 0; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->ReadInput(usRelSts[iRelLop], &ucBSsts);
        if(iRetVal)
        {
            Sig_PrintLog("Unable to read Bypass Switch status",Failure);
            StartStopADCAcquisition(0);
            break;
        }

        if(ucBSsts)
        {
            qsResult[DP_BPECOS_RLY_STS] = "OFF";
        }
        else
        {
            qsResult[DP_BPECOS_RLY_STS] = "ON";
            bReslut2 = false;
        }

        if(bReslut1 && bReslut2)
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_PASS;
        }
        else
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_FAIL;
        }
        qsResult[DP_BPECOS_RES].remove("<td>");
        qsResult[DP_BPECOS_RES].remove("</td>\n");


        qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">OFF</td><td>"+qsResult[DP_BPECOS_RLY_STS]+"</td><td>"+qsResult[DP_BPECOS_RES]+"</td></tr>\n<tr>";
        bReslut2 = true;
    }
    qsTableRes.chop(4);
    qsTableContents += qsTableRes;
    bReslut1 = true;

    sleep(4);
    /*************************COS ON, Bypass OFF and Emergency Switch OFF (2)*************************/
    //            emit Sig_MsgBox("Kindly ensure that Bypass Switch and Emergency COS Off switch is in OFF condition", MSGTYPE_INFO);

    COSPowerON();

    iRetVal = m_p3096Wrapper->ReadInput(DI_BYPASS_SWITCH_STS, &ucBSsts);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Bypass Switch status",Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(ucBSsts)
    {
        qsResult[DP_BPECOS_BP_STS] = "HIGH";
    }
    else
    {
        qsResult[DP_BPECOS_BP_STS] = "LOW";
        bReslut1 = false;
    }

    for(int iRelLop = 1; iRelLop < iLoopVar; iRelLop++)
    {
        if(iRelLop%2 == 0)
            iRetVal = m_p3096Wrapper->SetOutput(usDOsts[iRelLop], 1);
        else
            iRetVal = m_p3096Wrapper->SetOutput(usDOsts[iRelLop], 0);
    }

    sleep(2);

    /**********Read Voltage on COS PSU and load ****************************************/
    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_PS_COS_V, 1, &fPSU_Volt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read PSU Voltage", Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fPSU_Volt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fPSU_Volt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
    }

    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_COS_V, 1, &fLoadVolt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Load Voltage", Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fLoadVolt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fLoadVolt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
    }

    qsTableContents += "<tr><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON Pulse</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF (Default Position)</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF (Default Position)</th><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">HIGH</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ECOS_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_COS_V]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">28&#177;"+QString::number(DP_TOL_COS_ADC_OUT_VOLT, 'f', 2)+"V</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ME_COS_V]+"</td>";
    qsTableRes = "";

    for(int iRelLop = 0; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->ReadInput(usRelSts[iRelLop], &ucBSsts);
        if(iRetVal)
        {
            Sig_PrintLog("Unable to read Bypass Switch status",Failure);
            COSPowerOFF();
            StartStopADCAcquisition(0);
            return;
        }

        if(iRelLop%2 == 0)
        {
            if(ucBSsts)
            {
                qsResult[DP_BPECOS_RLY_STS] = "OFF";
                bReslut2 = false;
            }
            else
            {
                qsResult[DP_BPECOS_RLY_STS] = "ON";
            }
        }
        else
        {
            if(ucBSsts)
            {
                qsResult[DP_BPECOS_RLY_STS] = "OFF";
            }
            else
            {
                qsResult[DP_BPECOS_RLY_STS] = "ON";
                bReslut2 = false;
            }
        }

        if(bReslut1 && bReslut2)
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_PASS;
        }
        else
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_FAIL;
        }
        qsResult[DP_BPECOS_RES].remove("<td>");
        qsResult[DP_BPECOS_RES].remove("</td>\n");

        if(iRelLop%2 == 0)
        {
            qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">ON</td><td>"+qsResult[DP_BPECOS_RLY_STS]+"</td><td>"+qsResult[DP_BPECOS_RES]+"</td></tr>\n<tr>";
        }
        else
        {
            qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">OFF</td><td>"+qsResult[DP_BPECOS_RLY_STS]+"</td><td>"+qsResult[DP_BPECOS_RES]+"</td></tr>\n<tr>";
        }
        bReslut2 = true;
    }
    qsTableRes.chop(4);
    qsTableContents += qsTableRes;
    bReslut1 = true;

    sleep(2);

    /*************************COS ON, Bypass OFF and Emergency Switch ON (3)*************************/
    //            emit Sig_MsgBox("Kindly ensure that Bypass Switch is in OFF condition", MSGTYPE_INFO);

    COSPowerON();

    emit Sig_GetUserInput(2, "Press Emergency COS Off switch and click \"<b>Yes</b>\" if LED in Emergency COS Off switch glown only for momentary else click \"<b>No</b>\".");
    if(m_iBuzzerRing)
    {
        qsResult[DP_BPECOS_ECOS_LED_STS] = "ON";
    }
    else
    {
        qsResult[DP_BPECOS_ECOS_LED_STS] = "OFF";
        bReslut1 = false;
    }

    iRetVal = m_p3096Wrapper->ReadInput(DI_BYPASS_SWITCH_STS, &ucBSsts);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Bypass Switch status",Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(ucBSsts)
    {
        qsResult[DP_BPECOS_BP_STS] = "HIGH";
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_BP_STS] = "LOW";
    }

    for(int iRelLop = 1; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->SetOutput(usDOsts[iRelLop], 1);
    }

    sleep(2);

    /**********Read Voltage on COS PSU and load ****************************************/
    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_PS_COS_V, 1, &fPSU_Volt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read PSU Voltage", Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fPSU_Volt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fPSU_Volt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
    }

    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_COS_V, 1, &fLoadVolt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Load Voltage", Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fLoadVolt >= (0.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fLoadVolt <= (0.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
    }

    qsTableContents += "<tr><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON Pulse</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF (Default Position)</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON (Momentary)</th><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">LOW</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ECOS_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_COS_V]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">0&#177;"+QString::number(DP_TOL_COS_ADC_OUT_VOLT, 'f', 2)+"V</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ME_COS_V]+"</td>";
    qsTableRes = "";

    for(int iRelLop = 0; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->ReadInput(usRelSts[iRelLop], &ucBSsts);
        if(iRetVal)
        {
            Sig_PrintLog("Unable to read Bypass Switch status",Failure);
            COSPowerOFF();
            StartStopADCAcquisition(0);
            return;
        }

        if(ucBSsts)
        {
            qsResult[DP_BPECOS_RLY_STS] = "OFF";
        }
        else
        {
            qsResult[DP_BPECOS_RLY_STS] = "ON";
            bReslut2 = false;
        }

        if(bReslut1 && bReslut2)
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_PASS;
        }
        else
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_FAIL;
        }
        qsResult[DP_BPECOS_RES].remove("<td>");
        qsResult[DP_BPECOS_RES].remove("</td>\n");

        qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">OFF</td><td>"+qsResult[DP_BPECOS_RLY_STS]+"</td><td>"+qsResult[DP_BPECOS_RES]+"</td></tr>\n<tr>";
        bReslut2 = true;
    }
    qsTableRes.chop(4);
    qsTableContents += qsTableRes;
    bReslut1 = true;

    sleep(2);

    /*************************COS OFF, Bypass OFF and Emergency Switch ON (4)*************************/
    //            emit Sig_MsgBox("Kindly ensure that Bypass Switch is in OFF condition", MSGTYPE_INFO);

    COSPowerOFF();

    emit Sig_GetUserInput(2, "Press Emergency COS Off switch and click \"<b>Yes</b>\" if LED in Emergency COS Off switch glown only for momentary else click \"<b>No</b>\".");
    if(m_iBuzzerRing)
    {
        qsResult[DP_BPECOS_ECOS_LED_STS] = "ON";
    }
    else
    {
        qsResult[DP_BPECOS_ECOS_LED_STS] = "OFF";
        bReslut1 = false;
    }

    iRetVal = m_p3096Wrapper->ReadInput(DI_BYPASS_SWITCH_STS, &ucBSsts);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Bypass Switch status",Failure);
        StartStopADCAcquisition(0);
        return;
    }

    if(ucBSsts)
    {
        qsResult[DP_BPECOS_BP_STS] = "HIGH";
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_BP_STS] = "LOW";
    }

    for(int iRelLop = 1; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->SetOutput(usDOsts[iRelLop], 1);
    }

    sleep(2);

    /**********Read Voltage on COS PSU and load ****************************************/
    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_PS_COS_V, 1, &fPSU_Volt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read PSU Voltage", Failure);
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fPSU_Volt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fPSU_Volt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
    }

    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_COS_V, 1, &fLoadVolt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Load Voltage", Failure);
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fLoadVolt >= (0.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fLoadVolt <= (0.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
    }

    qsTableContents += "<tr><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF (Default Position)</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON (Momentary)</th><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">LOW</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ECOS_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_COS_V]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">0&#177;"+QString::number(DP_TOL_COS_ADC_OUT_VOLT, 'f', 2)+"V</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ME_COS_V]+"</td>";
    qsTableRes = "";

    for(int iRelLop = 0; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->ReadInput(usRelSts[iRelLop], &ucBSsts);
        if(iRetVal)
        {
            Sig_PrintLog("Unable to read Bypass Switch status",Failure);
            StartStopADCAcquisition(0);
            return;
        }

        if(ucBSsts)
        {
            qsResult[DP_BPECOS_RLY_STS] = "OFF";
        }
        else
        {
            qsResult[DP_BPECOS_RLY_STS] = "ON";
            bReslut2 = false;
        }

        if(bReslut1 && bReslut2)
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_PASS;
        }
        else
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_FAIL;
        }
        qsResult[DP_BPECOS_RES].remove("<td>");
        qsResult[DP_BPECOS_RES].remove("</td>\n");

        qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">OFF</td><td>"+qsResult[DP_BPECOS_RLY_STS]+"</td><td>"+qsResult[DP_BPECOS_RES]+"</td></tr>\n<tr>";
        bReslut2 = true;
    }
    qsTableRes.chop(4);
    qsTableContents += qsTableRes;
    bReslut1 = true;

    sleep(2);

#if 1
    /*************************COS OFF, Bypass ON and Emergency Switch ON (5)*************************/
    emit Sig_MsgBox("Kindly ensure that Bypass Switch is in ON condition", MSGTYPE_INFO);
    emit Sig_GetUserInput(2, "Does BY-PASS CONTROL LED glowing?");

    if(m_iBuzzerRing)
    {
        qsResult[DP_BPECOS_BP_LED_STS] = "ON";
    }
    else
    {
        qsResult[DP_BPECOS_BP_LED_STS] = "OFF";
        bReslut1 = false;
    }
    COSPowerOFF();

    emit Sig_GetUserInput(2, "Press Emergency COS Off switch and click \"<b>Yes</b>\" if LED in Emergency COS Off switch glown only for momentary else click \"<b>No</b>\".");
    if(m_iBuzzerRing)
    {
        qsResult[DP_BPECOS_ECOS_LED_STS] = "ON";
    }
    else
    {
        qsResult[DP_BPECOS_ECOS_LED_STS] = "OFF";
        bReslut1 = false;
    }

    iRetVal = m_p3096Wrapper->ReadInput(DI_BYPASS_SWITCH_STS, &ucBSsts);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Bypass Switch status",Failure);
        StartStopADCAcquisition(0);
        return;
    }

    if(ucBSsts)
    {
        qsResult[DP_BPECOS_BP_STS] = "HIGH";
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_BP_STS] = "LOW";
    }

    for(int iRelLop = 1; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->SetOutput(usDOsts[iRelLop], 1);
    }

    sleep(2);

    /**********Read Voltage on COS PSU and load ****************************************/
    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_PS_COS_V, 1, &fPSU_Volt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read PSU Voltage", Failure);
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fPSU_Volt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fPSU_Volt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
    }

    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_COS_V, 1, &fLoadVolt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Load Voltage", Failure);
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fLoadVolt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fLoadVolt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
    }

    qsTableContents += "<tr><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON (Momentary)</th><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">LOW</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ECOS_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_COS_V]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">28&#177;"+QString::number(DP_TOL_COS_ADC_OUT_VOLT, 'f', 2)+"V</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ME_COS_V]+"</td>";
    qsTableRes = "";

    for(int iRelLop = 0; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->ReadInput(usRelSts[iRelLop], &ucBSsts);
        if(iRetVal)
        {
            Sig_PrintLog("Unable to read Bypass Switch status",Failure);
            StartStopADCAcquisition(0);
            return;
        }

        if(iRelLop == 0)
        {
            if(ucBSsts)
            {
                qsResult[DP_BPECOS_RLY_STS] = "OFF";
            }
            else
            {
                qsResult[DP_BPECOS_RLY_STS] = "ON";
                bReslut2 = false;
            }
            qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">OFF</td><td>"+qsResult[DP_BPECOS_RLY_STS];
        }
        else
        {
            if(ucBSsts)
            {
                qsResult[DP_BPECOS_RLY_STS] = "OFF";
                bReslut2 = false;
            }
            else
            {
                qsResult[DP_BPECOS_RLY_STS] = "ON";
            }
            qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">ON</td><td>"+qsResult[DP_BPECOS_RLY_STS];
        }

        if(bReslut1 && bReslut2)
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_PASS;
        }
        else
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_FAIL;
        }
        qsResult[DP_BPECOS_RES].remove("<td>");
        qsResult[DP_BPECOS_RES].remove("</td>\n");

        qsTableRes += "</td><td>"+qsResult[DP_BPECOS_RES]+"</td></tr>\n<tr>";
        bReslut2 = true;
    }
    qsTableRes.chop(4);
    qsTableContents += qsTableRes;
    bReslut1 = true;

    sleep(2);

    /*************************COS ON, Bypass ON and Emergency Switch ON (6)*************************/
    //            emit Sig_MsgBox("Kindly ensure that Bypass Switch is in ON condition", MSGTYPE_INFO);

    COSPowerON();

    emit Sig_GetUserInput(2, "Press Emergency COS Off switch and click \"<b>Yes</b>\" if LED in Emergency COS Off switch glown only for momentary else click \"<b>No</b>\".");
    if(m_iBuzzerRing)
    {
        qsResult[DP_BPECOS_ECOS_LED_STS] = "ON";
    }
    else
    {
        qsResult[DP_BPECOS_ECOS_LED_STS] = "OFF";
        bReslut1 = false;
    }

    iRetVal = m_p3096Wrapper->ReadInput(DI_BYPASS_SWITCH_STS, &ucBSsts);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Bypass Switch status",Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(ucBSsts)
    {
        qsResult[DP_BPECOS_BP_STS] = "HIGH";
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_BP_STS] = "LOW";
    }

    for(int iRelLop = 1; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->SetOutput(usDOsts[iRelLop], 1);
        //                if(iRetVal)
        //                {
        //                    qDebug() << "Failed to set realy:" << usDOsts[iRelLop];
        //                }
    }

    sleep(2);

    /**********Read Voltage on COS PSU and load ****************************************/
    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_PS_COS_V, 1, &fPSU_Volt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read PSU Voltage", Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fPSU_Volt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fPSU_Volt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
    }

    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_COS_V, 1, &fLoadVolt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Load Voltage", Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fLoadVolt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fLoadVolt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
    }

    qsTableContents += "<tr><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON Pulse</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON (Momentry)</th><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">LOW</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ECOS_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_COS_V]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">28&#177;"+QString::number(DP_TOL_COS_ADC_OUT_VOLT, 'f', 2)+"V</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ME_COS_V]+"</td>";
    qsTableRes = "";

    for(int iRelLop = 0; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->ReadInput(usRelSts[iRelLop], &ucBSsts);
        if(iRetVal)
        {
            Sig_PrintLog("Unable to read Bypass Switch status",Failure);
            COSPowerOFF();
            StartStopADCAcquisition(0);
            return;
        }

        if(iRelLop == 0)
        {
            if(ucBSsts)
            {
                qsResult[DP_BPECOS_RLY_STS] = "OFF";
            }
            else
            {
                qsResult[DP_BPECOS_RLY_STS] = "ON";
                bReslut2 = false;
            }
            qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">OFF</td><td>"+qsResult[DP_BPECOS_RLY_STS];
        }
        else
        {
            if(ucBSsts)
            {
                qsResult[DP_BPECOS_RLY_STS] = "OFF";
                bReslut2 = false;
            }
            else
            {
                qsResult[DP_BPECOS_RLY_STS] = "ON";
            }
            qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">ON</td><td>"+qsResult[DP_BPECOS_RLY_STS];
        }

        if(bReslut1 && bReslut2)
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_PASS;
        }
        else
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_FAIL;
        }
        qsResult[DP_BPECOS_RES].remove("<td>");
        qsResult[DP_BPECOS_RES].remove("</td>\n");

        qsTableRes += "</td><td>"+qsResult[DP_BPECOS_RES]+"</td></tr>\n<tr>";
        bReslut2 = true;
    }
    qsTableRes.chop(4);
    qsTableContents += qsTableRes;
    bReslut1 = true;

    sleep(2);
    /*************************COS ON, Bypass ON and Emergency Switch OFF (7)*************************/

    COSPowerON();
    //            emit Sig_MsgBox("Kindly ensure that Bypass Switch is in ON condition", MSGTYPE_INFO);

    m_iBuzzerRing = 1;
    emit Sig_GetUserInput(2, "Does Emergency COS OFF switch LED glowing?");

    if(!m_iBuzzerRing)
    {
        qsResult[DP_BPECOS_ECOS_LED_STS] = "OFF";
    }
    else
    {
        qsResult[DP_BPECOS_ECOS_LED_STS] = "ON";
        bReslut1 = false;
    }

    iRetVal = m_p3096Wrapper->ReadInput(DI_BYPASS_SWITCH_STS, &ucBSsts);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Bypass Switch status",Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(ucBSsts)
    {
        qsResult[DP_BPECOS_BP_STS] = "HIGH";
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_BP_STS] = "LOW";
    }

    for(int iRelLop = 1; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->SetOutput(usDOsts[iRelLop], 1);
        //                if(iRetVal)
        //                {
        //                    qDebug() << "Failed to set realy:" << usDOsts[iRelLop];
        //                }
    }

    sleep(2);

    /**********Read Voltage on COS PSU and load ****************************************/
    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_PS_COS_V, 1, &fPSU_Volt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read PSU Voltage", Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fPSU_Volt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fPSU_Volt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
    }

    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_COS_V, 1, &fLoadVolt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Load Voltage", Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fLoadVolt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fLoadVolt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
    }

    qsTableContents += "<tr><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON Pulse</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF (Default Position)</th><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">LOW</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ECOS_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_COS_V]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">28&#177;"+QString::number(DP_TOL_COS_ADC_OUT_VOLT, 'f', 2)+"V</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ME_COS_V]+"</td>";
    qsTableRes = "";

    for(int iRelLop = 0; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->ReadInput(usRelSts[iRelLop], &ucBSsts);
        if(iRetVal)
        {
            Sig_PrintLog("Unable to read Bypass Switch status",Failure);
            COSPowerOFF();
            StartStopADCAcquisition(0);
            return;
        }

        if(ucBSsts)
        {
            qsResult[DP_BPECOS_RLY_STS] = "OFF";
            bReslut2 = false;
        }
        else
        {
            qsResult[DP_BPECOS_RLY_STS] = "ON";
        }

        if(bReslut1 && bReslut2)
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_PASS;
        }
        else
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_FAIL;
        }
        qsResult[DP_BPECOS_RES].remove("<td>");
        qsResult[DP_BPECOS_RES].remove("</td>\n");

        qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">ON</td><td>"+qsResult[DP_BPECOS_RLY_STS]+"</td><td>"+qsResult[DP_BPECOS_RES]+"</td></tr>\n<tr>";
        bReslut2 = true;
    }
    qsTableRes.chop(4);
    qsTableContents += qsTableRes;
    bReslut1 = true;

    sleep(2);
#endif
    /*************************COS OFF, Bypass ON and Emergency Switch OFF (8)*************************/
    //            emit Sig_MsgBox("Kindly ensure that Bypass Switch is in ON condition", MSGTYPE_INFO);

    COSPowerOFF();

    iRetVal = m_p3096Wrapper->ReadInput(DI_BYPASS_SWITCH_STS, &ucBSsts);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Bypass Switch status",Failure);
        StartStopADCAcquisition(0);
        return;
    }

    if(ucBSsts)
    {
        qsResult[DP_BPECOS_BP_STS] = "HIGH";
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_BP_STS] = "LOW";
    }

    for(int iRelLop = 1; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->SetOutput(usDOsts[iRelLop], 1);
        //                if(iRetVal)
        //                {
        //                    qDebug() << "Failed to set realy:" << usDOsts[iRelLop];
        //                }
    }

    sleep(2);

    /**********Read Voltage on COS PSU and load ****************************************/
    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_PS_COS_V, 1, &fPSU_Volt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read PSU Voltage", Failure);
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fPSU_Volt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fPSU_Volt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
    }

    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_COS_V, 1, &fLoadVolt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Load Voltage", Failure);
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fLoadVolt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fLoadVolt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
    }

    qsTableContents += "<tr><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF (Default Position)</th><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">LOW</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ECOS_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_COS_V]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">28&#177;"+QString::number(DP_TOL_COS_ADC_OUT_VOLT, 'f', 2)+"V</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ME_COS_V]+"</td>";
    qsTableRes = "";

    for(int iRelLop = 0; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->ReadInput(usRelSts[iRelLop], &ucBSsts);
        if(iRetVal)
        {
            Sig_PrintLog("Unable to read Bypass Switch status",Failure);
            StartStopADCAcquisition(0);
            return;
        }

        if(iRelLop == 0)
        {
            if(ucBSsts)
            {
                qsResult[DP_BPECOS_RLY_STS] = "OFF";
            }
            else
            {
                qsResult[DP_BPECOS_RLY_STS] = "ON";
                bReslut2 = false;
            }
            qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">OFF</td><td>"+qsResult[DP_BPECOS_RLY_STS];
        }
        else
        {
            if(ucBSsts)
            {
                qsResult[DP_BPECOS_RLY_STS] = "OFF";
                bReslut2 = false;
            }
            else
            {
                qsResult[DP_BPECOS_RLY_STS] = "ON";
            }
            qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">ON</td><td>"+qsResult[DP_BPECOS_RLY_STS];
        }

        if(bReslut1 && bReslut2)
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_PASS;
        }
        else
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_FAIL;
        }
        qsResult[DP_BPECOS_RES].remove("<td>");
        qsResult[DP_BPECOS_RES].remove("</td>\n");

        qsTableRes += "</td><td>"+qsResult[DP_BPECOS_RES]+"</td></tr>\n<tr>";
        bReslut2 = true;
    }
    qsTableRes.chop(4);
    qsTableContents += qsTableRes;
    bReslut1 = true;
#if 1
    sleep(2);
    /*************************COS ON, Bypass OFF and Emergency Switch OFF (9)*************************/
    emit Sig_MsgBox("Kindly ensure that Bypass Switch and Emergency COS Off switch is in OFF condition", MSGTYPE_INFO);
    emit Sig_GetUserInput(2, "Does BY-PASS CONTROL LED glowing?");

    if(!m_iBuzzerRing)
    {
        qsResult[DP_BPECOS_BP_LED_STS] = "OFF";
    }
    else
    {
        qsResult[DP_BPECOS_BP_LED_STS] = "ON";
        bReslut1 = false;
    }
    COSPowerON();

    iRetVal = m_p3096Wrapper->ReadInput(DI_BYPASS_SWITCH_STS, &ucBSsts);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Bypass Switch status",Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(ucBSsts)
    {
        qsResult[DP_BPECOS_BP_STS] = "HIGH";
    }
    else
    {
        qsResult[DP_BPECOS_BP_STS] = "LOW";
        bReslut1 = false;
    }

    for(int iRelLop = 1; iRelLop < iLoopVar; iRelLop++)
    {
        if(iRelLop%2 == 0)
            iRetVal = m_p3096Wrapper->SetOutput(usDOsts[iRelLop], 1);
        else
            iRetVal = m_p3096Wrapper->SetOutput(usDOsts[iRelLop], 0);
    }

    sleep(2);

    /**********Read Voltage on COS PSU and load ****************************************/
    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_PS_COS_V, 1, &fPSU_Volt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read PSU Voltage", Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fPSU_Volt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fPSU_Volt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_COS_V] = QString::number(fPSU_Volt, 'f', 2);
    }

    iRetVal = m_p1105Wrapper->ReadRecentSample(AI_COS_V, 1, &fLoadVolt, 1);
    if(iRetVal)
    {
        Sig_PrintLog("Unable to read Load Voltage", Failure);
        COSPowerOFF();
        StartStopADCAcquisition(0);
        return;
    }

    if(!((fLoadVolt >= (28.0-DP_TOL_COS_ADC_OUT_VOLT)) && (fLoadVolt <= (28.0+DP_TOL_COS_ADC_OUT_VOLT))))
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
        bReslut1 = false;
    }
    else
    {
        qsResult[DP_BPECOS_ME_COS_V] = QString::number(fLoadVolt, 'f', 2);
    }

    qsTableContents += "<tr><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">ON Pulse</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF (Default Position)</th><th rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF (Default Position)</th><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">HIGH</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_BP_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">OFF</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ECOS_LED_STS]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_COS_V]+"</td><td rowspan = \""+QString::number(iLoopVar)+"\" style=\"background-color:#ededed\">28&#177;"+QString::number(DP_TOL_COS_ADC_OUT_VOLT, 'f', 2)+"V</td><td rowspan = \""+QString::number(iLoopVar)+"\">"+qsResult[DP_BPECOS_ME_COS_V]+"</td>";
    qsTableRes = "";

    for(int iRelLop = 0; iRelLop < iLoopVar; iRelLop++)
    {
        iRetVal = m_p3096Wrapper->ReadInput(usRelSts[iRelLop], &ucBSsts);
        if(iRetVal)
        {
            Sig_PrintLog("Unable to read Bypass Switch status",Failure);
            COSPowerOFF();
            StartStopADCAcquisition(0);
            return;
        }

        if(iRelLop%2 == 0)
        {
            if(ucBSsts)
            {
                qsResult[DP_BPECOS_RLY_STS] = "OFF";
                bReslut2 = false;
            }
            else
            {
                qsResult[DP_BPECOS_RLY_STS] = "ON";
            }
        }
        else
        {
            if(ucBSsts)
            {
                qsResult[DP_BPECOS_RLY_STS] = "OFF";
            }
            else
            {
                qsResult[DP_BPECOS_RLY_STS] = "ON";
                bReslut2 = false;
            }
        }

        if(bReslut1 && bReslut2)
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_PASS;
        }
        else
        {
            qsResult[DP_BPECOS_RES] = REPORT_RESULT_FAIL;
        }
        qsResult[DP_BPECOS_RES].remove("<td>");
        qsResult[DP_BPECOS_RES].remove("</td>\n");

        if(iRelLop%2 == 0)
        {
            qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">ON</td><td>"+qsResult[DP_BPECOS_RLY_STS]+"</td><td>"+qsResult[DP_BPECOS_RES]+"</td></tr>\n<tr>";
        }
        else
        {
            qsTableRes += "<td style=\"background-color:#ededed\">"+qsRelay[iRelLop]+"</td><td style=\"background-color:#ededed\">OFF</td><td>"+qsResult[DP_BPECOS_RLY_STS]+"</td><td>"+qsResult[DP_BPECOS_RES]+"</td></tr>\n<tr>";
        }
        bReslut2 = true;
    }
    qsTableRes.chop(4);
    qsTableContents += qsTableRes;
    qsTableContents += "</table>\n<br>\n<b>Note: Conditions for Emergency COS OFF switch LED momentary glow </b> <br>\n1)COS power switched off through Software <br>\n2)Emergency COS OFF switch pressed";
    bReslut1 = true;
#endif
    StartStopADCAcquisition(0);
    COSPowerOFF();

    PSU_TestReport(qsTestName,qsReportFile,qsTableContents);
    Sig_PrintLog("Bypass Test Completed", MSGTYPE_INFO);
    Sig_PrintLog("======================================================",MSGTYPE_INFO);
    Sig_PrintLog("",MSGTYPE_INFO);

#endif
}

void CTestThread::DP_LINS_EmergencyTest(int *out_piStatus)
{
    unsigned short usDI_GrpSts[3] = {0};
    int iResult = 0;
    float fPSUVolt = 0.0, fLoadVolt = 0.0;

    emit Sig_MsgBox("Kindly turn ON the emergency COS-OFF switch",MSGTYPE_INFO);

    iResult = m_p3096Wrapper->SetOutput(DO_COS_PWR_ON, DIO_ENABLE);
    if(iResult)
    {
        emit Sig_PrintLog("Unable to read Relay status", MSGTYPE_ERROR);
        iResult = LINS_TEST_FAIL;
    }
    else
    {
        iResult = m_p3096Wrapper->ReadAllInput(DO_COS_PWR_ON, usDI_GrpSts);
        if(iResult)
        {
            emit Sig_PrintLog("Unable to read Relay status", MSGTYPE_ERROR);
            iResult = LINS_TEST_FAIL;
        }
        else
        {

            if((usDI_GrpSts[0] != 0xFFFF) || (usDI_GrpSts[1] != 0xFFFF) || (usDI_GrpSts[2] != 0xFFFF))
            {
                iResult = LINS_TEST_FAIL;
            }
            else
            {
                /* Read current on COS PSU and load */
                iResult =  m_p1105Wrapper->ReadRecentSample(AI_PS_COS_V, 1, &fPSUVolt, 1);
                if(iResult)
                {
                    emit Sig_MsgBox("Unable to read COS PSU voltage", MSGTYPE_ERROR);
                    iResult = LINS_TEST_FAIL;
                }

                if((fPSUVolt > TEST_COSPSU_ON_MAX)||(fPSUVolt < TEST_COSPSU_ON_MIN))
                {
                    iResult = LINS_TEST_FAIL;
                }

                iResult =  m_p1105Wrapper->ReadRecentSample(AI_COS_V, 1, &fLoadVolt, 1);
                if(iResult)
                {
                    emit Sig_MsgBox("Unable to read Load voltage", MSGTYPE_ERROR);
                    iResult = LINS_TEST_FAIL;
                }

                if(fLoadVolt > TEST_COSPSU_OFF_MAX)
                {
                    iResult = LINS_TEST_FAIL;
                }
            }
        }
    }

    emit Sig_MsgBox("Kindly turn OFF the emergency COS-OFF switch",MSGTYPE_INFO);

    if(iResult != 0)
    {
        emit Sig_PrintLog("Emergency Switch Test FAIL", MSGTYPE_ERROR);
    }
    else
    {
        emit Sig_PrintLog("Emergency Switch Test PASS", MSGTYPE_SUCCESS);
    }

    *out_piStatus = iResult;
}
