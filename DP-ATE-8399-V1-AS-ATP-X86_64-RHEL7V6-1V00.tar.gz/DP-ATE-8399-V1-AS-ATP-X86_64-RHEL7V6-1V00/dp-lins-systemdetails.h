#ifndef DPLINSSYSTEMDETAILS_H
#define DPLINSSYSTEMDETAILS_H

#include <QDialog>
#include <QLineEdit>

namespace Ui {
class CSystemDetails;
}

class CSystemDetails : public QDialog
{
    Q_OBJECT

public:
    QLineEdit *m_leSlNo;
    QLineEdit *m_leLoca;
    QLineEdit *m_leTestBy;

    unsigned char m_ucContinue;

    explicit CSystemDetails(QWidget *parent = 0);
    ~CSystemDetails();

    void ShowDialog();

private slots:
    void on_pbUpdate_clicked();

    void on_pbContinue_clicked();


private:
    Ui::CSystemDetails *ui;
};

#endif // DPLINSSYSTEMDETAILS_H
