#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    initGraph();

    m_pFileOpenDialog = new CFileOpenDialog(this);

    m_qstrLogFileName = QString();

    connect(ui->widgetGraph, SIGNAL(mouseDoubleClick(QMouseEvent*)), this, SLOT(slot_mouseDoubleClicked(QMouseEvent*)));
    connect(ui->widgetGraph, SIGNAL(mouseMove(QMouseEvent*)), this, SLOT(slot_mouseMoved(QMouseEvent*)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::initGraph()
{
    if (ui->widgetGraph->graphCount() > 0)
    {
        ui->widgetGraph->clearItems();
        ui->widgetGraph->clearGraphs();
    }

    QCPItemText *tempItemTemp = NULL;
    while(vectItemText.size())
    {
        tempItemTemp = vectItemText.at(0);
        if(ui->widgetGraph->hasItem(tempItemTemp))
        {
            ui->widgetGraph->removeItem(tempItemTemp);
        }
        vectItemText.pop_front();
    }

    ui->widgetGraph->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);

    ui->widgetGraph->legend->setVisible(true);
    ui->widgetGraph->xAxis->setVisible(true);
    ui->widgetGraph->yAxis->setVisible(true);
    ui->widgetGraph->xAxis2->setVisible(false);
    ui->widgetGraph->yAxis2->setVisible(true);

    ui->widgetGraph->xAxis->setLabel("Time (ms)");
    ui->widgetGraph->yAxis->setLabel("Position Command (degree)");
    ui->widgetGraph->yAxis2->setLabel("Position Feedback (degree)");

    ui->widgetGraph->xAxis->grid()->setSubGridVisible(true);

    // Tracer

    m_tracer = new QCPItemTracer(ui->widgetGraph); //generate a cursor
    m_tracer->position->setType(QCPItemPosition::ptViewportRatio);
    //The following code sets the tracer appearance

//    tracer->setGraph(ui->widgetGraph->graph(0));

    m_tracerLabel = new QCPItemText(ui->widgetGraph); //generate a cursor explained
    //This sets the cursor is described look like and alignment state
    m_tracerLabel->setLayer("overlay");

    //this statement is very important, it will anchor at the cursor specification tracer position, automatically follow
    m_tracerLabel->position->setParentAnchor(m_tracer->position);
    m_tracerLabel->position->setCoords(0,0);

    m_tracerLine = new QCPItemLine(ui->widgetGraph);
    m_tracerLine->start->setCoords(0, 0);
    m_tracerLine->end->setCoords(0, 0);


    m_tracerLine->setVisible(false);
    m_tracerLabel->setVisible(false);
    m_tracer->setVisible(false);

    m_tracer2 = new QCPItemTracer(ui->widgetGraph);
    m_tracer2->position->setType(QCPItemPosition::ptViewportRatio);


    m_tracerLabel2 = new QCPItemText(ui->widgetGraph);
    m_tracerLabel2->setLayer("overlay");

    m_tracerLabel2->position->setParentAnchor(m_tracer2->position);
    m_tracerLabel2->position->setCoords(0, 0);

    m_tracer2->setVisible(false);
    m_tracerLabel2->setVisible(false);

    /* Change graph styling */
    setGraphAppearance();

    ui->widgetGraph->replot();
}

void MainWindow::setGraphAppearance()
{
    QPen pen(Qt::DashLine);
    pen.setColor(GRID_COLOR);

    ui->widgetGraph->xAxis->grid()->setPen(pen);
    ui->widgetGraph->yAxis->grid()->setPen(pen);
    ui->widgetGraph->yAxis2->grid()->setPen(pen);

    pen.setColor(SUBGRID_COLOR);
    ui->widgetGraph->xAxis->grid()->setSubGridPen(pen);

    m_tracer->setPen(QPen(TRACER1_COLOR));
    m_tracer->setBrush(QBrush(TRACER1_COLOR));
    m_tracer->setStyle(TRACER_STYLE);
    m_tracer->setSize(TRACER_SIZE);

    m_tracerLabel->setPen(QPen(TRACER1_COLOR));
    m_tracerLabel->setPositionAlignment(TRACER1_LABEL_POSITION);

    m_tracerLine->setPen(QPen(TRACER_LINE_COLOR));

    m_tracer2->setPen(QPen(TRACER2_COLOR));
    m_tracer2->setBrush(QBrush(TRACER2_COLOR));
    m_tracer2->setStyle(TRACER_STYLE);
    m_tracer2->setSize(TRACER_SIZE);

    m_tracerLabel2->setPen(QPen(TRACER2_COLOR));
    m_tracerLabel2->setPositionAlignment(TRACER2_LABEL_POSITION);

    ui->widgetGraph->setBackground(QBrush(GRAPH_BACKGROUND_COLOR));
    ui->widgetGraph->legend->setBrush(QBrush(LEGEND_COLOR));
    ui->widgetGraph->legend->setTextColor(LEGEND_TEXT_COLOR);
    ui->widgetGraph->legend->setBorderPen(QPen(LEGEND_BORDER_COLOR));
    ui->widgetGraph->xAxis->setSubTickPen(QPen(XAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis->setSubTickPen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis2->setSubTickPen(QPen(YAXIS2_BASE_TICK_COLOR));
    ui->widgetGraph->xAxis->setBasePen(QPen(XAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis->setBasePen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis2->setBasePen(QPen(YAXIS2_BASE_TICK_COLOR));
    ui->widgetGraph->xAxis->setTickPen(QPen(XAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis->setTickPen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis2->setTickPen(QPen(YAXIS2_BASE_TICK_COLOR));
    ui->widgetGraph->xAxis->setLabelColor(XAXIS_BASE_TICK_COLOR);
    ui->widgetGraph->yAxis->setLabelColor(YAXIS_BASE_TICK_COLOR);
    ui->widgetGraph->yAxis2->setLabelColor(YAXIS2_BASE_TICK_COLOR);
    ui->widgetGraph->xAxis->setLabelFont(LABEL_FONT);
    ui->widgetGraph->yAxis->setLabelFont(LABEL_FONT);
    ui->widgetGraph->yAxis2->setLabelFont(LABEL_FONT);
    ui->widgetGraph->xAxis->setTickLabelColor(LEGEND_TEXT_COLOR);
    ui->widgetGraph->yAxis->setTickLabelColor(LEGEND_TEXT_COLOR);
    ui->widgetGraph->yAxis2->setTickLabelColor(LEGEND_TEXT_COLOR);
}

bool MainWindow::readLinesFromLog(QStringList *out_strLines)
{
    QFile fpLogfile;
    QTextStream stream;

    if (m_qstrLogFileName.isEmpty())
    {
        return false;
    }

    fpLogfile.setFileName(m_qstrLogFileName);
    if (!fpLogfile.open(QIODevice::ReadOnly))
    {
        qDebug("File open error");
        return false;
    }

    stream.setDevice(&fpLogfile);
    while (!stream.atEnd())
    {
        out_strLines->append(stream.readLine());
    }

    fpLogfile.close();

    return true;
}

bool MainWindow::extractLogData(QStringList in_strLog, QVector<double> *out_dvectTime, \
                                QVector<double> *out_dvectPosDemand, QVector<double> *out_dvectPosResponse)
{
    QStringList strTempList;
    bool bOk = false;
    double dTemp = 0.0;
    int iCount = 0;

    out_dvectTime->clear();
    out_dvectPosDemand->clear();
    out_dvectPosResponse->clear();

    if (in_strLog.isEmpty())
    {
        return false;
    }

    foreach (QString strLine, in_strLog)
    {
        iCount = 0;
        strTempList = strLine.trimmed().split(",");

        foreach (QString strTemp, strTempList)
        {
            dTemp = strTemp.toDouble(&bOk);
            if (!bOk) return false;

            switch (iCount)
            {
            case 0:
            {
                out_dvectTime->append(dTemp);
                break;
            }
            case 1:
            {
                out_dvectPosDemand->append(dTemp);
                break;
            }
            case 2:
            {
                out_dvectPosResponse->append(dTemp);
                break;
            }
            default:
            { return false; }
            }
            iCount++;
        }
    }

    return true;
}

void MainWindow::getRange(QVector<double> in_dVector, double *out_pdLower, double *out_pdUpper)
{
    double dTemp = 0.0;

    *out_pdUpper = INT_MIN;
    *out_pdLower = INT_MAX;

    QVectorIterator<double> iter(in_dVector);

    while (iter.hasNext())
    {
        dTemp = iter.next();

        if (dTemp > *out_pdUpper)
        {
            *out_pdUpper = dTemp;
        }
        if (dTemp < *out_pdLower)
        {
            *out_pdLower = dTemp;
        }
    }
}

bool MainWindow::plotGraph(QVector<double> in_dvectTime, QVector<double> in_dvectPosDemand, \
                           QVector<double> in_dvectPosResponse)
{
    double dLowerLimit = 0.0;
    double dUpperLimit = 0.0;

    if (in_dvectTime.isEmpty() || in_dvectPosDemand.isEmpty() || in_dvectPosResponse.isEmpty())
    {
        return false;
    }

    if ((in_dvectTime.length() != in_dvectPosDemand.length()) \
            || (in_dvectPosDemand.length() != in_dvectPosResponse.length()) \
            || (in_dvectPosResponse.length() != in_dvectTime.length()))
    {
        return false;
    }

    initGraph();

    ui->widgetGraph->addGraph(ui->widgetGraph->xAxis, ui->widgetGraph->yAxis);
    ui->widgetGraph->addGraph(ui->widgetGraph->xAxis, ui->widgetGraph->yAxis2);

    ui->widgetGraph->graph(0)->setPen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->graph(1)->setPen(QPen(YAXIS2_BASE_TICK_COLOR));
    ui->widgetGraph->graph(0)->setSelectable(QCP::stMultipleDataRanges);
    ui->widgetGraph->graph(1)->setSelectable(QCP::stMultipleDataRanges);
    ui->widgetGraph->graph(0)->setName("Position Demand");
    ui->widgetGraph->graph(1)->setName("Position Response");

    /* Getting range for Frequency (X-Axis) */
    getRange(in_dvectTime, &dLowerLimit, &dUpperLimit);
    ui->widgetGraph->xAxis->setRange(dLowerLimit, dUpperLimit);

    /* Getting range for Gain (Y-Axis) */
    getRange(in_dvectPosDemand, &dLowerLimit, &dUpperLimit);
    ui->widgetGraph->yAxis->setRange(dLowerLimit, dUpperLimit);

    /* Getting range for Phase (Y2-Axis) */
    getRange(in_dvectPosResponse, &dLowerLimit, &dUpperLimit);
    ui->widgetGraph->yAxis2->setRange(dLowerLimit, dUpperLimit);

    ui->widgetGraph->graph(0)->setData(in_dvectTime, in_dvectPosDemand);
    ui->widgetGraph->graph(0)->setLineStyle(QCPGraph::lsLine);
    ui->widgetGraph->graph(1)->setData(in_dvectTime, in_dvectPosResponse);
    ui->widgetGraph->graph(1)->setLineStyle(QCPGraph::lsLine);

    ui->widgetGraph->replot();

    return true;
}

void MainWindow::saveGraph(QString in_qstrFilename)
{
    bool bOk = false;
    bOk = ui->widgetGraph->savePdf(in_qstrFilename);

    if (bOk)
    {
        QMessageBox::information(this, "Graph Saved :)", "Graph has been saved in <b><i><code>" + in_qstrFilename);
    }
    else
    {
        QMessageBox::information(this, "Graph Unsaved :(", "Error saving Graph as PDF");
    }

    SET_TRACING_STATE(true);
}

void MainWindow::on_action_Choose_File_triggered()
{
    QString strMessage = QString();
    if (!m_pFileOpenDialog)
    {
        return;
    }
    m_pFileOpenDialog->exec();
    if (m_pFileOpenDialog->m_strLogFilename.isEmpty())
    {
        strMessage.append("No Log file selected...\n");
        if (!m_qstrLogFileName.isEmpty())
        {
            strMessage.append("Continuing with previous log file <b>" + m_qstrLogFileName + "</b>\n");
        }
        QMessageBox::information(this, "Log file", strMessage.trimmed());
        return;
    }

    m_qstrLogFileName = m_pFileOpenDialog->m_strLogFilename;
    QMessageBox::information(this, "Configuration", "Log file loaded : <b>" + m_qstrLogFileName);
}

void MainWindow::on_action_Save_Graph_triggered()
{
    if (ui->widgetGraph->graphCount() < 2)
    {
        QMessageBox::information(this, "Save Graph !?", "No graph plotted to save");
        return;
    }

    SET_TRACING_STATE(false)

    QString strSavePDF_Filename = QFileDialog::getSaveFileName(this, "Save Graph as PDF", "../OutputFiles/", "PDF File (*.pdf)");

    if (strSavePDF_Filename.isEmpty())
    {
        QMessageBox::information(this, "Save Graph as PDF", "No file selected");
        return;
    }

    if (!(strSavePDF_Filename.endsWith(".pdf") || strSavePDF_Filename.endsWith(".PDF")))
    {
        strSavePDF_Filename.append(".pdf");
    }

    saveGraph(strSavePDF_Filename);
}

void MainWindow::on_pbPlot_clicked()
{
    bool bOk = false;
    QStringList strLogfileLines;

    SET_PLOT_BUTTON ("Plotting...", false, ui->pbPlot);

    initGraph();

    bOk = readLinesFromLog(&strLogfileLines);

    if (!bOk)
    {
        QMessageBox::information(this, "File error", "Cannot read log file data");
        SET_PLOT_BUTTON("&Plot", true, ui->pbPlot);
        return;
    }

    bOk = false;
    bOk = extractLogData(strLogfileLines, &m_dvectTime, &m_dvectPosDemand, &m_dvectPosResponse);
    if (!bOk)
    {
        QMessageBox::information(this, "File error", "Cannot read log file data");
        SET_PLOT_BUTTON("&Plot", true, ui->pbPlot);
        return;
    }

    bOk = false;
    bOk = plotGraph(m_dvectTime, m_dvectPosDemand, m_dvectPosResponse);
    if (!bOk)
    {
        QMessageBox::information(this, "Graph Error", "Cannot plot graph");
        SET_PLOT_BUTTON("&Plot", true, ui->pbPlot);
        return;
    }
    SET_PLOT_BUTTON("&Plot", true, ui->pbPlot);
}

void MainWindow::slot_mouseDoubleClicked(QMouseEvent *mevent)
{
    Q_UNUSED(mevent);

    if (ui->widgetGraph->graphCount() < 2)
    {
        return;
    }

    double xValue = 0.0;
    double yValue = 0.0;
    QString qstrData = QString("");
    QPointF qPos = QPointF();
    QPointF qPos2 = QPointF();
    QCPItemText *pTracerLabel = NULL;

    m_tracer->setGraph(ui->widgetGraph->graph(0));

    qPos = m_tracer->position->pixelPosition();
    qPos2 = m_tracer2->position->pixelPosition();

    pTracerLabel = new QCPItemText(ui->widgetGraph); //generate a cursor explained
    vectItemText.push_back(pTracerLabel);
    pTracerLabel->setLayer("overlay");
    pTracerLabel->setPen(QPen(YAXIS_BASE_TICK_COLOR));
    pTracerLabel->setColor(MOUSE_TRACER_LABEL_COLOR);
    pTracerLabel->setPositionAlignment(TRACER1_LABEL_POSITION);

    xValue = m_tracer->position->key();
    yValue = m_tracer->position->value();
    qstrData.sprintf("%0.5f - Freq(Hz)\n %0.5f - Phase(Deg)", xValue, yValue);

    pTracerLabel->position->setPixelPosition(qPos);
    pTracerLabel->setText(qstrData);

    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);

    m_tracer2->setGraph(ui->widgetGraph->graph(1));

    pTracerLabel = new QCPItemText(ui->widgetGraph);
    vectItemText.push_back(pTracerLabel);
    pTracerLabel->setLayer("overlay");
    pTracerLabel->setPen(QPen(YAXIS2_BASE_TICK_COLOR));
    pTracerLabel->setColor(LEGEND_TEXT_COLOR);
    pTracerLabel->setPositionAlignment(TRACER2_LABEL_POSITION);

    xValue = m_tracer2->position->key();
    yValue = m_tracer2->position->value();

    qstrData.sprintf("%0.5f - Freq(Hz)\n%0.5f - Phase(Deg)", xValue, yValue);

    pTracerLabel->position->setPixelPosition(qPos2);
    pTracerLabel->setText(qstrData);

    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}

void MainWindow::slot_mouseMoved(QMouseEvent *mevent)
{
    if (ui->widgetGraph->graphCount() < 2)
    {
        return;
    }

    QString qstrData = QString("");
    double dMouseX = 0.0;
    double dStart = 0.0;
    double dEnd = 0.0;
    double dValueX = 0.0;
    double dValueY = 0.0;

    dMouseX = ui->widgetGraph->xAxis->pixelToCoord(mevent->pos().x());

    dStart = ui->widgetGraph->yAxis->pixelToCoord(0);
    dEnd = ui->widgetGraph->yAxis->pixelToCoord(ui->widgetGraph->size().height());

    m_tracerLine->start->setCoords(dMouseX, dStart);
    m_tracerLine->end->setCoords(dMouseX, dEnd);

    m_tracer->setGraph(ui->widgetGraph->graph(0));

    m_tracer->setGraphKey(dMouseX); //cursor abscissa (key) set to the abscissa x data obtained immediately
    m_tracer->setInterpolating(true); //ordinate cursor can automatically (this curve data by linear interpolation do not have to manually calculate)
    m_tracer->updatePosition();

    dValueX = m_tracer->position->key();
    dValueY = m_tracer->position->value();

    m_tracerLabel->position->setType(QCPItemPosition::ptAbsolute);

    m_tracerLabel->setPositionAlignment(TRACER1_LABEL_POSITION);
    m_tracerLabel->position->setCoords(1.0, 1);

    m_tracerLabel->setTextAlignment(Qt::AlignRight);
    m_tracerLabel->setFont(QFont(font().family(), 12));
    m_tracerLabel->setPadding(QMargins(9, 3, 3, 9));

    qstrData.sprintf("(%0.5f, %0.5f)", dValueX, dValueY);

    m_tracerLabel->setText(qstrData);

    m_tracer->setVisible(true);
    m_tracerLabel->setVisible(true);
    m_tracerLine->setVisible(true);

    m_tracer2->setGraph(ui->widgetGraph->graph(1));
    m_tracer2->setGraphKey(dMouseX);
    m_tracer2->setInterpolating(true);
    m_tracer2->updatePosition();

    dValueX = m_tracer2->position->key();
    dValueY = m_tracer2->position->value();

    m_tracerLabel2->position->setType(QCPItemPosition::ptAbsolute);
    m_tracerLabel2->setPositionAlignment(TRACER2_LABEL_POSITION);
    m_tracerLabel2->position->setCoords(0, 0);
    m_tracerLabel2->setTextAlignment(Qt::AlignRight);
    m_tracerLabel2->setFont(QFont(font().family(), 12));
    m_tracerLabel2->setPadding(QMargins(9, 3, 3, 9));
    qstrData.sprintf("(%0.5f, %0.5f)", dValueX, dValueY);
    m_tracerLabel2->setText(qstrData);

    m_tracerLabel2->setColor(LEGEND_TEXT_COLOR);
    m_tracerLabel->setColor(LEGEND_TEXT_COLOR);
    m_tracer->setPen(QPen(MOUSE_TRACER_COLOR));
    m_tracer2->setPen(QPen(MOUSE_TRACER2_COLOR));
    m_tracer->setBrush(QBrush(MOUSE_TRACER_COLOR));
    m_tracer2->setBrush(QBrush(MOUSE_TRACER2_COLOR));

    m_tracer2->setVisible(true);
    m_tracerLabel->setVisible(true);
    m_tracerLabel2->setVisible(true);

    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}
