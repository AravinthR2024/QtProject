#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QMessageBox>
#include <QVector>
#include <QVectorIterator>

#include "qcustomplot.h"
#include "fileopendialog.h"
#include "macros.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    QString m_qstrLogFileName;
    bool m_bIsLogFileLoaded;
    QVector<double> m_dvectTime;
    QVector<double> m_dvectPosDemand;
    QVector<double> m_dvectPosResponse;

    QCPItemLine *m_tracerLine;
    QCPItemTracer *m_tracer;
    QCPItemText *m_tracerLabel;

    QCPItemTracer *m_tracer2;
    QCPItemText *m_tracerLabel2;

    //QCPGraph graph[2];
    QVector<QCPItemText*> vectItemText;

    CFileOpenDialog *m_pFileOpenDialog;

    void initGraph();
    void setGraphAppearance();
    bool readLinesFromLog(QStringList *out_strLines);
    bool extractLogData (QStringList in_strLog, QVector<double> *out_dvectTime, QVector<double> *out_dvectPosDemand, QVector<double> *out_dvectPosResponse);
    void getRange(QVector<double> in_dVector, double *out_pdLower, double *out_pdUpper);
    bool plotGraph(QVector<double> in_dvectFrequency, QVector<double> in_dvectGain, QVector<double> in_dvectPhase);
    void saveGraph(QString in_qstrFilename);

public slots:
    void slot_mouseMoved(QMouseEvent *mevent);

    void slot_mouseDoubleClicked(QMouseEvent *mevent);

private slots:
    void on_action_Choose_File_triggered();

    void on_action_Save_Graph_triggered();

    void on_pbPlot_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
