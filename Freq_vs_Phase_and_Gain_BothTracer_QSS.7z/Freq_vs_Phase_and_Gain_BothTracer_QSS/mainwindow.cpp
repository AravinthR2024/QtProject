#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    initGraph();

    m_objFileOpenDialog = new CFileOpenDialog(this);

    m_strLogFileName = QString();

    connect(ui->widgetGraph, SIGNAL(mouseDoubleClick(QMouseEvent*)), this, SLOT(slot_mouseDoubleClicked(QMouseEvent*)));
    connect(ui->widgetGraph, SIGNAL(mouseMove(QMouseEvent*)), this, SLOT(slot_mouseMoved(QMouseEvent*)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::initGraph()
{
    if (ui->widgetGraph->graphCount() > 0)
    {
        ui->widgetGraph->clearItems();
        ui->widgetGraph->clearGraphs();
    }

    QCPItemText *tempItemTemp = NULL;
    while(vectItemText.size())
    {
        tempItemTemp = vectItemText.at(0);
        //qDebug("%x", tempItem);
        if(ui->widgetGraph->hasItem(tempItemTemp))
        {
            ui->widgetGraph->removeItem(tempItemTemp);
        }
        vectItemText.pop_front();
    }

    ui->widgetGraph->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);

    ui->widgetGraph->legend->setVisible(true);
    ui->widgetGraph->xAxis->setVisible(true);
    ui->widgetGraph->yAxis->setVisible(true);
    ui->widgetGraph->xAxis2->setVisible(false);
    ui->widgetGraph->yAxis2->setVisible(true);

    ui->widgetGraph->xAxis->setLabel("Frequency (Hz)");
    ui->widgetGraph->yAxis->setLabel("Gain (dB)");
    ui->widgetGraph->yAxis2->setLabel("Phase (degree)");

    ui->widgetGraph->xAxis->grid()->setSubGridVisible(true);

    QPen pen(Qt::DashLine);

#ifdef _QSS_
    pen.setColor(QColor(0x00, 0x91, 0x8F));
#endif
    ui->widgetGraph->xAxis->grid()->setPen(pen);

#ifdef _QSS_
    pen.setColor(QColor(0x00, 0XCC, 0xD3));
#else
    pen.setColor(Qt::darkGray);
#endif
    ui->widgetGraph->xAxis->grid()->setSubGridPen(pen);

#ifdef _QSS_
    pen.setColor(QColor(0x3C, 0xDD, 0xDC));
#endif
    ui->widgetGraph->yAxis->grid()->setPen(pen);

#ifdef _QSS_
    pen.setColor(QColor(0x75, 0xE9, 0xE5));
#endif
    ui->widgetGraph->yAxis2->grid()->setPen(pen);

    // Tracer

    m_tracer = new QCPItemTracer(ui->widgetGraph); //generate a cursor
    m_tracer->position->setType(QCPItemPosition::ptViewportRatio);
    //The following code sets the tracer appearance
    m_tracer->setPen(QPen(Qt::darkRed));
    m_tracer->setBrush(QBrush(Qt::darkRed));
    m_tracer->setStyle(QCPItemTracer::tsCircle);
    m_tracer->setSize(10.0);
//    tracer->setGraph(ui->widgetGraph->graph(0));

    m_tracerLabel = new QCPItemText(ui->widgetGraph); //generate a cursor explained
    //This sets the cursor is described look like and alignment state
    m_tracerLabel->setLayer("overlay");
    m_tracerLabel->setPen(QPen(Qt::darkRed));
    m_tracerLabel->setPositionAlignment(Qt::AlignLeft | Qt::AlignTop);
    //this statement is very important, it will anchor at the cursor specification tracer position, automatically follow
    m_tracerLabel->position->setParentAnchor(m_tracer->position);
    m_tracerLabel->position->setCoords(0,0);

    m_tracerLine = new QCPItemLine(ui->widgetGraph);
    m_tracerLine->start->setCoords(0, 0);
    m_tracerLine->end->setCoords(0, 0);
    m_tracerLine->setPen(QPen(Qt::darkYellow));

    m_tracerLine->setVisible(false);
    m_tracerLabel->setVisible(false);
    m_tracer->setVisible(false);

#ifdef _TRACE_BOTH_
    m_tracer2 = new QCPItemTracer(ui->widgetGraph);
    m_tracer2->position->setType(QCPItemPosition::ptViewportRatio);
    m_tracer2->setPen(QPen(Qt::darkGreen));
    m_tracer2->setBrush(QBrush(Qt::darkGreen));
    m_tracer2->setStyle(QCPItemTracer::tsCircle);
    m_tracer2->setSize(10.0);

    m_tracerLabel2 = new QCPItemText(ui->widgetGraph);
    m_tracerLabel2->setLayer("overlay");
    m_tracerLabel2->setPen(QPen(Qt::darkGreen));
    m_tracerLabel2->setPositionAlignment(Qt::AlignRight | Qt::AlignBottom);
    m_tracerLabel2->position->setParentAnchor(m_tracer2->position);
    m_tracerLabel2->position->setCoords(0, 0);

    m_tracer2->setVisible(false);
    m_tracerLabel2->setVisible(false);
#endif

#ifdef _QSS_

    ui->widgetGraph->setBackground(QBrush(Qt::black));
    ui->widgetGraph->legend->setBrush(QBrush(Qt::black));
    ui->widgetGraph->legend->setTextColor(Qt::white);
    ui->widgetGraph->legend->setBorderPen(QPen(Qt::lightGray));
    ui->widgetGraph->xAxis->setSubTickPen(QPen((QColor(20, 173, 181))));
    ui->widgetGraph->xAxis->setSubTickPen(QPen(Qt::white));
    ui->widgetGraph->yAxis->setSubTickPen(QPen(Qt::red));
    ui->widgetGraph->yAxis2->setSubTickPen(QPen(Qt::green));
    ui->widgetGraph->xAxis->setBasePen(QPen(Qt::white));
    ui->widgetGraph->yAxis->setBasePen(QPen(Qt::red));
    ui->widgetGraph->yAxis2->setBasePen(QPen(Qt::green));
    ui->widgetGraph->yAxis->setTickPen(QPen(Qt::red));
    ui->widgetGraph->yAxis2->setTickPen(QPen(Qt::green));
    ui->widgetGraph->xAxis->setTickPen(QPen(Qt::white));
    ui->widgetGraph->xAxis->setLabelColor(Qt::white);
    ui->widgetGraph->yAxis->setLabelColor(Qt::red);
    ui->widgetGraph->yAxis2->setLabelColor(Qt::green);
    ui->widgetGraph->xAxis->setLabelFont(QFont("Arial", 13));
    ui->widgetGraph->yAxis->setLabelFont(QFont("Arial", 13));
    ui->widgetGraph->yAxis2->setLabelFont(QFont("Arial", 13));
    ui->widgetGraph->xAxis->setTickLabelColor(Qt::white);
    ui->widgetGraph->yAxis->setTickLabelColor(Qt::white);
    ui->widgetGraph->yAxis2->setTickLabelColor(Qt::white);

#endif

    /////////

    QSharedPointer<QCPAxisTickerLog> ticker(new QCPAxisTickerLog);
    ui->widgetGraph->xAxis->setTicker(ticker);
    ui->widgetGraph->xAxis->setScaleType(QCPAxis::stLogarithmic);

    ui->widgetGraph->yAxis->ticker().data()->setTickCount(10);
    ui->widgetGraph->yAxis2->ticker().data()->setTickCount(10);

    ui->widgetGraph->replot();
}

bool MainWindow::readLogFile(QStringList *out_strLines)
{
    QFile fpLogfile;

    if (m_strLogFileName.isEmpty())
    {
        return false;
    }

    fpLogfile.setFileName(m_strLogFileName);
    if (!fpLogfile.open(QIODevice::ReadOnly))
    {
        qDebug("File open error");
        return false;
    }

    QTextStream stream(&fpLogfile);
    while (!stream.atEnd())
    {
        out_strLines->append(stream.readLine());
    }

    fpLogfile.close();

    return true;
}

bool MainWindow::extractLogData(QStringList in_strLog, QVector<double> *out_dvectFrequency, \
                                QVector<double> *out_dvectGain, QVector<double> *out_dvectPhase)
{
    QStringList strTempList;
    bool bOk = false;
    double dTemp = 0.0;
    int iCount = 0;

    out_dvectFrequency->clear();
    out_dvectGain->clear();
    out_dvectPhase->clear();

    if (in_strLog.isEmpty())
    {
        return false;
    }

    foreach (QString strLine, in_strLog)
    {
        iCount = 0;
        strTempList = strLine.trimmed().split(",");

        foreach (QString strTemp, strTempList)
        {
            dTemp = strTemp.toDouble(&bOk);
            if (!bOk) return false;

            switch (iCount)
            {
            case 0:
            {
                out_dvectFrequency->append(dTemp);
                break;
            }
            case 1:
            {
                out_dvectGain->append(dTemp);
                break;
            }
            case 2:
            {
                out_dvectPhase->append(dTemp);
                break;
            }
            default:
            {return false;}
            }
            iCount++;
        }
    }

    return true;
}

bool MainWindow::plotGraph(QVector<double> in_dvectFrequency, QVector<double> in_dvectGain, \
                           QVector<double> in_dvectPhase)
{
    if (in_dvectFrequency.isEmpty() || in_dvectGain.isEmpty() || in_dvectPhase.isEmpty())
    {
        return false;
    }

    if ((in_dvectFrequency.length() != in_dvectGain.length()) \
            || (in_dvectGain.length() != in_dvectPhase.length()) \
            || (in_dvectPhase.length() != in_dvectFrequency.length()))
    {
        return false;
    }

    initGraph();

    ui->widgetGraph->addGraph(ui->widgetGraph->xAxis, ui->widgetGraph->yAxis);
    ui->widgetGraph->addGraph(ui->widgetGraph->xAxis, ui->widgetGraph->yAxis2);

    ui->widgetGraph->graph(0)->setPen(QPen(Qt::red));
    ui->widgetGraph->graph(1)->setPen(QPen(Qt::green));
    ui->widgetGraph->graph(0)->setSelectable(QCP::stMultipleDataRanges);
    ui->widgetGraph->graph(1)->setSelectable(QCP::stMultipleDataRanges);
    ui->widgetGraph->graph(0)->setName("Gain");
    ui->widgetGraph->graph(1)->setName("Phase");

    ui->widgetGraph->xAxis->setRange(in_dvectFrequency.first() - 5, in_dvectFrequency.last() + 5);
    ui->widgetGraph->yAxis->setRange(in_dvectGain.first() - 5, in_dvectGain.last() + 5);
    ui->widgetGraph->yAxis2->setRange(in_dvectPhase.first() - 5, in_dvectPhase.last() + 5);

    ui->widgetGraph->graph(0)->setData(in_dvectFrequency, in_dvectGain);
    ui->widgetGraph->graph(0)->setLineStyle(QCPGraph::lsLine);
    ui->widgetGraph->graph(1)->setData(in_dvectFrequency, in_dvectPhase);
    ui->widgetGraph->graph(1)->setLineStyle(QCPGraph::lsLine);

    ui->widgetGraph->replot();

    return true;
}

void MainWindow::on_action_Choose_File_triggered()
{
    QString strMessage = QString();
    if (!m_objFileOpenDialog)
    {
        return;
    }
    m_objFileOpenDialog->exec();
    if (m_objFileOpenDialog->m_strLogFilename.isEmpty())
    {
        strMessage.append("No Log file selected...\n");
        if (!m_strLogFileName.isEmpty())
        {
            strMessage.append("Continuing with previous log file <b>" + m_strLogFileName + "</b>\n");
        }
        QMessageBox::information(this, "Log file", strMessage.trimmed());
        return;
    }

    m_strLogFileName = m_objFileOpenDialog->m_strLogFilename;
    QMessageBox::information(this, "Configuration", "Log file loaded : <b>" + m_strLogFileName);
}

void MainWindow::on_pbPlot_clicked()
{
    bool bOk = false;
    QStringList strLogfileLines;

    initGraph();

    bOk = readLogFile(&strLogfileLines);

    if (!bOk)
    {
        QMessageBox::information(this, "File error", "Cannot read log file data");
        return;
    }

    bOk = false;
    bOk = extractLogData(strLogfileLines, &m_dvectFrequencyList, &m_dvectGainList, &m_dvectPhaseList);
    if (!bOk)
    {
        QMessageBox::information(this, "File error", "Cannot read log file data");
        return;
    }

    bOk = false;
    bOk = plotGraph(m_dvectFrequencyList, m_dvectGainList, m_dvectPhaseList);
    if (!bOk)
    {
        QMessageBox::information(this, "Graph Error", "Cannot plot graph");
        return;
    }
}

void MainWindow::slot_mouseDoubleClicked(QMouseEvent *mevent)
{
    Q_UNUSED(mevent);

    if (ui->widgetGraph->graphCount() < 2)
    {
        return;
    }
    QCPItemText *tracerLabel1;
    QString StrData;

    m_tracer->setGraph(ui->widgetGraph->graph(0));
    tracerLabel1 = new QCPItemText(ui->widgetGraph); //generate a cursor explained

    vectItemText.push_back(tracerLabel1);
    tracerLabel1->setLayer("overlay");
    tracerLabel1->setPen(QPen(Qt::red));
#ifdef _QSS_

    tracerLabel1->setColor(Qt::white);

#endif
    tracerLabel1->setPositionAlignment(Qt::AlignTop | Qt::AlignLeft);

    double xValue2 = m_tracer->position->key();
    double yValue2 = m_tracer->position->value();
    StrData.sprintf("%0.5f - Freq(Hz)\n %0.5f - Phase(Deg)", xValue2, yValue2);

    QPointF qPos2;
    qPos2 = m_tracer->position->pixelPosition();

    tracerLabel1->position->setPixelPosition(qPos2);


    tracerLabel1->setText(StrData);

    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);

#ifdef _TRACE_BOTH_

    QCPItemText *tracerLabel2;

    m_tracer2->setGraph(ui->widgetGraph->graph(1));
    tracerLabel2 = new QCPItemText(ui->widgetGraph);

    vectItemText.push_back(tracerLabel2);
    tracerLabel2->setLayer("overlay");
    tracerLabel2->setPen(QPen(Qt::green));
#ifdef _QSS_

    tracerLabel2->setColor(Qt::white);

#endif
    tracerLabel2->setPositionAlignment(Qt::AlignRight | Qt::AlignBottom);

    double xValue = m_tracer2->position->key();
    double yValue = m_tracer2->position->value();

    StrData.sprintf("%0.5f - Freq(Hz)\n%0.5f - Phase(Deg)", xValue, yValue);

    QPointF qPos;
    qPos = m_tracer2->position->pixelPosition();
    tracerLabel2->position->setPixelPosition(qPos);
    //        tracerLabel1->setFont(QFont(font().family(), 12, QFont::ExtraBold, true));
    tracerLabel2->setText(StrData);


    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
#endif
}

void MainWindow::slot_mouseMoved(QMouseEvent *mevent)
{
    if (ui->widgetGraph->graphCount() < 2)
    {
        return;
    }
    QString strData;

    double mouseX = ui->widgetGraph->xAxis->pixelToCoord(mevent->pos().x());

    double start = ui->widgetGraph->yAxis->pixelToCoord(0);
    double end = ui->widgetGraph->yAxis->pixelToCoord(ui->widgetGraph->size().height());

    m_tracerLine->start->setCoords(mouseX, start);
    m_tracerLine->end->setCoords(mouseX, end);

    m_tracer->setGraph(ui->widgetGraph->graph(0));

    m_tracer->setGraphKey(mouseX); //cursor abscissa (key) set to the abscissa x data obtained immediately
    m_tracer->setInterpolating(true); //ordinate cursor can automatically (this curve data by linear interpolation do not have to manually calculate)
    m_tracer->updatePosition();

    double xValue = m_tracer->position->key();
    double yValue = m_tracer->position->value();

    m_tracerLabel->position->setType(QCPItemPosition::ptAbsolute);

    m_tracerLabel->setPositionAlignment(Qt::AlignLeft | Qt::AlignTop);
    m_tracerLabel->position->setCoords(1.0, 1);

    m_tracerLabel->setTextAlignment(Qt::AlignRight);
    m_tracerLabel->setFont(QFont(font().family(), 12));
    m_tracerLabel->setPadding(QMargins(9, 3, 3, 9));

    strData.sprintf("(%0.5f, %0.5f)", xValue, yValue);

    m_tracerLabel->setText(strData);

    m_tracer->setVisible(true);
    m_tracerLabel->setVisible(true);
    m_tracerLine->setVisible(true);

    //        ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);

#ifdef _TRACE_BOTH_

    m_tracer2->setGraph(ui->widgetGraph->graph(1));
    m_tracer2->setGraphKey(mouseX);
    m_tracer2->setInterpolating(true);
    m_tracer2->updatePosition();

    double xValue2 = m_tracer2->position->key();
    double yValue2 = m_tracer2->position->value();

    m_tracerLabel2->position->setType(QCPItemPosition::ptAbsolute);
    m_tracerLabel2->setPositionAlignment(Qt::AlignRight | Qt::AlignBottom);
    m_tracerLabel2->position->setCoords(0, 0);
    m_tracerLabel2->setTextAlignment(Qt::AlignRight);
    m_tracerLabel2->setFont(QFont(font().family(), 12));
    m_tracerLabel2->setPadding(QMargins(9, 3, 3, 9));
    strData.sprintf("(%0.5f, %0.5f)", xValue2, yValue2);
    m_tracerLabel2->setText(strData);

#ifdef _QSS_
    m_tracerLabel2->setColor(Qt::white);
    m_tracerLabel->setColor(Qt::white);
    m_tracer->setPen(QPen(Qt::cyan));
    m_tracer2->setPen(QPen(Qt::darkMagenta));
    m_tracer->setBrush(QBrush(Qt::cyan));
    m_tracer2->setBrush(QBrush(Qt::darkMagenta));
#endif

    m_tracer2->setVisible(true);
    m_tracerLabel->setVisible(true);
    m_tracerLabel2->setVisible(true);

#endif
    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}

void MainWindow::on_action_Save_triggered()
{
    if (ui->widgetGraph->graphCount() < 2)
    {
        QMessageBox::information(this, "Save Graph !?", "No graph plotted to save");
        return;
    }

    m_tracer->setVisible(false);
    m_tracer2->setVisible(false);
    m_tracerLine->setVisible(false);
    m_tracerLabel->setVisible(false);
    m_tracerLabel2->setVisible(false);
    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);

    QString strSavePDF_Filename = QFileDialog::getSaveFileName(this, "Save Graph as PDF", "../OutputFiles/", "PDF File (*.pdf)");

    if (strSavePDF_Filename.isEmpty())
    {
        QMessageBox::information(this, "Save Graph as PDF", "No file selected");
        return;
    }

    if (!(strSavePDF_Filename.endsWith(".pdf") || strSavePDF_Filename.endsWith(".PDF")))
    {
        strSavePDF_Filename.append(".pdf");
    }

    bool bOk = ui->widgetGraph->savePdf(strSavePDF_Filename);
    if (bOk)
    {
        QMessageBox::information(this, "Graph Saved :)", "Graph has been saved in <b><i><code>" + strSavePDF_Filename);
    }
    else
    {
        QMessageBox::information(this, "Graph Unsaved :(", "Error saving Graph as PDF");
    }

    m_tracer->setVisible(true);
    m_tracer2->setVisible(true);
    m_tracerLine->setVisible(true);
    m_tracerLabel->setVisible(true);
    m_tracerLabel2->setVisible(true);
    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}
