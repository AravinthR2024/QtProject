#ifndef MACROS
#define MACROS

#define _QSS_        /** define _QSS_ for Dark Mode, undef for Light Mode */

#ifdef _QSS_    /* APPEARANCE FOR DARK MODE */

#define GRAPH_BACKGROUND_COLOR          QColor(0x00, 0x00, 0x00)        /* BLACK */
#define LEGEND_TEXT_COLOR               QColor(0xFF, 0xFF, 0xFF)        /* WHITE */
#define GRID_COLOR                      QColor(0xA0, 0xA0, 0xA4)        /* GRAY */
#define YAXIS2_BASE_TICK_COLOR          QColor(0x00, 0xFF, 0xFF)        /* CYAN */
#define TRACER2_COLOR                   QColor(0x00, 0x80, 0x80)        /* DARK CYAN */

#else           /* APPEARANCE FOR LIGHT MODE */

#define GRAPH_BACKGROUND_COLOR          QColor(0xFF, 0xFF, 0xFF)        /* WHITE */
#define LEGEND_TEXT_COLOR               QColor(0x00, 0x00, 0x00)        /* BLACK */
#define GRID_COLOR                      QColor(0x00, 0x00, 0x00)        /* BLACK */
#define YAXIS2_BASE_TICK_COLOR          QColor(0x00, 0x00, 0xFF)        /* BLUE */
#define TRACER2_COLOR                   QColor(0x00, 0x00, 0x80)        /* DARK BLUE */

#endif

/* APPEARANCE WITH NO CHANGE FOR DARK OR LIGHT MODE */
#define SUBGRID_COLOR                   QColor(0x80, 0x80, 0x80)        /* DARK GRAY */

#define XAXIS_BASE_TICK_COLOR           GRID_COLOR
#define YAXIS_BASE_TICK_COLOR           QColor(0xFF, 0x00, 0x00)        /* RED */

#define LEGEND_COLOR                    GRAPH_BACKGROUND_COLOR
#define LEGEND_BORDER_COLOR             QColor(0xC0, 0xC0, 0xC0)        /* LIGHT GRAY */

#define LABEL_FONT                      QFont("Arial", 13)

#define TRACER_STYLE                    QCPItemTracer::tsCircle
#define TRACER_SIZE                     10.0
#define TRACER_LINE_COLOR               QColor(0x80, 0x80, 0x00)        /* DARK YELLOW */

#define TRACER1_COLOR                   QColor(0x80, 0x00, 0x00)        /* DARK RED */
#define TRACER1_LABEL_POSITION          Qt::AlignLeft | Qt::AlignRight

#define TRACER2_LABEL_POSITION          Qt::AlignRight | Qt::AlignBottom

#define MOUSE_TRACER_LABEL_COLOR        LEGEND_TEXT_COLOR
#define MOUSE_TRACER_COLOR              QColor(0x00, 0x80, 0x80)        /* DARK CYAN */
#define MOUSE_TRACER2_COLOR             QColor(0x80, 0x00, 0x80)        /* DARK MAGENTA */

#define ENABLE_BODE_GRAPH(graph) {\
    QSharedPointer<QCPAxisTickerLog> ticker(new QCPAxisTickerLog);\
    graph->xAxis->setTicker(ticker);\
    graph->xAxis->setScaleType(QCPAxis::stLogarithmic);\
    graph->yAxis->ticker().data()->setTickCount(10);\
    graph->yAxis2->ticker().data()->setTickCount(10);\
}

#define SET_PLOT_BUTTON(text, isEnabled, button) {\
    button->setText(text);\
    button->setEnabled(isEnabled);\
}

#define SET_TRACING_STATE(state) {\
    m_tracer->setVisible(state);\
    m_tracer2->setVisible(state);\
    m_tracerLine->setVisible(state);\
    m_tracerLabel->setVisible(state);\
    m_tracerLabel2->setVisible(state);\
    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);\
}

#endif // MACROS

