#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QMessageBox>
#include <QVector>
#include <QVectorIterator>

#include "qcustomplot.h"
#include "fileopendialog.h"

#include "macros.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    QString m_strLogFileName;
    bool m_bIsLogFileLoaded;
    QVector<double> m_dvectFrequencyList;
    QVector<double> m_dvectGainList;
    QVector<double> m_dvectPhaseList;

    QCPItemLine *m_tracerLine;
    QCPItemTracer *m_tracer;
    QCPItemText *m_tracerLabel;

    QCPItemTracer *m_tracer2;
    QCPItemText *m_tracerLabel2;

#if 0
    QCPGraph graph[2];
    QVector<QCPItemText*> vectItemText;
#endif

    CFileOpenDialog *m_pFileOpenDialog;

    void initGraph();
    void setGraphAppearance();
    bool readLogFileLines(QStringList *out_strLines);
    bool parseLogData (QStringList in_strLog, QVector<double> *out_dvectFrequency, QVector<double> *out_dvectGain, QVector<double> *out_dvectPhase);
    void getRange(QVector<double> in_dVector, double *out_pdLower, double *out_pdUpper);
    bool plotGraph(QVector<double> in_dvectFrequency, QVector<double> in_dvectGain, QVector<double> in_dvectPhase);
    void saveGraph(QString in_qstrFilename);


private slots:
    void on_action_Choose_File_triggered();

    void on_pbPlot_clicked();

    void slot_mouseDoubleClicked(QMouseEvent *in_pMevent);

    void slot_mouseMoved(QMouseEvent *in_pMevent);

    void on_action_Save_triggered();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
