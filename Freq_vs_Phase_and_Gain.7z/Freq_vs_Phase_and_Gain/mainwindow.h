#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QMessageBox>

#include "qcustomplot.h"
#include "fileopendialog.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    QString m_strLogFileName;
    bool m_bIsLogFileLoaded;

    CFileOpenDialog *m_objFileOpenDialog;

    void initGraph();
    bool readLogFile(QStringList *out_strLines);
    bool extractLogData (QStringList in_strLog, QVector<double> *out_dvectFrequency, QVector<double> *out_dvectGain, QVector<double> *out_dvectPhase);
    bool plotGraph(QVector<double> in_dvectFrequency, QVector<double> in_dvectGain, QVector<double> in_dvectPhase);

private slots:
    void on_action_Choose_File_triggered();

    void on_pbPlot_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
