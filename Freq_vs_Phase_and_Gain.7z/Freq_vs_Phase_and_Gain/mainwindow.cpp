/**************************************************************************
// File Name: mainwindow.cpp
// Author: aravinth.rajalingam
// Created Date: 15th September, 2022
// Description: This file provides all the functions for
                    Frequency-vs-Gain-and-Phase Graph
**************************************************************************/

#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    initGraph();
    m_pFileOpenDialog   = new CFileOpenDialog(this);
    m_strLogFileName    = QString();

    connect(ui->widgetGraph, SIGNAL(mouseDoubleClick(QMouseEvent*)), this, SLOT(slot_mouseDoubleClicked(QMouseEvent*)));
    connect(ui->widgetGraph, SIGNAL(mouseMove(QMouseEvent*)), this, SLOT(slot_mouseMoved(QMouseEvent*)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

/**************************************************************************
// Name: initGraph
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Used to initialize graph and set graph appearance.
***********************************************************************//**
 * @brief MainWindow::initGraph
 */
void MainWindow::initGraph()
{
    /* Clear all graphs, tracers, tracer lines and tracer labels, if any */
    if (ui->widgetGraph->graphCount() > 0)
    {
        ui->widgetGraph->clearItems();
        ui->widgetGraph->clearGraphs();
    }

#if 0
    QCPItemText *tempItemTemp = NULL;
    while(vectItemText.size())
    {
        tempItemTemp = vectItemText.at(0);
        if(ui->widgetGraph->hasItem(tempItemTemp))
        {
            ui->widgetGraph->removeItem(tempItemTemp);
        }
        vectItemText.pop_front();
    }
#endif

    /* Set user-interactions allowed in the graph plot -> Drag Range, Zoom Range */
    ui->widgetGraph->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);

    /* Show Legend, X-Axis, Y-Axis, Y2-Axis and Hide X2-Axis */
    ui->widgetGraph->legend->setVisible(true);
    ui->widgetGraph->xAxis->setVisible(true);
    ui->widgetGraph->yAxis->setVisible(true);
    ui->widgetGraph->xAxis2->setVisible(false);
    ui->widgetGraph->yAxis2->setVisible(true);

    /* Setting label for X, Y and Y2 Axes */
    ui->widgetGraph->xAxis->setLabel("Frequency (Hz)");
    ui->widgetGraph->yAxis->setLabel("Gain (dB)");
    ui->widgetGraph->yAxis2->setLabel("Phase (degree)");

    /* Only show subgrids for X-Axis */
    ui->widgetGraph->xAxis->grid()->setSubGridVisible(true);

    /* Create a tracer(cursor) for 1st graph (Gain) */
    m_tracer = new QCPItemTracer(ui->widgetGraph);

#if 0
    m_tracer->position->setType(QCPItemPosition::ptViewportRatio);
#endif

    /* Create tracer label (text on tracer) */
    m_tracerLabel = new QCPItemText(ui->widgetGraph);
    m_tracerLabel->setLayer("overlay");

    /* Make the tracer label change position with respect to the tracer */
    m_tracerLabel->position->setParentAnchor(m_tracer->position);
    m_tracerLabel->position->setCoords(0,0);

    /* Create tracer line */
    m_tracerLine = new QCPItemLine(ui->widgetGraph);
    m_tracerLine->start->setCoords(0, 0);
    m_tracerLine->end->setCoords(0, 0);

    /* Hide tracer, tracer label, tracer line initially */
    m_tracerLine->setVisible(false);
    m_tracerLabel->setVisible(false);
    m_tracer->setVisible(false);

    /* Creating tracer, tracer label for 2nd graph (Phase) */
    m_tracer2 = new QCPItemTracer(ui->widgetGraph);
    m_tracer2->position->setType(QCPItemPosition::ptViewportRatio);
    m_tracerLabel2 = new QCPItemText(ui->widgetGraph);
    m_tracerLabel2->setLayer("overlay");
    m_tracerLabel2->position->setParentAnchor(m_tracer2->position);
    m_tracerLabel2->position->setCoords(0, 0);
    m_tracer2->setVisible(false);
    m_tracerLabel2->setVisible(false);

    /* Change graph styling */
    setGraphAppearance();

    /** Enabling Bode Graph */
    ENABLE_BODE_GRAPH(ui->widgetGraph);

    /* Make sure to replot to reflect the changes */
    ui->widgetGraph->replot();
}

/**************************************************************************
// Name: setGraphAppearance
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Used to change the Graph style.
***********************************************************************//**
 * @brief MainWindow::setGraphAppearance
 */
void MainWindow::setGraphAppearance()
{
    /* Create a Dash lined pen */
    QPen pen(Qt::DashLine);
    pen.setColor(GRID_COLOR);

    /* Set pen style for all axes */
    ui->widgetGraph->xAxis->grid()->setPen(pen);
    ui->widgetGraph->yAxis->grid()->setPen(pen);
    ui->widgetGraph->yAxis2->grid()->setPen(pen);

    /* Change X-axis subgrid style */
    pen.setColor(SUBGRID_COLOR);
    ui->widgetGraph->xAxis->grid()->setSubGridPen(pen);

    /* Change Gain tracer style */
    m_tracer->setPen(QPen(TRACER1_COLOR));
    m_tracer->setBrush(QBrush(TRACER1_COLOR));
    m_tracer->setStyle(TRACER_STYLE);
    m_tracer->setSize(TRACER_SIZE);

    /* Change Gain tracer label style */
    m_tracerLabel->setPen(QPen(TRACER1_COLOR));
    m_tracerLabel->setPositionAlignment(TRACER1_LABEL_POSITION);

    /* Change tracer line style */
    m_tracerLine->setPen(QPen(TRACER_LINE_COLOR));

    /* Change Phase tracer style */
    m_tracer2->setPen(QPen(TRACER2_COLOR));
    m_tracer2->setBrush(QBrush(TRACER2_COLOR));
    m_tracer2->setStyle(TRACER_STYLE);
    m_tracer2->setSize(TRACER_SIZE);

    /* Change Phase tracer label style */
    m_tracerLabel2->setPen(QPen(TRACER2_COLOR));
    m_tracerLabel2->setPositionAlignment(TRACER2_LABEL_POSITION);

    /* Set Graph Background */
    ui->widgetGraph->setBackground(QBrush(GRAPH_BACKGROUND_COLOR));

    /* Change legend style */
    ui->widgetGraph->legend->setBrush(QBrush(LEGEND_COLOR));
    ui->widgetGraph->legend->setTextColor(LEGEND_TEXT_COLOR);
    ui->widgetGraph->legend->setBorderPen(QPen(LEGEND_BORDER_COLOR));

    /* Change Base color for all axes */
    ui->widgetGraph->xAxis->setBasePen(QPen(XAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis->setBasePen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis2->setBasePen(QPen(YAXIS2_BASE_TICK_COLOR));

    /* Change tick style for all axes */
    ui->widgetGraph->xAxis->setTickPen(QPen(XAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis->setTickPen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis2->setTickPen(QPen(YAXIS2_BASE_TICK_COLOR));

    /* Change subtick style for all axes */
    ui->widgetGraph->xAxis->setSubTickPen(QPen(XAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis->setSubTickPen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->yAxis2->setSubTickPen(QPen(YAXIS2_BASE_TICK_COLOR));

    /* Change label color, font for all axes */
    ui->widgetGraph->xAxis->setLabelColor(XAXIS_BASE_TICK_COLOR);
    ui->widgetGraph->yAxis->setLabelColor(YAXIS_BASE_TICK_COLOR);
    ui->widgetGraph->yAxis2->setLabelColor(YAXIS2_BASE_TICK_COLOR);
    ui->widgetGraph->xAxis->setLabelFont(LABEL_FONT);
    ui->widgetGraph->yAxis->setLabelFont(LABEL_FONT);
    ui->widgetGraph->yAxis2->setLabelFont(LABEL_FONT);

    /* Change tick label color for all axes */
    ui->widgetGraph->xAxis->setTickLabelColor(LEGEND_TEXT_COLOR);
    ui->widgetGraph->yAxis->setTickLabelColor(LEGEND_TEXT_COLOR);
    ui->widgetGraph->yAxis2->setTickLabelColor(LEGEND_TEXT_COLOR);
}

/**************************************************************************
// Name: readLogFileLines
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Used to return list of lines from Log file.
***********************************************************************//**
 * @brief MainWindow::readLogFileLines
 * @param[out] out_strLines     List of lines will be stored here
 * @return true     if read lines successful
 * @return false    if any error occured
 */
bool MainWindow::readLogFileLines(QStringList *out_strLines)
{
    QFile fpLogfile;
    QTextStream stream;

    /* Return false if no file name is set */
    if (m_strLogFileName.isEmpty())
    {
        return false;
    }

    fpLogfile.setFileName(m_strLogFileName);
    /* Return false if file not opened */
    if (!fpLogfile.open(QIODevice::ReadOnly))
    {
        qDebug("File open error");
        return false;
    }

    /* Set stream device as QFile pointer */
    stream.setDevice(&fpLogfile);

    /* Iterate through all the lines in the file */
    while (!stream.atEnd())
    {
        /* Append every line as a QString into out_strLines QStringList */
        out_strLines->append(stream.readLine());
    }

    /* Make sure to close the log file */
    fpLogfile.close();

    return true;
}

/**************************************************************************
// Name: extractLogData
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Used to parse data from list of lines
***********************************************************************//**
 * @brief MainWindow::extractLogData
 * @param[in] in_strLog     Contains the list of lines in the log file
 * @param[out] out_dvectFrequency   Frequency data will be stored here
 * @param[out] out_dvectGain        Gain data will be stored here
 * @param[out] out_dvectPhase       Phase data will be store here
 * @return true     If data parse successful
 * @return false    If any error occured
 */
bool MainWindow::parseLogData(QStringList in_strLog, QVector<double> *out_dvectFrequency, \
                                QVector<double> *out_dvectGain, QVector<double> *out_dvectPhase)
{
    bool bOk        = false;
    double dTemp    = 0.0;
    int iCount      = 0;
    QStringList strTempList = QStringList();

    /* Clear the output vectors, incase if any */
    out_dvectFrequency->clear();
    out_dvectGain->clear();
    out_dvectPhase->clear();

    /* Return false if list of lines is empty */
    if (in_strLog.isEmpty())
    {
        return false;
    }

    /* Iterate through all lines in the list */
    foreach (QString strLine, in_strLog)
    {
        iCount = 0;
        /* Trim (to clear trailing spaces) and split with ',' */
        strTempList = strLine.trimmed().split(",");

        /* Iterate the splitted list */
        foreach (QString strTemp, strTempList)
        {
            /* Typecast first data to double, if cannot typecast, then return false */
            dTemp = strTemp.toDouble(&bOk);
            if (!bOk) return false;

            switch (iCount)
            {
            case 0: /* If 1st cycle, then append data to Frequency vector */
            {
                out_dvectFrequency->append(dTemp);
                break;
            }
            case 1: /* If 2nd cycle, then append data to Gain vector */
            {
                out_dvectGain->append(dTemp);
                break;
            }
            case 2: /* If 3rd cycle, then append data to Phase vector */
            {
                out_dvectPhase->append(dTemp);
                break;
            }
            default:
            { return false; }
            }
            iCount++;   /* Increment iCount to go to next cycle */
        }
    }

    return true;
}

/**************************************************************************
// Name: getRange
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Used to get min and max range of data.
***********************************************************************//**
 * @brief MainWindow::getRange
 * @param[in] in_dVector    Contains vector for which to find range
 * @param[out] out_pdLower  Lower limit(Min range) will be stored
 * @param[out] out_pdUpper  Upper limit(Max range) will be stored
 */
void MainWindow::getRange(QVector<double> in_dVector, double *out_pdLower, double *out_pdUpper)
{
    double dTemp = 0.0;

    *out_pdUpper = INT_MIN; /* Set upper limit to be minimum value initially */
    *out_pdLower = INT_MAX; /* Set lower limit to be maximum value initially */

    /* Create a QVectorIterator to iterate input vector */
    QVectorIterator<double> iter(in_dVector);

    /* Iterate all the elements of vector */
    while (iter.hasNext())
    {
        dTemp = iter.next();

        /* If element is greater than upper limit, then the element is new upper limit */
        if (dTemp > *out_pdUpper)
        {
            *out_pdUpper = dTemp;
        }

        /* If element is lesser than lower limit, then the element is new lower limit */
        if (dTemp < *out_pdLower)
        {
            *out_pdLower = dTemp;
        }
    }
}

/**************************************************************************
// Name: plotGraph
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Used to plot the graph for input data (frequency, gain, phase)
***********************************************************************//**
 * @brief MainWindow::plotGraph
 * @param[in] in_dvectFrequency Contains the data for Frequency (X-Axis)
 * @param[in] in_dvectGain      Contains the data for Gain (Y-Axis)
 * @param[in] in_dvectPhase     Contains the data for Phase (Y2-Axis)
 * @return true     If plotting is successful
 * @return false    If any error occured
 */
bool MainWindow::plotGraph(QVector<double> in_dvectFrequency, QVector<double> in_dvectGain, \
                           QVector<double> in_dvectPhase)
{
    double dLowerLimit = 0.0;
    double dUpperLimit = 0.0;

    /* If any of the input is empty, return false */
    if (in_dvectFrequency.isEmpty() || in_dvectGain.isEmpty() || in_dvectPhase.isEmpty())
    {
        return false;
    }

    /* If all inputs does not have same number of data, return false */
    if ((in_dvectFrequency.length() != in_dvectGain.length()) \
            || (in_dvectGain.length() != in_dvectPhase.length()) \
            || (in_dvectPhase.length() != in_dvectFrequency.length()))
    {
        return false;
    }

    /* Initialize graph to remove previous plots (if any) */
    initGraph();

    /* Add 2 new graphs */
    ui->widgetGraph->addGraph(ui->widgetGraph->xAxis, ui->widgetGraph->yAxis);  /* Frequency-Gain graph, X-Y plot */
    ui->widgetGraph->addGraph(ui->widgetGraph->xAxis, ui->widgetGraph->yAxis2); /* Frequency-Phase grah, X-Y2 plot */

    /* Set pen style for both graphs */
    ui->widgetGraph->graph(0)->setPen(QPen(YAXIS_BASE_TICK_COLOR));
    ui->widgetGraph->graph(1)->setPen(QPen(YAXIS2_BASE_TICK_COLOR));

#if 0
    ui->widgetGraph->graph(0)->setSelectable(QCP::stMultipleDataRanges);
    ui->widgetGraph->graph(1)->setSelectable(QCP::stMultipleDataRanges);
#endif

    /* Set names for both graph (Displayed in legend) */
    ui->widgetGraph->graph(0)->setName("Gain");
    ui->widgetGraph->graph(1)->setName("Phase");

    /* Set range for Frequency (X-Axis) */
    getRange(in_dvectFrequency, &dLowerLimit, &dUpperLimit);
    ui->widgetGraph->xAxis->setRange(dLowerLimit, dUpperLimit);

    /* Set range for Gain (Y-Axis) */
    getRange(in_dvectGain, &dLowerLimit, &dUpperLimit);
    ui->widgetGraph->yAxis->setRange(dLowerLimit, dUpperLimit);

    /* Set range for Phase (Y2-Axis) */
    getRange(in_dvectPhase, &dLowerLimit, &dUpperLimit);
    ui->widgetGraph->yAxis2->setRange(dLowerLimit, dUpperLimit);

    /* Set the data and line style for both graphs */
    ui->widgetGraph->graph(0)->setData(in_dvectFrequency, in_dvectGain);
    ui->widgetGraph->graph(0)->setLineStyle(QCPGraph::lsLine);
    ui->widgetGraph->graph(1)->setData(in_dvectFrequency, in_dvectPhase);
    ui->widgetGraph->graph(1)->setLineStyle(QCPGraph::lsLine);

    /* Make sure to replot to reflect the changes */
    ui->widgetGraph->replot();

    return true;
}

/**************************************************************************
// Name: saveGraph
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Used to save the graph as PDF.
***********************************************************************//**
 * @brief MainWindow::saveGraph
 * @param[in] in_qstrFilename   Contains the save as filename
 */
void MainWindow::saveGraph(QString in_qstrFilename)
{
    bool bIsSuccess     = false;
    QString qstrTitle   = QString("");
    QString qstrMessage = QString("");

    /* Hide tracer, tracer label, tracer line */
    SET_TRACING_STATE(false);

    /* Save the graph with given filename */
    bIsSuccess = ui->widgetGraph->savePdf(in_qstrFilename);
    if (bIsSuccess)
    {
        qstrTitle.sprintf("Graph Saved :)");
        qstrMessage = QString("Graph saved <a style=\"color: white;\" href=\"file:///%1\">here!</a>")\
                .arg(in_qstrFilename);  /* Display saved message with link to the file */
    }
    else
    {
        qstrTitle.sprintf("Graph Unsaved :(");
        qstrMessage.sprintf("Error saving Graph as PDF");
    }

    /* Display success or error message */
    QMessageBox::information(this, qstrTitle, qstrMessage);

    /* Re-show the tracer, tracer label, tracer line */
    SET_TRACING_STATE(true);
}

/**************************************************************************
// Name: on_action_Choose_File_triggered
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Called when Load menu action is clicked.
                Used to open Fileopen dialog to select log file to plot.
***********************************************************************//**
 * @brief MainWindow::on_action_Choose_File_triggered
 */
void MainWindow::on_action_Choose_File_triggered()
{
    QString strMessage = QString();
    QFileInfo qfileInfo = QFileInfo();

    /* Return if CFileOpenDialog object is not valid */
    if (!m_pFileOpenDialog)
    {
        return;
    }

    /* Execute CFileOpenDialog */
    m_pFileOpenDialog->exec();

    /* Check if log filename is selected */
    if (m_pFileOpenDialog->m_strLogFilename.isEmpty())
    {
        strMessage.append("No Log file selected...\n");

        /* If any log file is previously selected (this->m_strLogFileName not empty), then continue with that */
        if (!m_strLogFileName.isEmpty())
        {
            /* Get fileinfo of current logfile */
            qfileInfo.setFile(m_strLogFileName);

            /* Display previous log file name */
            strMessage.append("Continuing with previous log file <b>" + qfileInfo.fileName() + "</b>\n");
        }

        /* Display the message */
        QMessageBox::information(this, "Log file", strMessage.trimmed());
        return;
    }

    /* Set current Log filename as selected filename */
    m_strLogFileName = m_pFileOpenDialog->m_strLogFilename;

    /* Get fileinfo of log file */
    qfileInfo.setFile(m_strLogFileName);

    /* Display log file name */
    QMessageBox::information(this, "Configuration", "Log file loaded : <b>" + qfileInfo.fileName());
}

/**************************************************************************
// Name: on_pbPlot_clicked
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Called when Plot button is clicked.
                Used to read log file and plot the graph.
***********************************************************************/
void MainWindow::on_pbPlot_clicked()
{
    bool bIsSuccess             = false;
    QStringList strLogfileLines = QStringList();

    /* Disable Plot Button */
    SET_PLOT_BUTTON ("Plotting...", false, ui->pbPlot);

    /* Read all lines from log file */
    bIsSuccess = readLogFileLines(&strLogfileLines);
    if (!bIsSuccess)    /* If read lines failed, then terminate */
    {
        QMessageBox::information(this, "File error", "Cannot read log file data");
        SET_PLOT_BUTTON("&Plot", true, ui->pbPlot); /* Re-enable Plot Button */
        return;
    }

    bIsSuccess = false;

    /* Parse data from log file lines */
    bIsSuccess = parseLogData(strLogfileLines, &m_dvectFrequencyList, &m_dvectGainList, &m_dvectPhaseList);
    if (!bIsSuccess)    /* If parsing failed, then termiante */
    {
        QMessageBox::information(this, "File error", "Cannot read log file data");
        SET_PLOT_BUTTON("&Plot", true, ui->pbPlot); /* Re-enable Plot Button */
        return;
    }

    bIsSuccess = false;

    /* Plot graph with parsed Frequency, Gain and Phase values */
    bIsSuccess = plotGraph(m_dvectFrequencyList, m_dvectGainList, m_dvectPhaseList);
    if (!bIsSuccess)    /* If plotting failed, then terminate */
    {
        initGraph();    /* Clear wrong graph (if any) */
        QMessageBox::information(this, "Graph Error", "Cannot plot graph");
        SET_PLOT_BUTTON("&Plot", true, ui->pbPlot); /* Re-enable Plot Button */
        return;
    }

    /* Re-enable Plot Button */
    SET_PLOT_BUTTON("&Plot", true, ui->pbPlot);
}

/**************************************************************************
// Name: slot_mouseDoubleClicked
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Called when QCustomPlot emits mouseDoubleClick signal.
                Used to fix label at current tracer position.
***********************************************************************//**
 * @brief MainWindow::slot_mouseDoubleClicked
 * @param[in] in_pMevent    Contains data of mouse event
 */
void MainWindow::slot_mouseDoubleClicked(QMouseEvent *in_pMevent)
{
    /* Ignore if other than left mouse button is clicked */
    if (in_pMevent->button() != Qt::LeftButton)
    {
        return;
    }

    /* Ignore if number of graphs is not equal to 2 */
    if (ui->widgetGraph->graphCount() != 2)
    {
        return;
    }

    double xValue       = 0.0;
    double yValue       = 0.0;
    QString qstrData    = QString("");
    QPointF qPos        = QPointF();
    QPointF qPos2       = QPointF();
    QCPItemText *pTracerLabel = NULL;

    /* Set tracer for Gain Graph (Y-Axis) and tracer2 for Phase Graph (Y2-Axis) */
    m_tracer->setGraph(ui->widgetGraph->graph(0));
    m_tracer2->setGraph(ui->widgetGraph->graph(1));

    /* Get the position in pixels of both tracers */
    qPos = m_tracer->position->pixelPosition();
    qPos2 = m_tracer2->position->pixelPosition();

    /* Create a tracer label for Gain graph */
    pTracerLabel = new QCPItemText(ui->widgetGraph);
    pTracerLabel->setLayer("overlay");
#if 0
//    vectItemText.push_back(pTracerLabel);
#endif

    /* Set style for tracer label */
    pTracerLabel->setPen(QPen(YAXIS_BASE_TICK_COLOR));
    pTracerLabel->setColor(MOUSE_TRACER_LABEL_COLOR);
    pTracerLabel->setPositionAlignment(TRACER1_LABEL_POSITION);

    /* Get X(Frequency) and Y(Gain) values from the tracer */
    xValue = m_tracer->position->key();
    yValue = m_tracer->position->value();
    qstrData.sprintf("%0.5f - Freq(Hz)\n %0.5f - Gain(Deg)", xValue, yValue);

    /* Set label at the tracer position (fixed) */
    pTracerLabel->position->setPixelPosition(qPos);
    pTracerLabel->setText(qstrData);

    /* Replot to reflect the changes */
    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);

    /* Create a tracer label for Phase graph */
    pTracerLabel = new QCPItemText(ui->widgetGraph);
    pTracerLabel->setLayer("overlay");
#if 0
//    vectItemText.push_back(pTracerLabel);
#endif

    /* Set style for tracer label */
    pTracerLabel->setPen(QPen(YAXIS2_BASE_TICK_COLOR));
    pTracerLabel->setColor(LEGEND_TEXT_COLOR);
    pTracerLabel->setPositionAlignment(TRACER2_LABEL_POSITION);

    /* Get X(Frequency) and Y(Phase) values from the tracer2 */
    xValue = m_tracer2->position->key();
    yValue = m_tracer2->position->value();
    qstrData.sprintf("%0.5f - Freq(Hz)\n%0.5f - Phase(Deg)", xValue, yValue);

    /* Set label at the tracer2 position (fixed) */
    pTracerLabel->position->setPixelPosition(qPos2);
    pTracerLabel->setText(qstrData);

    /* Replot to reflect the changes */
    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}

/**************************************************************************
// Name: slot_mouseMoved
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Called when QCustomPlot emits mouseMove signal.
                Used to trace both graphs.
***********************************************************************//**
 * @brief MainWindow::slot_mouseMoved
 * @param[in] in_pMevent    Contains data of mouse event
 */
void MainWindow::slot_mouseMoved(QMouseEvent *in_pMevent)
{
    /* Ignore if number of graph is not 2 */
    if (ui->widgetGraph->graphCount() < 2)
    {
        return;
    }

    QString qstrData    = QString("");
    double dMouseX      = 0.0;
    double dStart       = 0.0;
    double dEnd         = 0.0;
    double dValueX      = 0.0;
    double dValueY      = 0.0;

    /* Get X value of mouse position */
    dMouseX = ui->widgetGraph->xAxis->pixelToCoord(in_pMevent->pos().x());

    /* Get start and end (0 and height of graph) */
    dStart = ui->widgetGraph->yAxis->pixelToCoord(0);
    dEnd = ui->widgetGraph->yAxis->pixelToCoord(ui->widgetGraph->size().height());

    /* Set tracer line start at (mouseX, start) and ends at (mouseX, end) */
    m_tracerLine->start->setCoords(dMouseX, dStart);
    m_tracerLine->end->setCoords(dMouseX, dEnd);

    /* Set tracer for Gain graph */
    m_tracer->setGraph(ui->widgetGraph->graph(0));

    /* Set tracer position key to mouseX */
    m_tracer->setGraphKey(dMouseX);

    /* Set interpolation for the graph
     * Enable to trace along the plot
     * Else only plotted data points is positioned */
    m_tracer->setInterpolating(true);

    /* Update position everytime to move tracer to new position */
    m_tracer->updatePosition();

    /* Get X(Frequency) and Y(Gain) values from tracer position */
    dValueX = m_tracer->position->key();
    dValueY = m_tracer->position->value();
    qstrData.sprintf("(%0.5f, %0.5f)", dValueX, dValueY);

    /* Set label position */
    m_tracerLabel->position->setType(QCPItemPosition::ptAbsolute);
    m_tracerLabel->setPositionAlignment(TRACER1_LABEL_POSITION);
    m_tracerLabel->position->setCoords(1.0, 1);

    /* Set tracer style */
    m_tracer->setPen(QPen(MOUSE_TRACER_COLOR));
    m_tracer->setBrush(QBrush(MOUSE_TRACER_COLOR));

    /* Set label style */
    m_tracerLabel->setTextAlignment(Qt::AlignRight);
    m_tracerLabel->setFont(QFont(font().family(), 12));
    m_tracerLabel->setPadding(QMargins(9, 3, 3, 9));
    m_tracerLabel->setColor(LEGEND_TEXT_COLOR);
    m_tracerLabel->setText(qstrData);   /* Display label */

    /* Set tracer2 for Gain graph */
    m_tracer2->setGraph(ui->widgetGraph->graph(1));

    /* Set tracer position key to mouseX */
    m_tracer2->setGraphKey(dMouseX);

    /* Set interpolation for the graph
     * Enable to trace along the plot
     * Else only plotted data points is positioned */
    m_tracer2->setInterpolating(true);

    /* Update position everytime to move tracer2 to new position */
    m_tracer2->updatePosition();

    /* Get X(Frequency) and Y(Gain) values from tracer2 position */
    dValueX = m_tracer2->position->key();
    dValueY = m_tracer2->position->value();
    qstrData.sprintf("(%0.5f, %0.5f)", dValueX, dValueY);

    /* Set label2 position */
    m_tracerLabel2->position->setType(QCPItemPosition::ptAbsolute);
    m_tracerLabel2->setPositionAlignment(TRACER2_LABEL_POSITION);
    m_tracerLabel2->position->setCoords(0, 0);

    /* Set tracer2 style */
    m_tracer2->setPen(QPen(MOUSE_TRACER2_COLOR));
    m_tracer2->setBrush(QBrush(MOUSE_TRACER2_COLOR));

    /* Set label2 style */
    m_tracerLabel2->setTextAlignment(Qt::AlignRight);
    m_tracerLabel2->setFont(QFont(font().family(), 12));
    m_tracerLabel2->setPadding(QMargins(9, 3, 3, 9));
    m_tracerLabel2->setColor(LEGEND_TEXT_COLOR);
    m_tracerLabel2->setText(qstrData);  /* Display label2 */

    /* Show tracer, tracer label for both graph */
    m_tracer->setVisible(true);
    m_tracerLabel->setVisible(true);
    m_tracerLine->setVisible(true);
    m_tracer2->setVisible(true);
    m_tracerLabel->setVisible(true);
    m_tracerLabel2->setVisible(true);

    /* Replot graph to reflect the changes */
    ui->widgetGraph->replot(QCustomPlot::rpImmediateRefresh);
}

/**************************************************************************
// Name: on_action_Save_triggered
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Called when Save menu action is clicked.
                Used to get Save as file name and save graph as PDF.
***********************************************************************/
void MainWindow::on_action_Save_triggered()
{
    /* Ignore if number of graph is not 2 */
    if (ui->widgetGraph->graphCount() < 2)
    {
        QMessageBox::information(this, "Save Graph :|", "No graph plotted to save");
        return;
    }

    /* Get save as filename */
    QString strSavePDF_Filename = QFileDialog::getSaveFileName(this, "Save Graph as PDF", "../OutputFiles/", "PDF File (*.pdf)");

    /* Ignore if filename is empty (not selected) */
    if (strSavePDF_Filename.isEmpty())
    {
        QMessageBox::information(this, "Save Graph as PDF :|", "No file selected");
        return;
    }

    /* Ensure filename ends with .pdf extension */
    if (!(strSavePDF_Filename.endsWith(".pdf") || strSavePDF_Filename.endsWith(".PDF")))
    {
        strSavePDF_Filename.append(".pdf");
    }

    /* Save graph */
    saveGraph(strSavePDF_Filename);
}
