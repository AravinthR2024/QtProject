#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

//    ui->widgetGraph->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);

//    ui->widgetGraph->legend->setVisible(true);
//    ui->widgetGraph->xAxis->setVisible(false);
//    ui->widgetGraph->yAxis->setVisible(true);
//    ui->widgetGraph->xAxis2->setVisible(false);
//    ui->widgetGraph->yAxis2->setVisible(true);

    initGraph();

    m_objFileOpenDialog = new CFileOpenDialog(this);

    m_strLogFileName = QString();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::initGraph()
{
    ui->widgetGraph->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);

    ui->widgetGraph->legend->setVisible(true);
    ui->widgetGraph->xAxis->setVisible(true);
    ui->widgetGraph->yAxis->setVisible(true);
    ui->widgetGraph->xAxis2->setVisible(false);
    ui->widgetGraph->yAxis2->setVisible(true);

    ui->widgetGraph->xAxis->setLabel("Frequency (Hz)");
    ui->widgetGraph->yAxis->setLabel("Gain (dB)");
    ui->widgetGraph->yAxis2->setLabel("Phase (degree)");

    ui->widgetGraph->xAxis->grid()->setSubGridVisible(true);

    QPen pen(Qt::DashLine);
    pen.setColor(Qt::darkGray);
    ui->widgetGraph->xAxis->grid()->setSubGridPen(pen);
    ui->widgetGraph->xAxis->grid()->setPen(pen);
    ui->widgetGraph->yAxis->grid()->setPen(pen);
    ui->widgetGraph->yAxis2->grid()->setPen(pen);

    QSharedPointer<QCPAxisTickerLog> ticker(new QCPAxisTickerLog);
    ui->widgetGraph->xAxis->setTicker(ticker);
    ui->widgetGraph->xAxis->setScaleType(QCPAxis::stLogarithmic);

    ui->widgetGraph->yAxis->ticker().data()->setTickCount(10);
    ui->widgetGraph->yAxis2->ticker().data()->setTickCount(10);
}

bool MainWindow::readLogFile(QStringList *out_strLines)
{
    QFile fpLogfile;

    if (m_strLogFileName.isEmpty())
    {
        return false;
    }

    fpLogfile.setFileName(m_strLogFileName);
    if (!fpLogfile.open(QIODevice::ReadOnly))
    {
        qDebug("File open error");
        return false;
    }

    QTextStream stream(&fpLogfile);
    while (!stream.atEnd())
    {
        out_strLines->append(stream.readLine());
    }

    fpLogfile.close();


//    qDebug() << "FILE DATA FROM FUNCTION : " << *out_strLines;
    return true;
}

bool MainWindow::extractLogData(QStringList in_strLog, QVector<double> *out_dvectFrequency, \
                                QVector<double> *out_dvectGain, QVector<double> *out_dvectPhase)
{
    QStringList strTempList;
    bool bOk = false;
    double dTemp = 0.0;
    int iCount = 0;

    if (in_strLog.isEmpty())
    {
        return false;
    }

    foreach (QString strLine, in_strLog)
    {
        iCount = 0;
        strTempList = strLine.trimmed().split(",");
        foreach (QString strTemp, strTempList)
        {
            dTemp = strTemp.toDouble(&bOk);
            if (!bOk) return false;

            switch (iCount)
            {
            case 0:
            {
                out_dvectFrequency->append(dTemp);
                break;
            }
            case 1:
            {
                out_dvectGain->append(dTemp);
                break;
            }
            case 2:
            {
                out_dvectPhase->append(dTemp);
                break;
            }
            default:
            {return false;}
            }
            iCount++;
        }
    }

    return true;
}

bool MainWindow::plotGraph(QVector<double> in_dvectFrequency, QVector<double> in_dvectGain, \
                           QVector<double> in_dvectPhase)
{
    if (in_dvectFrequency.isEmpty() || in_dvectGain.isEmpty() || in_dvectPhase.isEmpty())
    {
        return false;
    }

    if ((in_dvectFrequency.length() != in_dvectGain.length()) \
            || (in_dvectGain.length() != in_dvectPhase.length()) \
            || (in_dvectPhase.length() != in_dvectFrequency.length()))
    {
        return false;
    }

    initGraph();

    ui->widgetGraph->addGraph(ui->widgetGraph->xAxis, ui->widgetGraph->yAxis);
    ui->widgetGraph->addGraph(ui->widgetGraph->xAxis, ui->widgetGraph->yAxis2);

    ui->widgetGraph->graph(0)->setPen(QPen(Qt::red));
    ui->widgetGraph->graph(1)->setPen(QPen(Qt::blue));
    ui->widgetGraph->graph(0)->setSelectable(QCP::stMultipleDataRanges);
    ui->widgetGraph->graph(1)->setSelectable(QCP::stMultipleDataRanges);
    ui->widgetGraph->graph(0)->setName("Gain");
    ui->widgetGraph->graph(1)->setName("Phase");

    ui->widgetGraph->xAxis->setRange(in_dvectFrequency.first() - 5, in_dvectFrequency.last() + 5);
    ui->widgetGraph->yAxis->setRange(in_dvectGain.first() - 5, in_dvectGain.last() + 5);
    ui->widgetGraph->yAxis2->setRange(in_dvectPhase.first() - 5, in_dvectPhase.last() + 5);

    ui->widgetGraph->graph(0)->setData(in_dvectFrequency, in_dvectGain);
    ui->widgetGraph->graph(0)->setLineStyle(QCPGraph::lsLine);
    ui->widgetGraph->graph(1)->setData(in_dvectFrequency, in_dvectPhase);
    ui->widgetGraph->graph(1)->setLineStyle(QCPGraph::lsLine);

    ui->widgetGraph->replot();

    return true;
}

void MainWindow::on_action_Choose_File_triggered()
{
    QString strMessage = QString();
    if (!m_objFileOpenDialog)
    {
        return;
    }
    m_objFileOpenDialog->exec();
    if (m_objFileOpenDialog->m_strLogFilename.isEmpty())
    {
        strMessage.append("No Log file selected...\n");
        if (!m_strLogFileName.isEmpty())
        {
            strMessage.append("Continuing with previous log file <b>" + m_strLogFileName + "</b>\n");
        }
        QMessageBox::information(this, "Log file", strMessage.trimmed());
        return;
    }

    m_strLogFileName = m_objFileOpenDialog->m_strLogFilename;
    QMessageBox::information(this, "Configuration", "Log file loaded : <b>" + m_strLogFileName);
}

void MainWindow::on_pbPlot_clicked()
{
    bool bOk = false;
    QStringList strLogfileLines;
    QVector<double> dvectFrequencyList;
    QVector<double> dvectGainList;
    QVector<double> dvectPhaseList;

    bOk = readLogFile(&strLogfileLines);

    if (!bOk)
    {
        QMessageBox::information(this, "File error", "Cannot read log file data");
        return;
    }

    bOk = false;
    bOk = extractLogData(strLogfileLines, &dvectFrequencyList, &dvectGainList, &dvectPhaseList);
    if (!bOk)
    {
        QMessageBox::information(this, "File error", "Cannot read log file data");
        return;
    }

    bOk = false;
    bOk = plotGraph(dvectFrequencyList, dvectGainList, dvectPhaseList);
    if (!bOk)
    {
        QMessageBox::information(this, "Graph Error", "Cannot plot graph");
        return;
    }
}
