#ifndef FILEOPENDIALOG_H
#define FILEOPENDIALOG_H

#include <QDialog>
#include <QFileDialog>
#include <QMessageBox>

namespace Ui {
class CFileOpenDialog;
}

class CFileOpenDialog : public QDialog
{
    Q_OBJECT

public:
    explicit CFileOpenDialog(QWidget *parent = 0);
    ~CFileOpenDialog();

    QString m_strLogFilename;

private slots:
    void on_pbBrowse_clicked();

    void on_pbOpenFile_clicked();

    void on_pbCancelBrowse_clicked();

private:
    Ui::CFileOpenDialog *ui;
};

#endif // FILEOPENDIALOG_H
