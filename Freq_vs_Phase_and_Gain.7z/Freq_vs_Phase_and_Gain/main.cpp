/**************************************************************************
// File Name: main.cpp
// Author: aravinth.rajalingam
// Created Date: 15th September, 2022
// Description: This file contains the main function for the project
**************************************************************************/

#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.showMaximized();

    return a.exec();
}
