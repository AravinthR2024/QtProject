#include "fileopendialog.h"
#include "ui_fileopendialog.h"

CFileOpenDialog::CFileOpenDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CFileOpenDialog)
{
    ui->setupUi(this);

    m_strLogFilename = QString();

    setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);
}

CFileOpenDialog::~CFileOpenDialog()
{
    delete ui;
}

void CFileOpenDialog::on_pbBrowse_clicked()
{
    QString strFilename = QString();

    strFilename = QFileDialog::getOpenFileName(this, "Log File", "./", "CSV (*.csv)");

    if (strFilename.isEmpty())
    {
        return;
    }
    ui->leFileName->setText(strFilename);
}

void CFileOpenDialog::on_pbOpenFile_clicked()
{
    if (ui->leFileName->text().isEmpty())
    {
        QMessageBox::information(this, "Log File", "Log file not selected...");
        return;
    }
    m_strLogFilename = ui->leFileName->text();
    on_pbCancelBrowse_clicked();
}

void CFileOpenDialog::on_pbCancelBrowse_clicked()
{
    this->close();
}
