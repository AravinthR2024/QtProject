/**************************************************************************
// File Name: fileopendialog.cpp
// Author: aravinth.rajalingam
// Created Date: 15th September, 2022
// Description: This file provides interface to select file to open
**************************************************************************/

#include "fileopendialog.h"
#include "ui_fileopendialog.h"

CFileOpenDialog::CFileOpenDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CFileOpenDialog)
{
    ui->setupUi(this);

    layout()->setSizeConstraint(QLayout::SetFixedSize);

    m_strLogFilename = QString();

    setWindowFlags(windowFlags() & ~Qt::WindowContextHelpButtonHint);
}

CFileOpenDialog::~CFileOpenDialog()
{
    delete ui;
}

/**************************************************************************
// Name: on_pbBrowse_clicked
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Called when Browse button is clicked.
                Used to open File browse dialog.
***********************************************************************//**
 * @brief CFileOpenDialog::on_pbBrowse_clicked
 */
void CFileOpenDialog::on_pbBrowse_clicked()
{
    QString strFilename = QString();

    strFilename = QFileDialog::getOpenFileName(this, "Log File", "../InputFiles/", "CSV (*.csv)");

    if (strFilename.isEmpty())
    {
        return;
    }
    ui->leFileName->setText(strFilename);
}

/**************************************************************************
// Name: on_pbOpenFile_clicked
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Called when Open button is clicked.
                Used to set the selected log file name.
***********************************************************************//**
 * @brief CFileOpenDialog::on_pbOpenFile_clicked
 */
void CFileOpenDialog::on_pbOpenFile_clicked()
{
    if (ui->leFileName->text().isEmpty())
    {
        QMessageBox::information(this, "Log File", "Log file not selected...");
        return;
    }
    m_strLogFilename = ui->leFileName->text();
    on_pbCancelBrowse_clicked();
}

/**************************************************************************
// Name: on_pbCancelBrowse_clicked
// Author: aravinth.rajalingam
// Global Variables affected: NA
// Created Date: 15th September, 2022
// Revision Date: NA
// Reason for Revising: NA
// Description: Called when Cancel button is clicked.
                Used to close the File browse dialog.
***********************************************************************/
void CFileOpenDialog::on_pbCancelBrowse_clicked()
{
    this->close();
}
