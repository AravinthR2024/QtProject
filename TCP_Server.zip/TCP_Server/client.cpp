#include "client.h"
#include "ui_client.h"

#include <QMessageBox>

CClient::CClient(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    m_pClientSocket = new QTcpSocket(this);
    ui->setupUi(this);
}

CClient::~CClient()
{
    delete ui;
}

void CClient::slot_displayError(QAbstractSocket::SocketError in_socketError)
{
    switch (in_socketError)
    {
    case QAbstractSocket::RemoteHostClosedError:
    {
        break;
    }
    case QAbstractSocket::HostNotFoundError:
    {
        QMessageBox::information(this, tr("Fortune Client"),
                                 tr("The host was not found. Please check the "
                                    "host name and port settings."));
        break;
    }
    case QAbstractSocket::ConnectionRefusedError:
    {
        QMessageBox::information(this, tr("Fortune Client"),
                                 tr("The connection was refused by the peer. "
                                    "Make sure the fortune server is running, "
                                    "and check that the host name and port "
                                    "settings are correct."));
        break;
    }
    default:
    {
        QMessageBox::information(this, tr("Fortune Client"),
                                 tr("The following error occurred: %1.")
                                 .arg(m_pClientSocket->errorString()));
    }
    }
}

void CClient::on_pbConnect_clicked()
{
    m_pClientSocket->connectToHost(ui->leClntIP->text(),quint16(ui->leClntPort->text().toInt()) );
    connect(m_pClientSocket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(slot_displayError(QAbstractSocket::SocketError)));
}

void CClient::on_pbSend_clicked()
{
    QString qstrMessage = ui->leClntMessage->text().trimmed();

    if(!qstrMessage.isEmpty())
    {
        m_pClientSocket->write(QString(qstrMessage + "\n").toUtf8());
    }

    ui->leClntMessage->selectAll();

    ui->leClntMessage->setFocus();
}
