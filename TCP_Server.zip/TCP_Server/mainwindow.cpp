#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    m_pServer = new CServer(this);

    m_pClient = new CClient;
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::addMessage(QString in_qstrMessage)
{
    ui->teChat->append(QString("%1\n").arg(in_qstrMessage));
}

void MainWindow::on_pbStart_clicked()
{
    bool bOk = m_pServer->listen(QHostAddress::Any, quint16(ui->sbSrvrPort->value()));

    bOk ? addMessage("Server running...") : addMessage("Server connection failed...");
}

void MainWindow::on_pbClient_clicked()
{
    m_pClient->show();
}
