#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QMessageBox>
#include <QAbstractSocket>

#include "server.h"
#include "client.h"

class CServer;

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    CServer *m_pServer;
    CClient *m_pClient;

    void addMessage(QString in_qstrMessage);

private slots:
    void on_pbStart_clicked();

    void on_pbClient_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
