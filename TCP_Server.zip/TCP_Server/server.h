#ifndef CSERVER_H
#define CSERVER_H

#include <QTcpServer>
#include <QTcpSocket>

#include "mainwindow.h"
class MainWindow;

class CServer : public QTcpServer
{
    Q_OBJECT

public:
    CServer(MainWindow *in_pMainwindow, QObject *in_pParent = 0);
    ~CServer();

    MainWindow *m_pMainwindows;

    void incomingConnection(int in_iSocketID);


public slots:
    void slot_readyRead();
    void slot_disconnected();

};

#endif // CSERVER_H
