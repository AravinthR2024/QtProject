#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QTcpSocket>

namespace Ui {
class Dialog;
}

class CClient : public QDialog
{
    Q_OBJECT

public:
    explicit CClient(QWidget *parent = 0);
    ~CClient();
     QTcpSocket *m_pClientSocket;

private slots:
    void slot_displayError (QAbstractSocket::SocketError in_socketError);

private slots:

    void on_pbConnect_clicked();

    void on_pbSend_clicked();

private:
    Ui::Dialog *ui;
};

#endif // DIALOG_H
