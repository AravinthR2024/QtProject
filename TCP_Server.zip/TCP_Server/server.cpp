#include "server.h"

CServer::CServer(MainWindow *in_pMainwindow, QObject *in_pParent) : QTcpServer(in_pParent)
{
    m_pMainwindows = in_pMainwindow;
}

CServer::~CServer()
{

}

void CServer::incomingConnection(int in_iSocketID)
{
    QTcpSocket *pClient = new QTcpSocket(this);
    pClient->setSocketDescriptor(in_iSocketID);

    m_pMainwindows->addMessage("Client connected : " + pClient->peerAddress().toString());

    connect(pClient, SIGNAL(readyRead()), this, SLOT(slot_readyRead()));
    connect(pClient, SIGNAL(disconnected()), this, SLOT(slot_disconnected()));
}

void CServer::slot_readyRead()
{
    QTcpSocket *pClient = (QTcpSocket *) sender();

    while (pClient->canReadLine())
    {
        QString qstrLine = QString(pClient->readLine().toStdString().c_str());
        m_pMainwindows->addMessage(qstrLine);
    }
}

void CServer::slot_disconnected()
{
    QTcpSocket *pClient = (QTcpSocket *) sender();

    m_pMainwindows->addMessage("Client Disconnected : " + pClient->peerAddress().toString());
}

